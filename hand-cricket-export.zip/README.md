# Hand Cricket — Portable Standalone & KhelGhor Integration Package

A complete, production-ready **Hand Cricket** game built with **React 19, TypeScript, Tailwind CSS v4, Motion (`motion/react`), Lucide React, and Express (SSE real-time multiplayer + persistent Career/Leaderboard engine)**.

---

## 1. Quick Start (Run Independently)

### Prerequisites
- **Node.js** `>= 18.x` (Node 20+ recommended)
- **npm** `>= 9.x` (or `bun` / `pnpm`)

### Installation & Development
```bash
# 1. Install dependencies
npm install

# 2. Copy safe environment variables template
cp .env.example .env

# 3. Start full-stack development server (Express API + Vite on port 3000)
npm run dev
```
Open `http://localhost:3000` in your browser.

### Production Build & Execution
```bash
# 1. Compile TypeScript check
npm run lint

# 2. Build production frontend bundle into dist/
npm run build

# 3. Start production Express server serving dist/ and /api/handcricket/*
NODE_ENV=production PORT=3000 npm start
```

### Run Automated Engine & Wicket Logic Tests
```bash
npx tsx test/hand-cricket.test.ts
```

---

## 2. Complete Hand Cricket File Structure

```text
├── .env.example                                     # Safe environment variable template
├── package.json                                     # Dependencies and scripts
├── tsconfig.json                                    # TypeScript configuration
├── vite.config.ts                                   # Vite + React + Tailwind v4 configuration
├── index.html                                       # Entry HTML (Google Fonts + PWA manifest)
├── server.ts                                        # Express server & /api/handcricket/* routes
├── handcricket-data.json                            # Persistent JSON store for Career & Leaderboard (auto-created)
├── game-stats.json                                  # Persistent JSON store for play counts (auto-created)
├── test/
│   └── hand-cricket.test.ts                         # Automated unit & integration tests
└── src/
    ├── main.tsx                                     # React DOM entry point
    ├── App.tsx                                      # Platform host router mounting <HandCricketApp />
    ├── index.css                                    # Tailwind CSS v4 import & animations
    ├── types/
    │   ├── handCricket.ts                           # All Hand Cricket TypeScript interfaces & types
    │   └── game.ts                                  # Shared KhelGhor platform types
    ├── engine/
    │   ├── handCricketEngine.ts                     # Core rules, 1A-6C wicket logic, overs, Test match, results
    │   └── handCricketAI.ts                         # Easy / Medium / Hard AI strategy & toss logic
    ├── server/
    │   ├── handCricketManager.ts                    # Authoritative room manager, SSE pub/sub, career XP & leaderboard
    │   └── gameStatsManager.ts                      # Global game play & unique player counter
    ├── utils/
    │   └── sound.ts                                 # 100% offline Web Audio API sound synthesizer
    └── handcricket/
        ├── data/
        │   └── gestureRegistry.ts                   # 18 hand gestures (1A–6C) catalog & ID validators
        ├── utils/
        │   └── guestIdentity.ts                     # Persistent cryptographic guest playerId generator
        └── components/
            ├── HandCricketApp.tsx                   # Standalone root component & API/SSE controller
            ├── HandCricketHomeAndSetup.tsx          # Home menu, profile summary, AI & Multiplayer setup
            ├── HandCricketWaitingRoom.tsx           # Multiplayer room lobby, room code copy/share, ready toggle
            ├── HandCricketTossScreen.tsx            # Vertical 3D coin flip, call & bat/bowl decision
            ├── HandCricketGameplayScreen.tsx        # Live pitch animation, dual hand stages, 18-gesture deck
            ├── HandCricketResultScreen.tsx          # Post-match result, innings summary, XP rewards & rematch
            ├── CareerDashboardModal.tsx             # Career stats, records, achievements, history & leaderboard
            ├── HandCricketRulesModal.tsx            # Rules & 18 hand gesture variations reference modal
            └── HandGestureIllustration.tsx          # Custom vector SVG hand gesture renderer (1A–6C + pumping fist)
```

---

## 3. Integrating into Another Existing KhelGhor React App

### Step 1: Copy Source Directories
Copy the following files into your target KhelGhor project:
- `src/types/handCricket.ts`
- `src/engine/handCricketEngine.ts`
- `src/engine/handCricketAI.ts`
- `src/handcricket/**` (all files in `components/`, `data/`, `utils/`)
- `src/utils/sound.ts` (if not already present in KhelGhor)
- `src/server/handCricketManager.ts`
- `src/server/gameStatsManager.ts` (if not already present in KhelGhor)

### Step 2: Ensure Frontend Dependencies are Installed
```bash
npm install lucide-react motion
```

### Step 3: Mount Backend Routes in Express (`server.ts`)
Mount the `/api/handcricket/*` endpoints in your Express server:
- `GET /api/handcricket/career/:playerId`
- `POST /api/handcricket/career/:playerId/profile`
- `GET /api/handcricket/leaderboard`
- `POST /api/handcricket/rooms`
- `POST /api/handcricket/rooms/:roomId/join`
- `POST /api/handcricket/rooms/:roomId/leave`
- `POST /api/handcricket/rooms/:roomId/ready`
- `POST /api/handcricket/rooms/:roomId/config`
- `POST /api/handcricket/rooms/:roomId/start`
- `POST /api/handcricket/rooms/:roomId/toss-call`
- `POST /api/handcricket/rooms/:roomId/toss-decision`
- `POST /api/handcricket/rooms/:roomId/ball`
- `POST /api/handcricket/rooms/:roomId/advance`
- `POST /api/handcricket/rooms/:roomId/rematch`
- `GET /api/handcricket/rooms/:roomId/state`
- `GET /api/handcricket/rooms/:roomId/events` (Server-Sent Events stream)

### Step 4: Render `<HandCricketApp />` in Your Router or App View
```tsx
import { HandCricketApp } from './handcricket/components/HandCricketApp';

// Inside your view switch or React Router route:
<HandCricketApp onBackToKhelghor={() => navigate('/')} />
```
