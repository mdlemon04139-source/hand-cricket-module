import { BorderPassEngine } from '../src/engine/borderpassEngine';
import { BORDER_PASS_CARDS } from '../src/data/borderpassAssets';
import { BorderPassPlayer, BorderPassPlayerPrivate, CardInstance } from '../src/types/borderpass';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ FAILED: ${message}`);
    process.exit(1);
  }
}

console.log('🧪 Starting Border Pass Automated Rules Verification...\n');

// 1. Deck Tests
console.log('--- 1. Canonical Deck Tests ---');
const deck = BorderPassEngine.createCanonicalDeck();
assert(deck.length === 81, `Canonical deck must have 81 cards, got ${deck.length}`);

const idSet = new Set<string>();
for (const card of deck) {
  assert(!idSet.has(card.instanceId), `Duplicate instance ID found: ${card.instanceId}`);
  idSet.add(card.instanceId);
}
assert(idSet.size === 81, 'All 81 instance IDs must be unique');

// Count verification
const counts: Record<string, number> = {};
for (const card of deck) {
  counts[card.typeId] = (counts[card.typeId] || 0) + 1;
}
assert(counts['branded_watch'] === 12, 'Branded watch count must be 12');
assert(counts['duty_free_chocolates'] === 16, 'Chocolates count must be 16');
assert(counts['designer_perfume'] === 10, 'Perfume count must be 10');
assert(counts['silk_apparel'] === 10, 'Silk apparel count must be 10');
assert(counts['raw_diamonds'] === 6, 'Raw diamonds count must be 6');
assert(counts['historic_relic'] === 6, 'Historic relic count must be 6');
assert(counts['classified_drive'] === 8, 'Classified drive count must be 8');
assert(counts['gold_bullion'] === 6, 'Gold bullion count must be 6');
assert(counts['diplomatic_immunity'] === 3, 'Diplomatic immunity count must be 3');
assert(counts['customs_clearance_seal'] === 4, 'Customs clearance seal count must be 4');
console.log('✅ Canonical deck composition verified (48 Duty-Free + 26 Contraband + 7 Power = 81 cards).');

// Shuffling
const shuffled = BorderPassEngine.shuffleDeck(deck);
assert(shuffled.length === 81, 'Shuffled deck size must remain 81');
const shuffledSet = new Set(shuffled.map((c) => c.instanceId));
assert(shuffledSet.size === 81, 'Shuffled deck has all unique instances');
console.log('✅ Shuffling preserves deck size and instance uniqueness.');

// 2. Round Tests & Officer Rotation
console.log('\n--- 2. Round & Officer Rotation Tests ---');
assert(BorderPassEngine.calculateTotalRounds(3) === 6, '3 players = 6 rounds');
assert(BorderPassEngine.calculateTotalRounds(4) === 8, '4 players = 8 rounds');
assert(BorderPassEngine.calculateTotalRounds(5) === 10, '5 players = 10 rounds');
assert(BorderPassEngine.calculateTotalRounds(6) === 12, '6 players = 12 rounds');

const mockPlayers: BorderPassPlayer[] = [
  BorderPassEngine.initializePlayer('p1', 'Player 1', '👮', 0),
  BorderPassEngine.initializePlayer('p2', 'Player 2', '🕵️', 1),
  BorderPassEngine.initializePlayer('p3', 'Player 3', '🧑‍✈️', 2),
  BorderPassEngine.initializePlayer('p4', 'Player 4', '🧑‍💼', 3),
];
const totalRounds = BorderPassEngine.calculateTotalRounds(mockPlayers.length);
const officerCounts: Record<string, number> = {};
for (let r = 1; r <= totalRounds; r++) {
  const off = BorderPassEngine.getOfficerForRound(mockPlayers, r);
  officerCounts[off.id] = (officerCounts[off.id] || 0) + 1;
}
for (const p of mockPlayers) {
  assert(officerCounts[p.id] === 2, `Every player must be officer exactly 2 times, ${p.id} got ${officerCounts[p.id]}`);
}
console.log('✅ 4 players = 8 rounds, every player is Officer exactly 2 times clockwise.');

// 3. Dealing & Replenishment Tests
console.log('\n--- 3. Dealing & Replenishment Tests ---');
const privateStore = new Map<string, BorderPassPlayerPrivate>();
const dealResult = BorderPassEngine.dealInitialHands(mockPlayers, privateStore, shuffled);
for (const p of mockPlayers) {
  assert(p.cash === 500, 'Initial cash must be $500');
  assert(p.handCount === 5, 'Initial hand must have 5 cards');
  const priv = privateStore.get(p.id)!;
  assert(priv.hand.length === 5, 'Private hand must have 5 cards');
}
assert(dealResult.drawDeck.length === 81 - 20, 'Remaining deck should have 61 cards');

// Hand replenishment test
const p1Priv = privateStore.get('p1')!;
p1Priv.hand.splice(0, 3); // Player 1 played 3 cards, 2 left
mockPlayers[0].handCount = 2;
const replenResult = BorderPassEngine.replenishHands(mockPlayers, privateStore, dealResult.drawDeck, []);
assert(p1Priv.hand.length === 5, `Hand should be replenished back to 5 cards, got ${p1Priv.hand.length}`);
console.log('✅ Initial dealing & replenishment to 5 cards verified.');

// 4. Financial & Fine Settlement Tests
console.log('\n--- 4. Financial & Fine Settlement Tests ---');
// Scenario: $300 fine with $100 cash and $500 vault value
const pTest = BorderPassEngine.initializePlayer('pt', 'Test Passenger', '🎒', 0);
pTest.cash = 100;
pTest.vault = [
  { instanceId: 'v1', typeId: 'raw_diamonds', baseValue: 500, effectiveValue: 500, sealBonusApplied: false, roundSecured: 1 },
];
BorderPassEngine.updatePlayerNetWorth(pTest);
assert(pTest.netWorth === 600, 'Initial net worth must be 100 + 500 = 600');

const pTestPriv: BorderPassPlayerPrivate = {
  hand: [],
  suitcase: {
    cards: [{ instanceId: 'c1', typeId: 'raw_diamonds' }], // $300 fine
    declaration: { declaredItem: 'branded_watch', declaredQuantity: 1, bribeOffer: 0 },
    submittedAt: Date.now(),
  },
};
const officer = BorderPassEngine.initializePlayer('off', 'Officer', '👮', 1);
officer.cash = 500;

const inspectRes = BorderPassEngine.resolveInspectionAction(officer, pTest, pTestPriv, 1, []);
assert(inspectRes.result.isHonest === false, 'Contraband must be detected as dishonest');
assert(inspectRes.result.totalFineCalculated === 300, 'Raw diamonds fine must be $300');
assert(pTest.cash === 0, 'Cash should be reduced from 100 to 0');
assert(pTest.vaultScoreAdjustment === 200, 'Vault deficit must be 200');
assert(pTest.effectiveVaultValue === 300, `Effective vault value must be 500 - 200 = 300, got ${pTest.effectiveVaultValue}`);
assert(pTest.netWorth === 300, `Net worth must be 0 + 300 = 300, got ${pTest.netWorth}`);
console.log('✅ $300 fine with $100 cash and $500 vault properly settled: $0 cash, $300 vault, $300 net worth.');

// 5. Honest Passenger Inspection & Compensation Test
console.log('\n--- 5. Honest Inspection & Compensation Tests ---');
const honestPassenger = BorderPassEngine.initializePlayer('hp', 'Honest', '😇', 0);
honestPassenger.cash = 200;
const hpPriv: BorderPassPlayerPrivate = {
  hand: [],
  suitcase: {
    cards: [
      { instanceId: 'w1', typeId: 'branded_watch' },
      { instanceId: 'w2', typeId: 'branded_watch' },
    ],
    declaration: { declaredItem: 'branded_watch', declaredQuantity: 2, bribeOffer: 20 },
    submittedAt: Date.now(),
  },
};
officer.cash = 100; // Officer only has $100
const honestRes = BorderPassEngine.resolveInspectionAction(officer, honestPassenger, hpPriv, 1, []);
assert(honestRes.result.isHonest === true, 'Honest passenger correctly identified');
assert(honestRes.result.compensationPaid === 100, 'Compensation capped at officer available cash ($100)');
assert(officer.cash === 0, 'Officer cash must not drop below 0');
assert(honestPassenger.cash === 300, 'Honest passenger received $100 compensation');
assert(honestPassenger.vault.length === 2, '2 watches entered vault');
console.log('✅ Honest inspection pays compensation capped at officer cash without negative balances.');

// 6. Diplomatic Immunity Pass Test
console.log('\n--- 6. Diplomatic Immunity Pass Tests ---');
const smugglerWithImmunity = BorderPassEngine.initializePlayer('swi', 'Diplomat', '🕶️', 0);
smugglerWithImmunity.cash = 400;
const dipPriv: BorderPassPlayerPrivate = {
  hand: [],
  suitcase: {
    cards: [
      { instanceId: 'd1', typeId: 'raw_diamonds' },
      { instanceId: 'dip1', typeId: 'diplomatic_immunity' },
    ],
    declaration: { declaredItem: 'silk_apparel', declaredQuantity: 2, bribeOffer: 0 },
    submittedAt: Date.now(),
  },
};
officer.cash = 500;
let discardPile: CardInstance[] = [];
const dipRes = BorderPassEngine.resolveInspectionAction(officer, smugglerWithImmunity, dipPriv, 1, discardPile);
assert(dipRes.result.isHonest === false, 'Declared silk but had diamonds');
assert(dipRes.result.hasDiplomaticImmunity === true, 'Diplomatic immunity detected');
assert(dipRes.result.confiscatedCards.length === 0, 'No cards should be confiscated with immunity');
assert(smugglerWithImmunity.vault.length === 1, 'Diamonds safely entered vault');
assert(smugglerWithImmunity.vault[0].typeId === 'raw_diamonds', 'Diamonds in vault');
assert(dipRes.discardPile.some((c) => c.typeId === 'diplomatic_immunity'), 'Diplomatic immunity consumed to discard pile');
assert(smugglerWithImmunity.cash === 400, 'No fines charged with immunity');
console.log('✅ Diplomatic Immunity Pass protected entire suitcase, no fines, 0 confiscations, immunity pass discarded.');

// 7. Customs Clearance Seal (+50% bonus) Test
console.log('\n--- 7. Customs Clearance Seal (+50% bonus) Tests ---');
const sealPassenger = BorderPassEngine.initializePlayer('sp', 'Seal User', '📦', 0);
sealPassenger.cash = 300;
const sealPriv: BorderPassPlayerPrivate = {
  hand: [],
  suitcase: {
    cards: [
      { instanceId: 'w1', typeId: 'branded_watch' }, // $100 base
      { instanceId: 'seal1', typeId: 'customs_clearance_seal' },
    ],
    declaration: { declaredItem: 'branded_watch', declaredQuantity: 2, bribeOffer: 30 },
    submittedAt: Date.now(),
  },
};
const passRes = BorderPassEngine.resolvePassAction(officer, sealPassenger, sealPriv, true, 1, []);
assert(sealPassenger.vault.length === 1, 'Watch placed into vault');
assert(sealPassenger.vault[0].effectiveValue === 150, `Watch base $100 boosted by 50% to $150, got ${sealPassenger.vault[0].effectiveValue}`);
assert(sealPassenger.vault[0].sealBonusApplied === true, 'Seal bonus applied flag set');
assert(passRes.discardPile.some((c) => c.typeId === 'customs_clearance_seal'), 'Seal card moved to discard');
console.log('✅ Customs Clearance Seal properly granted +50% value boost to duty-free goods and was discarded.');

// 8. Reshuffle Draw Deck Test
console.log('\n--- 8. Reshuffle Deck Exhaustion Tests ---');
const emptyDeck: CardInstance[] = [];
const testDiscard: CardInstance[] = [
  { instanceId: 'res1', typeId: 'silk_apparel' },
  { instanceId: 'res2', typeId: 'branded_watch' },
];
const reshuffPlayer = BorderPassEngine.initializePlayer('rp', 'Draw Tester', '🎲', 0);
const rPrivStore = new Map<string, BorderPassPlayerPrivate>();
rPrivStore.set('rp', { hand: [], suitcase: undefined });
const reshuffOutcome = BorderPassEngine.replenishHands([reshuffPlayer], rPrivStore, emptyDeck, testDiscard);
assert(rPrivStore.get('rp')!.hand.length === 2, 'Drew all 2 cards from recycled discard pile');
assert(reshuffOutcome.discardPile.length === 0, 'Discard pile emptied after reshuffle');
console.log('✅ Empty draw deck automatically reshuffles discard pile without losing card instances.');

// 9. Officer Suitcase Prohibition Test
console.log('\n--- 9. Officer Suitcase Prohibition Tests ---');
const testOfficer = BorderPassEngine.initializePlayer('off1', 'Officer Jane', '👮', 0);
testOfficer.role = 'officer';
const testOfficerPriv: BorderPassPlayerPrivate = {
  hand: [{ instanceId: 'w1', typeId: 'branded_watch' }],
  suitcase: undefined,
};
const packAttempt = BorderPassEngine.packSuitcase(
  testOfficer,
  testOfficerPriv,
  ['w1'],
  { declaredItem: 'branded_watch', declaredQuantity: 1, bribeOffer: 0 }
);
assert(packAttempt.success === false, 'Officer must be prohibited from packing a suitcase');
assert(testOfficerPriv.suitcase === undefined, 'Officer private suitcase must remain undefined');
console.log('✅ Customs Officer is strictly blocked from packing a suitcase.');

// 10. Multi-Player Strict Role Rotation & Seat Order Tests (3, 4, 5, 6 players)
console.log('\n--- 10. Multi-Player Strict Role Rotation Tests (3, 4, 5, 6 players) ---');
for (const playerCount of [3, 4, 5, 6]) {
  const players: BorderPassPlayer[] = Array.from({ length: playerCount }, (_, i) =>
    BorderPassEngine.initializePlayer(`p_${playerCount}_${i}`, `Player ${i}`, '👤', i)
  );
  const totalRounds = BorderPassEngine.calculateTotalRounds(playerCount);
  assert(totalRounds === playerCount * 2, `Total rounds must be ${playerCount * 2} for ${playerCount} players`);

  const officerRoundsPerPlayer: Record<string, number> = {};
  for (let r = 1; r <= totalRounds; r++) {
    const officer = BorderPassEngine.getOfficerForRound(players, r);
    const expectedOfficerSeat = (r - 1) % playerCount;
    assert(
      officer.seatNumber === expectedOfficerSeat,
      `Round ${r} officer should be seat ${expectedOfficerSeat}, got seat ${officer.seatNumber}`
    );
    officerRoundsPerPlayer[officer.id] = (officerRoundsPerPlayer[officer.id] || 0) + 1;
  }

  for (const p of players) {
    assert(
      officerRoundsPerPlayer[p.id] === 2,
      `Player ${p.id} must be officer exactly 2 times, got ${officerRoundsPerPlayer[p.id]}`
    );
  }
}
console.log('✅ Deterministic clockwise rotation verified for 3, 4, 5, and 6 players: every player serves as Officer exactly 2 times.');

// 11. Negotiation 30s Countdown & Expiration Rules Test
console.log('\n--- 11. Negotiation 30-Second Timeout Rule Tests ---');
const now = Date.now();
const negotiationTimeoutMs = 30000;
const testNegotiation = {
  id: 'neg_test',
  passengerId: 'p2',
  officerId: 'p1',
  demandedBribe: 150,
  currentOffer: 50,
  startedAt: now,
  expiresAt: now + negotiationTimeoutMs,
  isSettled: false,
};
assert(testNegotiation.expiresAt - testNegotiation.startedAt === 30000, 'Negotiation duration must be exactly 30 seconds (30000 ms)');
assert(testNegotiation.isSettled === false, 'Negotiation initial settled flag must be false');
console.log('✅ Negotiation timing contract verified: 30-second server countdown with explicit settlement flag.');

console.log('\n🎉 ALL 11 TEST SUITES COMPLETED AND PASSED PERFECTLY!\n');

