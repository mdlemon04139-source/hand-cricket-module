import { shadowDetectiveRoomManager } from '../src/server/shadowDetectiveRoomManager';
import { CASE_QUESTIONS_CATALOG } from '../src/shadowdetective/engine/caseGenerator';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ Test failed: ${message}`);
    process.exit(1);
  }
}

console.log('🧪 Starting Nishipur Shadow Detective Automated Engine Verification...');

// 1. Room Creation
const created = shadowDetectiveRoomManager.createRoom('রবিন', '🕵️‍♂️', 'human_ai_multiplayer', 5);
assert(Boolean(created.roomId), 'Room ID should be generated');
assert(Boolean(created.roomCode), 'Room code should be generated');
assert(Boolean(created.playerId), 'Host player ID should be generated');
console.log('✅ Room creation verified (5 players Nishipur case)');

// 2. Joining & Adding Bots
const room = shadowDetectiveRoomManager.getRoom(created.roomId);
assert(Boolean(room), 'Room should exist');
assert(room!.players.length === 1, 'Room should have 1 player initially');

shadowDetectiveRoomManager.addBot(created.roomId);
shadowDetectiveRoomManager.addBot(created.roomId);
shadowDetectiveRoomManager.addBot(created.roomId);
shadowDetectiveRoomManager.addBot(created.roomId);
assert(room!.players.length === 5, 'Room should now have 5 players');
console.log('✅ Bot additions up to 5 seats verified');

// 3. Start Game
const startRes = shadowDetectiveRoomManager.startGame(created.roomId, created.playerId);
assert(startRes.success, 'Game should start successfully');
assert(room!.phase === 'STORY_INTRO', 'Game phase should transition to STORY_INTRO');

const robin = room!.players.find((p) => p.assignedRole === 'robin');
assert(Boolean(robin), 'Robin role must be assigned to host');

const suspects = room!.players.filter((p) => p.assignedRole === 'suspect');
assert(suspects.length === 4, '4 suspects must be assigned for 5-player mode');
suspects.forEach((s) => {
  assert(Boolean(s.characterId), 'Each suspect bot/player must have a character assigned');
});
console.log('✅ Role & Character distribution verified');

// 4. Information Isolation
const robinState = shadowDetectiveRoomManager.getClientState(created.roomId, created.playerId);
assert(robinState !== null, 'Robin state should exist');
assert(robinState!.myPrivateBriefing === undefined, 'Robin should not receive suspect private briefing');

const suspectPlayer = suspects[0];
const suspectState = shadowDetectiveRoomManager.getClientState(created.roomId, suspectPlayer.id);
assert(Boolean(suspectState!.myPrivateBriefing), 'Suspect should receive private narrative briefing');
console.log('✅ Information isolation verified');

// 5. Phase Transitions: Story Intro -> Role Briefing -> Phase 1
shadowDetectiveRoomManager.advanceFromStoryIntro(created.roomId);
assert(room!.phase === 'ROLE_BRIEFING', 'Phase should transition to ROLE_BRIEFING');

shadowDetectiveRoomManager.advanceFromRoleBriefing(created.roomId);
assert(room!.phase === 'PHASE_1_INTERROGATION', 'Phase should transition to PHASE_1_INTERROGATION');
assert(room!.questionsRemainingInPhase === 5, 'Phase 1 should allow 5 questions');
console.log('✅ Story to Interrogation phase transition verified');

// 6. Interrogation Cycle
const targetSuspect = room!.activeSuspectIds[0];
const q = CASE_QUESTIONS_CATALOG[0];
const askRes = shadowDetectiveRoomManager.askQuestion(created.roomId, created.playerId, targetSuspect, q.id);
assert(askRes.success, 'Robin should successfully ask a question');
assert(room!.activeInterrogation !== undefined, 'Interrogation should become active');

// Submit Answer
const ansRes = shadowDetectiveRoomManager.submitAnswer(
  created.roomId,
  targetSuspect,
  'আমি ঘটনার রাতে ঘরেই ছিলাম এবং বই পড়ছিলাম।'
);
assert(ansRes.success, 'Suspect answer should be recorded');
assert(room!.evidenceNotebook.verifiedStatements.length === 1, 'Statement should be appended to notebook');
assert(room!.questionsRemainingInPhase === 4, 'Questions remaining should decrement');
console.log('✅ Interrogation question and verified statement recording verified');

// 7. Mandatory Release Rule Verification: Releasing Culprit Triggers Immediate Defeat!
const culpritId = room!.caseTruth.culpritCharacterId;
// Move directly to release phase for test
room!.phase = 'PHASE_1_RELEASE';
const releaseCulpritRes = shadowDetectiveRoomManager.releaseSuspect(created.roomId, created.playerId, culpritId);
assert(releaseCulpritRes.success, 'Release function should execute');
assert((room!.phase as string) === 'CASE_RESOLVED', 'Releasing culprit must resolve case immediately');
assert(room!.finalVerdictResult?.isVictory === false, 'Releasing culprit must result in defeat');
console.log('✅ Mandatory release rule verified: Releasing culprit triggers immediate defeat');

// 8. Final Verdict Showdown Verification
const newCreated = shadowDetectiveRoomManager.createRoom('রবিন ২', '🕵️‍♂️', 'ai_solo', 5);
const newRoom = shadowDetectiveRoomManager.getRoom(newCreated.roomId)!;
newRoom.phase = 'FINAL_VERDICT';
const finalCulprit = newRoom.caseTruth.culpritCharacterId;
const innocentId = newRoom.activeSuspectIds.find((id) => id !== finalCulprit) || 'gafur_matbor';
newRoom.finalTwoSuspectIds = [finalCulprit, innocentId];

const verdictRes = shadowDetectiveRoomManager.submitFinalVerdict(
  newCreated.roomId,
  newCreated.playerId,
  finalCulprit,
  innocentId
);
assert(verdictRes.success, 'Final verdict submission should succeed');
assert((newRoom.phase as string) === 'CASE_RESOLVED', 'Case should be resolved');
assert(newRoom.finalVerdictResult?.isVictory === true, 'Correct accusation must result in Victory');
console.log('✅ Final verdict showdown verified: Identifying true culprit results in Victory');

console.log('🎉 ALL NISHIPUR SHADOW DETECTIVE TESTS PASSED!');
process.exit(0);
