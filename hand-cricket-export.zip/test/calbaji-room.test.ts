import { calbajiRoomManager } from '../src/server/calbajiRoomManager';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ FAILED: ${message}`);
    process.exit(1);
  }
}

console.log('🧪 Starting Calbaji Multiplayer Room Manager Verification...\n');

// 1. Room Creation
console.log('--- 1. Calbaji Room Creation ---');
const room = calbajiRoomManager.createRoom('হোস্ট প্লেয়ার', '👑');
assert(Boolean(room.roomId), 'Room ID must be generated');
assert(room.code.startsWith('CAL-'), `Room code must start with CAL-, got ${room.code}`);
assert(Boolean(room.playerId), 'Host player ID must be generated');

const state = calbajiRoomManager.getClientState(room.roomId, room.playerId);
assert(state !== null, 'Room state must exist');
assert(state!.phase === 'LOBBY', 'Initial phase must be LOBBY');
assert(state!.players.length === 1, 'Initial player count must be 1');
assert(state!.players[0].isHost === true, 'Creator must be host');
console.log(`✅ Calbaji room created successfully with code: ${room.code}`);

// 2. Room Joining
console.log('\n--- 2. Calbaji Room Joining ---');
const joinRes = calbajiRoomManager.joinRoom(room.code, 'প্লেয়ার ২', '⚔️');
assert(joinRes.success === true, 'Player 2 must join successfully');
assert(Boolean(joinRes.playerId), 'Player 2 ID must exist');

const stateAfterJoin = calbajiRoomManager.getClientState(room.roomId, room.playerId);
assert(stateAfterJoin!.players.length === 2, 'Player count must be 2');
assert(stateAfterJoin!.players[1].name === 'প্লেয়ার ২', 'Player 2 name must match');
console.log('✅ Player 2 joined using room code.');

// 3. Adding Bots
console.log('\n--- 3. Adding Bot ---');
const addBotRes = calbajiRoomManager.addBot(room.roomId, 'strategic');
assert(addBotRes.success === true, 'Bot must be added successfully');

const stateAfterBot = calbajiRoomManager.getClientState(room.roomId, room.playerId);
assert(stateAfterBot!.players.length === 3, 'Player count must be 3');
assert(stateAfterBot!.players[2].isBot === true, 'Player 3 must be a bot');
console.log('✅ AI Bot added to lobby slots.');

// 4. Starting Match
console.log('\n--- 4. Starting Match ---');
const startRes = calbajiRoomManager.startGame(room.roomId, room.playerId);
assert(startRes.success === true, 'Host must be able to start the game');

const stateInGame = calbajiRoomManager.getClientState(room.roomId, room.playerId);
assert(stateInGame!.phase === 'MATCH_STARTING', 'Phase must transition to MATCH_STARTING');
assert(stateInGame!.myCards.length === 2, 'Host must receive exactly 2 private cards');
assert(stateInGame!.players[0].coins === 2, 'Starting coins must be 2');
assert(stateInGame!.drawDeckCount === 15 - 6, 'Remaining deck should have 9 cards');
console.log('✅ Match started with 15 canonical cards dealt and synchronized.');

// 5. Action Processing: Income
console.log('\n--- 5. Action Processing: Income ---');
const incomeRes = calbajiRoomManager.declareAction(room.roomId, room.playerId, 'income');
assert(incomeRes.success === true, 'Host must be able to take Income');

const stateAfterIncome = calbajiRoomManager.getClientState(room.roomId, room.playerId);
assert(stateAfterIncome!.players[0].coins === 3, 'Coins must increase from 2 to 3');
assert(stateAfterIncome!.currentTurnPlayerId !== room.playerId, 'Turn must advance to next player');
console.log('✅ Income action correctly increased coins and advanced clockwise turn.');

console.log('\n🎉 ALL CALBAJI MULTIPLAYER ROOM TESTS PASSED!\n');
process.exit(0);
