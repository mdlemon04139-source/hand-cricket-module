import fs from 'fs';
import path from 'path';
import {
  VERIFIED_CHARACTER_REGISTRY,
  ORDERED_CHARACTER_IDS,
  ALL_VERIFIED_CHARACTERS,
  getCharacterRecord,
} from '../src/shadowdetective/data/characterRegistry';
import { NISHIPUR_CHARACTERS } from '../src/data/nishipurCharacters';
import { NishipurCaseGenerator } from '../src/shadowdetective/engine/caseGenerator';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ Assertion Failed: ${message}`);
    process.exit(1);
  }
}

console.log('--- TEST: SHADOW DETECTIVE 15 CHARACTER REGISTRY & VISUAL ASSET VALIDATION ---');

// 1. Verify all 15 required character IDs exist
const REQUIRED_CHARACTER_IDS = [
  'robin',
  'tuha',
  'gafur_matbor',
  'kalu_chor',
  'matin_mia',
  'mostafa_sir',
  'rehana_apa',
  'bablu',
  'rakib_chacha',
  'kader_ali',
  'farzana_begum',
  'tanvir',
  'mitu',
  'sohel_mondol',
  'abdul_hakim',
] as const;

assert(ORDERED_CHARACTER_IDS.length === 15, `Expected 15 character IDs, got ${ORDERED_CHARACTER_IDS.length}`);
assert(ALL_VERIFIED_CHARACTERS.length === 15, `Expected 15 verified characters, got ${ALL_VERIFIED_CHARACTERS.length}`);

for (const id of REQUIRED_CHARACTER_IDS) {
  assert(ORDERED_CHARACTER_IDS.includes(id), `Missing required character ID in ORDERED_CHARACTER_IDS: ${id}`);
  assert(id in VERIFIED_CHARACTER_REGISTRY, `Missing required character in VERIFIED_CHARACTER_REGISTRY: ${id}`);
}
console.log('✅ 1. All 15 required character IDs exist.');

// 2. Verify all records have required fields
for (const id of REQUIRED_CHARACTER_IDS) {
  const char = VERIFIED_CHARACTER_REGISTRY[id];
  assert(char.characterId === id, `Character ${id} has wrong characterId: ${char.characterId}`);
  assert(Boolean(char.bengaliName && char.bengaliName.trim()), `Character ${id} missing bengaliName`);
  assert(Boolean(char.englishName && char.englishName.trim()), `Character ${id} missing englishName`);
  assert(Boolean(char.imagePath && char.imagePath.trim()), `Character ${id} missing imagePath`);
  assert(Boolean(char.occupation && char.occupation.trim()), `Character ${id} missing occupation`);
  assert(Boolean(char.characterDescription && char.characterDescription.trim()), `Character ${id} missing characterDescription`);
}
console.log('✅ 2. Every record contains characterId, bengaliName, englishName, imagePath, occupation, characterDescription.');

// 3. Verify every character has a valid, existing image file on disk
const usedImages = new Set<string>();
for (const id of REQUIRED_CHARACTER_IDS) {
  const char = VERIFIED_CHARACTER_REGISTRY[id];
  const relativeImagePath = char.imagePath.startsWith('/') ? char.imagePath.slice(1) : char.imagePath;
  const fullPath = path.resolve(process.cwd(), 'public', relativeImagePath);

  assert(
    fs.existsSync(fullPath),
    `Image file missing on disk for character ${id}: expected at ${fullPath}`
  );

  const stats = fs.statSync(fullPath);
  assert(stats.isFile() && stats.size > 10000, `Image file invalid/empty for ${id}: ${fullPath}`);

  // 4. Ensure no duplicate image mapping between different characters
  assert(!usedImages.has(char.imagePath), `Duplicate image reference detected: ${char.imagePath} used more than once!`);
  usedImages.add(char.imagePath);
}
console.log('✅ 3 & 4. All 15 character images exist on disk and have strictly unique 1-to-1 mappings.');

// 5. Verify exact canonical character visual identities
assert(
  VERIFIED_CHARACTER_REGISTRY['robin'].imagePath.includes('Investigator_Robin_Bengali_Character_Card'),
  'Robin must point to Robin investigator card'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['tuha'].imagePath.includes('Tuha__the_Field_Assistant'),
  'Tuha must point to Tuha field assistant card'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['bablu'].imagePath.includes('Bengali_Detective_Character_Card_a90b3dcc'),
  'Bablu must point to Bengali_Detective_Character_Card_a90b3dcc (Bablu card)'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['kalu_chor'].imagePath.includes('2065dfc2'),
  'Kalu Chor must point to 2065dfc2 (Kalu Chor card)'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['matin_mia'].imagePath.includes('5a641189'),
  'Matin Mia must point to 5a641189 (Matin Mia card)'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['sohel_mondol'].imagePath.includes('f53c4e27'),
  'Sohel Mondol must point to f53c4e27 (Sohel Mondol electrician card)'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['abdul_hakim'].imagePath.includes('Wise_Teacher_Portrait_Card_04db49fe'),
  'Abdul Hakim must point to Wise_Teacher_Portrait_Card_04db49fe'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['kader_ali'].imagePath.includes('Influential_Elder_Character_Card_71b778fc'),
  'Kader Ali must point to Influential_Elder_Character_Card_71b778fc'
);
assert(
  VERIFIED_CHARACTER_REGISTRY['farzana_begum'].imagePath.includes('Community_Leader_Portrait_Card_f4b8fc20'),
  'Farzana Begum must point to Community_Leader_Portrait_Card_f4b8fc20'
);
console.log('✅ 5. Exact visual identities aligned with on-card character artwork.');

// 6. Test missing reference reporting
const nonExistent = getCharacterRecord('ghost_character');
assert(nonExistent === undefined, 'Non-existent character must return undefined instead of silent fallback');
console.log('✅ 6. Missing character lookups cleanly report undefined without silent cross-replacement.');

// 7. Verify Case Generator suspect assignment preserves characterId -> (name, image, occupation) integrity
const testCase = NishipurCaseGenerator.generateCase(5);
assert(testCase.coreSuspectIds.length === 4, `Expected 4 core suspects, got ${testCase.coreSuspectIds.length}`);
for (const suspectId of testCase.coreSuspectIds) {
  const registered = NISHIPUR_CHARACTERS[suspectId];
  assert(Boolean(registered), `Suspect ${suspectId} must exist in registry`);
  assert(registered.characterId === suspectId, `Suspect ${suspectId} characterId mismatch`);
  assert(Boolean(registered.imagePath), `Suspect ${suspectId} must have valid imagePath`);
  assert(testCase.characterStories[suspectId] !== undefined, `Suspect ${suspectId} must have story`);
}
console.log('✅ 7. Case generator properly maps suspects via stable character IDs without array desynchronization.');

console.log('🎉 ALL 15 SHADOW DETECTIVE CHARACTERS VALIDATION CHECKS PASSED!');
