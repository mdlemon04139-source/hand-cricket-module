// Authoritative Types for Nishipur: Shadow Detective

import { NishipurCharacter } from '../../data/nishipurCharacters';

export type GameMode = 'ai_solo' | 'human_multiplayer' | 'human_ai_multiplayer';
export type PlayerCountOption = 5 | 7 | 9;

export type ShadowPhase =
  | 'HOME'
  | 'MODE_SELECT'
  | 'ROOM_LOBBY'
  | 'STORY_INTRO'
  | 'ROLE_BRIEFING'
  | 'PHASE_1_INTERROGATION'
  | 'PHASE_1_RELEASE'
  | 'PHASE_2_INTERROGATION'
  | 'PHASE_2_RELEASE'
  | 'PHASE_3_TUHA'
  | 'PHASE_3_RELEASE'
  | 'FINAL_VERDICT'
  | 'CASE_RESOLVED';

export type CaseCategory =
  | 'theft'
  | 'robbery'
  | 'missing_object'
  | 'missing_person'
  | 'fraud'
  | 'blackmail'
  | 'financial_dispute'
  | 'land_dispute'
  | 'murder';

export interface CaseEvidenceItem {
  id: string;
  nameBn: string;
  nameEn: string;
  category: 'physical' | 'document' | 'forensic' | 'digital';
  locationFoundBn: string;
  descriptionBn: string;
  relevanceBn: string;
  isInitialClue: boolean;
  unlockedInPhase?: 1 | 2 | 3;
}

export interface CaseQuestion {
  id: string;
  labelBn: string;
  promptBn: string;
  phaseAllowed: number;
}

export interface CaseCharacterStory {
  characterId: string;
  isCulprit: boolean;
  roleInCaseBn: string;
  privateBriefingStoryBn: string; // 50-90 words short story
  alibiBn: string;
  motiveBn: string;
  relationshipWithVictimBn: string;
  secretBn: string;
  bluffTokensRemaining: number;
  canBluff: boolean;
  answers: Record<string, {
    truthBn: string;
    bluffOptionsBn?: string[];
  }>;
}

export interface NishipurCaseTruth {
  caseId: string;
  titleBn: string;
  category: CaseCategory;
  categoryNameBn: string;
  locationNameBn: string;
  incidentTimeBn: string;
  shortPublicStoryPages: string[]; // multi-page storybook
  culpritCharacterId: string;
  motiveBn: string;
  timelineBn: string[];
  coreSuspectIds: string[]; // 5 core suspects (excluding Robin and Tuha)
  supportingCharacterIds?: string[]; // for 7 or 9 player modes
  evidenceList: CaseEvidenceItem[];
  characterStories: Record<string, CaseCharacterStory>;
  tuhaHintBn: string;
  tuhaEvidenceAnalysisBn: string;
  keyContradictionsBn: string[];
  finalCaseExplanationBn: string;
}

export interface VerifiedStatement {
  id: string;
  suspectId: string;
  suspectNameBn: string;
  questionPromptBn: string;
  answerTextBn: string;
  recordedPhase: number;
  timestamp: number;
}

export interface ShadowPlayer {
  id: string;
  nickname: string;
  avatar: string;
  isHost: boolean;
  isBot: boolean;
  isOnline: boolean;
  isReady: boolean;
  assignedRole: 'robin' | 'tuha' | 'suspect';
  characterId?: string; // e.g. 'robin', 'gafur_matbor', etc.
  isReleased: boolean;
}

export interface ShadowRoomClientState {
  roomId: string;
  roomCode: string;
  hostId: string;
  phase: ShadowPhase;
  mode: GameMode;
  targetPlayerCount: PlayerCountOption;
  myPlayerId: string;
  myPlayer: ShadowPlayer;
  players: ShadowPlayer[];
  
  // Public Case Overview
  caseOverview?: {
    caseId: string;
    titleBn: string;
    categoryNameBn: string;
    locationNameBn: string;
    incidentTimeBn: string;
    shortPublicStoryPages: string[];
    coreSuspectIds: string[];
    supportingCharacterIds?: string[];
  };

  // Private Character Briefing (information isolation: ONLY sent to the specific player)
  myPrivateBriefing?: {
    characterId: string;
    characterNameBn: string;
    roleInCaseBn: string;
    privateBriefingStoryBn: string; // 50-90 words narrative
    secretBn: string;
    alibiBn: string;
    bluffTokensRemaining: number;
    canBluff: boolean;
  };

  // Investigation Public State
  currentPhaseNumber: number;
  questionsRemainingInPhase: number;
  releasedSuspectIds: string[];
  activeSuspectIds: string[];
  finalTwoSuspectIds?: [string, string];

  // Interrogation Dialog / Question Active
  activeInterrogation?: {
    targetSuspectId: string;
    question: CaseQuestion;
    availableAnswers?: string[]; // shown to human suspect answering
    waitingForAnswer: boolean;
  };

  // Verified Evidence & Statement Notebook
  evidenceNotebook: {
    publicEvidence: CaseEvidenceItem[];
    verifiedStatements: VerifiedStatement[];
  };

  // Tuha Assistance (unlocked in Phase 3)
  tuhaAssistance?: {
    isUnlocked: boolean;
    hintBn: string;
    evidenceAnalysisBn: string;
  };

  // Verdict & Outcome (revealed in CASE_RESOLVED)
  finalVerdictResult?: {
    declaredGuiltyId: string;
    declaredInnocentId: string;
    isVictory: boolean;
    trueCulpritId: string;
    motiveBn: string;
    timelineBn: string[];
    keyContradictionsBn: string[];
    finalCaseExplanationBn: string;
  };

  // Logs
  gameLogs: Array<{
    id: string;
    textBn: string;
    type: 'system' | 'interrogation' | 'release' | 'tuha' | 'verdict';
    timestamp: number;
  }>;
}
