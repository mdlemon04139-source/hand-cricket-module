import React, { useState } from 'react';
import {
  Compass,
  BookOpen,
  Play,
  Users,
  ShieldAlert,
  Search,
  Sparkles,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Flame,
  Info,
  X,
} from 'lucide-react';
import { NISHIPUR_CHARACTERS, NishipurCharacter } from '../../data/nishipurCharacters';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface GameHomeScreenProps {
  onStartClick: () => void;
  onBackToKhelghor: () => void;
  stats?: { totalPlays: number; totalUniquePlayers: number };
}

export const GameHomeScreen: React.FC<GameHomeScreenProps> = ({
  onStartClick,
  onBackToKhelghor,
  stats = { totalPlays: 32, totalUniquePlayers: 19 },
}) => {
  const [selectedChar, setSelectedChar] = useState<NishipurCharacter | null>(null);
  const [showRulesModal, setShowRulesModal] = useState(false);
  const [characterFilter, setCharacterFilter] = useState<'all' | 'investigators' | 'villagers'>('all');

  const filteredCharacters = NISHIPUR_CHARACTERS.filter((c) => {
    if (characterFilter === 'investigators') return c.id === 'robin' || c.id === 'tuha';
    if (characterFilter === 'villagers') return c.id !== 'robin' && c.id !== 'tuha';
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#060c14] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-b from-cyan-900/20 via-blue-900/10 to-transparent blur-3xl pointer-events-none" />

      {/* Top Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              onBackToKhelghor();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-500 text-xs sm:text-sm font-bengali transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>খেলাঘর হোম</span>
          </button>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* Rules button */}
          <button
            onClick={() => {
              sound.playClick();
              setShowRulesModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 hover:bg-slate-800 text-xs sm:text-sm font-bengali transition-all cursor-pointer shadow"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>নিয়মাবলী</span>
          </button>
        </div>
      </header>

      {/* Main Hero & Character Showcase */}
      <main className="relative z-10 max-w-6xl mx-auto px-4 py-6 sm:px-8 w-full flex-1 flex flex-col justify-center">
        {/* Title Banner */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-semibold mb-3">
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>নিশিপুর: রহস্যের এক গ্রাম (A Village of Secrets)</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white font-bengali tracking-tight">
            শ্যাডো ডিটেক্টিভ: নিশিপুর
          </h1>
          <p className="text-sm sm:text-base text-slate-300 mt-2 font-bengali leading-relaxed">
            গোয়েন্দা রবিন ও সহকারী তুহার সাথে নিশিপুর গ্রামের চাঞ্চল্যকর রহস্যভেদ করুন। গ্রামবাসীদের জিজ্ঞাসাবাদ করুন, মিথ্যা জবানবন্দি ধরুন এবং সঠিক সময়ে অপরাধীকে চিহ্নিত করুন!
          </p>

          {/* Live Persistent Stats Badges */}
          <div className="mt-4 flex items-center justify-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-xs text-cyan-300 font-mono">
              <Flame className="w-3.5 h-3.5 text-cyan-400" />
              <span>মোট তদন্ত সম্পন্ন: <strong>{stats.totalPlays}</strong></span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900 border border-slate-700/80 text-xs text-slate-300 font-mono">
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              <span>নিবন্ধিত গোয়েন্দা: <strong>{stats.totalUniquePlayers}</strong></span>
            </div>
          </div>

          {/* Call to Action Button */}
          <div className="mt-6 flex items-center justify-center gap-4">
            <button
              onClick={() => {
                sound.playClick();
                onStartClick();
              }}
              className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-black text-base sm:text-lg font-bengali shadow-xl shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-105 transition-all cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>তদন্তে প্রবেশ করুন</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 15 Canonical Characters Showcase */}
        <section className="mt-4 bg-slate-950/60 rounded-3xl p-5 border border-slate-800 backdrop-blur-md">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <div>
              <h2 className="text-lg font-bold text-white font-bengali flex items-center gap-2">
                <span>নিশিপুরের ১৫ জন স্থায়ী বাসিন্দা ও তদন্তকারী</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">
                  15 Assets
                </span>
              </h2>
              <p className="text-xs text-slate-400 font-bengali">
                যেকোনো কার্ডে ক্লিক করে তাদের চরিত্র, পেশা ও গোপন তথ্যের বিবরণ দেখুন
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setCharacterFilter('all')}
                className={`px-3 py-1 rounded-lg text-xs font-bengali transition-all ${
                  characterFilter === 'all' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                সকল ({NISHIPUR_CHARACTERS.length})
              </button>
              <button
                onClick={() => setCharacterFilter('investigators')}
                className={`px-3 py-1 rounded-lg text-xs font-bengali transition-all ${
                  characterFilter === 'investigators'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                তদন্তকারী (২)
              </button>
              <button
                onClick={() => setCharacterFilter('villagers')}
                className={`px-3 py-1 rounded-lg text-xs font-bengali transition-all ${
                  characterFilter === 'villagers'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                গ্রামবাসী (১৩)
              </button>
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3.5">
            {filteredCharacters.map((char) => (
              <div
                key={char.id}
                onClick={() => {
                  try {
                    if (typeof sound?.playCardFlip === 'function') {
                      sound.playCardFlip();
                    } else if (typeof sound?.playCardDeal === 'function') {
                      sound.playCardDeal();
                    } else {
                      sound?.playClick?.();
                    }
                  } catch {}
                  setSelectedChar(char);
                }}
                className={`group relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-200 border-2 bg-slate-900 flex flex-col ${
                  char.id === 'robin' || char.id === 'tuha'
                    ? 'border-cyan-500/80 shadow-md shadow-cyan-500/10 hover:border-cyan-400 hover:scale-105'
                    : 'border-slate-700/80 hover:border-amber-400 hover:scale-105'
                }`}
              >
                <div className="relative aspect-[3/4] w-full overflow-hidden bg-slate-950">
                  <img
                    src={char.image}
                    alt={char.nameBn}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-108"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-sm border border-slate-700 text-[10px] text-cyan-300 font-mono">
                    {char.avatar} {char.englishName || char.nameEn}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-950 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white font-bengali group-hover:text-cyan-300 transition-colors truncate">
                      {char.nameBn}
                    </h4>
                    <p className="text-[11px] text-amber-400 font-bengali truncate mt-0.5">
                      {char.roleBn}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Character Inspect Modal */}
      {selectedChar && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-lg w-full bg-slate-900 border-2 border-cyan-500/80 rounded-3xl overflow-hidden shadow-2xl p-6">
            <button
              onClick={() => {
                sound.playClick();
                setSelectedChar(null);
              }}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex gap-5 items-start">
              <div className="w-36 h-48 sm:w-44 sm:h-56 shrink-0 rounded-2xl overflow-hidden border-2 border-cyan-400 shadow-xl">
                <img
                  src={selectedChar.image}
                  alt={selectedChar.nameBn}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1">
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  {selectedChar.id}
                </span>
                <h3 className="text-2xl font-black text-white font-bengali mt-1">
                  {selectedChar.nameBn}
                </h3>
                <p className="text-sm text-amber-400 font-bengali font-semibold mt-0.5">
                  {selectedChar.roleBn}
                </p>

                <div className="mt-3 text-xs text-slate-300 font-bengali leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  {selectedChar.bioBn}
                </div>

                <div className="mt-3 text-[11px] text-slate-400 font-mono">
                  English Bio: <span className="text-slate-300">{selectedChar.bioEn}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedChar(null)}
                className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-sm font-bengali hover:bg-cyan-400"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-2xl w-full max-h-[85vh] overflow-y-auto bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 text-slate-200 shadow-2xl">
            <button
              onClick={() => setShowRulesModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-2xl font-black text-white font-bengali flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-cyan-400" />
              <span>শ্যাডো ডিটেক্টিভ: খেলার নিয়ম ও পর্যায়ক্রম</span>
            </h2>

            <div className="mt-4 space-y-4 text-xs sm:text-sm font-bengali leading-relaxed">
              <div className="bg-slate-950/70 p-4 rounded-2xl border border-cyan-500/30">
                <h4 className="font-bold text-cyan-300 text-base mb-1">১. মামলার সূচনা ও চরিত্র বন্টন</h4>
                <p>
                  প্রতিটি মামলায় নিশিপুর গ্রামের ১ জন হবেন <strong>প্রধান গোয়েন্দা রবিন</strong>, ১ জন <strong>সহকারী তুহা</strong> এবং বাকিরা হবেন ৫ জন সক্রিয় সন্দেহভাজন গ্রামবাসী। প্রত্যেকে নিজস্ব গোপন স্টোরি ব্রিফিং পাবেন যা অন্য কেউ দেখতে পারবে না।
                </p>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-2xl border border-amber-500/30">
                <h4 className="font-bold text-amber-300 text-base mb-1">২. পর্যায় ১ — প্রাথমিক জিজ্ঞাসাবাদ ও প্রথম মুক্তি</h4>
                <p>
                  রবিন সন্দেহভাজনদের মোট ৫টি প্রশ্ন করবেন। প্রশ্ন শেষে রবিনকে বাধ্যতামূলকভাবে ১ জন সন্দেহভাজনকে মুক্তি দিতে হবে।
                  <br />
                  <strong className="text-rose-400">গুরুত্বপূর্ণ নিয়ম: ভুলবশত আসল অপরাধীকে মুক্তি দিলে তাৎক্ষণিক পরাজয় ঘটবে!</strong>
                </p>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-2xl border border-blue-500/30">
                <h4 className="font-bold text-blue-300 text-base mb-1">৩. পর্যায় ২ — গভীর অনুসন্ধান ও দ্বিতীয় মুক্তি</h4>
                <p>
                  অবশিষ্ট ৪ জন সন্দেহভাজনকে আরও ৩টি প্রশ্ন করার সুযোগ থাকবে। অমিল ও অসঙ্গতি খুঁজে বের করে রবিন আরও ১ জনকে মুক্তি দেবেন।
                </p>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-2xl border border-emerald-500/30">
                <h4 className="font-bold text-emerald-300 text-base mb-1">৪. পর্যায় ৩ — সহকারী তুহার ফরেনসিক রিপোর্ট ও শেষ ২ জন</h4>
                <p>
                  তুহা নতুন ল্যাব টেস্ট ও ফরেনসিক আলামতের রিপোর্ট আনবেন! ১টি চূড়ান্ত প্রশ্ন শেষে ১ জনকে মুক্তি দিয়ে শেষ ২ জন সন্দেহভাজনকে নিয়ে ফাইনাল রায়ে প্রবেশ করা হবে।
                </p>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-2xl border border-purple-500/30">
                <h4 className="font-bold text-purple-300 text-base mb-1">৫. চূড়ান্ত রায় (Final Verdict)</h4>
                <p>
                  শেষ ২ জন সন্দেহভাজনের মধ্যে একজনকে <strong>দোষী</strong> ও অন্যজনকে <strong>নির্দোষ</strong> ঘোষণা করতে হবে। আসল অপরাধীকে দোষী সাব্যস্ত করলেই নিশিপুরের রহস্য মীমাংসা ও রবিনের মহাবিজয়!
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowRulesModal(false)}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-sm font-bengali hover:bg-cyan-400"
              >
                বুঝতে পেরেছি
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RIRahat Footer */}
      <RIRahatFooter />
    </div>
  );
};
