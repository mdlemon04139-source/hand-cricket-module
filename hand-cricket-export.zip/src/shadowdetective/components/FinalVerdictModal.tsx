import React, { useState } from 'react';
import { Gavel, AlertTriangle, ShieldCheck, X, ArrowRight } from 'lucide-react';
import { ShadowRoomClientState } from '../types/shadowDetective';
import { NISHIPUR_CHARACTERS } from '../../data/nishipurCharacters';
import { sound } from '../../utils/sound';

interface FinalVerdictModalProps {
  state: ShadowRoomClientState;
  onSubmitVerdict: (guiltySuspectId: string, innocentSuspectId: string) => void;
  onClose: () => void;
}

export const FinalVerdictModal: React.FC<FinalVerdictModalProps> = ({
  state,
  onSubmitVerdict,
  onClose,
}) => {
  const finalTwo = state.finalTwoSuspectIds || [
    state.activeSuspectIds[0] || 'kalu_chor',
    state.activeSuspectIds[1] || 'gafur_matbor',
  ];

  const [guiltyId, setGuiltyId] = useState<string | null>(null);

  const char1 = NISHIPUR_CHARACTERS[finalTwo[0]];
  const char2 = NISHIPUR_CHARACTERS[finalTwo[1]];

  const innocentId = guiltyId === finalTwo[0] ? finalTwo[1] : finalTwo[0];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-2xl w-full bg-slate-900 border-2 border-rose-500/80 rounded-3xl p-6 sm:p-8 text-slate-200 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs font-mono font-bold mb-2">
            <Gavel className="w-3.5 h-3.5" />
            <span>FINAL VERDICT SHOWDOWN</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-bengali">
            নিশিপুরের অন্তিম রায় ঘোষণা
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-1">
            শেষ ২ জন সন্দেহভাজনের মধ্যে একজনকে <strong>দোষী (Guilty)</strong> নির্বাচন করুন। অপরজন স্বয়ংক্রিয়ভাবে নির্দোষ সাব্যস্ত হবেন।
          </p>
        </div>

        {/* Head to Head Cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {/* Candidate 1 */}
          <div
            onClick={() => {
              sound.playClick();
              setGuiltyId(finalTwo[0]);
            }}
            className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col items-center text-center ${
              guiltyId === finalTwo[0]
                ? 'border-rose-500 bg-rose-950/30 scale-102 shadow-xl shadow-rose-500/20'
                : 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
            }`}
          >
            <div className="w-24 h-32 sm:w-28 sm:h-36 rounded-xl overflow-hidden border-2 border-slate-700 mb-3 shadow-md">
              <img src={char1?.image} alt={char1?.nameBn} className="w-full h-full object-cover" />
            </div>
            <h4 className="font-bold text-base text-white font-bengali">{char1?.nameBn}</h4>
            <p className="text-xs text-amber-400 font-bengali mt-0.5">{char1?.roleBn}</p>

            <div className="mt-3 w-full">
              {guiltyId === finalTwo[0] ? (
                <span className="block py-1.5 rounded-xl bg-rose-500 text-slate-950 font-bold text-xs font-bengali shadow">
                  দোষী সাব্যস্ত (Accused)
                </span>
              ) : (
                <span className="block py-1.5 rounded-xl bg-slate-800 text-slate-400 text-xs font-bengali">
                  দোষী নির্বাচন করুন
                </span>
              )}
            </div>
          </div>

          {/* Candidate 2 */}
          <div
            onClick={() => {
              sound.playClick();
              setGuiltyId(finalTwo[1]);
            }}
            className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col items-center text-center ${
              guiltyId === finalTwo[1]
                ? 'border-rose-500 bg-rose-950/30 scale-102 shadow-xl shadow-rose-500/20'
                : 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
            }`}
          >
            <div className="w-24 h-32 sm:w-28 sm:h-36 rounded-xl overflow-hidden border-2 border-slate-700 mb-3 shadow-md">
              <img src={char2?.image} alt={char2?.nameBn} className="w-full h-full object-cover" />
            </div>
            <h4 className="font-bold text-base text-white font-bengali">{char2?.nameBn}</h4>
            <p className="text-xs text-amber-400 font-bengali mt-0.5">{char2?.roleBn}</p>

            <div className="mt-3 w-full">
              {guiltyId === finalTwo[1] ? (
                <span className="block py-1.5 rounded-xl bg-rose-500 text-slate-950 font-bold text-xs font-bengali shadow">
                  দোষী সাব্যস্ত (Accused)
                </span>
              ) : (
                <span className="block py-1.5 rounded-xl bg-slate-800 text-slate-400 text-xs font-bengali">
                  দোষী নির্বাচন করুন
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bengali text-xs hover:text-white"
          >
            পুনরায় প্রমাণ যাচাই করুন
          </button>
          <button
            disabled={!guiltyId}
            onClick={() => {
              if (guiltyId) {
                sound.playClick();
                onSubmitVerdict(guiltyId, innocentId);
              }
            }}
            className={`px-6 py-2.5 rounded-xl font-bold font-bengali text-sm flex items-center gap-2 transition-all ${
              guiltyId
                ? 'bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 cursor-pointer shadow-xl shadow-rose-500/25'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Gavel className="w-4 h-4" />
            <span>চূড়ান্ত রায় কার্যকর করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
