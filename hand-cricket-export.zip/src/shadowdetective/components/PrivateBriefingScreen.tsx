import React from 'react';
import { Shield, Eye, Lock, ArrowRight, UserCheck, AlertTriangle } from 'lucide-react';
import { ShadowRoomClientState } from '../types/shadowDetective';
import { NISHIPUR_CHARACTERS } from '../../data/nishipurCharacters';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface PrivateBriefingScreenProps {
  state: ShadowRoomClientState;
  onProceed: () => void;
}

export const PrivateBriefingScreen: React.FC<PrivateBriefingScreenProps> = ({ state, onProceed }) => {
  const isRobin = state.myPlayer?.assignedRole === 'robin';
  const briefing = state.myPrivateBriefing;
  const characterId = state.myPlayer?.characterId;
  const charData = characterId ? NISHIPUR_CHARACTERS[characterId] : null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#070e17] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-rose-400" />
          <span className="font-bold text-xs sm:text-sm text-rose-300 font-bengali">
            গোপন চরিত্র ব্রিফিং (Strict Confidential Information)
          </span>
        </div>

        <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-slate-400 font-mono">
          Only Visible to You
        </span>
      </header>

      {/* Main Container */}
      <main className="relative z-10 max-w-2xl mx-auto px-4 py-6 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div className="rounded-3xl bg-slate-900/80 border-2 border-slate-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
          {/* Accent top banner */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-cyan-500 via-indigo-500 to-rose-500" />

          {isRobin ? (
            // Robin Investigator Briefing
            <div>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-20 rounded-xl overflow-hidden border-2 border-cyan-400 shadow-md">
                  <img
                    src="/assets/aistudio/Investigator_Robin_Bengali_Character_Card_f976d6f4.png"
                    alt="রবিন"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                    LEAD INVESTIGATOR
                  </span>
                  <h2 className="text-2xl font-black text-white font-bengali mt-0.5">
                    প্রধান গোয়েন্দা রবিন
                  </h2>
                  <p className="text-xs text-cyan-300 font-bengali">
                    সহকারী তুহা ও নিশিপুরের আইনশৃঙ্খলা বাহিনী আপনার আদেশের অপেক্ষায়।
                  </p>
                </div>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-2xl border border-cyan-500/30 mb-4 text-xs sm:text-sm text-slate-200 font-bengali leading-relaxed">
                <p className="mb-2">
                  <strong>আপনার দায়িত্ব:</strong> থানায় উপস্থিত ৫ জন সন্দেহভাজন গ্রামবাসীকে ধারাবাহিকভাবে জিজ্ঞাসাবাদ করুন। তাদের দেওয়া উত্তরের অমিল ও বৈপরীত্য লক্ষ্য করুন।
                </p>
                <p className="text-rose-300 font-bold">
                  ⚠️ সতর্কতা: প্রতি পর্যায় শেষে আপনাকে ১ জন সন্দেহভাজনকে মুক্তি দিতে হবে। ভুলবশত আসল অপরাধীকে মুক্তি দিলে অপরাধী পালিয়ে যাবে এবং আপনি পরাজিত হবেন!
                </p>
              </div>
            </div>
          ) : briefing && charData ? (
            // Suspect Villager Briefing (~50-90 words short story)
            <div>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-20 rounded-xl overflow-hidden border-2 border-amber-400 shadow-md">
                  <img src={charData.image} alt={charData.nameBn} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-500/30">
                    {briefing.roleInCaseBn}
                  </span>
                  <h2 className="text-2xl font-black text-white font-bengali mt-0.5">
                    {briefing.characterNameBn}
                  </h2>
                  <p className="text-xs text-amber-300 font-bengali">
                    {charData.roleBn}
                  </p>
                </div>
              </div>

              {/* Private Story Box */}
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-700 mb-4">
                <h4 className="text-xs font-bold text-cyan-400 font-bengali mb-1.5 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5" />
                  <span>আপনার ব্যক্তিগত বিবরণ ও গোপন ঘটনা:</span>
                </h4>
                <p className="text-xs sm:text-sm text-slate-200 font-bengali leading-relaxed">
                  {briefing.privateBriefingStoryBn}
                </p>
              </div>

              {/* Secret and Alibi */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-400 font-bengali block">অ্যালিবাই:</span>
                  <span className="text-xs text-slate-200 font-bengali font-semibold">
                    {briefing.alibiBn}
                  </span>
                </div>
                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-400 font-bengali block">গোপন তথ্য:</span>
                  <span className="text-xs text-amber-300 font-bengali font-semibold">
                    {briefing.secretBn}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-sm text-slate-300 font-bengali">
                তদন্তকারী দলের সদস্য হিসেবে আপনার ভূমিকা নির্ধারিত হয়েছে।
              </p>
            </div>
          )}

          {/* Action Button */}
          <div className="pt-4 border-t border-slate-800/80 flex justify-end">
            <button
              onClick={() => {
                sound.playClick();
                onProceed();
              }}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm font-bengali shadow-xl shadow-cyan-500/25 transition-all cursor-pointer"
            >
              <span>তদন্ত ডেস্কে প্রবেশ করুন</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </main>

      <RIRahatFooter />
    </div>
  );
};
