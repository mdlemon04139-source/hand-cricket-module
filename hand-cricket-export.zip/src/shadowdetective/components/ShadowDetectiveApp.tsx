import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameMode, PlayerCountOption, ShadowRoomClientState } from '../types/shadowDetective';
import { GameHomeScreen } from './GameHomeScreen';
import { ModeSelectScreen } from './ModeSelectScreen';
import { RoomLobbyScreen } from './RoomLobbyScreen';
import { StoryIntroScreen } from './StoryIntroScreen';
import { PrivateBriefingScreen } from './PrivateBriefingScreen';
import { InvestigationDashboard } from './InvestigationDashboard';
import { FinalVerdictModal } from './FinalVerdictModal';
import { CaseOutcomeScreen } from './CaseOutcomeScreen';
import { sound } from '../../utils/sound';
import { Loader2, ArrowLeft } from 'lucide-react';

interface ShadowDetectiveAppProps {
  onBackToKhelghor: () => void;
  initialRoomId?: string | null;
  initialPlayerId?: string | null;
}

export const ShadowDetectiveApp: React.FC<ShadowDetectiveAppProps> = ({
  onBackToKhelghor,
  initialRoomId,
  initialPlayerId,
}) => {
  const [currentScreen, setCurrentScreen] = useState<
    'home' | 'mode_select' | 'lobby' | 'story' | 'briefing' | 'dashboard' | 'outcome'
  >('home');

  const [roomId, setRoomId] = useState<string | null>(initialRoomId || null);
  const [playerId, setPlayerId] = useState<string | null>(initialPlayerId || null);
  const [roomState, setRoomState] = useState<ShadowRoomClientState | null>(null);
  const [showFinalVerdictModal, setShowFinalVerdictModal] = useState(false);
  const [joinError, setJoinError] = useState<string | null>(null);
  const [stats, setStats] = useState<{ totalPlays: number; totalUniquePlayers: number }>({
    totalPlays: 32,
    totalUniquePlayers: 19,
  });

  const eventSourceRef = useRef<EventSource | null>(null);

  // Sync screen with room phase
  const syncScreenWithPhase = useCallback((phase: string) => {
    if (phase === 'ROOM_LOBBY') {
      setCurrentScreen('lobby');
    } else if (phase === 'STORY_INTRO') {
      setCurrentScreen('story');
    } else if (phase === 'ROLE_BRIEFING') {
      setCurrentScreen('briefing');
    } else if (
      phase === 'PHASE_1_INTERROGATION' ||
      phase === 'PHASE_1_RELEASE' ||
      phase === 'PHASE_2_INTERROGATION' ||
      phase === 'PHASE_2_RELEASE' ||
      phase === 'PHASE_3_TUHA' ||
      phase === 'PHASE_3_RELEASE' ||
      phase === 'FINAL_VERDICT'
    ) {
      setCurrentScreen('dashboard');
    } else if (phase === 'CASE_RESOLVED') {
      setShowFinalVerdictModal(false);
      setCurrentScreen('outcome');
    }
  }, []);

  // Proactive state fetcher
  const refreshState = useCallback(async (targetRoomId?: string | null, targetPlayerId?: string | null) => {
    const rid = targetRoomId || roomId;
    const pid = targetPlayerId || playerId;
    if (!rid || !pid) return;

    try {
      const res = await fetch(`/api/shadowdetective/rooms/${rid}/state?playerId=${encodeURIComponent(pid)}`);
      if (res.ok) {
        const data: ShadowRoomClientState = await res.json();
        setRoomState(data);
        syncScreenWithPhase(data.phase);
      }
    } catch (err) {
      console.error('Failed to fetch room state:', err);
    }
  }, [roomId, playerId, syncScreenWithPhase]);

  // Fetch initial game statistics
  useEffect(() => {
    fetch('/api/shadowdetective/stats')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.shadowdetective) {
          setStats(data.shadowdetective);
        }
      })
      .catch(() => {});
  }, []);

  // Connect SSE real-time state stream
  useEffect(() => {
    if (!roomId || !playerId) {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      return;
    }

    // Proactively fetch initial state immediately on room/player setup
    refreshState(roomId, playerId);

    const sseUrl = `/api/shadowdetective/rooms/${roomId}/events?playerId=${encodeURIComponent(playerId)}`;
    const es = new EventSource(sseUrl);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const data: ShadowRoomClientState = JSON.parse(event.data);
        setRoomState(data);
        syncScreenWithPhase(data.phase);
      } catch (err) {
        console.error('Failed to parse SSE state:', err);
      }
    };

    es.onerror = () => {
      // Browser reconnects automatically
    };

    return () => {
      es.close();
      eventSourceRef.current = null;
    };
  }, [roomId, playerId, refreshState, syncScreenWithPhase]);

  // Fallback polling during active interrogation or waiting states
  useEffect(() => {
    if (!roomId || !playerId) return;
    if (
      currentScreen !== 'dashboard' &&
      currentScreen !== 'story' &&
      currentScreen !== 'briefing' &&
      currentScreen !== 'lobby'
    ) {
      return;
    }

    const timer = setInterval(() => {
      refreshState();
    }, 2000);

    return () => clearInterval(timer);
  }, [roomId, playerId, currentScreen, refreshState]);

  // Create room handler
  const handleSelectMode = async (
    mode: GameMode,
    playerCount: PlayerCountOption,
    hostName: string
  ) => {
    try {
      const res = await fetch('/api/shadowdetective/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: hostName,
          avatar: '🕵️‍♂️',
          mode,
          targetPlayerCount: playerCount,
        }),
      });
      const data = await res.json();
      if (data.roomId && data.playerId) {
        setRoomId(data.roomId);
        setPlayerId(data.playerId);
        if (data.state) {
          setRoomState(data.state);
        }
        if (mode === 'ai_solo') {
          setCurrentScreen('story');
        } else {
          setCurrentScreen('lobby');
        }
        await refreshState(data.roomId, data.playerId);
      }
    } catch (err) {
      console.error('Error creating room:', err);
    }
  };

  // Join Room handler
  const handleJoinRoom = async (roomCode: string, name: string) => {
    setJoinError(null);
    try {
      const res = await fetch(`/api/shadowdetective/rooms/${roomCode}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, avatar: '🕵️' }),
      });
      const data = await res.json();
      if (data.success && data.playerId) {
        setRoomId(roomCode);
        setPlayerId(data.playerId);
        if (data.state) {
          setRoomState(data.state);
          syncScreenWithPhase(data.state.phase);
        } else {
          setCurrentScreen('lobby');
          await refreshState(roomCode, data.playerId);
        }
      } else {
        setJoinError(data.error || 'রুমে প্রবেশ করা সম্ভব হয়নি। কোডটি পুনরায় পরীক্ষা করুন।');
      }
    } catch (err) {
      console.error('Failed to join room:', err);
      setJoinError('সার্ভারে যোগাযোগ করতে সমস্যা হয়েছে।');
    }
  };

  // Add bot to room
  const handleAddBot = async () => {
    if (!roomId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/add-bot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to add bot:', err);
    }
  };

  // Toggle ready
  const handleToggleReady = async () => {
    if (!roomId || !playerId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/toggle-ready`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId }),
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to toggle ready:', err);
    }
  };

  // Start game from lobby
  const handleStartGame = async () => {
    if (!roomId || !playerId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requesterId: playerId }),
      });
      setCurrentScreen('story');
      await refreshState();
    } catch (err) {
      console.error('Failed to start game:', err);
    }
  };

  // Advance from Story Intro
  const handleAdvanceStory = async () => {
    if (!roomId) return;
    try {
      setCurrentScreen('briefing');
      await fetch(`/api/shadowdetective/rooms/${roomId}/advance-story`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to advance story:', err);
    }
  };

  // Advance from Role Briefing
  const handleAdvanceBriefing = async () => {
    if (!roomId) return;
    try {
      setCurrentScreen('dashboard');
      await fetch(`/api/shadowdetective/rooms/${roomId}/advance-briefing`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to advance briefing:', err);
    }
  };

  // Ask Question
  const handleAskQuestion = async (targetSuspectId: string, questionId: string) => {
    if (!roomId || !playerId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/ask-question`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requesterId: playerId,
          targetSuspectId,
          questionId,
        }),
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to ask question:', err);
    }
  };

  // Submit Answer
  const handleSubmitAnswer = async (characterId: string, answerText: string) => {
    if (!roomId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/submit-answer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          characterId,
          answerText,
        }),
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to submit answer:', err);
    }
  };

  // Release Suspect
  const handleReleaseSuspect = async (suspectId: string) => {
    if (!roomId || !playerId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/release`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requesterId: playerId,
          suspectId,
        }),
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to release suspect:', err);
    }
  };

  // Submit Final Verdict
  const handleSubmitFinalVerdict = async (guiltySuspectId: string, innocentSuspectId: string) => {
    if (!roomId || !playerId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/final-verdict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requesterId: playerId,
          guiltySuspectId,
          innocentSuspectId,
        }),
      });
      setShowFinalVerdictModal(false);
      await refreshState();
    } catch (err) {
      console.error('Failed to submit verdict:', err);
    }
  };

  // Restart match
  const handleRestart = async () => {
    if (!roomId || !playerId) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/restart`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requesterId: playerId }),
      });
      await refreshState();
    } catch (err) {
      console.error('Failed to restart:', err);
    }
  };

  // Leave room
  const handleLeaveRoom = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    setRoomId(null);
    setPlayerId(null);
    setRoomState(null);
    setJoinError(null);
    setCurrentScreen('home');
  };

  return (
    <div className="w-full min-h-screen">
      {currentScreen === 'home' && (
        <GameHomeScreen
          onStartClick={() => setCurrentScreen('mode_select')}
          onBackToKhelghor={onBackToKhelghor}
          stats={stats}
        />
      )}

      {currentScreen === 'mode_select' && (
        <>
          {joinError && (
            <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-rose-950/90 border border-rose-500 text-rose-200 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bengali shadow-2xl backdrop-blur-md">
              {joinError}
            </div>
          )}
          <ModeSelectScreen
            onSelectMode={handleSelectMode}
            onJoinRoom={handleJoinRoom}
            onBack={() => {
              setJoinError(null);
              setCurrentScreen('home');
            }}
          />
        </>
      )}

      {/* Loading state safeguard if room created/joined but state not yet loaded */}
      {currentScreen !== 'home' && currentScreen !== 'mode_select' && !roomState && (
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 text-slate-200 p-6">
          <div className="p-4 rounded-full bg-slate-900 border border-slate-800 text-cyan-400 mb-4 animate-pulse">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
          <h3 className="text-xl font-bold font-bengali text-white mb-2">
            নিশিপুরের গোপন নথি সংগৃহীত হচ্ছে...
          </h3>
          <p className="text-xs text-slate-400 font-bengali mb-6">
            সার্ভারের সাথে সংযোগ স্থাপন করা হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন।
          </p>
          <button
            onClick={handleLeaveRoom}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bengali text-slate-300 hover:text-white cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>হোমে ফিরে যান</span>
          </button>
        </div>
      )}

      {currentScreen === 'lobby' && roomState && (
        <RoomLobbyScreen
          state={roomState}
          onAddBot={handleAddBot}
          onToggleReady={handleToggleReady}
          onStartGame={handleStartGame}
          onLeaveRoom={handleLeaveRoom}
        />
      )}

      {currentScreen === 'story' && roomState && (
        <StoryIntroScreen
          state={roomState}
          onProceed={handleAdvanceStory}
        />
      )}

      {currentScreen === 'briefing' && roomState && (
        <PrivateBriefingScreen
          state={roomState}
          onProceed={handleAdvanceBriefing}
        />
      )}

      {currentScreen === 'dashboard' && roomState && (
        <>
          <InvestigationDashboard
            state={roomState}
            onAskQuestion={handleAskQuestion}
            onSubmitAnswer={handleSubmitAnswer}
            onReleaseSuspect={handleReleaseSuspect}
            onOpenFinalVerdict={() => setShowFinalVerdictModal(true)}
            onLeaveRoom={handleLeaveRoom}
          />

          {showFinalVerdictModal && (
            <FinalVerdictModal
              state={roomState}
              onSubmitVerdict={handleSubmitFinalVerdict}
              onClose={() => setShowFinalVerdictModal(false)}
            />
          )}
        </>
      )}

      {currentScreen === 'outcome' && roomState && (
        <CaseOutcomeScreen
          state={roomState}
          onRestart={handleRestart}
          onBackToHome={handleLeaveRoom}
        />
      )}
    </div>
  );
};
