import React, { useState } from 'react';
import { Bot, Users, UserCheck, ChevronLeft, ArrowRight, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { GameMode, PlayerCountOption } from '../types/shadowDetective';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface ModeSelectScreenProps {
  onSelectMode: (mode: GameMode, playerCount: PlayerCountOption, hostName: string) => void;
  onJoinRoom?: (roomCode: string, playerName: string) => void;
  onBack: () => void;
}

export const ModeSelectScreen: React.FC<ModeSelectScreenProps> = ({ onSelectMode, onJoinRoom, onBack }) => {
  const [activeTab, setActiveTab] = useState<'create' | 'join'>('create');
  const [selectedMode, setSelectedMode] = useState<GameMode>('ai_solo');
  const [playerCount, setPlayerCount] = useState<PlayerCountOption>(5);
  const [playerName, setPlayerName] = useState('রবিন');
  const [joinRoomCode, setJoinRoomCode] = useState('');

  const modes: Array<{
    id: GameMode;
    titleBn: string;
    subtitleBn: string;
    descriptionBn: string;
    icon: React.ReactNode;
    badgeBn: string;
    accentColor: string;
  }> = [
    {
      id: 'ai_solo',
      titleBn: 'একক গোয়েন্দা অভিযান (AI Solo)',
      subtitleBn: 'রবিন বনাম নিশিপুরের ৫ জন এআই সন্দেহভাজন',
      descriptionBn: 'আপনি সরাসরি প্রধান গোয়েন্দা রবিনের ভূমিকা পালন করবেন। নিশিপুর থানার সকল সন্দেহভাজনকে স্বয়ংক্রিয় এআই নিয়ন্ত্রণ করবে।',
      icon: <Bot className="w-6 h-6 text-cyan-400" />,
      badgeBn: 'তাত্ক্ষণিক খেলা',
      accentColor: 'border-cyan-500/80 bg-cyan-950/20 text-cyan-300',
    },
    {
      id: 'human_ai_multiplayer',
      titleBn: 'বন্ধু + এআই মাল্টিপ্লেয়ার (Human + AI)',
      subtitleBn: 'বন্ধুদের সাথে খেলুন, বাকি আসনে এআই বট',
      descriptionBn: 'রুম কোড দিয়ে বন্ধুদের আমন্ত্রণ জানান। আসন খালি থাকলে বুদ্ধিদীপ্ত এআই বট যুক্ত করে ৫, ৭ বা ৯ জনের মামলা সাজান। কোনো বন্ধু অফলাইনে গেলে স্বয়ংক্রিয় বট দায়িত্ব নেবে।',
      icon: <UserCheck className="w-6 h-6 text-indigo-400" />,
      badgeBn: 'সবচেয়ে জনপ্রিয়',
      accentColor: 'border-indigo-500/80 bg-indigo-950/20 text-indigo-300',
    },
    {
      id: 'human_multiplayer',
      titleBn: 'অনলাইন রুম মাল্টিপ্লেয়ার (Human Only)',
      subtitleBn: 'শুধুমাত্র বন্ধুদের নিয়ে সামাজিক অনুসন্ধান',
      descriptionBn: 'রুম কোড শেয়ার করে বন্ধুদের সাথে যুক্ত হোন। প্রত্যেকে গোপন চরিত্র পেয়ে নিজেদের মধ্যে প্রশ্ন ও ব্লাফ চালাবেন।',
      icon: <Users className="w-6 h-6 text-amber-400" />,
      badgeBn: 'সম্পূর্ণ সামাজিক',
      accentColor: 'border-amber-500/80 bg-amber-950/20 text-amber-300',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#060c14] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-500 text-xs sm:text-sm font-bengali transition-all cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>পেছনে ফিরুন</span>
        </button>

        <span className="text-sm font-bold text-cyan-400 font-bengali">
          তদন্ত মোড ও খেলোয়াড় সংখ্যা
        </span>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-3xl mx-auto px-4 py-6 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div className="text-center mb-6">
          <h2 className="text-2xl sm:text-3xl font-black text-white font-bengali">
            {activeTab === 'create' ? 'তদন্তের ধরন নির্বাচন করুন' : 'তদন্তে অংশগ্রহণ করুন'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 font-bengali mt-1">
            {activeTab === 'create'
              ? 'আপনি কীভাবে নিশিপুরের মামলাটি তদন্ত করতে চান?'
              : 'বন্ধুর রুম কোড ও আপনার নাম দিয়ে তদন্তে যোগ দিন'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 p-1 bg-slate-900 border border-slate-800 rounded-2xl mb-6">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setActiveTab('create');
            }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bengali font-bold transition-all cursor-pointer ${
              activeTab === 'create'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            নতুন তদন্ত রুম তৈরি
          </button>
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setActiveTab('join');
            }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bengali font-bold transition-all cursor-pointer ${
              activeTab === 'join'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            রুম কোড দিয়ে যোগ দিন
          </button>
        </div>

        {/* Player Name Input */}
        <div className="mb-6 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
          <label className="block text-xs font-bold text-cyan-300 font-bengali mb-1.5">
            আপনার নাম / ডাকনাম:
          </label>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            placeholder="গোয়েন্দা রবিন"
            maxLength={20}
            className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-bengali text-sm focus:outline-none focus:border-cyan-400 transition-colors"
          />
        </div>

        {activeTab === 'join' ? (
          <div className="space-y-6 mb-6">
            <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
              <label className="block text-xs font-bold text-indigo-300 font-bengali mb-1.5">
                রুম কোড (Room Code):
              </label>
              <input
                type="text"
                value={joinRoomCode}
                onChange={(e) => setJoinRoomCode(e.target.value.toUpperCase())}
                placeholder="যেমন: SD-8472"
                maxLength={12}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm tracking-wider uppercase focus:outline-none focus:border-indigo-400 transition-colors"
              />
              <p className="text-[11px] text-slate-400 font-bengali mt-1.5">
                রুম হোস্টের কাছ থেকে পাওয়া কোডটি এখানে লিখুন।
              </p>
            </div>

            <button
              onClick={() => {
                if (!joinRoomCode.trim()) return;
                sound.playClick();
                if (onJoinRoom) {
                  onJoinRoom(joinRoomCode.trim(), playerName.trim() || 'গ্রামবাসী');
                }
              }}
              disabled={!joinRoomCode.trim()}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 via-blue-600 to-cyan-500 hover:from-indigo-400 hover:to-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-black text-base font-bengali shadow-xl shadow-indigo-500/25 transition-all cursor-pointer"
            >
              <span>তদন্তে যোগ দিন</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <>

        {/* Mode Cards */}
        <div className="space-y-3.5 mb-6">
          {modes.map((m) => {
            const isSelected = selectedMode === m.id;
            return (
              <div
                key={m.id}
                onClick={() => {
                  sound.playClick();
                  setSelectedMode(m.id);
                }}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  isSelected
                    ? m.accentColor + ' shadow-lg scale-[1.01]'
                    : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    {m.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-base text-white font-bengali">
                        {m.titleBn}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950 border border-slate-700 font-mono">
                        {m.badgeBn}
                      </span>
                    </div>
                    <p className="text-xs text-amber-300 font-bengali mt-0.5">
                      {m.subtitleBn}
                    </p>
                    <p className="text-xs text-slate-400 font-bengali mt-1.5 leading-relaxed">
                      {m.descriptionBn}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Player Count Selection (5, 7, 9) */}
        <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 mb-6">
          <label className="block text-xs font-bold text-slate-200 font-bengali mb-2">
            মোট চরিত্র ও খেলোয়াড় সংখ্যা:
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[5, 7, 9].map((cnt) => (
              <button
                key={cnt}
                type="button"
                onClick={() => {
                  sound.playClick();
                  setPlayerCount(cnt as PlayerCountOption);
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs sm:text-sm font-bengali font-bold transition-all ${
                  playerCount === cnt
                    ? 'border-cyan-400 bg-cyan-950/50 text-cyan-300 shadow-md'
                    : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                {cnt === 5 && '৫ জন (মৌলিক)'}
                {cnt === 7 && '৭ জন (বিস্তৃত)'}
                {cnt === 9 && '৯ জন (বৃহৎ)'}
              </button>
            ))}
          </div>
        </div>

        {/* Start / Proceed Button */}
        <button
          onClick={() => {
            sound.playClick();
            onSelectMode(selectedMode, playerCount, playerName.trim() || 'রবিন');
          }}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-black text-base font-bengali shadow-xl shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all cursor-pointer"
        >
          <span>
            {selectedMode === 'ai_solo' ? 'একক অভিযান শুরু করুন' : 'লবি তৈরি ও পরিচালনা করুন'}
          </span>
          <ArrowRight className="w-5 h-5" />
        </button>
        </>
        )}
      </main>

      <RIRahatFooter />
    </div>
  );
};
