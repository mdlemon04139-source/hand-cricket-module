import React, { useState } from 'react';
import {
  Users,
  Copy,
  Check,
  Bot,
  UserCheck,
  UserX,
  Play,
  ArrowRight,
  ChevronLeft,
  Crown,
  Wifi,
  WifiOff,
  AlertCircle,
  Plus,
} from 'lucide-react';
import { ShadowRoomClientState, ShadowPlayer } from '../types/shadowDetective';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface RoomLobbyScreenProps {
  state: ShadowRoomClientState;
  onAddBot: () => void;
  onToggleReady: () => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
  onChangeTargetCount?: (count: 5 | 7 | 9) => void;
}

export const RoomLobbyScreen: React.FC<RoomLobbyScreenProps> = ({
  state,
  onAddBot,
  onToggleReady,
  onStartGame,
  onLeaveRoom,
  onChangeTargetCount,
}) => {
  const [copied, setCopied] = useState(false);
  const isHost = state.myPlayer?.isHost;
  const canStart = state.players.length >= 3; // minimum 3 players or bots

  const handleCopyCode = () => {
    sound.playClick();
    navigator.clipboard.writeText(state.roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#060c14] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <button
          onClick={() => {
            sound.playClick();
            onLeaveRoom();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-500 text-xs sm:text-sm font-bengali transition-all cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>লবি ত্যাগ করুন</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-bengali hidden sm:inline">রুম কোড:</span>
          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/60 border border-cyan-500/50 text-cyan-300 font-mono font-bold text-sm tracking-wider hover:bg-cyan-900/60 transition-all cursor-pointer shadow"
          >
            <span>{state.roomCode}</span>
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 py-6 sm:px-8 w-full flex-1 flex flex-col justify-center">
        {/* Lobby Banner */}
        <div className="text-center mb-6">
          <h2 className="text-2xl sm:text-3xl font-black text-white font-bengali">
            নিশিপুর তদন্ত পরিষদ লবি
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 font-bengali mt-1">
            খেলোয়াড়দের একত্রিত করুন। প্রয়োজনমাফিক এআই বট যোগ করে তদন্ত শুরু করুন।
          </p>
        </div>

        {/* Player Roster Grid */}
        <div className="bg-slate-900/60 rounded-3xl p-5 border border-slate-800 backdrop-blur-md mb-6">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-white font-bengali">
                উপস্থিত সদস্যবৃন্দ ({state.players.length}/{state.targetPlayerCount})
              </h3>
            </div>

            {isHost && state.players.length < state.targetPlayerCount && (
              <button
                onClick={() => {
                  sound.playClick();
                  onAddBot();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-cyan-300 hover:border-cyan-400 text-xs font-bengali transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <Bot className="w-3.5 h-3.5" />
                <span>বট যোগ করুন</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {state.players.map((p) => {
              const isMe = p.id === state.myPlayerId;
              return (
                <div
                  key={p.id}
                  className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${
                    isMe
                      ? 'border-cyan-500/80 bg-cyan-950/20'
                      : 'border-slate-800 bg-slate-950/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-lg">
                      {p.avatar || '🕵️'}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-white font-bengali truncate max-w-[120px]">
                          {p.nickname}
                        </span>
                        {p.isHost && (
                          <span title="হোস্ট">
                            <Crown className="w-3.5 h-3.5 text-amber-400" />
                          </span>
                        )}
                      </div>

                      {/* Online / Offline Status Badge */}
                      <div className="flex items-center gap-1 mt-0.5">
                        {p.isOnline ? (
                          <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
                            সক্রিয় (Online)
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[10px] text-amber-400 font-mono">
                            <WifiOff className="w-3 h-3 text-amber-400" />
                            অফলাইন (বট বিকল্প)
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    {p.isReady ? (
                      <span className="text-xs px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-bengali font-bold">
                        প্রস্তুত
                      </span>
                    ) : (
                      <span className="text-xs px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-slate-400 font-bengali">
                        অপেক্ষমান
                      </span>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Empty slots placeholders */}
            {Array.from({ length: Math.max(0, state.targetPlayerCount - state.players.length) }).map(
              (_, idx) => (
                <div
                  key={`empty_${idx}`}
                  className="p-3 rounded-2xl border border-dashed border-slate-800 bg-slate-950/30 flex items-center justify-center text-slate-600 text-xs font-bengali"
                >
                  খালি আসন (বট বা খেলোয়াড়)
                </div>
              )
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              onToggleReady();
            }}
            className={`w-full sm:w-1/2 py-3 rounded-2xl font-bold font-bengali text-sm border transition-all cursor-pointer ${
              state.myPlayer?.isReady
                ? 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
                : 'bg-cyan-950/60 border-cyan-500 text-cyan-300 hover:bg-cyan-900/60'
            }`}
          >
            {state.myPlayer?.isReady ? 'প্রস্তুতি বাতিল করুন' : 'আমি প্রস্তুত (Ready)'}
          </button>

          {isHost ? (
            <button
              onClick={() => {
                sound.playClick();
                onStartGame();
              }}
              className="w-full sm:w-1/2 flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-black text-sm font-bengali shadow-xl shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>তদন্ত শুরু করুন (Start Game)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <div className="w-full sm:w-1/2 text-center text-xs text-slate-400 font-bengali py-3">
              হোস্টের খেলা শুরুর অপেক্ষায়...
            </div>
          )}
        </div>
      </main>

      <RIRahatFooter />
    </div>
  );
};
