import React, { useState } from 'react';
import { BookOpen, ChevronLeft, ChevronRight, ArrowRight, Compass, ShieldAlert, Sparkles } from 'lucide-react';
import { ShadowRoomClientState } from '../types/shadowDetective';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface StoryIntroScreenProps {
  state: ShadowRoomClientState;
  onProceed: () => void;
}

export const StoryIntroScreen: React.FC<StoryIntroScreenProps> = ({ state, onProceed }) => {
  const [currentPage, setCurrentPage] = useState(0);

  const pages = state.caseOverview?.shortPublicStoryPages || [
    'নিশিপুর গ্রামে আজ এক গভীর অন্ধকার নেমে এসেছে। এক চাঞ্চল্যকর ঘটনা পুরো গ্রামের শান্তি বিনষ্ট করেছে...',
  ];

  const totalPages = pages.length;
  const isLastPage = currentPage === totalPages - 1;

  const playFlipSound = () => {
    try {
      if (typeof sound?.playCardFlip === 'function') {
        sound.playCardFlip();
      } else if (typeof sound?.playCardDeal === 'function') {
        sound.playCardDeal();
      } else if (typeof sound?.playClick === 'function') {
        sound.playClick();
      }
    } catch {
      // safe fallback
    }
  };

  const handleNext = () => {
    playFlipSound();
    if (!isLastPage) {
      setCurrentPage((p) => p + 1);
    } else {
      onProceed();
    }
  };

  const handlePrev = () => {
    playFlipSound();
    if (currentPage > 0) {
      setCurrentPage((p) => p - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#070e17] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Dossier Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-amber-400" />
          <span className="font-bold text-sm text-white font-bengali">
            নিশিপুর থানা কেস ফাইল #{state.caseOverview?.caseId.slice(-6).toUpperCase() || 'DOSSIER'}
          </span>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onProceed();
          }}
          className="text-xs text-slate-400 hover:text-cyan-300 font-bengali underline cursor-pointer"
        >
          সরাসরি তদন্তে যান (Skip)
        </button>
      </header>

      {/* Main Storybook Container */}
      <main className="relative z-10 max-w-3xl mx-auto px-4 py-8 sm:px-8 w-full flex-1 flex flex-col justify-center">
        {/* Story Dossier Card */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-b from-[#161f2c] via-[#0d141e] to-slate-950 border-2 border-amber-500/50 shadow-2xl shadow-amber-500/10 p-6 sm:p-10 flex flex-col justify-between min-h-[420px]">
          {/* Case Meta Badges */}
          <div>
            <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
              <span className="text-xs px-2.5 py-1 rounded-md bg-amber-950/70 border border-amber-500/40 text-amber-300 font-mono font-bold">
                {state.caseOverview?.categoryNameBn || 'অপরাধ তদন্ত'}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                পৃষ্ঠা {currentPage + 1} / {totalPages}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-amber-200 font-bengali tracking-tight">
              {state.caseOverview?.titleBn || 'নিশিপুরের রহস্যময় ঘটনা'}
            </h1>
            <div className="flex items-center gap-3 text-xs text-slate-400 font-bengali mt-1">
              <span>ঘটনাস্থল: {state.caseOverview?.locationNameBn || 'নিশিপুর'}</span>
              <span>•</span>
              <span>সময়: {state.caseOverview?.incidentTimeBn || 'মধ্যরাত'}</span>
            </div>
          </div>

          {/* Current Page Text */}
          <div className="my-6 bg-slate-950/60 p-5 sm:p-6 rounded-2xl border border-slate-800 text-sm sm:text-base text-slate-200 font-bengali leading-relaxed shadow-inner">
            {pages[currentPage]}
          </div>

          {/* Story Navigation Controls */}
          <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-4">
            <button
              onClick={handlePrev}
              disabled={currentPage === 0}
              className={`flex items-center gap-1 px-4 py-2 rounded-xl text-xs sm:text-sm font-bengali font-semibold transition-all ${
                currentPage === 0
                  ? 'text-slate-600 bg-slate-900/40 cursor-not-allowed'
                  : 'text-slate-300 bg-slate-900 border border-slate-700 hover:text-white hover:border-slate-500 cursor-pointer'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
              <span>পূর্ববর্তী পাতা</span>
            </button>

            {/* Page Dots */}
            <div className="flex items-center gap-1.5">
              {pages.map((_, idx) => (
                <div
                  key={idx}
                  className={`w-2 h-2 rounded-full transition-all ${
                    idx === currentPage ? 'w-6 bg-amber-400' : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={handleNext}
              className="flex items-center gap-1 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm font-bengali shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              <span>{isLastPage ? 'গোপন ব্রিফিংয়ে যান' : 'পরবর্তী পাতা'}</span>
              {isLastPage ? <ArrowRight className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </main>

      <RIRahatFooter />
    </div>
  );
};
