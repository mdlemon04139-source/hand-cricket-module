import React from 'react';

export const RIRahatFooter: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <footer
      className={`relative z-20 px-4 py-3 border-t border-slate-800/80 bg-slate-950/80 text-center text-xs text-slate-400 font-bengali flex items-center justify-center gap-2 ${className}`}
    >
      <span>শ্যাডো ডিটেক্টিভ: নিশিপুর</span>
      <span className="text-slate-600">•</span>
      <span>খেলাঘর গেমিং প্ল্যাটফর্ম</span>
      <span className="text-slate-600">•</span>
      <span className="font-semibold text-cyan-400 font-mono tracking-wide">RI Rahat</span>
    </footer>
  );
};
