import React, { useState } from 'react';
import {
  Search,
  MessageSquare,
  HelpCircle,
  AlertTriangle,
  UserCheck,
  UserX,
  Compass,
  FileText,
  Sparkles,
  Shield,
  Clock,
  Send,
  X,
  CheckCircle,
  Eye,
  Gavel,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  ShadowRoomClientState,
  CaseQuestion,
  CaseEvidenceItem,
  VerifiedStatement,
} from '../types/shadowDetective';
import { NISHIPUR_CHARACTERS, NishipurCharacter } from '../../data/nishipurCharacters';
import { CASE_QUESTIONS_CATALOG } from '../engine/caseGenerator';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface InvestigationDashboardProps {
  state: ShadowRoomClientState;
  onAskQuestion: (targetSuspectId: string, questionId: string) => void;
  onSubmitAnswer: (characterId: string, answerText: string) => void;
  onReleaseSuspect: (suspectId: string) => void;
  onOpenFinalVerdict: () => void;
  onLeaveRoom: () => void;
}

export const InvestigationDashboard: React.FC<InvestigationDashboardProps> = ({
  state,
  onAskQuestion,
  onSubmitAnswer,
  onReleaseSuspect,
  onOpenFinalVerdict,
  onLeaveRoom,
}) => {
  const isRobin = state.myPlayer?.assignedRole === 'robin';
  const myCharacterId = state.myPlayer?.characterId;

  // Modals state
  const [selectedSuspectForQuestion, setSelectedSuspectForQuestion] = useState<string | null>(null);
  const [selectedQuestion, setSelectedQuestion] = useState<CaseQuestion | null>(null);
  const [showReleaseModal, setShowReleaseModal] = useState(false);
  const [selectedReleaseSuspectId, setSelectedReleaseSuspectId] = useState<string | null>(null);
  const [inspectEvidence, setInspectEvidence] = useState<CaseEvidenceItem | null>(null);
  const [activeTab, setActiveTab] = useState<'suspects' | 'evidence' | 'statements' | 'logs'>('suspects');

  const isReleasePhase =
    state.phase === 'PHASE_1_RELEASE' ||
    state.phase === 'PHASE_2_RELEASE' ||
    state.phase === 'PHASE_3_RELEASE';

  // Check if I am the active suspect being questioned
  const isMeBeingQuestioned =
    state.activeInterrogation &&
    state.activeInterrogation.waitingForAnswer &&
    state.activeInterrogation.targetSuspectId === myCharacterId;

  const currentPhaseTitle = () => {
    switch (state.phase) {
      case 'PHASE_1_INTERROGATION':
        return 'পর্যায় ১: প্রাথমিক জিজ্ঞাসাবাদ (৫টি প্রশ্ন)';
      case 'PHASE_1_RELEASE':
        return 'পর্যায় ১: ১ম সন্দেহভাজনকে বাধ্যতামূলক মুক্তি প্রদান';
      case 'PHASE_2_INTERROGATION':
        return 'পর্যায় ২: বৈপরীত্য ও গভীর জবানবন্দি (৩টি প্রশ্ন)';
      case 'PHASE_2_RELEASE':
        return 'পর্যায় ২: ২য় সন্দেহভাজনকে বাধ্যতামূলক মুক্তি প্রদান';
      case 'PHASE_3_TUHA':
        return 'পর্যায় ৩: সহকারী তুহার ফরেনসিক রিপোর্ট ও অন্তিম প্রশ্ন';
      case 'PHASE_3_RELEASE':
        return 'পর্যায় ৩: শেষ ২ জন চূড়ান্ত সন্দেহভাজন নির্ধারণ';
      case 'FINAL_VERDICT':
        return 'চূড়ান্ত পর্যায়: নিশিপুরের চূড়ান্ত রায় (Final Verdict)';
      default:
        return 'তদন্ত সক্রিয়';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#070e17] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Top Navigation & Status Bar */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              onLeaveRoom();
            }}
            className="text-xs px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white font-bengali cursor-pointer"
          >
            প্রস্থান
          </button>
          <div>
            <h1 className="text-sm sm:text-base font-black text-white font-bengali flex items-center gap-2">
              <span className="text-cyan-400">শ্যাডো ডিটেক্টিভ: নিশিপুর</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono">
                {state.caseOverview?.titleBn}
              </span>
            </h1>
          </div>
        </div>

        {/* Phase Badges & Question Counter */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900 border border-cyan-500/40 text-xs font-bengali text-cyan-300">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{currentPhaseTitle()}</span>
          </div>

          {!isReleasePhase && state.phase !== 'FINAL_VERDICT' && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-950/70 border border-amber-500/40 text-xs font-mono font-bold text-amber-300">
              <span>প্রশ্ন বাকি: {state.questionsRemainingInPhase}</span>
            </div>
          )}

          {state.phase === 'FINAL_VERDICT' && (
            <button
              onClick={() => {
                sound.playClick();
                onOpenFinalVerdict();
              }}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 text-slate-950 font-black text-xs font-bengali animate-pulse cursor-pointer shadow-lg"
            >
              <Gavel className="w-4 h-4" />
              <span>চূড়ান্ত রায় ঘোষণা করুন</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Investigation Area */}
      <main className="relative z-10 max-w-6xl mx-auto px-4 py-4 sm:px-8 w-full flex-1 flex flex-col">
        {/* Active Interrogation Status Banner */}
        {state.activeInterrogation && state.activeInterrogation.waitingForAnswer && (
          <div className="mb-4 p-4 rounded-2xl bg-cyan-950/60 border border-cyan-500/50 flex items-center gap-3 animate-pulse shadow-lg">
            <div className="w-9 h-9 rounded-xl bg-cyan-900/80 border border-cyan-400 flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5 text-cyan-300 animate-bounce" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-cyan-200 font-bengali">
                জিজ্ঞাসাবাদ চলছে... {NISHIPUR_CHARACTERS[state.activeInterrogation.targetSuspectId]?.nameBn || 'সন্দেহভাজন'} জবানবন্দি চিন্তা করছেন
              </h4>
              <p className="text-xs text-slate-300 font-bengali italic mt-0.5">
                প্রশ্ন: "{state.activeInterrogation.question.promptBn}"
              </p>
            </div>
          </div>
        )}

        {/* Final Verdict Action Prompt Banner */}
        {state.phase === 'FINAL_VERDICT' && isRobin && (
          <div className="mb-4 p-5 rounded-3xl bg-gradient-to-r from-rose-950/80 via-slate-900 to-amber-950/80 border-2 border-rose-500/80 shadow-2xl flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <Gavel className="w-8 h-8 text-rose-400 shrink-0 animate-bounce" />
              <div>
                <h4 className="font-black text-rose-300 text-base font-bengali">
                  তদন্তের অন্তিম মুহূর্ত: চূড়ান্ত রায় ঘোষণা করুন!
                </h4>
                <p className="text-xs text-slate-300 font-bengali mt-0.5">
                  সকল জিজ্ঞাসাবাদ ও আলামতের ভিত্তিতে শেষ ২ জন সন্দেহভাজনের মধ্যে আসল অপরাধীকে চিহ্নিত করুন।
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onOpenFinalVerdict();
              }}
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 font-black text-xs sm:text-sm font-bengali shadow-xl shadow-rose-500/30 cursor-pointer transition-all"
            >
              রায় ঘোষণা করুন
            </button>
          </div>
        )}

        {/* Release Phase Alert Banner */}
        {isReleasePhase && isRobin && (
          <div className="mb-4 p-4 rounded-2xl bg-amber-950/50 border-2 border-amber-500/60 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
              <div>
                <h4 className="font-bold text-amber-300 text-sm font-bengali">
                  বাধ্যতামূলক সন্দেহভাজন মুক্তি পর্যায়
                </h4>
                <p className="text-xs text-slate-300 font-bengali mt-0.5">
                  পরবর্তী ধাপে যেতে ১ জন সন্দেহভাজনকে মুক্তি দিন।
                  <span className="text-rose-400 font-bold ml-1">
                    (সতর্কতা: আসল অপরাধীকে মুক্তি দিলে তাৎক্ষণিক পরাজয় ঘটবে!)
                  </span>
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                setShowReleaseModal(true);
              }}
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs font-bengali shadow-md cursor-pointer"
            >
              সন্দেহভাজন মুক্তি দিন
            </button>
          </div>
        )}

        {/* Tuha Assistance Banner (Phase 3) */}
        {state.tuhaAssistance && (
          <div className="mb-4 p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/40 flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-indigo-400 shrink-0">
              <img
                src="/assets/aistudio/Tuha__the_Field_Assistant_7620c696.png"
                alt="তুহা"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-indigo-300 font-bengali">
                  সহকারী তুহার ফরেনসিক বিশ্লেষণ রিপোর্ট
                </span>
                <span className="text-[10px] px-2 py-0.2 rounded bg-indigo-900 text-indigo-200 font-mono">
                  Phase 3 Forensic Intel
                </span>
              </div>
              <p className="text-xs text-slate-200 font-bengali mt-1">
                <strong>ইঙ্গিত:</strong> {state.tuhaAssistance.hintBn}
              </p>
              <p className="text-xs text-cyan-300 font-bengali mt-0.5">
                <strong>ল্যাব বিশ্লেষণ:</strong> {state.tuhaAssistance.evidenceAnalysisBn}
              </p>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 mb-4">
          <button
            onClick={() => setActiveTab('suspects')}
            className={`px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bengali font-bold transition-all ${
              activeTab === 'suspects'
                ? 'bg-cyan-500 text-slate-950'
                : 'text-slate-400 hover:text-white bg-slate-900/50'
            }`}
          >
            সক্রিয় সন্দেহভাজন ({state.activeSuspectIds.length})
          </button>
          <button
            onClick={() => setActiveTab('evidence')}
            className={`px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bengali font-bold transition-all ${
              activeTab === 'evidence'
                ? 'bg-cyan-500 text-slate-950'
                : 'text-slate-400 hover:text-white bg-slate-900/50'
            }`}
          >
            আলামত ও সূত্র ({state.evidenceNotebook.publicEvidence.length})
          </button>
          <button
            onClick={() => setActiveTab('statements')}
            className={`px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bengali font-bold transition-all ${
              activeTab === 'statements'
                ? 'bg-cyan-500 text-slate-950'
                : 'text-slate-400 hover:text-white bg-slate-900/50'
            }`}
          >
            রেকর্ডকৃত জবানবন্দি ({state.evidenceNotebook.verifiedStatements.length})
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bengali font-bold transition-all ${
              activeTab === 'logs'
                ? 'bg-cyan-500 text-slate-950'
                : 'text-slate-400 hover:text-white bg-slate-900/50'
            }`}
          >
            তদন্ত ডায়েরি (Logs)
          </button>
        </div>

        {/* Tab 1: Suspects Grid */}
        {activeTab === 'suspects' && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3.5 flex-1">
            {state.activeSuspectIds.map((charId) => {
              const char = NISHIPUR_CHARACTERS[charId];
              if (!char) return null;

              const player = state.players.find((p) => p.characterId === charId);
              const isOffline = player && !player.isOnline;

              return (
                <div
                  key={charId}
                  className="rounded-2xl overflow-hidden border-2 border-slate-700 bg-slate-900/80 flex flex-col justify-between shadow-lg relative group hover:border-cyan-400 transition-all"
                >
                  {/* Card Image */}
                  <div className="relative aspect-[3/4] w-full overflow-hidden bg-slate-950">
                    <img
                      src={char.image}
                      alt={char.nameBn}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
                  </div>



                  {/* Character Meta & Interrogate Button */}
                  <div className="p-3 bg-slate-950 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-white font-bengali truncate">
                        {char.nameBn}
                      </h4>
                      <p className="text-[11px] text-amber-400 font-bengali truncate mt-0.5">
                        {char.roleBn}
                      </p>
                    </div>

                    {isRobin && !isReleasePhase && state.questionsRemainingInPhase > 0 && (
                      <button
                        disabled={state.activeInterrogation?.waitingForAnswer}
                        onClick={() => {
                          sound.playClick();
                          setSelectedSuspectForQuestion(charId);
                        }}
                        className={`mt-3 w-full py-1.5 rounded-xl font-bold text-xs font-bengali transition-all flex items-center justify-center gap-1 shadow ${
                          state.activeInterrogation?.waitingForAnswer
                            ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                            : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer'
                        }`}
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>
                          {state.activeInterrogation?.waitingForAnswer ? 'অপেক্ষা করুন...' : 'জিজ্ঞাসাবাদ'}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 2: Evidence List */}
        {activeTab === 'evidence' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {state.evidenceNotebook.publicEvidence.map((ev) => (
              <div
                key={ev.id}
                onClick={() => setInspectEvidence(ev)}
                className="p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/30 hover:border-cyan-400 cursor-pointer transition-all shadow-md"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40">
                    {ev.category}
                  </span>
                  <span className="text-xs text-slate-400 font-bengali">
                    {ev.locationFoundBn}
                  </span>
                </div>
                <h4 className="font-bold text-base text-white font-bengali">
                  {ev.nameBn}
                </h4>
                <p className="text-xs text-slate-300 font-bengali mt-1 line-clamp-2">
                  {ev.descriptionBn}
                </p>
                <p className="text-xs text-amber-300 font-bengali mt-2 font-semibold">
                  প্রাসঙ্গিকতা: {ev.relevanceBn}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: Verified Statements */}
        {activeTab === 'statements' && (
          <div className="space-y-3">
            {state.evidenceNotebook.verifiedStatements.length === 0 ? (
              <div className="text-center py-10 text-slate-500 font-bengali text-sm">
                এখনো কোনো জবানবন্দি রেকর্ড করা হয়নি। সন্দেহভাজনদের জিজ্ঞাসাবাদ শুরু করুন।
              </div>
            ) : (
              state.evidenceNotebook.verifiedStatements.map((stmt) => (
                <div
                  key={stmt.id}
                  className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-cyan-300 text-sm font-bengali">
                      {stmt.suspectNameBn}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      পর্যায় {stmt.recordedPhase}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 font-bengali mb-1 italic">
                    প্রশ্ন: "{stmt.questionPromptBn}"
                  </p>
                  <p className="text-xs sm:text-sm text-slate-200 font-bengali leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                    "{stmt.answerTextBn}"
                  </p>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 4: Logs */}
        {activeTab === 'logs' && (
          <div className="bg-slate-950/80 rounded-2xl p-4 border border-slate-800 space-y-2 max-h-[60vh] overflow-y-auto">
            {state.gameLogs.map((log) => (
              <div
                key={log.id}
                className="text-xs font-bengali text-slate-300 flex items-start gap-2 border-b border-slate-900 pb-1.5"
              >
                <span className="text-slate-600 font-mono shrink-0">
                  {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                <span>{log.textBn}</span>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Interrogation Question Picker Modal (For Robin) */}
      {selectedSuspectForQuestion && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-lg w-full bg-slate-900 border-2 border-cyan-500/80 rounded-3xl p-6 text-slate-200 shadow-2xl">
            <button
              onClick={() => setSelectedSuspectForQuestion(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold text-white font-bengali mb-1 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-cyan-400" />
              <span>
                জিজ্ঞাসাবাদ: {NISHIPUR_CHARACTERS[selectedSuspectForQuestion]?.nameBn}
              </span>
            </h3>
            <p className="text-xs text-slate-400 font-bengali mb-4">
              একটি উপযুক্ত প্রশ্ন নির্বাচন করুন যা তার জবানবন্দির সত্যতা যাচাই করবে:
            </p>

            <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
              {CASE_QUESTIONS_CATALOG.filter(
                (q) => q.phaseAllowed <= state.currentPhaseNumber
              ).map((q) => (
                <div
                  key={q.id}
                  onClick={() => setSelectedQuestion(q)}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    selectedQuestion?.id === q.id
                      ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                      : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <span className="text-xs font-bold font-bengali block mb-1 text-cyan-300">
                    {q.labelBn}
                  </span>
                  <p className="text-xs font-bengali">{q.promptBn}</p>
                </div>
              ))}
            </div>

            <div className="mt-5 pt-4 border-t border-slate-800 flex justify-end gap-3">
              <button
                onClick={() => setSelectedSuspectForQuestion(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bengali text-xs"
              >
                বাতিল
              </button>
              <button
                disabled={!selectedQuestion}
                onClick={() => {
                  if (selectedQuestion) {
                    sound.playClick();
                    onAskQuestion(selectedSuspectForQuestion, selectedQuestion.id);
                    setSelectedSuspectForQuestion(null);
                    setSelectedQuestion(null);
                  }
                }}
                className={`px-5 py-2 rounded-xl font-bold font-bengali text-xs transition-all ${
                  selectedQuestion
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer shadow-md'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                প্রশ্ন পেশ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Human Suspect Answer Selection Modal */}
      {isMeBeingQuestioned && state.activeInterrogation && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-lg w-full bg-slate-900 border-2 border-amber-500 rounded-3xl p-6 text-slate-200 shadow-2xl">
            <h3 className="text-lg font-bold text-amber-300 font-bengali mb-2 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-amber-400" />
              <span>গোয়েন্দা রবিন আপনাকে প্রশ্ন করেছেন!</span>
            </h3>

            <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-700 text-sm font-bengali text-white mb-4">
              "{state.activeInterrogation.question.promptBn}"
            </div>

            <p className="text-xs text-slate-300 font-bengali mb-3">
              আপনার উত্তর নির্বাচন করুন:
            </p>

            <div className="space-y-2.5">
              {state.activeInterrogation.availableAnswers?.map((ans, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    sound.playClick();
                    onSubmitAnswer(myCharacterId!, ans);
                  }}
                  className="w-full text-left p-3.5 rounded-2xl border border-slate-700 bg-slate-950 hover:border-amber-400 hover:bg-amber-950/20 text-xs sm:text-sm font-bengali text-slate-200 transition-all cursor-pointer"
                >
                  {ans}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Mandatory Release Suspect Modal */}
      {showReleaseModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-md w-full bg-slate-900 border-2 border-rose-500/80 rounded-3xl p-6 text-slate-200 shadow-2xl">
            <button
              onClick={() => setShowReleaseModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold text-rose-300 font-bengali mb-1 flex items-center gap-2">
              <UserX className="w-5 h-5 text-rose-400" />
              <span>সন্দেহভাজন মুক্তি প্রদান</span>
            </h3>
            <p className="text-xs text-slate-300 font-bengali mb-4 leading-relaxed">
              আপনি কাকে নির্দোষ মনে করে নিশিপুর থানা থেকে মুক্তি দিতে চান?
              <br />
              <strong className="text-rose-400">
                ⚠️ চূড়ান্ত সতর্কতা: ভুলবশত আসল অপরাধীকে মুক্তি দিলে সে নিশিপুর সীমান্ত দিয়ে পালিয়ে যাবে এবং আপনি তাৎক্ষণিকভাবে পরাজিত হবেন!
              </strong>
            </p>

            <div className="space-y-2 mb-5">
              {state.activeSuspectIds.map((cid) => {
                const char = NISHIPUR_CHARACTERS[cid];
                if (!char) return null;
                const isSelected = selectedReleaseSuspectId === cid;

                return (
                  <div
                    key={cid}
                    onClick={() => setSelectedReleaseSuspectId(cid)}
                    className={`p-3 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${
                      isSelected
                        ? 'border-rose-400 bg-rose-950/30 text-white'
                        : 'border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0">
                      <img src={char.image} alt={char.nameBn} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm font-bengali">{char.nameBn}</h4>
                      <p className="text-[11px] text-amber-400 font-bengali">{char.roleBn}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowReleaseModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bengali text-xs"
              >
                বাতিল
              </button>
              <button
                disabled={!selectedReleaseSuspectId}
                onClick={() => {
                  if (selectedReleaseSuspectId) {
                    sound.playClick();
                    onReleaseSuspect(selectedReleaseSuspectId);
                    setShowReleaseModal(false);
                    setSelectedReleaseSuspectId(null);
                  }
                }}
                className={`px-5 py-2 rounded-xl font-bold font-bengali text-xs transition-all ${
                  selectedReleaseSuspectId
                    ? 'bg-rose-500 hover:bg-rose-400 text-white cursor-pointer shadow-md'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                মুক্তি নিশ্চিত করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Evidence Inspect Modal */}
      {inspectEvidence && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-md w-full bg-slate-900 border-2 border-cyan-500/70 rounded-3xl p-6 text-slate-200 shadow-2xl">
            <button
              onClick={() => setInspectEvidence(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
              {inspectEvidence.category}
            </span>
            <h3 className="text-xl font-bold text-white font-bengali mt-1">
              {inspectEvidence.nameBn}
            </h3>
            <p className="text-xs text-slate-400 font-bengali mt-0.5">
              প্রাপ্তিস্থান: {inspectEvidence.locationFoundBn}
            </p>

            <div className="mt-4 bg-slate-950/70 p-4 rounded-2xl border border-slate-800 text-xs sm:text-sm text-slate-200 font-bengali leading-relaxed">
              {inspectEvidence.descriptionBn}
            </div>

            <p className="mt-3 text-xs text-amber-300 font-bengali">
              <strong>তদন্তে প্রভাব:</strong> {inspectEvidence.relevanceBn}
            </p>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setInspectEvidence(null)}
                className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs font-bengali hover:bg-cyan-400"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      <RIRahatFooter />
    </div>
  );
};
