import React, { useEffect } from 'react';
import {
  Trophy,
  AlertOctagon,
  RotateCcw,
  Home,
  CheckCircle,
  XCircle,
  Clock,
  Sparkles,
  ArrowRight,
  BookOpen,
  Eye,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ShadowRoomClientState } from '../types/shadowDetective';
import { NISHIPUR_CHARACTERS } from '../../data/nishipurCharacters';
import { sound } from '../../utils/sound';
import { RIRahatFooter } from './RIRahatFooter';

interface CaseOutcomeScreenProps {
  state: ShadowRoomClientState;
  onRestart: () => void;
  onBackToHome: () => void;
}

export const CaseOutcomeScreen: React.FC<CaseOutcomeScreenProps> = ({
  state,
  onRestart,
  onBackToHome,
}) => {
  const result = state.finalVerdictResult;
  const isVictory = result?.isVictory ?? false;
  const culpritId = result?.trueCulpritId || 'kalu_chor';
  const culpritChar = NISHIPUR_CHARACTERS[culpritId];

  useEffect(() => {
    if (isVictory) {
      sound.playVictory();
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } else {
      sound.playDefeat();
    }
  }, [isVictory]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#070e17] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <span className="text-xs font-bold text-slate-400 font-bengali">
          মামলার অন্তিম প্রতিবেদন ও নিষ্পত্তি
        </span>
        <button
          onClick={() => {
            sound.playClick();
            onBackToHome();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-xs font-bengali transition-all cursor-pointer"
        >
          <Home className="w-3.5 h-3.5" />
          <span>প্রধান মেনু</span>
        </button>
      </header>

      {/* Main Container */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 py-8 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div
          className={`rounded-3xl border-2 p-6 sm:p-10 shadow-2xl relative overflow-hidden ${
            isVictory
              ? 'border-emerald-500/80 bg-gradient-to-b from-[#0a201b] via-[#081512] to-slate-950 shadow-emerald-500/20'
              : 'border-rose-500/80 bg-gradient-to-b from-[#250d12] via-[#16070a] to-slate-950 shadow-rose-500/20'
          }`}
        >
          {/* Status Banner */}
          <div className="text-center mb-6">
            <div
              className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-mono font-bold uppercase mb-3 ${
                isVictory
                  ? 'bg-emerald-950 border border-emerald-500/60 text-emerald-300'
                  : 'bg-rose-950 border border-rose-500/60 text-rose-300'
              }`}
            >
              {isVictory ? <Trophy className="w-4 h-4" /> : <AlertOctagon className="w-4 h-4" />}
              <span>{isVictory ? 'CASE SOLVED • VICTORY' : 'CASE COMPROMISED • DEFEAT'}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white font-bengali">
              {isVictory
                ? 'অভিনন্দন! নিশিপুরের রহস্য সফলভাবে উন্মোচিত হয়েছে!'
                : 'তদন্ত ব্যর্থ! নিশিপুরের আসল অপরাধী পালিয়ে গেছে!'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-2 max-w-xl mx-auto leading-relaxed">
              {result?.finalCaseExplanationBn}
            </p>
          </div>

          {/* Culprit Card & Details */}
          <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800 mb-6 flex flex-col sm:flex-row items-center gap-6">
            <div className="w-32 h-44 sm:w-36 sm:h-48 rounded-xl overflow-hidden border-2 border-amber-400 shrink-0 shadow-lg">
              <img src={culpritChar?.image} alt={culpritChar?.nameBn} className="w-full h-full object-cover" />
            </div>

            <div className="flex-1 text-center sm:text-left">
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-500/30">
                আসল অপরাধী (The Culprit)
              </span>
              <h3 className="text-2xl font-black text-white font-bengali mt-1">
                {culpritChar?.nameBn}
              </h3>
              <p className="text-xs text-amber-400 font-bengali font-semibold mt-0.5">
                {culpritChar?.roleBn}
              </p>

              <div className="mt-3 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-xs font-bold text-cyan-300 font-bengali block mb-1">
                  অপরাধের মূল উদ্দেশ্য (Motive):
                </span>
                <p className="text-xs text-slate-200 font-bengali leading-relaxed">
                  {result?.motiveBn}
                </p>
              </div>
            </div>
          </div>

          {/* Timeline & Key Contradictions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            {/* Timeline */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <h4 className="text-xs font-bold text-amber-300 font-bengali mb-2 flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>অপরাধের সময়রেখা (Timeline)</span>
              </h4>
              <ul className="space-y-1.5">
                {result?.timelineBn.map((t, idx) => (
                  <li key={idx} className="text-xs text-slate-300 font-bengali flex items-start gap-2">
                    <span className="text-amber-400 font-mono font-bold">•</span>
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contradictions */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <h4 className="text-xs font-bold text-cyan-300 font-bengali mb-2 flex items-center gap-1.5">
                <Eye className="w-4 h-4" />
                <span>ধরা পড়ার মূল সূত্র ও বৈপরীত্য</span>
              </h4>
              <ul className="space-y-1.5">
                {result?.keyContradictionsBn.map((c, idx) => (
                  <li key={idx} className="text-xs text-slate-300 font-bengali flex items-start gap-2">
                    <span className="text-cyan-400 font-mono font-bold">✓</span>
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Replay Actions */}
          <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-4 flex-wrap">
            <button
              onClick={() => {
                sound.playClick();
                onBackToHome();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 hover:text-white font-bengali text-xs transition-all cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>প্রধান মেনু</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                onRestart();
              }}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm font-bengali shadow-xl shadow-cyan-500/25 transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>নতুন মামলা শুরু করুন</span>
            </button>
          </div>
        </div>
      </main>

      <RIRahatFooter />
    </div>
  );
};
