import { NISHIPUR_CHARACTERS, NishipurCharacter } from '../../data/nishipurCharacters';
import {
  NishipurCaseTruth,
  CaseCategory,
  CaseEvidenceItem,
  CaseQuestion,
  CaseCharacterStory,
  PlayerCountOption,
} from '../types/shadowDetective';

export const CASE_QUESTIONS_CATALOG: CaseQuestion[] = [
  {
    id: 'q_alibi_time',
    labelBn: 'মধ্যরাতের অবস্থান ও অ্যালিবাই',
    promptBn: 'ঘটনার সময় (রাত ১২টা থেকে ১টা) আপনি ঠিক কোথায় ছিলেন এবং আপনার সঙ্গে কে ছিল?',
    phaseAllowed: 1,
  },
  {
    id: 'q_relationship',
    labelBn: 'ভুক্তভোগী ও সম্পর্কের দ্বন্দ্ব',
    promptBn: 'ভুক্তভোগী বা সংশ্লিষ্ট সম্পত্তির সাথে আপনার ব্যক্তিগত সম্পর্কের প্রকৃতি কেমন ছিল?',
    phaseAllowed: 1,
  },
  {
    id: 'q_suspicious_sightings',
    labelBn: 'ঘটনাস্থলের আলো, শব্দ ও ছায়া',
    promptBn: 'ঘটনার রাতে নদীঘাট বা বাঁশঝাড়ের দিকে কোনো সন্দেহজনক আলো বা দৌড়ানোর শব্দ শুনতে পেয়েছিলেন কি?',
    phaseAllowed: 1,
  },
  {
    id: 'q_occupational_tools',
    labelBn: 'অস্ত্র, হাতিয়ার ও কাজের সরঞ্জাম',
    promptBn: 'ঘটনাস্থলে ফেলে যাওয়া ধাতব সরঞ্জাম, রাসায়নিক বা তারের সঙ্গে আপনার কাজের কোনো সংশ্লিষ্টতা আছে?',
    phaseAllowed: 2,
  },
  {
    id: 'q_contradiction_check',
    labelBn: 'জবানবন্দির বৈপরীত্য পরীক্ষা',
    promptBn: 'গ্রামবাসীদের সাক্ষ্যের সাথে আপনার দেওয়া সময়ের অমিল কেন দেখা যাচ্ছে? কিছু লুকাচ্ছেন কি?',
    phaseAllowed: 2,
  },
  {
    id: 'q_final_motive_pressure',
    labelBn: 'চূড়ান্ত চাপ ও গোপন উদ্দেশ্য',
    promptBn: 'তুহার ফরেনসিক রিপোর্ট আপনার দিকেই ইঙ্গিত করছে—আপনার কাছে আসল চাবি বা আলামত এল কীভাবে?',
    phaseAllowed: 3,
  },
];

interface CaseBlueprint {
  titleBn: string;
  category: CaseCategory;
  categoryNameBn: string;
  locationNameBn: string;
  incidentTimeBn: string;
  shortPublicStoryPages: string[];
  motiveTemplateBn: (culpritName: string) => string;
  evidenceItems: CaseEvidenceItem[];
  timeline: string[];
}

const BLUEPRINTS: CaseBlueprint[] = [
  {
    titleBn: 'নিশিপুর জমিদারের শতবর্ষী সিন্দুক ও বিষাক্ত আতর রহস্য',
    category: 'theft',
    categoryNameBn: 'প্রাচীন প্রত্নসম্পদ ও সিন্দুক চুরি',
    locationNameBn: 'মাতবরের প্রাচীন বৈঠকখানা ও জমিদার ভবনের ধ্বংসাবশেষ',
    incidentTimeBn: 'অমাবস্যার মধ্যরাত ১২:১৫ মিনিট',
    shortPublicStoryPages: [
      'নিশিপুর গ্রামের অন্যতম প্রাচীন ঐতিহ্য শতবর্ষী জমিদার ভবনের লৌহ সিন্দুক। অমাবস্যার মধ্যরাতে প্রবল ঝড়-বৃষ্টির মধ্যে একদল দুর্বৃত্ত অত্যন্ত নিখুঁত দক্ষতায় প্রাচীন ভারী তালা ভেঙে ফেলে।',
      'সিন্দুক থেকে উধাও হয়েছে শতবর্ষী পারিবারিক নীলকান্তমণি ও নিশিপুর মৌজার গোপন দলিল। ঘটনাস্থলে নিথর অবস্থায় পাওয়া যায় প্রহরীর দেহ, যার নাকে লেগে ছিল অদ্ভুত সুবাসযুক্ত বিষাক্ত রাসায়নিক আতর।',
      'ঘটনাস্থলের অদূরে কাদার মধ্যে ভারী বুটের ছাপ, একটি ভাঙা অ্যান্টিক পিতলের লকেট এবং পোড়া দেশলাই কাঠি পাওয়া গেছে।',
      'প্রধান গোয়েন্দা রবিন ও সহকারী তুহা নিশ্চিত—গ্রামের ভেতরের অতি পরিচিত কোনো প্রভাবশালী বা ধুরন্ধর ব্যক্তি ছাড়া এই গোপন পথ ও সিন্দুকের অবস্থান কারো জানা সম্ভব নয়!',
    ],
    motiveTemplateBn: (name) =>
      `${name} বহু বছর ধরে নিশিপুর মৌজার শত কোটি টাকার গোপন দলিল হস্তগত করতে চেয়েছিলেন। জমিদারের সিন্দুকের নীলকান্তমণি বিক্রি করে ঋণমুক্ত হওয়া ও গ্রামের নিয়ন্ত্রণ নেওয়াই ছিল উদ্দেশ্য।`,
    evidenceItems: [
      {
        id: 'ev_locket',
        nameBn: 'ভাঙা অ্যান্টিক পিতলের লকেট',
        nameEn: 'Broken Antique Brass Locket',
        category: 'physical',
        locationFoundBn: 'সিন্দুকের দরজার গোড়ায় মেঝেতে',
        descriptionBn: 'একটি ক্ষতিগ্রস্ত লকেট যার ভেতরের সূক্ষ্ম খোদাইয়ে কারো পারিবারিক সিলমোহর দেখা যায়।',
        relevanceBn: 'অপরাধী তাড়াহুড়ো করে পালানোর সময় গলার চেন ছিঁড়ে এটি ফেলে যায়।',
        isInitialClue: true,
      },
      {
        id: 'ev_chemical_vial',
        nameBn: 'বিষাক্ত রাসায়নিক তরলের শিশি',
        nameEn: 'Toxic Chemical Vial',
        category: 'forensic',
        locationFoundBn: ' বৈঠকখানার জানালার বাইরে ঘাসের ওপর',
        descriptionBn: 'গাঢ় বেগুনি রঙের চেতনানাশক তরলের তীব্র ঝাঁঝালো গন্ধযুক্ত কাচের শিশি।',
        relevanceBn: 'প্রহরীকে কাবু করতে এই রাসায়নিক ক্লোরোফর্ম ব্যবহার করা হয়েছিল।',
        isInitialClue: true,
      },
      {
        id: 'ev_torn_page',
        nameBn: 'ছেঁড়া হিসাবের ডায়েরির পাতা',
        nameEn: 'Torn Ledger Page',
        category: 'document',
        locationFoundBn: 'নদীঘাটের নৌকার নিচে লুকানো',
        descriptionBn: 'কালো কালিতে লেখা গোপন টাকার লেনদেন ও মধ্যরাতের সাংকেতিক সংকেত।',
        relevanceBn: 'চুরির মালামাল হস্তান্তরের সময় ও প্রাপ্তির অগ্রিম তালিকা।',
        isInitialClue: false,
        unlockedInPhase: 2,
      },
      {
        id: 'ev_footprints',
        nameBn: 'কাদামাটির ভারী বুটের ছাপ',
        nameEn: 'Heavy Muddy Bootprints',
        category: 'physical',
        locationFoundBn: 'পেছনের কাঁটাতার ও বাঁশঝাড়ের পথ',
        descriptionBn: 'আট নম্বর সাইজের ভারী কাজের বুটের নির্দিষ্ট দাগ, যার গোড়ালিতে তেল ও গ্রিজের অবশেষ।',
        relevanceBn: 'অপরাধীর চলাচলের গতিপথ মেকানিক বা কর্মস্থলের মানুষের সাথে মিলে যায়।',
        isInitialClue: false,
        unlockedInPhase: 3,
      },
    ],
    timeline: [
      'রাত ১১:০০ — বৈঠকখানার বাতি নিভিয়ে প্রহরী গেট পাহারা দিচ্ছিল।',
      'রাত ১২:১৫ — জানালার গ্রিল কেটে চেতনানাশক তরল স্প্রে করা হয়।',
      'রাত ১২:৩৫ — সিন্দুক ভেঙে দলিল ও মণি নিয়ে চোর পেছনের বাঁশঝাড় দিয়ে পালায়।',
      'রাত ০১:০০ — ঝড় থামার পর গ্রামবাসীরা ভাঙা দরজা দেখতে পায়।',
    ],
  },
  {
    titleBn: 'সুরমা নদীঘাটের ইঞ্জিন বোট বিস্ফোরণ ও গোপন ড্রাইভ অপহরণ',
    category: 'robbery',
    categoryNameBn: 'ডাকাতি ও সাইবার ব্ল্যাকমেইল',
    locationNameBn: 'সুরমা নদীর মোহনা ও নির্জন ইঞ্জিন ওয়ার্কশপ',
    incidentTimeBn: 'রাত আনুমানিক ১:০০ টা',
    shortPublicStoryPages: [
      'সুরমা নদীঘাটের খেয়া নৌকার মেকানিকের ঘরে মধ্যরাতে একটি আকস্মিক বিস্ফোরণ ও অগ্নিকাণ্ডের সূত্রপাত হয়। স্থানীয়রা আগুন নেভানোর পর দেখতে পায় ঘরের ভেতরে ধস্তাধস্তির স্পষ্ট চিহ্ন।',
      'মেকানিকের লোহার ট্রাঙ্ক ভেঙে গ্রামের সমবায় ব্যাংকের সমস্ত নগদ টাকা এবং একটি সামরিক মানের এনক্রিপ্টেড ফ্ল্যাশ ড্রাইভ ছিনতাই করা হয়েছে।',
      'ড্রাইভে ছিল গ্রামের সমবায় ঋণের জালিয়াতি ও প্রভাবশালী ব্যক্তিদের অবৈধ লেনদেনের সমস্ত হিসাব। ড্রাইভটি ফাঁস হলে অনেকেরই মুখোশ উন্মোচিত হয়ে যেত।',
      'ঘটনাস্থলে পাওয়া গেছে একটি রক্তমাখা দামি হাতঘড়ি এবং হাই-ভোল্টেজ বিদ্যুতের তারের টুকরো। প্রধান গোয়েন্দা রবিন তদন্তভার গ্রহণ করেছেন!',
    ],
    motiveTemplateBn: (name) =>
      `${name} সমবায় ব্যাংকের অর্থ আত্মসাৎ ধামাচাপা দিতে এবং ব্ল্যাকমেইলারের হাতে থাকা গোপন ড্রাইভ চিরতরে ধ্বংস করতেই মধ্যরাতে এই দুঃসাহসিক ডাকাতি ঘটিয়েছে।`,
    evidenceItems: [
      {
        id: 'ev_watch',
        nameBn: 'রক্তমাখা লাক্সারি হাতঘড়ি',
        nameEn: 'Blood-Stained Luxury Watch',
        category: 'physical',
        locationFoundBn: 'ভাঙা ট্রাঙ্কের কোণে মেঝেতে',
        descriptionBn: 'কাচ ফাটা সময় রাত ১টা ০৫ মিনিটে আটকে থাকা রক্তের দাগযুক্ত সোনার ঘড়ি।',
        relevanceBn: 'সংঘর্ষের সময় অপরাধীর হাত থেকে এটি ছিটকে পড়ে যায়।',
        isInitialClue: true,
      },
      {
        id: 'ev_shock_wire',
        nameBn: 'হাই-ভোল্টেজ ইলেকট্রিক তারের অবশেষ',
        nameEn: 'Electric Shock Wire Fragment',
        category: 'forensic',
        locationFoundBn: 'ওয়ার্কশপের ফিউজ বক্সের নিচে',
        descriptionBn: 'নির্দিষ্ট তামার তার যা নিরাপত্তা সার্কিট শর্ট করতে কৃত্রিমভাবে জোড়া লাগানো ছিল।',
        relevanceBn: 'বৈদ্যুতিক জ্ঞান ছাড়া এমন বিপজ্জনক শর্ট-সার্কিট করা অসম্ভব।',
        isInitialClue: true,
      },
      {
        id: 'ev_encrypted_drive_case',
        nameBn: 'এনক্রিপ্টেড ফ্ল্যাশ ড্রাইভের খোলস',
        nameEn: 'Encrypted Drive Casing',
        category: 'digital',
        locationFoundBn: 'নদীঘাটের কর্দমাক্ত চরে',
        descriptionBn: 'ধাতব লাল রঙের ড্রাইভের বাইরের প্রতিরক্ষামূলক কেসিং।',
        relevanceBn: 'অপরাধী ড্রাইভটি নিজের কাছে রেখে কেসিংটি ছুড়ে ফেলে দিয়েছিল।',
        isInitialClue: false,
        unlockedInPhase: 2,
      },
      {
        id: 'ev_burnt_diesel_can',
        nameBn: 'অগ্নিকাণ্ডে ব্যবহৃত ডিজেল ক্যানিস্টার',
        nameEn: 'Burnt Diesel Canister',
        category: 'physical',
        locationFoundBn: 'নৌকার নোঙরের পাথরের নিচে লুকানো',
        descriptionBn: 'পোড়া ডিজেলের গন্ধযুক্ত প্লাস্টিকের ড্রাম, যা মেকানিক শেডের বাইরে থেকে আনা হয়েছিল।',
        relevanceBn: 'আগুন দুর্ঘটনা ছিল না, পরিকল্পিত নাশকতার প্রমাণ।',
        isInitialClue: false,
        unlockedInPhase: 3,
      },
    ],
    timeline: [
      'রাত ১২:২০ — নদীঘাটের সব বাতি হঠাৎ ফিউজ কেটে বন্ধ হয়ে যায়।',
      'রাত ১২:৫০ — ইঞ্জিন রুমে ভারী হাতুড়ি পেটানোর মতো ধাতব আঘাত শোনা যায়।',
      'রাত ০১:০৫ — প্রচণ্ড বিস্ফোরণ ও ধোঁয়ায় চারপাশ ঢেকে যায়; অপরাধী দ্রুত সরে পড়ে।',
      'রাত ০১:৩০ — পুলিশ ও রবিন নদীঘাটে উপস্থিত হয়ে আলামত জব্দ করেন।',
    ],
  },
  {
    titleBn: 'নিশিপুর হাইস্কুলের নথি অগ্নিকাণ্ড ও ভূতুড়ে হামলা',
    category: 'fraud',
    categoryNameBn: 'দলিল জালিয়াতি ও প্রশাসনিক কেলেঙ্কারি',
    locationNameBn: 'নিশিপুর বহুমুখী উচ্চ বিদ্যালয় শিক্ষক মিলনায়তন',
    incidentTimeBn: 'রাত ১১:৪৫ মিনিট',
    shortPublicStoryPages: [
      'নিশিপুর উচ্চ বিদ্যালয়ের শিক্ষক মিলনায়তনে গভীর রাতে এক রহস্যময় অগ্নিকাণ্ডের ঘটনা ঘটে। নাইট গার্ড দাবি করে, সাদা চাদর পরা কাউকে ছায়ার মতো দোতলার বারান্দা দিয়ে নামতে দেখেছে।',
      'আলমারি থেকে চুরি হয়েছে সরকারি অনুদানের হিসাব বহি, শিক্ষক নিয়োগের গোপন তালিকা এবং একটি সিলগালা ফাইল।',
      'ঘটনাস্থলে অ্যাসিডের গন্ধ, একটি ভারী রেঞ্চ এবং সিগারেটের পোড়া অবশিষ্টাংশ উদ্ধার হয়েছে।',
      'গ্রামের বিশিষ্ট ব্যক্তিরা একে অপরের দিকে আঙুল তুলছেন। রবিনকে অবিলম্বে সত্য উদঘাটন করতে হবে!',
    ],
    motiveTemplateBn: (name) =>
      `${name} শিক্ষক নিয়োগ দুর্নীতি ও জাল সার্টিফিকেটের প্রমাণ লোপাট করতে নিজের প্রভাব খাটিয়ে মধ্যরাতে বিদ্যালয়ের আলমারি ভেঙেছে।`,
    evidenceItems: [
      {
        id: 'ev_wrench',
        nameBn: 'ভারী শিল্প রেঞ্চ',
        nameEn: 'Heavy Industrial Wrench',
        category: 'physical',
        locationFoundBn: 'দোতলার সিঁড়ির কোণে ফেলে যাওয়া',
        descriptionBn: 'লোহার ভারী রেঞ্চ যা আলমারির তালা ভাঙতে লিভার হিসেবে ব্যবহৃত হয়েছে।',
        relevanceBn: 'রেঞ্চের হাতলে আঙুলের ছাপ ও হলুদ রঙের বার্নিশ পাওয়া গেছে।',
        isInitialClue: true,
      },
      {
        id: 'ev_cigarette',
        nameBn: 'ফিল্টারযুক্ত বিদেশি সিগারেটের অবশেষ',
        nameEn: 'Foreign Cigarette Butt',
        category: 'forensic',
        locationFoundBn: 'শিক্ষক মিলনায়তনের টেবিলের নিচে',
        descriptionBn: 'দামি তামাকের ব্র্যান্ড, যা নিশিপুর বাজারে সাধারণ মানুষের কাছে মেলে না।',
        relevanceBn: 'অপরাধী সেখানে বেশ কিছুক্ষণ অপেক্ষা করে আলমারি ভাঙছিল।',
        isInitialClue: true,
      },
      {
        id: 'ev_sealed_envelope',
        nameBn: 'অর্ধপোড়া টাকার খাম ও সুপারিশপত্র',
        nameEn: 'Half-Burnt Cash Envelope',
        category: 'document',
        locationFoundBn: 'স্কুল প্রাঙ্গণের ছাইয়ের গাদায়',
        descriptionBn: 'ইউনিয়ন পরিষদের প্যাডে লেখা একটি গোপন ঘুষ ও সুপারিশের অনুলিপি।',
        relevanceBn: 'দুর্নীতির আসল যোগসূত্র নির্দেশ করে।',
        isInitialClue: false,
        unlockedInPhase: 2,
      },
      {
        id: 'ev_toxic_solvent',
        nameBn: 'দ্রাবক রাসায়নিকের খালি বোতল',
        nameEn: 'Toxic Solvent Bottle',
        category: 'forensic',
        locationFoundBn: 'স্কুল ল্যাবরেটরির পেছনে',
        descriptionBn: 'কালি মোছার কেমিক্যাল ও দাহ্য ইথারের বোতল।',
        relevanceBn: 'রেকর্ড বইয়ের নাম কেটে মুছে ফেলার জন্য আনা হয়েছিল।',
        isInitialClue: false,
        unlockedInPhase: 3,
      },
    ],
    timeline: [
      'রাত ১১:১৫ — নাইট গার্ড চা খেতে বাজারে যায়।',
      'রাত ১১:৪০ — পেছনের আমগাছ বেয়ে ভবনে প্রবেশ।',
      'রাত ১২:০৫ — আলমারি ভেঙে নথি সংগ্রহ ও আগুন ধরিয়ে পলায়ন।',
      'রাত ১২:৩০ — গ্রামবাসীদের সহযোগিতায় আগুন নিয়ন্ত্রণে আনা হয়।',
    ],
  },
];

export class NishipurCaseGenerator {
  public static generateCase(targetPlayerCount: PlayerCountOption = 5): NishipurCaseTruth {
    const blueprint = BLUEPRINTS[Math.floor(Math.random() * BLUEPRINTS.length)];
    const caseId = `case_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    // Suspect count: targetPlayerCount - 1 (since 1 player is always Robin the investigator)
    // 5 players = 4 suspects, 7 players = 6 suspects, 9 players = 8 suspects
    const availableVillagers = NISHIPUR_CHARACTERS.filter((c) => c.id !== 'robin' && c.id !== 'tuha');
    const shuffledVillagers = [...availableVillagers].sort(() => Math.random() - 0.5);

    const coreSuspects = shuffledVillagers.slice(0, 4);
    const coreSuspectIds = coreSuspects.map((c) => c.id);

    // Supporting characters if 7 or 9 players
    let supportingCharacters: NishipurCharacter[] = [];
    if (targetPlayerCount >= 7) {
      supportingCharacters.push(shuffledVillagers[4]);
      supportingCharacters.push(shuffledVillagers[5]);
    }
    if (targetPlayerCount >= 9) {
      supportingCharacters.push(shuffledVillagers[6]);
      supportingCharacters.push(shuffledVillagers[7]);
    }
    const supportingCharacterIds = supportingCharacters.map((c) => c.id);

    // Pick 1 culprit strictly among the 5 core suspects
    const culpritIndex = Math.floor(Math.random() * coreSuspects.length);
    const culprit = coreSuspects[culpritIndex];

    const motiveBn = blueprint.motiveTemplateBn(culprit.nameBn);

    // Build Character Stories with 50-90 words narrative private briefings
    const characterStories: Record<string, CaseCharacterStory> = {};

    coreSuspects.forEach((suspect, idx) => {
      const isCulprit = suspect.id === culprit.id;
      characterStories[suspect.id] = this.buildCharacterStory(
        suspect,
        isCulprit,
        blueprint,
        idx,
        culprit.nameBn
      );
    });

    supportingCharacters.forEach((suspect, idx) => {
      characterStories[suspect.id] = this.buildCharacterStory(
        suspect,
        false, // supporting characters are witnesses/innocent
        blueprint,
        5 + idx,
        culprit.nameBn
      );
    });

    // Tuha Hint & Analysis
    const tuhaHintBn = `তুহার গোপন পর্যবেক্ষণ: জেরা করার সময় লক্ষ্য করুন, আসল অপরাধী কিন্তু ঘটনাস্থলে উপস্থিত থাকার বিষয়টি আড়াল করতে চাইলেও নদীঘাট বা পেছনের পথের বিবরণ দিতে গিয়ে বারবার ভুল সময় উল্লেখ করেছে!`;
    const tuhaEvidenceAnalysisBn = `ফরেনসিক ল্যাবের পরীক্ষা অনুযায়ী, উদ্ধারকৃত আলামতে '${culprit.nameBn}'-এর দৈনন্দিন ব্যবহৃত উপাদানের রাসায়নিক কণা ও তেলের অবশেষের মিল স্পষ্ট। অন্য নির্দোষদের বক্তব্যে এই আলামতের কোনো সরাসরি সংযোগ নেই।`;

    return {
      caseId,
      titleBn: blueprint.titleBn,
      category: blueprint.category,
      categoryNameBn: blueprint.categoryNameBn,
      locationNameBn: blueprint.locationNameBn,
      incidentTimeBn: blueprint.incidentTimeBn,
      shortPublicStoryPages: blueprint.shortPublicStoryPages,
      culpritCharacterId: culprit.id,
      motiveBn,
      timelineBn: blueprint.timeline,
      coreSuspectIds,
      supportingCharacterIds,
      evidenceList: blueprint.evidenceItems,
      characterStories,
      tuhaHintBn,
      tuhaEvidenceAnalysisBn,
      keyContradictionsBn: [
        `অপরাধী দাবি করেছিল সে রাত ১২টায় ঘুমিয়ে ছিল, কিন্তু পদচিহ্ন ও চায়ের দোকানের সাক্ষী তাকে ১২টা ১৫ মিনিটে অদূরে দেখেছিল।`,
        `অপরাধীর কাপড়ের কোণে তেলের দাগ ও চুরির সরঞ্জামের সাথে উদ্ধারকৃত আলামতের নিখুঁত মিল রয়েছে।`,
      ],
      finalCaseExplanationBn: `তদন্তে সুস্পষ্ট প্রমাণিত হয়েছে যে, ${culprit.nameBn} নিজের ব্যক্তিগত স্বার্থ ও আর্থিক সংকটের দায় মেটাতে পূর্বপরিকল্পিতভাবে নিশিপুর গ্রামের শান্তি বিঘ্নিত করেছে। রবিনের তীক্ষ্ণ যুক্তি ও তুহার সঠিক বিশ্লেষণে সত্য প্রতিষ্ঠিত হলো।`,
    };
  }

  private static buildCharacterStory(
    character: NishipurCharacter,
    isCulprit: boolean,
    blueprint: CaseBlueprint,
    orderIdx: number,
    culpritNameBn: string
  ): CaseCharacterStory {
    if (isCulprit) {
      // 50-90 words rich narrative private briefing for the culprit
      const privateStory = `আমি ${character.nameBn}। নিশিপুরের সবাই আমাকে শ্রদ্ধার চোখে দেখলেও আমার কাঁধে অনেক দিনের লুকানো ঋণ আর গোপন পারিবারিক বিরোধ চেপে বসেছিল। এই ঘটনাটি আমাকে ঘটাতে হয়েছে নিজের অস্তিত্ব রক্ষার তাগিদে। মধ্যরাতে অন্ধকারে আমি নিঃশব্দে ঘটনাস্থলে ঢুকেছিলাম এবং কাজ শেষ করে পেছনের অন্ধকার পথ দিয়ে নদীঘাটের দিকে চলে আসি। তবে তাড়াহুড়ো করতে গিয়ে হয়তো কিছু চিহ্ন অসাবধানে ফেলে এসেছি। রবিন যেন আমার ইতস্তত ভাব ধরতে না পারে, আমাকে সাবধানে অভিনয় করতে হবে!`;

      return {
        characterId: character.id,
        isCulprit: true,
        roleInCaseBn: 'প্রধান সন্দেহভাজন (গোপন সত্য: আসল অপরাধী)',
        privateBriefingStoryBn: privateStory,
        alibiBn: 'রাত ১২টার সময় ঘরে শুয়ে একা রেডিও শুনছিলাম, কিন্তু কোনো প্রত্যক্ষদর্শী সাক্ষী নেই।',
        motiveBn: 'আর্থিক ঋণের দায় শোধ ও গোপন সম্পত্তির দখল নিয়ে ক্ষোভ।',
        relationshipWithVictimBn: 'দীর্ঘদিনের মতবিরোধ ও সম্পত্তি বণ্টন সংক্রান্ত বিরোধ।',
        secretBn: 'আমার কাছে এখনও ট্রাঙ্ক বা সিন্দুক খোলার অতিরিক্ত মাস্টার চাবি রয়েছে।',
        bluffTokensRemaining: 2,
        canBluff: true,
        answers: {
          q_alibi_time: {
            truthBn: 'রাত ১২টায় আমি একা ঘরে শুয়ে ছিলাম। বাইরে খুব ঝড়বৃষ্টি হচ্ছিল, তাই আমি বের হইনি। কেউ আমাকে বাইরে দেখার কোনো সুযোগ নেই।',
            bluffOptionsBn: [
              'আমি রাত বারোটায় রকিব চাচার দোকানে চা খাচ্ছিলাম, অনেকেই তো আমাকে দেখেছে!',
              'আমি অসুস্থ ছিলাম বলে রাত দশটাতেই ওষুধ খেয়ে ঘুমিয়ে পড়েছিলাম।',
            ],
          },
          q_relationship: {
            truthBn: 'আমাদের মাঝে সামান্য ব্যবসায়িক মতবিরোধ ছিল বটে, কিন্তু তা নিয়ে কোনো বড় কলহ কোনোদিন হয়নি। আমি কেন তার ক্ষতি করতে যাব?',
            bluffOptionsBn: [
              'তার সাথে তো আমার রক্তের সম্পর্কের মতো ভালোবাসা ছিল, কোনো বিরোধের প্রশ্নই ওঠে না!',
            ],
          },
          q_suspicious_sightings: {
            truthBn: 'আমি ঘরের ভেতরে ছিলাম, বাইরে কোনো শব্দ পাইনি। তবে নদীঘাটের দিকটায় কাউকে দৌড়াতে দেখে থাকতে পারে অন্য কেউ...',
            bluffOptionsBn: [
              'আমি দেখেছি কালু চোর নাকি কাদের আলীর লোকজনকে রাতের বেলা টর্চ ফেলে দৌড়াতে!',
            ],
          },
          q_occupational_tools: {
            truthBn: 'কাজের সাধারণ কিছু সরঞ্জাম আমার কাছে থাকা স্বাভাবিক। তবে ঘটনাস্থলের ঐ বিপজ্জনক বস্তুর সাথে আমার কোনো যোগসূত্র নেই।',
            bluffOptionsBn: [
              'ওসব সরঞ্জাম তো পুরো গ্রামের মেকানিক বা কামারদের সবার কাছেই থাকে, আমাকে দোষ দিচ্ছেন কেন?',
            ],
          },
          q_contradiction_check: {
            truthBn: '(চোখ নামিয়ে ইতস্তত করে) আসলে ঝড়ের কারণে আমি সময়ের হিসাব গুলিয়ে ফেলেছি। আমার মনে হয় ঘড়ির কাঁটা একটু ভুল ছিল...',
            bluffOptionsBn: [
              'গ্রামবাসীরা আমার নামে কুৎসা রটাচ্ছে! আমি নির্দোষ!',
            ],
          },
          q_final_motive_pressure: {
            truthBn: '(ঘেমে গিয়ে থমকে দাঁড়ায়) রবিন... তুমি ভুল করছ! প্রমাণগুলো অন্য কেউ আমার বিরুদ্ধে ষড়যন্ত্র করে সাজিয়েছে!',
            bluffOptionsBn: [
              'তুহার ল্যাব রিপোর্ট ভুল! আমি শেষ পর্যন্ত নির্দোষ দাবি করছি!',
            ],
          },
        },
      };
    }

    // Innocent Suspect Story (~50-80 words)
    const innocentStory = `আমি ${character.nameBn}। নিশিপুর গ্রামে আমার সম্মান ও সততা নিয়ে কোনোদিন কেউ প্রশ্ন তোলেনি। ঘটনার রাতে আমি নিজের দৈনন্দিন কাজেই ব্যস্ত ছিলাম। তবে দূর থেকে আমি কিছু অদ্ভুত আলো ও অস্বাভাবিক গতিবিধি লক্ষ্য করেছিলাম, যা তখন অতটা গুরুত্ব দিইনি। এখন বুঝতে পারছি ঐ সময়েই আসল অপরাধী নিজের অপকর্ম চালিয়েছিল। আমি গোয়েন্দা রবিনকে প্রতিটি প্রশ্নের শতভাগ সত্য উত্তর দিয়ে নিজের নির্দোষিতা প্রমাণ করব।`;

    return {
      characterId: character.id,
      isCulprit: false,
      roleInCaseBn: 'তদন্তভুক্ত গ্রামবাসী (নির্দোষ)',
      privateBriefingStoryBn: innocentStory,
      alibiBn: 'রাত বারোটায় আমি আমার স্বাভাবিক অবস্থান ও সাক্ষীদের উপস্থিতিতে ছিলাম।',
      motiveBn: 'ঘটনার সাথে কোনো স্বার্থের সংঘাত নেই।',
      relationshipWithVictimBn: 'পারস্পরিক সামাজিক শ্রদ্ধা ও সাধারণ গ্রাম্য পরিচয়।',
      secretBn: 'আমি রাতে একজনকে নদীঘাটের দিকে ভারী ব্যাগ নিয়ে দৌড়াতে দেখেছিলাম।',
      bluffTokensRemaining: 1,
      canBluff: false,
      answers: {
        q_alibi_time: {
          truthBn: `রাত বারোটায় আমি আমার স্বাভাবিক কাজের জায়গাতেই ছিলাম। গ্রামের দুজন প্রতিবেশী আমাকে স্পষ্ট দেখেছিল এবং প্রয়োজনে তারা সাক্ষ্য দেবে।`,
        },
        q_relationship: {
          truthBn: `ঘটনার সাথে বা ভুক্তভোগীর সম্পত্তির সাথে আমার কোনো বিরোধ নেই। আমরা একে অপরের সামাজিক অনুষ্ঠানে সবসময় সহযোগিতা করতাম।`,
        },
        q_suspicious_sightings: {
          truthBn: `রাত পৌনে একটার দিকে অন্ধকার বাঁশঝাড়ের কাছ দিয়ে কাউকে দ্রুত হেঁটে নদীঘাটের দিকে যেতে দেখেছিলাম। গায়ে গাঢ় রঙের চাদর ছিল।`,
        },
        q_occupational_tools: {
          truthBn: `ঘটনাস্থলে পাওয়া কোনো সরঞ্জামই আমার ব্যবহৃত নয়। আমার কাজের জিনিসপত্র সব আমার কাছেই যথাযথভাবে তালাবদ্ধ থাকে।`,
        },
        q_contradiction_check: {
          truthBn: `আমার জবানবন্দির প্রতিটি শব্দ সত্য। আপনি গ্রামের অন্য যে কারো সাথে মিলিয়ে নিতে পারেন, কোনো অসঙ্গতি পাবেন না।`,
        },
        q_final_motive_pressure: {
          truthBn: `আমি শুরু থেকেই সম্পূর্ণ সৎ ও সহযোগিতাপূর্ণ আচরণ করেছি রবিন ভাই। আসল অপরাধী কিন্তু আপনাদের চোখ ফাঁকি দেওয়ার চেষ্টা করছে!`,
        },
      },
    };
  }
}
