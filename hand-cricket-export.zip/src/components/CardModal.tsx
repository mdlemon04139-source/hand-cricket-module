import React from 'react';
import { CharacterDef } from '../types/game';
import { X, Coins, Shield, Swords, Eye, Award } from 'lucide-react';

interface CardModalProps {
  character: CharacterDef | null;
  onClose: () => void;
  hasTaxToken?: boolean;
}

export const CardModal: React.FC<CardModalProps> = ({
  character,
  onClose,
  hasTaxToken = false,
}) => {
  if (!character) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      {/* Click outside backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative z-10 w-full max-w-2xl bg-gradient-to-b from-slate-900 via-indigo-950/90 to-slate-950 border border-amber-500/40 rounded-3xl p-4 sm:p-6 shadow-2xl overflow-hidden flex flex-col md:flex-row gap-6 max-h-[90vh] overflow-y-auto">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 text-amber-200 hover:text-white hover:bg-red-600 transition-all z-20"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Card Artwork Side */}
        <div className="w-full md:w-1/2 flex flex-col items-center justify-center">
          <div
            className="w-full max-w-[280px] rounded-2xl overflow-hidden shadow-2xl border-2 border-amber-400/50 relative bg-slate-950"
            style={{ aspectRatio: '5/7' }}
          >
            <img
              src={character.image}
              alt={character.nameBn}
              className="w-full h-full object-contain pointer-events-none drop-shadow-xl"
            />
            {hasTaxToken && (
              <div className="absolute top-3 right-3 bg-emerald-600 text-amber-200 text-xs font-bold px-2.5 py-1 rounded-full border border-amber-300 shadow-md">
                ট্যাক্স টোকেন সক্রিয়
              </div>
            )}
          </div>
          <p className="text-[11px] text-amber-300/60 mt-2 text-center">
            মৌলিক সংগৃহীত চরিত্র কার্ড ডিজাইন
          </p>
        </div>

        {/* Character Info Side */}
        <div className="w-full md:w-1/2 flex flex-col justify-between space-y-4">
          <div>
            {/* Header Badge */}
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${character.badgeBg}`}>
                {character.titleBn}
              </span>
              <span className="text-xs text-amber-400/70 font-mono tracking-wider">
                {character.nameEn.toUpperCase()}
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-bengali tracking-wide">
              {character.nameBn}
            </h2>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-2 mt-4 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <div className="text-slate-400 text-[10px]">খরচ (Cost)</div>
                  <div className="font-bold text-amber-300">
                    {character.coinCost > 0 ? `${character.coinCost} মুদ্রা` : 'বিনামূল্যে (০)'}
                  </div>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-slate-400 text-[10px]">মুদ্রা লাভ (Gain)</div>
                  <div className="font-bold text-emerald-300">
                    {character.coinGain > 0 ? `+${character.coinGain} মুদ্রা` : 'বিশেষ ক্ষমতা'}
                  </div>
                </div>
              </div>
            </div>

            {/* Primary Ability Box */}
            <div className="mt-4 p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/30">
              <div className="flex items-center gap-2 text-amber-300 text-xs font-bold mb-1">
                <Swords className="w-3.5 h-3.5" />
                <span>ক্ষমতা ও কার্যাবলি (Ability)</span>
              </div>
              <p className="text-sm font-bengali text-amber-100 leading-relaxed">
                {character.descriptionBn}
              </p>
              <p className="text-xs text-slate-300/80 mt-1.5 italic font-sans">
                {character.descriptionEn}
              </p>
            </div>

            {/* Blocking Capability */}
            {character.canBlock && character.canBlock.length > 0 && (
              <div className="mt-3 p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/30">
                <div className="flex items-center gap-2 text-emerald-300 text-xs font-bold mb-1">
                  <Shield className="w-3.5 h-3.5" />
                  <span>প্রতিরক্ষা ক্ষমতা (Block Capability)</span>
                </div>
                <p className="text-xs font-bengali text-emerald-200">
                  এই চরিত্র দাবি করে আপনি অন্য খেলোয়াড়ের চুরি ও ডাকাতি প্রতিরোধ করতে পারেন।
                </p>
              </div>
            )}

            {/* Tactical Advice */}
            <div className="mt-3 p-2.5 rounded-xl bg-purple-950/20 border border-purple-500/20 text-xs text-purple-200/90 font-bengali">
              💡 <strong>কৌশল টিপস:</strong> আপনি এই কার্ড হাতে না রেখেও এর ক্ষমতার দাবি (Bluff) করতে পারেন। তবে কেউ চ্যালেঞ্জ করলে এবং আপনি ব্যর্থ হলে ১টি জীবন হারাতে হবে!
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-bold transition-all text-sm shadow-lg font-bengali cursor-pointer"
          >
            বন্ধ করুন (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
