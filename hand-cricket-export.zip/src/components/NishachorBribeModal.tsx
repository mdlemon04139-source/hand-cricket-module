import React from 'react';
import { ALL_CHARACTERS } from '../data/characters';
import { CardView } from './CardView';
import { Flame, Coins, ShieldAlert, Swords } from 'lucide-react';
import { sound } from '../utils/sound';

interface NishachorBribeModalProps {
  attackerNameBn: string;
  targetCoins: number;
  onPayBribe: () => void;
  onChallenge: () => void;
  onAcceptHit: () => void;
}

export const NishachorBribeModal: React.FC<NishachorBribeModalProps> = ({
  attackerNameBn,
  targetCoins,
  onPayBribe,
  onChallenge,
  onAcceptHit,
}) => {
  const canAffordBribe = targetCoins >= 2;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative z-10 w-full max-w-lg bg-gradient-to-b from-red-950 via-slate-900 to-slate-950 border-2 border-red-500/60 rounded-3xl p-5 sm:p-7 shadow-2xl text-center">
        {/* Warning Icon */}
        <div className="w-12 h-12 rounded-full bg-red-600/30 border border-red-500 flex items-center justify-center mx-auto mb-3 animate-pulse">
          <Flame className="w-6 h-6 text-red-400" />
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-red-400 font-bengali">
          {attackerNameBn} নিশাচরের আক্রমণ চালিয়েছে!
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-2">
          নিশাচরের মারাত্মক হামলায় আপনি ১টি অমূল্য জীবন হারাতে চলেছেন। আপনার সিদ্ধান্ত কী?
        </p>

        {/* Character Card Visual */}
        <div className="my-4 flex justify-center">
          <CardView
            characterId="nishachor"
            size="sm"
            className="w-28 ring-2 ring-red-500/50"
          />
        </div>

        <div className="space-y-2.5 mt-5">
          {/* Bribe Button */}
          <button
            onClick={() => {
              sound.playCoin();
              onPayBribe();
            }}
            disabled={!canAffordBribe}
            className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm font-bengali flex items-center justify-between transition-all cursor-pointer ${
              canAffordBribe
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4" />
              <span>২টি মুদ্রা ঘুষ দিন (Pay 2 Coins Bribe)</span>
            </div>
            <span className="text-xs font-mono">
              {canAffordBribe ? 'আক্রমণ বাতিল' : 'মুদ্রা অপর্যাপ্ত'}
            </span>
          </button>

          {/* Challenge Button */}
          <button
            onClick={() => {
              sound.playChallenge();
              onChallenge();
            }}
            className="w-full py-3 px-4 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs sm:text-sm font-bengali flex items-center justify-between transition-all cursor-pointer shadow-lg shadow-purple-900/30"
          >
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-purple-300" />
              <span>চালবাজি চ্যালেঞ্জ করুন! (Challenge Bluff)</span>
            </div>
            <span className="text-[11px] text-purple-200">মিথ্যা হলে আক্রমণকারী জীবন হারাবে</span>
          </button>

          {/* Take the Hit Button */}
          <button
            onClick={() => {
              sound.playLifeLost();
              onAcceptHit();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-red-950 hover:border-red-600 border border-slate-700 text-slate-300 hover:text-red-200 text-xs sm:text-sm font-bengali flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Swords className="w-4 h-4" />
            <span>আক্রমণ মেনে নিন (১টি জীবন ত্যাগ করুন)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
