import React, { useState } from 'react';
import { Card, CharacterId } from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';
import { CardView } from './CardView';
import { Sparkles, ArrowRightLeft, Check } from 'lucide-react';
import { sound } from '../utils/sound';

interface GuptochorModalProps {
  drawnCard: Card;
  handCards: Card[];
  onFinish: (swapWithIndex: number | null) => void; // null means keep hand cards
}

export const GuptochorInspectModal: React.FC<GuptochorModalProps> = ({
  drawnCard,
  handCards,
  onFinish,
}) => {
  const activeHand = handCards.filter((c) => !c.isRevealed);
  const [selectedSwapIndex, setSelectedSwapIndex] = useState<number | null>(null);
  const drawnDef = ALL_CHARACTERS[drawnCard.characterId];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative z-10 w-full max-w-2xl bg-gradient-to-b from-slate-900 via-purple-950/80 to-slate-950 border border-purple-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl text-center">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-400/30 mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>গুপ্তচর ক্ষমতা (Guptochor Secret Inspection)</span>
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-amber-300 font-bengali">
          ডেক থেকে ১টি কার্ড গোপনে দেখেছেন
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-1">
          আপনি কি ডেকে পাওয়া নতুন কার্ডটি আপনার হাতের কোনো কার্ডের সাথে অদলবদল (Swap) করতে চান?
        </p>

        {/* Drawn Card Display */}
        <div className="my-5 flex flex-col items-center">
          <span className="text-xs text-purple-300 font-bold mb-1.5">
            ডেক থেকে পাওয়া নতুন কার্ড:
          </span>
          <CardView
            characterId={drawnCard.characterId}
            size="md"
            className="w-32 sm:w-40 ring-4 ring-purple-400/70"
          />
          <div className="mt-2 text-xs text-slate-300 font-bengali">
            {drawnDef.nameBn} — {drawnDef.descriptionBn}
          </div>
        </div>

        {/* Current Active Hand Cards */}
        <div className="mt-4 pt-4 border-t border-purple-900/50">
          <span className="text-xs text-slate-400 font-bengali block mb-2">
            অদলবদল করতে নিচের হাতের কার্ড সিলেক্ট করুন (বা না চাইলে সরাসরি রেখে দিন):
          </span>

          <div className="flex justify-center gap-4">
            {activeHand.map((card, idx) => {
              const isSelected = selectedSwapIndex === idx;
              return (
                <div
                  key={card.uid}
                  onClick={() => {
                    sound.playClick();
                    setSelectedSwapIndex(isSelected ? null : idx);
                  }}
                  className={`cursor-pointer transition-all ${
                    isSelected ? 'scale-105' : 'hover:scale-100'
                  }`}
                >
                  <CardView
                    characterId={card.characterId}
                    size="sm"
                    isSelected={isSelected}
                    className="w-24 sm:w-28"
                  />
                  <div className="mt-1 text-[11px] font-bengali text-amber-200">
                    কার্ড {idx + 1}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-col sm:flex-row justify-center gap-3">
          <button
            onClick={() => {
              sound.playCardDeal();
              onFinish(null);
            }}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bengali transition-all cursor-pointer"
          >
            পরিবর্তন না করে রেখে দিন (Keep Current)
          </button>

          <button
            onClick={() => {
              if (selectedSwapIndex !== null) {
                sound.playCardDeal();
                onFinish(selectedSwapIndex);
              }
            }}
            disabled={selectedSwapIndex === null}
            className={`px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm font-bengali flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              selectedSwapIndex !== null
                ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/40'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>নির্বাচিত কার্ডের সাথে বদল করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};

interface JyotishiModalProps {
  drawnCards: Card[];
  handCards: Card[];
  onFinish: (keepCardUids: string[]) => void;
}

export const JyotishiInspectModal: React.FC<JyotishiModalProps> = ({
  drawnCards,
  handCards,
  onFinish,
}) => {
  const activeHand = handCards.filter((c) => !c.isRevealed);
  const totalCards = [...activeHand, ...drawnCards];
  const requiredCount = activeHand.length;

  const [selectedUids, setSelectedUids] = useState<string[]>(
    activeHand.map((c) => c.uid)
  );

  const toggleSelect = (uid: string) => {
    sound.playClick();
    if (selectedUids.includes(uid)) {
      if (selectedUids.length > 1) {
        setSelectedUids(selectedUids.filter((id) => id !== uid));
      }
    } else {
      if (selectedUids.length < requiredCount) {
        setSelectedUids([...selectedUids, uid]);
      } else {
        // replace first
        setSelectedUids([...selectedUids.slice(1), uid]);
      }
    }
  };

  const isComplete = selectedUids.length === requiredCount;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative z-10 w-full max-w-3xl bg-gradient-to-b from-slate-900 via-fuchsia-950/80 to-slate-950 border border-fuchsia-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl text-center">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-400/30 mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>জ্যোতিষী ক্ষমতা (Jyotishi Divine Inspection)</span>
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-amber-300 font-bengali">
          ডেক থেকে ২টি নতুন কার্ড তোলা হয়েছে
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-1">
          মোট {totalCards.length}টি কার্ডের মধ্য থেকে আপনার পছন্দের যেকোনো {requiredCount}টি কার্ড বেছে নিন। বাকি কার্ড ডেকে ফেরত চলে যাবে।
        </p>

        {/* Cards Grid */}
        <div className="my-6 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-xl mx-auto">
          {totalCards.map((card, idx) => {
            const isSelected = selectedUids.includes(card.uid);
            const isOriginalHand = activeHand.some((c) => c.uid === card.uid);

            return (
              <div
                key={card.uid}
                onClick={() => toggleSelect(card.uid)}
                className={`relative flex flex-col items-center p-2 rounded-2xl cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-fuchsia-500/20 border-2 border-fuchsia-400 shadow-lg scale-105'
                    : 'bg-slate-900/60 border border-slate-800 hover:border-slate-700 opacity-70'
                }`}
              >
                <div className="absolute top-1 left-1 text-[9px] px-1.5 py-0.5 rounded bg-black/80 font-bengali text-slate-300 z-10">
                  {isOriginalHand ? 'হাতের কার্ড' : 'ডেক থেকে'}
                </div>

                {isSelected && (
                  <div className="absolute top-1 right-1 bg-fuchsia-500 text-white rounded-full p-0.5 z-10">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                )}

                <CardView
                  characterId={card.characterId}
                  isSelected={isSelected}
                  size="sm"
                  className="w-full max-w-[120px]"
                />

                <div className="mt-1 text-xs font-bold font-bengali text-amber-200">
                  {ALL_CHARACTERS[card.characterId].nameBn}
                </div>
              </div>
            );
          })}
        </div>

        <button
          onClick={() => {
            if (isComplete) {
              sound.playCardDeal();
              onFinish(selectedUids);
            }
          }}
          disabled={!isComplete}
          className={`px-8 py-3 rounded-xl font-black text-sm font-bengali transition-all cursor-pointer ${
            isComplete
              ? 'bg-gradient-to-r from-fuchsia-500 to-purple-600 hover:brightness-110 text-white shadow-xl shadow-fuchsia-500/30'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          {isComplete
            ? `নির্বাচিত ${requiredCount}টি কার্ড রাখুন`
            : `${requiredCount - selectedUids.length}টি কার্ড নির্বাচন বাকি`}
        </button>
      </div>
    </div>
  );
};
