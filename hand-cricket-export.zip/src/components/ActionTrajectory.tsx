import React, { useEffect, useState } from 'react';
import { CharacterId } from '../types/game';

interface ActionTrajectoryProps {
  actorId: string;
  targetId: string;
  characterId: CharacterId;
  onComplete?: () => void;
}

// 4 Player Position Anchors on the Responsive Board (%)
const PLAYER_COORDS: Record<string, { x: number; y: number }> = {
  p1: { x: 50, y: 86 }, // Bottom
  ai_1: { x: 50, y: 14 }, // Top
  ai_2: { x: 14, y: 50 }, // Left
  ai_3: { x: 86, y: 50 }, // Right
};

const CHARACTER_PROJECTILE_STYLES: Record<
  CharacterId,
  { stroke: string; glow: string; icon: string; size: number }
> = {
  guptoghatok: {
    stroke: '#ef4444',
    glow: 'rgba(239, 68, 68, 0.6)',
    icon: '🗡️',
    size: 26,
  },
  nishachor: {
    stroke: '#dc2626',
    glow: 'rgba(220, 38, 38, 0.7)',
    icon: '👹',
    size: 28,
  },
  dosyu_sordar: {
    stroke: '#10b981',
    glow: 'rgba(16, 185, 129, 0.6)',
    icon: '⚔️',
    size: 26,
  },
  sidhel_chor: {
    stroke: '#14b8a6',
    glow: 'rgba(20, 184, 166, 0.6)',
    icon: '💰',
    size: 24,
  },
  nawab: {
    stroke: '#f59e0b',
    glow: 'rgba(245, 158, 11, 0.6)',
    icon: '👑',
    size: 26,
  },
  sodagor: {
    stroke: '#0ea5e9',
    glow: 'rgba(14, 165, 233, 0.6)',
    icon: '🪙',
    size: 26,
  },
  guptochor: {
    stroke: '#a855f7',
    glow: 'rgba(168, 85, 247, 0.6)',
    icon: '🦅',
    size: 26,
  },
  jyotishi: {
    stroke: '#e879f9',
    glow: 'rgba(232, 121, 249, 0.6)',
    icon: '🔮',
    size: 26,
  },
  khajnadar: {
    stroke: '#059669',
    glow: 'rgba(5, 150, 105, 0.6)',
    icon: '📜',
    size: 26,
  },
};

export const ActionTrajectory: React.FC<ActionTrajectoryProps> = ({
  actorId,
  targetId,
  characterId,
  onComplete,
}) => {
  const [progress, setProgress] = useState(0);
  const [hasImpacted, setHasImpacted] = useState(false);

  const start = PLAYER_COORDS[actorId] || { x: 50, y: 50 };
  const end = PLAYER_COORDS[targetId] || { x: 50, y: 50 };

  // Calculate quadratic bezier curve control point offset
  const midX = (start.x + end.x) / 2;
  const midY = (start.y + end.y) / 2;
  // Offset curve perpendicular to vector
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const perpX = -dy * 0.25;
  const perpY = dx * 0.25;
  const ctrlX = midX + perpX;
  const ctrlY = midY + perpY;

  const style = CHARACTER_PROJECTILE_STYLES[characterId] || {
    stroke: '#f59e0b',
    glow: 'rgba(245, 158, 11, 0.6)',
    icon: '⚡',
    size: 24,
  };

  useEffect(() => {
    let startTime: number | null = null;
    const duration = 750; // ms

    const animate = (time: number) => {
      if (!startTime) startTime = time;
      const elapsed = time - startTime;
      const t = Math.min(1, elapsed / duration);
      setProgress(t);

      if (t < 1) {
        requestAnimationFrame(animate);
      } else {
        setHasImpacted(true);
        setTimeout(() => {
          onComplete?.();
        }, 300);
      }
    };

    const animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, []);

  // Compute position along quadratic Bezier curve: B(t) = (1-t)^2*P0 + 2(1-t)t*P1 + t^2*P2
  const t = progress;
  const currentX = (1 - t) * (1 - t) * start.x + 2 * (1 - t) * t * ctrlX + t * t * end.x;
  const currentY = (1 - t) * (1 - t) * start.y + 2 * (1 - t) * t * ctrlY + t * t * end.y;

  const pathD = `M ${start.x} ${start.y} Q ${ctrlX} ${ctrlY} ${end.x} ${end.y}`;

  return (
    <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <filter id={`glow-${characterId}`} x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Trajectory Guide Path with Glow */}
        <path
          d={pathD}
          fill="none"
          stroke={style.stroke}
          strokeWidth="1.2"
          strokeDasharray="2 1.5"
          opacity="0.8"
          filter={`url(#glow-${characterId})`}
        />
      </svg>

      {/* Flying Projectile */}
      <div
        className="absolute -translate-x-1/2 -translate-y-1/2 transition-transform duration-75"
        style={{
          left: `${currentX}%`,
          top: `${currentY}%`,
          filter: `drop-shadow(0 0 8px ${style.glow})`,
        }}
      >
        <span className="text-xl sm:text-2xl select-none animate-pulse">
          {style.icon}
        </span>
      </div>

      {/* Target Impact Burst */}
      {hasImpacted && (
        <div
          className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-amber-400 animate-ping"
          style={{
            left: `${end.x}%`,
            top: `${end.y}%`,
            width: '60px',
            height: '60px',
            backgroundColor: style.glow,
          }}
        />
      )}
    </div>
  );
};
