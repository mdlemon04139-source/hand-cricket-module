import React, { useState } from 'react';
import { ShadowCard } from '../../types/shadowDetective';
import { ZoomIn, X, Tag } from 'lucide-react';

interface ShadowDetectiveCardProps {
  card: ShadowCard;
  isSelected?: boolean;
  isSolutionHint?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export const ShadowDetectiveCard: React.FC<ShadowDetectiveCardProps> = ({
  card,
  isSelected = false,
  isSolutionHint = false,
  disabled = false,
  onClick,
  size = 'md',
}) => {
  const [showZoom, setShowZoom] = useState(false);

  const isLethal = card.type === 'lethal_tool';
  const isArtifact = card.type === 'crime_artifact';
  const isPower = card.type === 'special_power';

  const borderColor = isSelected
    ? 'border-yellow-400 ring-2 ring-yellow-400 shadow-[0_0_20px_rgba(250,204,21,0.5)]'
    : isSolutionHint
    ? 'border-rose-500 ring-2 ring-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.6)] animate-pulse'
    : isLethal
    ? 'border-cyan-500/50 hover:border-cyan-400'
    : isArtifact
    ? 'border-amber-500/50 hover:border-amber-400'
    : 'border-purple-500/50 hover:border-purple-400';

  const typeBadgeColor = isLethal
    ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
    : isArtifact
    ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
    : 'bg-purple-950/80 text-purple-300 border-purple-500/40';

  const typeNameBn = isLethal
    ? 'মারাত্মক অস্ত্র (Tool)'
    : isArtifact
    ? 'ক্রাইম আলামত (Artifact)'
    : 'পাওয়ার কার্ড';

  const sizeClass =
    size === 'sm'
      ? 'w-24 h-36'
      : size === 'lg'
      ? 'w-44 h-64'
      : 'w-32 sm:w-36 h-48 sm:h-54';

  return (
    <>
      <div
        onClick={() => {
          if (!disabled && onClick) onClick();
        }}
        className={`group relative rounded-2xl overflow-hidden bg-slate-950 border-2 transition-all duration-300 flex flex-col justify-between p-1.5 select-none ${borderColor} ${sizeClass} ${
          disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:-translate-y-1'
        }`}
      >
        {/* Card Artwork */}
        <div className="relative w-full h-full rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
          <img
            src={card.image}
            alt={card.nameBn}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />

          {/* Quick Zoom Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowZoom(true);
            }}
            className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
            title="কার্ড জুম করে দেখুন"
          >
            <ZoomIn className="w-3.5 h-3.5 text-slate-200" />
          </button>

          {/* Type Badge */}
          <div className="absolute top-1 left-1 z-10">
            <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full border backdrop-blur-md ${typeBadgeColor}`}>
              {isLethal ? 'অস্ত্র' : isArtifact ? 'আলামত' : 'পাওয়ার'}
            </span>
          </div>

          {/* Bottom Title Gradient Overlay */}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-1.5 pt-4 text-center">
            <h4 className="text-[11px] sm:text-xs font-black text-white font-bengali leading-tight line-clamp-1 drop-shadow-md">
              {card.nameBn}
            </h4>
            {card.attributeTag && (
              <span className="text-[8px] text-slate-300 font-bengali flex items-center justify-center gap-0.5 mt-0.5">
                <Tag className="w-2 h-2 opacity-70" />
                <span>{card.attributeTag}</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Full-Screen Zoom Modal */}
      {showZoom && (
        <div
          onClick={() => setShowZoom(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-sm w-full bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-5 shadow-2xl flex flex-col items-center"
          >
            <button
              onClick={() => setShowZoom(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-48 h-72 rounded-2xl overflow-hidden border-2 border-slate-700 shadow-2xl mb-4 bg-slate-950">
              <img src={card.image} alt={card.nameBn} className="w-full h-full object-cover" />
            </div>

            <div className="text-center space-y-1">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${typeBadgeColor}`}>
                {typeNameBn}
              </span>
              <h3 className="text-base font-black text-white font-bengali pt-1">{card.nameBn}</h3>
              <p className="text-xs text-slate-400 font-sans italic">{card.nameEn}</p>
              <p className="text-xs text-slate-300 font-bengali leading-relaxed pt-2 px-2 bg-slate-950/60 rounded-xl border border-slate-800 p-2">
                {card.descriptionBn}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
