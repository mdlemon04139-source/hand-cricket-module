import React, { useState } from 'react';
import {
  ShadowDetectiveClientState,
  ShadowDetectiveRole,
} from '../../types/shadowDetective';
import { ROLE_INFO } from '../../data/shadowDetectiveCards';
import {
  Users,
  Copy,
  Check,
  Bot,
  Play,
  ArrowLeft,
  Shield,
  HelpCircle,
  Eye,
  Crosshair,
  BookOpen,
  Wifi,
} from 'lucide-react';
import { ShadowDetectiveManualModal } from './ShadowDetectiveManualModal';
import { NearbyMultiplayerTest } from '../multiplayer/NearbyMultiplayerTest';

interface ShadowDetectiveLobbyProps {
  roomState: ShadowDetectiveClientState;
  myPlayerId: string;
  onAddBot: () => void;
  onRemovePlayer: (playerId: string) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
}

export const ShadowDetectiveLobby: React.FC<ShadowDetectiveLobbyProps> = ({
  roomState,
  myPlayerId,
  onAddBot,
  onRemovePlayer,
  onStartGame,
  onLeaveRoom,
}) => {
  const [copied, setCopied] = useState(false);
  const [showRoleGuide, setShowRoleGuide] = useState(false);
  const [showManualModal, setShowManualModal] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  const me = roomState.players.find((p) => p.id === myPlayerId);
  const isHost = me?.isHost || false;
  const playerCount = roomState.players.length;
  const canStart = isHost && playerCount >= 5 && playerCount <= 6;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomState.roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-[100dvh] w-full bg-slate-950 text-slate-100 flex flex-col font-sans select-none overflow-y-auto overscroll-y-contain pb-24 relative">
      {/* Background noir styling */}
      <div className="fixed inset-0 bg-gradient-to-b from-indigo-950/20 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="fixed inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* Header - Sticky top */}
      <header className="sticky top-0 z-30 w-full bg-slate-950/95 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-slate-800 shadow-md">
        <button
          onClick={onLeaveRoom}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-bengali cursor-pointer transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>লবি ত্যাগ</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Crosshair className="w-4 h-4" />
          </div>
          <span className="font-black text-xs sm:text-base text-cyan-300 font-bengali">
            শ্যাডো ডিটেক্টিভ লবি
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowManualModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-bengali hover:bg-cyan-500/20 cursor-pointer"
            title="গেম ম্যানুয়াল"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">খেলার নিয়ম</span>
          </button>

          <button
            onClick={() => setShowDiagnostics(true)}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-bengali cursor-pointer"
            title="কাছাকাছি সংযোগ পরীক্ষা"
          >
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">টেস্ট</span>
          </button>

          <button
            onClick={() => setShowRoleGuide(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-xs font-bengali hover:text-white cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ভূমিকা</span>
          </button>
        </div>
      </header>

      {/* Main Lobby Container */}
      <main className="relative z-10 flex-1 max-w-4xl mx-auto w-full px-4 py-6 flex flex-col gap-6">
        {/* Room Code Card */}
        <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/40 backdrop-blur-xl shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold text-cyan-400 font-bengali tracking-wider uppercase block mb-1">
              বন্ধু বা সহ-তদন্তকারীদের আমন্ত্রণ জানান
            </span>
            <div className="flex items-center gap-3">
              <span className="font-mono font-black text-2xl sm:text-3xl text-white tracking-widest bg-slate-950 px-4 py-1.5 rounded-2xl border border-slate-800">
                {roomState.roomCode}
              </span>
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs font-bengali transition-all shadow-lg shadow-cyan-500/20 cursor-pointer"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'কপি হয়েছে!' : 'কোড কপি'}</span>
              </button>
            </div>
          </div>

          <div className="text-right sm:text-right">
            <div className="text-xs text-slate-400 font-bengali">খেলোয়াড় সংখ্যা:</div>
            <div className="text-xl sm:text-2xl font-black text-white font-mono">
              <span className={playerCount >= 5 ? 'text-emerald-400' : 'text-amber-400'}>
                {playerCount}
              </span>
              <span className="text-slate-500 text-base"> / ৬ (সর্বনিম্ন ৫)</span>
            </div>
          </div>
        </div>

        {/* Players Pods Grid */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-200 font-bengali flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>উপস্থিত খেলোয়াড় ও গোয়েন্দাবৃন্দ</span>
            </h3>

            {isHost && playerCount < 6 && (
              <button
                onClick={onAddBot}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-purple-300 text-xs font-bengali font-bold transition-all cursor-pointer shadow"
              >
                <Bot className="w-4 h-4" />
                <span>+ এআই বট যোগ করুন</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {roomState.players.map((p, idx) => (
              <div
                key={p.id}
                className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between shadow-md"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-2xl bg-slate-950 border border-slate-700 flex items-center justify-center text-xl shrink-0">
                    {p.avatar}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-xs text-white truncate font-bengali flex items-center gap-1.5">
                      <span>{p.name}</span>
                      {p.isHost && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                          HOST
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-bengali block mt-0.5">
                      আসন #{idx + 1} • {p.isOnline !== false ? 'অনলাইন' : 'অফলাইন'}
                    </span>
                  </div>
                </div>

                {isHost && p.id !== myPlayerId && (
                  <button
                    onClick={() => onRemovePlayer(p.id)}
                    className="text-[10px] text-red-400 hover:text-red-300 font-bengali px-2 py-1 rounded-lg bg-red-950/40 border border-red-500/30 cursor-pointer"
                  >
                    বাদ দিন
                  </button>
                )}
              </div>
            ))}

            {/* Empty Seat Placeholders */}
            {Array.from({ length: 6 - playerCount }).map((_, i) => (
              <div
                key={`empty_${i}`}
                className="p-3.5 rounded-2xl border-2 border-dashed border-slate-800/80 bg-slate-950/40 flex items-center justify-center text-slate-600 text-xs font-bengali"
              >
                + খালি আসন (#{playerCount + i + 1})
              </div>
            ))}
          </div>
        </div>

        {/* Start Game Action */}
        <div className="p-4 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 mt-auto">
          <div className="text-xs text-slate-400 font-bengali text-center sm:text-left">
            {playerCount < 5 ? (
              <span className="text-amber-400 font-bold">
                ⚠️ খেলা শুরু করতে আরও {5 - playerCount} জন খেলোয়াড় বা বট প্রয়োজন।
              </span>
            ) : (
              <span className="text-emerald-400 font-bold">
                ✓ যথেষ্ট খেলোয়াড় উপস্থিত! গোপন ভূমিকা ও কার্ড বণ্টনের জন্য প্রস্তুত।
              </span>
            )}
          </div>

          {isHost ? (
            <button
              onClick={onStartGame}
              disabled={!canStart}
              className={`px-8 py-3.5 rounded-2xl font-bengali font-black text-sm flex items-center gap-2 transition-all shadow-xl ${
                canStart
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 cursor-pointer shadow-cyan-500/30 hover:scale-105'
                  : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
              }`}
            >
              <Play className="w-5 h-5 fill-current" />
              <span>রহস্য তদন্ত শুরু করুন (Start Match)</span>
            </button>
          ) : (
            <div className="text-xs text-slate-400 font-bengali animate-pulse">
              হোস্টের খেলা শুরু করার অপেক্ষায়...
            </div>
          )}
        </div>
      </main>

      {/* Role Guide Modal */}
      {showRoleGuide && (
        <div
          onClick={() => setShowRoleGuide(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-xl w-full bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-6 shadow-2xl max-h-[85vh] overflow-y-auto space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-base text-white font-bengali">
                শ্যাডো ডিটেক্টিভ: গোপন ভূমিকা নির্দেশিকা
              </h3>
              <button
                onClick={() => setShowRoleGuide(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              {(Object.keys(ROLE_INFO) as ShadowDetectiveRole[]).map((rKey) => {
                const r = ROLE_INFO[rKey];
                return (
                  <div key={rKey} className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${r.badgeColor}`}>
                        {r.nameBn} ({r.nameEn})
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {r.team === 'detectives' ? 'তদন্তকারী দল' : 'অপরাধ সিন্ডিকেট'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 font-bengali leading-relaxed pt-1">
                      {r.descriptionBn}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Official Game Manual Modal */}
      <ShadowDetectiveManualModal
        isOpen={showManualModal}
        onClose={() => setShowManualModal(false)}
      />

      {/* Nearby Connection Diagnostics Modal */}
      <NearbyMultiplayerTest
        isOpen={showDiagnostics}
        onClose={() => setShowDiagnostics(false)}
      />
    </div>
  );
};
