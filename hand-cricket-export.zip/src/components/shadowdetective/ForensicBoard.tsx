import React, { useState } from 'react';
import {
  ForensicCategoryKey,
} from '../../types/shadowDetective';
import { FORENSIC_CATEGORIES } from '../../data/shadowDetectiveCards';
import { MapPin, ShieldAlert, Check } from 'lucide-react';

interface ForensicBoardProps {
  markers: Partial<Record<ForensicCategoryKey, string>>;
  isChief?: boolean;
  canEdit?: boolean;
  onSaveMarkers?: (markers: Partial<Record<ForensicCategoryKey, string>>) => void;
}

export const ForensicBoard: React.FC<ForensicBoardProps> = ({
  markers,
  isChief = false,
  canEdit = false,
  onSaveMarkers,
}) => {
  const [selectedMarkers, setSelectedMarkers] = useState<Partial<Record<ForensicCategoryKey, string>>>(markers);

  // Sync if external markers update
  React.useEffect(() => {
    setSelectedMarkers(markers);
  }, [markers]);

  const handleSelectOption = (catKey: ForensicCategoryKey, optionId: string) => {
    if (!canEdit) return;
    setSelectedMarkers((prev) => ({
      ...prev,
      [catKey]: optionId,
    }));
  };

  const allSelected =
    selectedMarkers.location && selectedMarkers.trauma && selectedMarkers.evidence_state;

  return (
    <div className="w-full rounded-3xl bg-slate-900/90 border-2 border-amber-500/40 p-4 sm:p-6 backdrop-blur-xl shadow-2xl relative overflow-hidden">
      {/* Background noir texture/lines */}
      <div className="absolute inset-0 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px] opacity-5 pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base sm:text-lg text-white font-bengali flex items-center gap-2">
              <span>ফরেনসিক কেস বোর্ড (Forensic Clue Board)</span>
              {canEdit && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                  CHIEF EDITING
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400 font-bengali">
              {canEdit
                ? 'অপরাধের দৃশ্যপট অনুযায়ী প্রতিটি সারির একটি করে সঠিক ক্লু নির্বাচন করে পিন করুন।'
                : 'প্রধান গোয়েন্দার স্থাপিত পিন সংকেত বিশ্লেষণ করে খুনি ও প্রমাণ আবিষ্কার করুন।'}
            </p>
          </div>
        </div>

        {canEdit && onSaveMarkers && (
          <button
            onClick={() => {
              if (allSelected) onSaveMarkers(selectedMarkers);
            }}
            disabled={!allSelected}
            className={`px-4 py-2 rounded-xl font-bengali font-bold text-xs flex items-center gap-1.5 transition-all shadow-lg ${
              allSelected
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 cursor-pointer shadow-amber-500/20'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            <Check className="w-4 h-4" />
            <span>ক্লু সংকেত নিশ্চিত করুন</span>
          </button>
        )}
      </div>

      {/* 3 Categories Grid */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
        {FORENSIC_CATEGORIES.map((category) => {
          const currentMarker = canEdit ? selectedMarkers[category.key] : markers[category.key];

          return (
            <div
              key={category.key}
              className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between"
            >
              <div className="flex items-center gap-2 pb-2.5 mb-2.5 border-b border-slate-800/80">
                <span className="text-xl">{category.icon}</span>
                <div className="min-w-0">
                  <h4 className="font-bold text-xs sm:text-sm text-amber-300 font-bengali truncate">
                    {category.titleBn}
                  </h4>
                  <span className="text-[9px] text-slate-500 block font-sans truncate">
                    {category.titleEn}
                  </span>
                </div>
              </div>

              {/* Options list */}
              <div className="space-y-1.5 flex-1">
                {category.options.map((opt) => {
                  const isMarked = currentMarker === opt.id;

                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleSelectOption(category.key, opt.id)}
                      disabled={!canEdit}
                      className={`w-full text-left p-2 rounded-xl transition-all flex items-center justify-between text-xs font-bengali ${
                        isMarked
                          ? 'bg-rose-950/80 text-rose-200 border-2 border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.3)] font-bold'
                          : canEdit
                          ? 'bg-slate-900/60 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer'
                          : 'bg-slate-900/40 text-slate-400 border border-slate-800/50'
                      }`}
                    >
                      <span className="truncate">{opt.labelBn}</span>
                      {isMarked ? (
                        <div className="flex items-center gap-1 text-[10px] text-rose-400 font-mono shrink-0 ml-1">
                          <MapPin className="w-3.5 h-3.5 fill-rose-500 text-rose-300 animate-bounce" />
                          <span>PINNED</span>
                        </div>
                      ) : (
                        canEdit && <span className="text-slate-600 text-[10px]">○</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
