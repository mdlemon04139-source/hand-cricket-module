import React, { useState, useEffect } from 'react';
import { ShadowPlayerPublic } from '../../types/shadowDetective';
import { Crosshair, Skull, Clock } from 'lucide-react';

interface WitnessHuntModalProps {
  isOpen: boolean;
  isKiller: boolean;
  deadline?: number;
  players: ShadowPlayerPublic[];
  myPlayerId: string;
  onHuntWitness: (targetPlayerId: string) => void;
}

export const WitnessHuntModal: React.FC<WitnessHuntModalProps> = ({
  isOpen,
  isKiller,
  deadline,
  players,
  myPlayerId,
  onHuntWitness,
}) => {
  const [secondsLeft, setSecondsLeft] = useState<number>(15);
  const [selectedTargetId, setSelectedTargetId] = useState<string>('');

  useEffect(() => {
    if (!isOpen || !deadline) return;

    const updateTimer = () => {
      const remaining = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      setSecondsLeft(remaining);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 500);
    return () => clearInterval(interval);
  }, [isOpen, deadline]);

  if (!isOpen) return null;

  // Potential targets are other players except the Killer himself and Chief
  const targets = players.filter((p) => p.id !== myPlayerId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative max-w-lg w-full bg-slate-900 border-2 border-red-500 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center">
        {/* Pulsing Skull icon */}
        <div className="w-16 h-16 rounded-2xl bg-red-950 border-2 border-red-500/80 flex items-center justify-center text-red-400 shadow-xl shadow-red-500/30 mb-3 animate-pulse">
          <Crosshair className="w-8 h-8" />
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-red-400 font-bengali flex items-center gap-2">
          <span>উইটনেস হান্ট (Witness Hunt)!</span>
        </h3>

        {/* 15s Countdown */}
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/60 text-red-300 font-mono text-sm font-bold my-2 shadow">
          <Clock className="w-4 h-4 animate-spin" />
          <span>সময় বাকি: {secondsLeft} সেকেন্ড</span>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 font-bengali max-w-md mt-1 leading-relaxed">
          {isKiller
            ? 'গোয়েন্দারা আপনাকে ধরে ফেলেছে! কিন্তু আপনার কাছে শেষ মোক্ষম সুযোগ: প্রত্যক্ষদর্শী (Eyewitness) কে ছিল তা সঠিকভাবে চিহ্নিত করুন এবং জয় ছিনিয়ে নিন!'
            : 'গোয়েন্দারা খুনিকে ধরে ফেলেছে! কিন্তু খুনি এখন প্রত্যক্ষদর্শীকে হত্যা করতে উইটনেস হান্ট চালাচ্ছে! শ্বাসরুদ্ধকর ১৫ সেকেন্ড...'}
        </p>

        {/* Killer selection controls */}
        {isKiller ? (
          <div className="w-full mt-4 space-y-3">
            <label className="text-xs font-bold text-slate-300 font-bengali block">
              টার্গেট নির্বাচন করুন (কে ছিল প্রত্যক্ষদর্শী?):
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {targets.map((p) => {
                const isSelected = selectedTargetId === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedTargetId(p.id)}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'bg-red-950 border-red-400 ring-2 ring-red-500/50 text-white font-bold'
                        : 'bg-slate-950/70 hover:bg-slate-800 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span className="text-2xl">{p.avatar}</span>
                    <span className="text-xs font-bengali truncate w-full">{p.name}</span>
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                if (selectedTargetId) {
                  onHuntWitness(selectedTargetId);
                }
              }}
              disabled={!selectedTargetId}
              className={`w-full py-3 rounded-2xl font-bengali font-black text-sm flex items-center justify-center gap-2 transition-all shadow-xl mt-3 ${
                selectedTargetId
                  ? 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white cursor-pointer shadow-red-600/40 hover:scale-[1.02]'
                  : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
              }`}
            >
              <Skull className="w-4 h-4" />
              <span>লক্ষ্যে চূড়ান্ত আঘাত হানুন</span>
            </button>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 w-full mt-4">
            <span className="text-xs text-amber-300 font-bengali animate-pulse">
              ছায়া খুনি তার শেষ টার্গেট বাছাই করছেন...
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
