import React, { useState } from 'react';
import {
  BookOpen,
  X,
  Shield,
  Crosshair,
  Skull,
  Eye,
  Radio,
  FileText,
  Clock,
  Gavel,
  Zap,
  HelpCircle,
  AlertTriangle,
  Award,
  ChevronRight,
} from 'lucide-react';

interface ShadowDetectiveManualModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShadowDetectiveManualModal: React.FC<ShadowDetectiveManualModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [activeTab, setActiveTab] = useState<number>(1);

  if (!isOpen) return null;

  const sections = [
    { id: 1, titleBn: '১. ভূমিকা ও উদ্দেশ্য', titleEn: '1. Intro & Objective', icon: <BookOpen className="w-4 h-4" /> },
    { id: 2, titleBn: '২. খেলোয়াড় সংখ্যা ও বণ্টন', titleEn: '2. Player Count & Roles', icon: <Shield className="w-4 h-4" /> },
    { id: 3, titleBn: '৩. ভূমিকা ও ক্ষমতা', titleEn: '3. Roles & Special Powers', icon: <Crosshair className="w-4 h-4" /> },
    { id: 4, titleBn: '৪. সেটআপ পর্যায়', titleEn: '4. Crime Setup Phase', icon: <FileText className="w-4 h-4" /> },
    { id: 5, titleBn: '৫. ফরেনসিক বোর্ড ও ক্লু', titleEn: '5. Forensic Clue Board', icon: <Radio className="w-4 h-4" /> },
    { id: 6, titleBn: '৬. ৩ মিনিটের আলোচনা ও জবানবন্দি', titleEn: '6. 3-Min Discussion Phase', icon: <Clock className="w-4 h-4" /> },
    { id: 7, titleBn: '৭. ৩টি মামলা দাখিলের সুযোগ', titleEn: '7. 3 Case Submission Attempts', icon: <Gavel className="w-4 h-4" /> },
    { id: 8, titleBn: '৮. ৩টি বিশেষ পাওয়ার কার্ড', titleEn: '8. Special Power Cards', icon: <Zap className="w-4 h-4" /> },
    { id: 9, titleBn: '৯. ১৫ সেকেন্ডের উইটনেস হান্ট', titleEn: '9. 15s Witness Hunt', icon: <Skull className="w-4 h-4" /> },
    { id: 10, titleBn: '১০. জয়-পরাজয়ের শর্তাবলী', titleEn: '10. Win & Loss Conditions', icon: <Award className="w-4 h-4" /> },
    { id: 11, titleBn: '১১. উদাহরণ রাউন্ড', titleEn: '11. Example Round Walkthrough', icon: <Eye className="w-4 h-4" /> },
    { id: 12, titleBn: '১২. সাধারণ প্রশ্নোত্তর (FAQ)', titleEn: '12. Frequently Asked Questions', icon: <HelpCircle className="w-4 h-4" /> },
    { id: 13, titleBn: '১৩. নিয়মের সতর্কতা ও সততা', titleEn: '13. Fairness Guidelines', icon: <AlertTriangle className="w-4 h-4" /> },
  ];

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-4xl w-full max-h-[92dvh] bg-slate-900 border-2 border-cyan-500/50 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-200"
      >
        {/* Header Bar */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white font-bengali flex items-center gap-2">
                <span>শ্যাডো ডিটেক্টিভ: গেম ম্যানুয়াল ও নিয়মাবলী</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  OFFICIAL RULES
                </span>
              </h2>
              <p className="text-[11px] text-slate-400 font-bengali">
                নিশিপুর গ্রামের রহস্যভেদ এবং গোয়েন্দা কৌশল নির্দেশিকা
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Toggle */}
            <div className="flex items-center p-0.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
              <button
                onClick={() => setLang('bn')}
                className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                  lang === 'bn' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                বাংলা
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                  lang === 'en' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                ENG
              </button>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body Container: Sidebar + Content */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Section List (Scrollable tabs) */}
          <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-800 bg-slate-950/60 p-2 overflow-x-auto md:overflow-y-auto shrink-0 flex md:flex-col gap-1">
            {sections.map((sec) => (
              <button
                key={sec.id}
                onClick={() => setActiveTab(sec.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-left transition-all shrink-0 cursor-pointer ${
                  activeTab === sec.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <span className="shrink-0">{sec.icon}</span>
                <span className="truncate font-bengali">
                  {lang === 'bn' ? sec.titleBn : sec.titleEn}
                </span>
              </button>
            ))}
          </div>

          {/* Detailed Content Reader */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto font-bengali text-xs sm:text-sm leading-relaxed space-y-4">
            {/* 1. Intro & Objective */}
            {activeTab === 1 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '১. গেম পরিচিতি ও মূল উদ্দেশ্য (Introduction & Objective)' : '1. Game Overview & Core Objective'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? 'শ্যাডো ডিটেক্টিভ (Shadow Detective) একটি রোমাঞ্চকর লুকানো ভূমিকা (Hidden-Role) এবং যৌক্তিক অনুমান (Deduction) ভিত্তিক তদন্তের খেলা। নিশিপুর গ্রামে একটি রহস্যজনক অপরাধ সংঘটিত হয়েছে। টেবিলের খেলোয়াড়দের মাঝেই লুকিয়ে আছে আসল খুনি এবং তার সহযোগী সিন্ডিকেট ইনসাইডার।'
                    : 'Shadow Detective is a high-stakes hidden-role deduction game set in the village of Nishipur. A crime has taken place, and the killer is seated right among the players at the table along with a secret syndicate insider.'}
                </p>
                <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-500/40 space-y-2">
                  <h4 className="font-bold text-cyan-200">
                    {lang === 'bn' ? 'তদন্তকারী দলের লক্ষ্য:' : "Detective Squad's Goal:"}
                  </h4>
                  <p className="text-slate-300">
                    {lang === 'bn'
                      ? 'প্রধান গোয়েন্দার স্থাপিত ফরেনসিক ক্লু সংকেত এবং খেলোয়াড়দের হাতের প্রকাশ্যে থাকা আলামত ও অস্ত্র বিশ্লেষণ করে ৩টি সুযোগের মধ্যে আসল খুনি, ব্যবহৃত ১টি অস্ত্র (Lethal Tool) এবং ১টি আলামত (Crime Scene Artifact) সঠিকভাবে চিহ্নিত করা।'
                      : 'Analyze forensic clue pins from the Chief Investigator to deduce the exact Killer, the 1 Lethal Tool, and 1 Crime Artifact within 3 team submission attempts.'}
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-rose-950/30 border border-rose-500/40 space-y-2">
                  <h4 className="font-bold text-rose-200">
                    {lang === 'bn' ? 'অপরাধী সিন্ডিকেটের লক্ষ্য:' : "Syndicate's Goal:"}
                  </h4>
                  <p className="text-slate-300">
                    {lang === 'bn'
                      ? 'আলোচনার মধ্যে ভুল সূত্র ঢুকিয়ে গোয়েন্দাদের ৩টি মামলায় ব্যর্থ করা অথবা যদি গোয়েন্দারা সঠিক সমাধান বের করেও ফেলে, তবে ১৫ সেকেন্ডের উইটনেস হান্ট পর্বে প্রধান প্রত্যক্ষদর্শীকে (Eyewitness) চিহ্নিত করে হত্যা করে জয় ছিনিয়ে নেওয়া।'
                      : 'Deceive detectives into exhausting all 3 submission attempts, or if caught, assassinate the Eyewitness during the 15-second sudden-death Witness Hunt.'}
                  </p>
                </div>
              </div>
            )}

            {/* 2. Player Count & Roles */}
            {activeTab === 2 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '২. খেলোয়াড় সংখ্যা ও ভূমিকার নিয়ম (Player Count & Role Matrix)' : '2. Player Count & Role Matrix'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? 'শ্যাডো ডিটেক্টিভ ৫ বা ৬ জন খেলোয়াড়ের জন্য সুনির্দিষ্টভাবে ভারসাম্যপূর্ণ:'
                    : 'Shadow Detective is strictly balanced for 5 or 6 players:'}
                </p>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border border-slate-800 rounded-xl overflow-hidden">
                    <thead className="bg-slate-950 text-slate-300 font-bold text-[11px]">
                      <tr>
                        <th className="p-2.5 border-b border-slate-800">প্লেয়ার সংখ্যা</th>
                        <th className="p-2.5 border-b border-slate-800">আইন ও তদন্তকারী দল</th>
                        <th className="p-2.5 border-b border-slate-800">অপরাধ সিন্ডিকেট</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-[11px] text-slate-300">
                      <tr>
                        <td className="p-2.5 font-bold text-white">৫ জন খেলোয়াড়</td>
                        <td className="p-2.5">প্রধান গোয়েন্দা + প্রত্যক্ষদর্শী + ১ জন গোয়েন্দা</td>
                        <td className="p-2.5 text-rose-300 font-bold">ছায়া খুনি + সিন্ডিকেট ইনসাইডার</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-bold text-white">৬ জন খেলোয়াড়</td>
                        <td className="p-2.5">প্রধান গোয়েন্দা + প্রত্যক্ষদর্শী + ২ জন গোয়েন্দা</td>
                        <td className="p-2.5 text-rose-300 font-bold">ছায়া খুনি + সিন্ডিকেট ইনসাইডার</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-[11px] text-amber-300 bg-amber-950/20 p-2.5 rounded-xl border border-amber-500/30">
                  {lang === 'bn'
                    ? '⚠️ নিয়ম: ৫ জনের কম বা ৬ জনের বেশি খেলোয়াড় নিয়ে খেলা শুরু করা যাবে না। খেলোয়াড় অপূর্ণ থাকলে AI বট যুক্ত করে ৫ বা ৬ জন পূর্ণ করুন।'
                    : '⚠️ Rule: Matches cannot start with fewer than 5 or more than 6 players. Add intelligent AI bots to fill empty slots.'}
                </p>
              </div>
            )}

            {/* 3. Roles & Special Powers */}
            {activeTab === 3 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৩. প্রতিটি ভূমিকার গোপন ক্ষমতা ও তথ্য' : '3. Role Powers & Secret Knowledge'}
                </h3>
                <div className="space-y-2.5">
                  <div className="p-3 rounded-2xl bg-amber-950/20 border border-amber-500/40">
                    <strong className="text-amber-300 font-bold block">১. প্রধান গোয়েন্দা (Chief Investigator):</strong>
                    <span>তিনি খুনের সঠিক ১টি অস্ত্র ও ১টি আলামত দেখতে পান। কিন্তু তিনি জানেন না খুনি কে! তিনি সরাসরি কথা বলতে পারবেন না; কেবল ফরেনসিক বোর্ডে ক্লু মার্কার পিন করে সংকেত দেবেন।</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-rose-950/20 border border-rose-500/40">
                    <strong className="text-rose-400 font-bold block">২. ছায়া খুনি (Shadow Killer):</strong>
                    <span>খেলা শুরুর সময় নিজের হাতের কার্ড থেকে গোপনে ১টি প্রাণঘাতী অস্ত্র ও ১টি আলামত নির্ধারণ করেন। আলোচনায় নিজের ওপর সন্দেহ না যেতে সাধারণ গোয়েন্দার ছদ্মবেশ ধারণ করেন।</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-purple-950/20 border border-purple-500/40">
                    <strong className="text-purple-300 font-bold block">৩. সিন্ডিকেট ইনসাইডার (Syndicate Insider):</strong>
                    <span>তিনি জানেন খুনি কে এবং খুনে কোন অস্ত্র ও আলামত ব্যবহৃত হয়েছে। তিনি গোয়েন্দাদের ভুল ব্যাখ্যা দিয়ে বিভ্রান্ত করেন এবং উইটনেস হান্ট পর্বে খুনিকে সাহায্য করেন।</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-emerald-950/20 border border-emerald-500/40">
                    <strong className="text-emerald-300 font-bold block">৪. প্রত্যক্ষদর্শী (Eyewitness):</strong>
                    <span>তিনি জানেন আসল খুনি কে! কিন্তু তিনি ব্যবহৃত অস্ত্র বা আলামত জানেন না। তাকে খুব সাবধানে অন্য গোয়েন্দাদের সঠিক পথে চালিত করতে হবে, কারণ ধরা পড়লে উইটনেস হান্টে তিনি নিহত হবেন!</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-cyan-950/20 border border-cyan-500/40">
                    <strong className="text-cyan-300 font-bold block">৫. গোয়েন্দা সদস্য (Detective Squad):</strong>
                    <span>কোনো গোপন তথ্য শুরুতে তাদের জানা থাকে না। তারা ক্লু বোর্ড বিশ্লেষণ করে, সন্দেহভাজনদের জেরা করে এবং ৩টি মামলা দাখিলের সুযোগ ব্যবহার করে খুনের কিনারা করেন।</span>
                  </div>
                </div>
              </div>
            )}

            {/* 4. Setup Instructions */}
            {activeTab === 4 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৪. অপরাধ সেটআপ পর্যায় (Crime Setup)' : '4. Crime Setup Phase'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? '১. প্রত্যেক সন্দেহভাজন খেলোয়াড়ের সামনে টেবিলে প্রকাশ্যে ৪টি কার্ড বন্টন করা হয় (২টি প্রাণঘাতী অস্ত্র কার্ড এবং ২টি অপরাধের আলামত কার্ড)।'
                    : '1. Each suspect is dealt 4 public cards on the table (2 Lethal Tools + 2 Crime Artifacts).'}
                </p>
                <p>
                  {lang === 'bn'
                    ? '২. ছায়া খুনি গোপনে তার নিজের ৪টি কার্ডের মধ্য থেকে ১টি অস্ত্র এবং ১টি আলামত নির্বাচন করে অপরাধ নিশ্চিত করেন।'
                    : '2. The Shadow Killer secretly chooses 1 tool and 1 artifact from their personal dealt cards.'}
                </p>
                <p>
                  {lang === 'bn'
                    ? '৩. সার্ভার গোপন সমাধানটি এনক্রিপ্ট করে শুধুমাত্র অনুমোদিত ভূমিকাদের (প্রধান গোয়েন্দা ও ইনসাইডার) কাছে সংকেত পাঠিয়ে পরবর্তী পর্যায়ে নিয়ে যায়।'
                    : '3. The authoritative game engine stores the crime combination and transitions to the Forensic Phase.'}
                </p>
              </div>
            )}

            {/* 5. Forensic Clues */}
            {activeTab === 5 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৫. ফরেনসিক বোর্ড ও ক্লু বিশ্লেষণ (Forensic Clues)' : '5. Forensic Clue Interpretation'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? 'প্রধান গোয়েন্দা কোনো কথা না বলে অপরাধের দৃশ্যের ৩টি অপরিহার্য বৈশিষ্ট্য নির্দেশ করতে বোর্ডে মার্কার পিন করেন:'
                    : 'The Chief Investigator sets 3 permanent markers on the Forensic Board:'}
                </p>
                <ul className="list-disc list-inside space-y-1.5 text-slate-300 pl-2">
                  <li><strong>ঘটনাস্থল (Location of Crime):</strong> পুরাতন জমিদার বাড়ি, চায়ের দোকান, নির্জন নদীঘাট, ধানক্ষেত ইত্যাদি।</li>
                  <li><strong>মৃত্যুর কারণ ও আঘাত (Cause & Trauma):</strong> বিষক্রিয়া, ভারী আঘাত, শ্বাসরোধ, রক্তক্ষরণ ইত্যাদি।</li>
                  <li><strong>আলামতের দৃশ্যমান অবস্থা (State of Clue):</strong> পুড়ে যাওয়া ছাই, ভাঙা কাচ, রক্তমাখা, নিখুঁত বা ভেজা।</li>
                </ul>
                <p className="text-[11px] text-cyan-300 bg-cyan-950/20 p-2.5 rounded-xl border border-cyan-500/30">
                  {lang === 'bn'
                    ? '💡 গোয়েন্দা পরামর্শ: কোন খেলোয়াড়ের কার্ডগুলোর সাথে ৩টি মার্কারের বিবরণ সবচেয়ে নিখুঁতভাবে মেলে? সন্দেহভাজনদের প্রতিটি কার্ডের ছবি ও শিরোনাম পর্যবেক্ষণ করুন।'
                    : '💡 Detective Tip: Cross-reference which suspect card set best matches all 3 pins.'}
                </p>
              </div>
            )}

            {/* 6. Discussion */}
            {activeTab === 6 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৬. ৩ মিনিটের আলোচনা ও জেরা পর্যায়' : '6. 3-Minute Discussion Phase'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? 'তদন্তের মূল পর্বে শুরু হয় ১৮০ সেকেন্ডের (৩ মিনিট) লাইভ টাইমার। এখানে খেলোয়াড়রা চ্যাট এবং দ্রুত সংকেত হুইল (Chat Wheel) ব্যবহার করে যুক্তি উপস্থাপন করেন।'
                    : 'A 180-second live countdown begins. Players discuss evidence using text chat and the Quick-Chat wheel.'}
                </p>
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="text-rose-300 font-bold">খুনির কৌশল:</div>
                  <p>নিজের কার্ড থেকে অন্য কারও কার্ডের দিকে গোয়েন্দাদের দৃষ্টি ঘুরিয়ে দিন। নিরীহ সেজে অন্য কাউকে সন্দেহভাজন বলুন।</p>
                  <div className="text-emerald-300 font-bold pt-1">প্রত্যক্ষদর্শীর কৌশল:</div>
                  <p>সরাসরি বলবেন না "আমি জানি ও খুনি!", কারণ ইনসাইডার আপনার আসল ভূমিকা ধরে ফেলবে। যুক্তি দিয়ে অন্যদের প্রভাবিত করুন।</p>
                </div>
              </div>
            )}

            {/* 7. Case Submissions */}
            {activeTab === 7 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৭. ৩টি মামলা দাখিলের সুযোগ (3 Case Submissions)' : '7. 3 Case Submission Attempts'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? 'যেকোনো গোয়েন্দা (প্রধান গোয়েন্দা ব্যতীত) আলোচনার যেকোনো মুহূর্তে "মামলা দাখিল (Submit Case)" বোতামে চেপে সমাধান উপস্থাপন করতে পারেন:'
                    : 'Any active squad member can tap "Submit Case" to accuse a suspect and name the weapon and artifact:'}
                </p>
                <div className="p-3 rounded-2xl bg-rose-950/20 border border-rose-500/40 space-y-1.5">
                  <span className="font-bold text-rose-300 block">দাখিল করার উপাদান:</span>
                  <div>১. সন্দেহভাজন ব্যক্তি (Suspect Name)</div>
                  <div>২. প্রাণঘাতী অস্ত্র (Lethal Tool Card)</div>
                  <div>৩. অপরাধের আলামত (Crime Scene Artifact Card)</div>
                </div>
                <p className="text-[11px] text-amber-300">
                  {lang === 'bn'
                    ? '⚠️ সতর্কতা: সম্পূর্ণ দলের জন্য মাত্র ৩টি সুযোগ বরাদ্দ থাকে! ৩ বারই ভুল মামলা দাখিল করলে বা ৩ মিনিটের সময়সীমা শেষ হয়ে গেলে গোয়েন্দা দল তাৎক্ষণিক পরাজিত হয়।'
                    : '⚠️ The entire squad shares 3 attempts total. 3 failed accusations or timer expiration results in immediate Syndicate Victory.'}
                </p>
              </div>
            )}

            {/* 8. Special Power Cards */}
            {activeTab === 8 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৮. ৩টি বিশেষ পাওয়ার কার্ডের কার্যকারিতা' : '8. 3 Special Power Cards'}
                </h3>
                <div className="space-y-2">
                  <div className="p-3 rounded-2xl bg-cyan-950/30 border border-cyan-500/40">
                    <strong className="text-cyan-300 font-bold block">🔬 ময়না তদন্ত রিপোর্ট (Autopsy Report):</strong>
                    <span>সন্দেহভাজনদের হাতের একটি ভুল কার্ড সম্পূর্ণ নিশ্চিতভাবে বাতিল (Eliminate) করে দেয়, যা তদন্তের পরিধি কমিয়ে আনে।</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-purple-950/30 border border-purple-500/40">
                    <strong className="text-purple-300 font-bold block">📡 আড়িপাতা পাস (Wiretap Pass):</strong>
                    <span>অপরাধ সিন্ডিকেটের গোপন সংকেতের একটি লুকানো ক্লু গোয়েন্দাদের কাছে উন্মুক্ত করে।</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-amber-950/30 border border-amber-500/40">
                    <strong className="text-amber-300 font-bold block">⚖️ আলিবাই চেক (Alibi Check):</strong>
                    <span>যেকোনো ১ জন খেলোয়াড়কে জেরা করে তার অপরাধের সম্ভাবনা প্রকাশ করে (৫০% বিশ্বস্ততা সহ ফরেনসিক রায় প্রদান করে)।</span>
                  </div>
                </div>
              </div>
            )}

            {/* 9. Witness Hunt */}
            {activeTab === 9 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '৯. ১৫ সেকেন্ডের উইটনেস হান্ট (Witness Hunt)' : '9. 15-Second Witness Hunt'}
                </h3>
                <p>
                  {lang === 'bn'
                    ? 'যদি গোয়েন্দা দল সঠিক খুনি, অস্ত্র ও আলামত উন্মোচন করে ফেলে, তবে খেলা এখানেই শেষ হয় না! শুরু হয় তীব্র স্নায়ুচাপের ১৫ সেকেন্ডের উইটনেস হান্ট পর্ব।'
                    : 'If detectives correctly solve the murder, the game is not won yet! A 15-second sudden-death countdown triggers.'}
                </p>
                <div className="p-3.5 rounded-2xl bg-rose-950/30 border border-rose-500/50 space-y-2">
                  <p className="text-rose-200">
                    খুনি এবং সিন্ডিকেট ইনসাইডার আলোচনা চলাকালে প্রত্যক্ষদর্শী কে ছিল তা বের করার জন্য ১৫ সেকেন্ড সময় পান। যদি তারা প্রত্যক্ষদর্শীকে ঠিকভাবে চিহ্নিত করে হত্যা করতে পারেন, তবে তদন্তকারী দলের নিশ্চিত জয় ছিনতাই হয়ে অপরাধী সিন্ডিকেট বিজয়ী হবে!
                  </p>
                  <p className="text-emerald-300 font-bold">
                    যদি তারা প্রত্যক্ষদর্শীকে ধরতে না পারে বা ১৫ সেকেন্ড পার হয়ে যায়, তবে তদন্তকারী দল চূড়ান্ত চ্যাম্পিয়ন ঘোষিত হয়!
                  </p>
                </div>
              </div>
            )}

            {/* 10. Win & Loss Conditions */}
            {activeTab === 10 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '১০. জয় ও পরাজয়ের সুনির্দিষ্ট শর্তাবলী' : '10. Win & Loss Conditions'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-500/40">
                    <h4 className="font-bold text-cyan-300 mb-2">🏆 তদন্তকারী দলের জয়:</h4>
                    <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                      <li>৩টি চেষ্টার মধ্যে সঠিক খুনি + অস্ত্র + আলামত চিহ্নিত করা।</li>
                      <li>এবং উইটনেস হান্ট পর্বে প্রত্যক্ষদর্শীকে রক্ষা করা (খুনি ধরতে না পারা বা সময় শেষ হওয়া)।</li>
                    </ul>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-rose-950/30 border border-rose-500/40">
                    <h4 className="font-bold text-rose-300 mb-2">💀 অপরাধ সিন্ডিকেটের জয়:</h4>
                    <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                      <li>গোয়েন্দারা তাদের ৩টি মামলাই ভুলভাবে দাখিল করলে।</li>
                      <li>১৮০ সেকেন্ডের আলোচনা সময়সীমা শেষ হয়ে গেলে।</li>
                      <li>অথবা উইটনেস হান্ট পর্বে প্রত্যক্ষদর্শীকে সফলভাবে হত্যা করলে।</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* 11. Example Round */}
            {activeTab === 11 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '১১. উদাহরণ রাউন্ড: নিশিপুর রহস্য (Example Round)' : '11. Example Round Walkthrough'}
                </h3>
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-[11px]">
                  <p><strong>সেটআপ:</strong> ৫ জন খেলোয়াড়: মতিন মিয়া, কালু চোর, মোস্তফা স্যার, রেহানা আপা, ও রবিন।</p>
                  <p><strong>গোপন অপরাধ:</strong> কালু চোর হলো 'ছায়া খুনি'। সে বেছে নিল অস্ত্র: <em>সাইলেন্সড পিস্তল</em> এবং আলামত: <em>রক্তমাখা ঘড়ি</em>।</p>
                  <p><strong>ফরেনসিক বোর্ড:</strong> প্রধান গোয়েন্দা পিন করলেন: স্থান = 'পুরাতন জমিদার বাড়ি', আঘাত = 'রক্তক্ষরণ', অবস্থা = 'রক্তাক্ত'।</p>
                  <p><strong>আলোচনা:</strong> রেহানা আপা (প্রত্যক্ষদর্শী) বললেন: "ঘড়ির সময় আর রক্তক্ষরণ কালু চোরের টেবিল কার্ডের সাথে হুবহু মিলছে!"</p>
                  <p><strong>মামলা:</strong> রবিন মামলা দাখিল করল: খুনি: কালু চোর, অস্ত্র: সাইলেন্সড পিস্তল, আলামত: রক্তমাখা ঘড়ি। মামলা সঠিক!</p>
                  <p><strong>উইটনেস হান্ট:</strong> কালু চোর সন্দেহ করল মোস্তফা স্যারকে। কিন্তু প্রত্যক্ষদর্শী ছিল রেহানা আপা! শিকার ব্যর্থ! গোয়েন্দা দল বিজয়ী!</p>
                </div>
              </div>
            )}

            {/* 12. FAQs */}
            {activeTab === 12 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '১২. সাধারণ জিজ্ঞাসা ও সমাধান (FAQ)' : '12. Frequently Asked Questions'}
                </h3>
                <div className="space-y-2">
                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-amber-300 block">প্রশ্ন: প্রধান গোয়েন্দা কি চ্যাটে লিখতে পারেন?</span>
                    <span className="text-slate-300">উত্তর: না। প্রধান গোয়েন্দার ভূমিকা নীরব ফরেনসিক বিজ্ঞানীর। তিনি কোনো চ্যাট বা ভয়েস সংকেত দিতে পারবেন না, শুধুমাত্র ৩টি বোর্ডের পিন স্থাপন করবেন।</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-amber-300 block">প্রশ্ন: কোনো খেলোয়াড় ডিসকানেক্ট হলে খেলা কি নষ্ট হবে?</span>
                    <span className="text-slate-300">উত্তর: না। কোনো খেলোয়াড় হঠাৎ অফলাইন হলে সার্ভার অটোমেটিক তার জায়গায় উপযুক্ত AI বট নিযুক্ত করে খেলা নিরবচ্ছিন্নভাবে পরিচালনা করে।</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-amber-300 block">প্রশ্ন: অফলাইনে কি ৫-৬ জন খেলা যায়?</span>
                    <span className="text-slate-300">উত্তর: হ্যাঁ, একই ফোনে "পাস অ্যান্ড প্লে" অথবা বট মোডের মাধ্যমে অফলাইনে ইন্টারনেট ছাড়াও খেলা যায়।</span>
                  </div>
                </div>
              </div>
            )}

            {/* 13. Fairness Guidelines */}
            {activeTab === 13 && (
              <div className="space-y-3">
                <h3 className="text-base font-bold text-cyan-300">
                  {lang === 'bn' ? '১৩. সততা ও খেলার শিষ্টাচার (Fairness Guidelines)' : '13. Fairness & Code of Honor'}
                </h3>
                <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/40 space-y-2 text-slate-300">
                  <p>• <strong>স্ক্রিন গোপন রাখা:</strong> পাস অ্যান্ড প্লে বা পাশাপাশি বসে খেলার সময় অন্য খেলোয়াড়ের ডিভাইসের স্ক্রিনে দৃষ্টি দেবেন না।</p>
                  <p>• <strong>ভূমিকায় অবিচল থাকা:</strong> আপনি ইনসাইডার বা খুনি হলে কখনো চ্যাটে নিজের ভূমিকা প্রকাশ করে দলের স্বার্থ বিসর্জন দেবেন না।</p>
                  <p>• <strong>ক্লু বোর্ডের পবিত্রতা:</strong> প্রধান গোয়েন্দার ক্লু বোর্ডটিই তদন্তের একমাত্র আনুষ্ঠানিক ভিত্তি। যুক্তির শক্তিতে সত্য উদঘাটন করুন।</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-400 font-bengali">
            পৃষ্ঠা {activeTab} / {sections.length}
          </div>
          <div className="flex items-center gap-2">
            {activeTab > 1 && (
              <button
                onClick={() => setActiveTab((p) => p - 1)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:text-white font-bengali cursor-pointer"
              >
                পূর্ববর্তী
              </button>
            )}
            {activeTab < sections.length ? (
              <button
                onClick={() => setActiveTab((p) => p + 1)}
                className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs font-bengali cursor-pointer"
              >
                পরবর্তী অধ্যায়
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs font-bengali cursor-pointer"
              >
                পড়া শেষ (Close)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
