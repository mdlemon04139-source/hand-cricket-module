import React from 'react';
import { CHAT_WHEEL_MESSAGES } from '../../data/shadowDetectiveCards';
import { X, MessageSquare, Radio } from 'lucide-react';

interface ChatWheelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMessage: (textBn: string) => void;
}

export const ChatWheelModal: React.FC<ChatWheelModalProps> = ({
  isOpen,
  onClose,
  onSelectMessage,
}) => {
  if (!isOpen) return null;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-lg w-full bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white font-bengali">
                ট্যাকটিকাল চ্যাট হুইল (Quick Tactical Phrases)
              </h3>
              <p className="text-[11px] text-slate-400 font-bengali">
                দ্রুত আলোচনা ও যোগাযোগের জন্য বার্তাটি নির্বাচন করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tactical Messages Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-4 max-h-80 overflow-y-auto">
          {CHAT_WHEEL_MESSAGES.map((msg) => (
            <button
              key={msg.id}
              onClick={() => {
                onSelectMessage(msg.textBn);
                onClose();
              }}
              className="p-3 rounded-2xl bg-slate-950/80 hover:bg-cyan-950/40 border border-slate-800 hover:border-cyan-500/60 text-left transition-all duration-200 group flex items-start gap-2.5 cursor-pointer shadow-md"
            >
              <MessageSquare className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0 group-hover:scale-110 transition-transform" />
              <div>
                <p className="font-bold text-xs text-white font-bengali group-hover:text-cyan-200 leading-snug">
                  {msg.textBn}
                </p>
                <span className="text-[9px] text-slate-500 font-sans block mt-0.5">
                  {msg.textEn}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
