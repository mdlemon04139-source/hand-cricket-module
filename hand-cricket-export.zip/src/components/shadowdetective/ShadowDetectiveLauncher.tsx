import React, { useState, useEffect } from 'react';
import {
  Crosshair,
  ArrowLeft,
  Users,
  Play,
  BookOpen,
  Wifi,
  Compass,
  Sparkles,
  Shield,
  Activity,
  Layers,
} from 'lucide-react';
import { sound } from '../../utils/sound';
import { ShadowDetectiveManualModal } from './ShadowDetectiveManualModal';
import { NearbyMultiplayerTest } from '../multiplayer/NearbyMultiplayerTest';
import { NISHIPUR_CHARACTERS } from '../../data/nishipurCharacters';

interface ShadowDetectiveLauncherProps {
  onBackToPlatform: () => void;
  onRoomReady: (roomId: string, playerId: string) => void;
  onStartStoryMode: () => void;
}

export const ShadowDetectiveLauncher: React.FC<ShadowDetectiveLauncherProps> = ({
  onBackToPlatform,
  onRoomReady,
  onStartStoryMode,
}) => {
  const [activeMode, setActiveMode] = useState<'story' | 'multiplayer'>('story');
  const [multiplayerTab, setMultiplayerTab] = useState<'create' | 'join'>('create');
  const [name, setName] = useState('রবিন');
  const [avatar, setAvatar] = useState('🕵️‍♂️');
  const [joinCode, setJoinCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showManualModal, setShowManualModal] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  // Live Statistics
  const [stats, setStats] = useState<{ totalPlays: number; totalUniquePlayers: number }>({
    totalPlays: 48,
    totalUniquePlayers: 16,
  });

  const avatars = ['🕵️‍♂️', '🔍', '💼', '🥷', '🕶️', '🔬', '💻', '📜'];

  useEffect(() => {
    fetch('/api/shadowdetective/stats')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && typeof data.totalPlays === 'number') {
          setStats(data);
        }
      })
      .catch(() => {});
  }, []);

  const handleCreateRoom = async () => {
    sound.playClick();
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/shadowdetective/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, avatar }),
      });
      const data = await res.json();
      if (data.roomId && data.playerId) {
        onRoomReady(data.roomId, data.playerId);
      } else {
        setErrorMsg('রুম তৈরি করা সম্ভব হয়নি।');
      }
    } catch {
      setErrorMsg('সার্ভারের সাথে সংযোগ স্থাপন করা যায়নি।');
    } finally {
      setIsLoading(false);
    }
  };

  const handleJoinRoom = async () => {
    sound.playClick();
    if (!joinCode.trim()) {
      setErrorMsg('অনুগ্রহ করে রুম কোড লিখুন।');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch(`/api/shadowdetective/rooms/${joinCode.trim().toUpperCase()}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, avatar }),
      });
      const data = await res.json();
      if (data.success && data.roomId && data.playerId) {
        onRoomReady(data.roomId, data.playerId);
      } else {
        setErrorMsg(data.error || 'রুমে প্রবেশ করা যায়নি। কোড চেক করুন।');
      }
    } catch {
      setErrorMsg('সার্ভারের সাথে সংযোগ স্থাপন করা যায়নি।');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-slate-950 text-slate-100 flex flex-col justify-between font-sans select-none overflow-y-auto relative pb-16">
      {/* Background noir styling */}
      <div className="fixed inset-0 bg-gradient-to-b from-cyan-950/20 via-slate-950 to-slate-950 pointer-events-none" />

      {/* Header - Sticky top */}
      <header className="sticky top-0 z-20 w-full bg-slate-950/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between shadow-md">
        <button
          onClick={onBackToPlatform}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-bengali cursor-pointer transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>হোমে ফিরুন</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Crosshair className="w-4 h-4" />
          </div>
          <span className="font-black text-xs sm:text-base text-cyan-300 font-bengali">
            শ্যাডো ডিটেক্টিভ — নিশিপুর
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowManualModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-bengali hover:bg-cyan-500/20 cursor-pointer"
            title="গেম ম্যানুয়াল"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">খেলার নিয়ম</span>
          </button>

          <button
            onClick={() => setShowDiagnostics(true)}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-bengali cursor-pointer"
            title="কাছাকাছি সংযোগ পরীক্ষা"
          >
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">টেস্ট</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 max-w-4xl w-full mx-auto px-4 py-6 flex-1 flex flex-col gap-6">
        {/* Live Game Statistics Bar */}
        <div className="p-3 sm:p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/30 flex items-center justify-between shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-xs text-slate-200 font-bengali">
                তদন্ত পরিসংখ্যান (Live Network Stats)
              </h3>
              <p className="text-[10px] text-slate-400 font-bengali">
                নিশিপুর গ্রামে মোট পরিচালিত তদন্ত ও গোয়েন্দাদের সক্রিয় তথ্য
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono font-bold">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-bengali block">মোট খেলা:</span>
              <span className="text-cyan-300 text-sm">{stats.totalPlays}</span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-bengali block">মোট গোয়েন্দা:</span>
              <span className="text-emerald-300 text-sm">{stats.totalUniquePlayers}</span>
            </div>
          </div>
        </div>

        {/* Mode Selector (Single Player Story vs Room Multiplayer) */}
        <div className="grid grid-cols-2 p-1.5 rounded-3xl bg-slate-900/90 border border-slate-800 max-w-lg mx-auto w-full shadow-lg">
          <button
            onClick={() => {
              sound.playClick();
              setActiveMode('story');
            }}
            className={`py-3 px-4 rounded-2xl font-bengali font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeMode === 'story'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>একক গোয়েন্দা অভিযান</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveMode('multiplayer');
            }}
            className={`py-3 px-4 rounded-2xl font-bengali font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeMode === 'multiplayer'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>রুম মাল্টিপ্লেয়ার</span>
          </button>
        </div>

        {/* MODE 1: SINGLE PLAYER STORY MODE CARD */}
        {activeMode === 'story' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/50 backdrop-blur-xl shadow-2xl flex flex-col md:flex-row items-center gap-6 animate-fadeIn">
            <div className="w-full md:w-5/12 flex flex-col items-center">
              <div className="relative group w-44 h-60 rounded-3xl overflow-hidden border-2 border-cyan-400 shadow-2xl bg-slate-950">
                <img
                  src="/assets/aistudio/Investigator_Robin_Bengali_Character_Card_f976d6f4.png"
                  alt="রবিন - প্রধান তদন্তকারী"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-x-0 bottom-0 p-2.5 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent text-center">
                  <span className="text-xs font-black text-cyan-300 font-bengali block">
                    রবিন — প্রধান তদন্তকারী
                  </span>
                  <span className="text-[10px] text-slate-300 font-bengali">
                    মাঠ সহকারী তুহার সাথে
                  </span>
                </div>
              </div>
            </div>

            <div className="w-full md:w-7/12 space-y-4">
              <div>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold font-bengali">
                  স্টোরি মোড (AI Investigation)
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-white font-bengali mt-2">
                  নিশিপুর কেস ফাইল — একক অভিযান
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 font-bengali leading-relaxed mt-2">
                  নিশিপুর গ্রামের কুখ্যাত রহস্য ও অমীমাংসিত অপরাধের সমাধান করুন। ৫ জন বিশিষ্ট গ্রামবাসীর মধ্যে একজন আসল অপরাধী লুকিয়ে আছে। ধাপে ধাপে জেরা করে একজনকে করে অব্যাহতি দিন এবং শেষ দ্বৈরথে অপরাধী ও ব্যবহৃত প্রমাণ উদঘাটন করুন!
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-bengali text-slate-400">
                <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <Shield className="w-4 h-4 text-cyan-400" />
                  <span>১৫ জন আসল চরিত্র</span>
                </div>
                <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>তুহার ফরেনসিক ল্যাব</span>
                </div>
              </div>

              <button
                onClick={() => {
                  sound.playClick();
                  onStartStoryMode();
                }}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm font-bengali shadow-xl shadow-cyan-500/25 hover:scale-[1.01] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>তদন্ত শুরু করুন (Start Solo Investigation)</span>
              </button>
            </div>
          </div>
        )}

        {/* MODE 2: ROOM MULTIPLAYER */}
        {activeMode === 'multiplayer' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/40 backdrop-blur-xl shadow-2xl flex flex-col gap-5 max-w-md mx-auto w-full animate-fadeIn">
            <div className="text-center">
              <h2 className="text-xl font-black text-white font-bengali">
                তদন্ত কক্ষে প্রবেশ (Multiplayer)
              </h2>
              <p className="text-xs text-slate-400 font-bengali mt-1">
                ৫-৬ জন খেলোয়াড় নিয়ে গোপন ভূমিকা ও সামাজিক অনুমান পর্ব
              </p>
            </div>

            {/* Sub-tabs */}
            <div className="grid grid-cols-2 p-1 rounded-2xl bg-slate-950 border border-slate-800">
              <button
                onClick={() => {
                  sound.playClick();
                  setMultiplayerTab('create');
                  setErrorMsg(null);
                }}
                className={`py-2 rounded-xl text-xs font-bengali font-bold transition-all cursor-pointer ${
                  multiplayerTab === 'create'
                    ? 'bg-cyan-500 text-slate-950 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                নতুন রুম তৈরি
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setMultiplayerTab('join');
                  setErrorMsg(null);
                }}
                className={`py-2 rounded-xl text-xs font-bengali font-bold transition-all cursor-pointer ${
                  multiplayerTab === 'join'
                    ? 'bg-cyan-500 text-slate-950 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                কোড দিয়ে প্রবেশ
              </button>
            </div>

            {/* Error notice */}
            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs font-bengali text-center">
                {errorMsg}
              </div>
            )}

            {/* Fields */}
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 font-bengali block mb-1">
                  আপনার গোয়েন্দা নাম:
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  maxLength={18}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-bengali text-sm focus:outline-none focus:border-cyan-500"
                  placeholder="নাম লিখুন..."
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 font-bengali block mb-1">
                  অবতার নির্বাচন:
                </label>
                <div className="flex items-center justify-between gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
                  {avatars.map((av) => (
                    <button
                      key={av}
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        setAvatar(av);
                      }}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg transition-all cursor-pointer ${
                        avatar === av
                          ? 'bg-cyan-500/20 border border-cyan-400 scale-110 shadow'
                          : 'hover:bg-slate-800 opacity-60 hover:opacity-100'
                      }`}
                    >
                      {av}
                    </button>
                  ))}
                </div>
              </div>

              {multiplayerTab === 'join' && (
                <div>
                  <label className="text-xs font-bold text-slate-300 font-bengali block mb-1">
                    রুম কোড (Room Code):
                  </label>
                  <input
                    type="text"
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    maxLength={8}
                    placeholder="যেমন: AB12C"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono font-bold tracking-widest text-center text-base focus:outline-none focus:border-cyan-500 uppercase"
                  />
                </div>
              )}
            </div>

            <button
              onClick={multiplayerTab === 'create' ? handleCreateRoom : handleJoinRoom}
              disabled={isLoading}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm font-bengali shadow-xl shadow-cyan-500/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{isLoading ? 'প্রবেশ চলছে...' : multiplayerTab === 'create' ? 'লবি তৈরি করুন' : 'রুমে প্রবেশ করুন'}</span>
            </button>
          </div>
        )}

        {/* Nishipur Character Universe Preview Strip */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-400 font-bengali flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>নিশিপুরের চরিত্র তালিকা (Nishipur Character Universe)</span>
            </h3>
            <span className="text-[11px] text-slate-500 font-bengali">
              ১৫ জন স্থায়ী চরিত্র
            </span>
          </div>

          <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-thin">
            {NISHIPUR_CHARACTERS.map((char) => (
              <div
                key={char.id}
                className="w-24 sm:w-28 shrink-0 p-2 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col items-center text-center gap-1.5 hover:border-cyan-500/40 transition-all"
              >
                <div className="w-16 h-20 sm:w-20 sm:h-24 rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shadow">
                  <img
                    src={char.image}
                    alt={char.nameBn}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="w-full">
                  <h4 className="font-bold text-[11px] text-white truncate font-bengali">
                    {char.nameBn}
                  </h4>
                  <span className="text-[9px] text-cyan-400 truncate block font-bengali">
                    {char.roleBn}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Mandatory Signature Footer: Strictly "RI Rahat" */}
      <footer className="relative z-10 py-3 text-center border-t border-slate-900 bg-slate-950/80">
        <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 font-bengali">
          <span>খেলাঘর • শ্যাডো ডিটেক্টিভ</span>
          <span className="text-slate-600">•</span>
          <span className="font-semibold tracking-wide text-cyan-400 font-mono">
            RI Rahat
          </span>
        </div>
      </footer>

      {/* Official Game Manual Modal */}
      <ShadowDetectiveManualModal
        isOpen={showManualModal}
        onClose={() => setShowManualModal(false)}
      />

      {/* Nearby Connection Diagnostics Modal */}
      <NearbyMultiplayerTest
        isOpen={showDiagnostics}
        onClose={() => setShowDiagnostics(false)}
      />
    </div>
  );
};
