import React, { useState, useEffect } from 'react';
import { NISHIPUR_CHARACTERS, NishipurCharacter } from '../../data/nishipurCharacters';
import { LETHAL_TOOLS, CRIME_ARTIFACTS } from '../../data/shadowDetectiveCards';
import { ShadowCard } from '../../types/shadowDetective';
import { ShadowDetectiveCard } from './ShadowDetectiveCard';
import { sound } from '../../utils/sound';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  Search,
  HelpCircle,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RotateCcw,
  Sparkles,
  Shield,
  Clock,
  Eye,
  Gavel,
  BookOpen,
  UserX,
  Compass,
} from 'lucide-react';

interface NishipurStoryGameProps {
  onBackToLauncher: () => void;
}

interface SuspectState {
  character: NishipurCharacter;
  isReleased: boolean;
  interrogationAnswers: Record<string, string>;
  isCulprit: boolean;
}

interface CaseTruth {
  titleBn: string;
  incidentBriefBn: string;
  culpritId: string;
  lethalTool: ShadowCard;
  crimeArtifact: ShadowCard;
  crimeMotiveBn: string;
  forensicReportBn: string;
}

const CASE_TEMPLATES = [
  {
    titleBn: 'নিশিপুর জমিদারের সিন্দুক ও বিষাক্ত আতর মামলা',
    incidentBriefBn:
      'মধ্যরাতে নিশিপুরের প্রাচীন জমিদার ভবনের গোপন সিন্দুক ভেঙে শতবর্ষী নীলকান্তমণি ও গোপন দলিল চুরি হয়েছে। ঘটনাস্থলে অজ্ঞান অবস্থায় এক প্রহরীর দেহ এবং বিষাক্ত রাসায়নিকের তীব্র গন্ধ পাওয়া গেছে।',
    motiveBn: 'শতবর্ষী জমিজমার গোপন দলিল হস্তগত করে নিশিপুর মৌজার বিপুল সম্পত্তির একচ্ছত্র মালিকানা প্রতিষ্ঠা করা।',
  },
  {
    titleBn: 'নদীঘাটের মাঝির হত্যাকাণ্ড ও এনক্রিপ্টেড ফ্ল্যাশ ড্রাইভ মামলা',
    incidentBriefBn:
      'বর্ষার রাতে সুরমা নদীর নির্জন ঘাটে নৌকা মেকানিকের ঘরে গোপন এনক্রিপ্ট ড্রাইভ ছিনতাই হয় এবং একজন নিরপরাধ সাক্ষী আহত হন। ঘটনাস্থলে রক্তের দাগমাখা অ্যান্টিক ঘড়ি পাওয়া গেছে।',
    motiveBn: 'গ্রামের চোরাচালান ও কালো টাকার লেনদেনের অকাট্য ডিজিটাল প্রমাণ ধ্বংস করে নিজেকে নিরাপদে রাখা।',
  },
  {
    titleBn: 'নিশিপুর উচ্চ বিদ্যালয়ের ল্যাব বিস্ফোরণ ও টপ সিক্রেট নথি মামলা',
    incidentBriefBn:
      'নিশিপুর উচ্চ বিদ্যালয়ের বিজ্ঞানাগারে গভীর রাতে অগ্নিকাণ্ড ঘটে। পরীক্ষার প্রশ্নপত্র ও সরকারি দুর্নীতির ব্ল্যাকমেইল সংক্রান্ত গুরুত্বপূর্ণ ফাইল পুড়িয়ে ফেলার চেষ্টা করা হয়েছে।',
    motiveBn: 'প্রশাসনিক তহবিলের তছরুপ ধামাচাপা দিতে এবং ব্ল্যাকমেইলারের গোপন নথি চিরতরে ছাই করে দিতে এই চক্রান্ত।',
  },
];

const QUESTIONS_BANK = [
  {
    id: 'q_alibi',
    labelBn: 'ঘটনাস্থলের অ্যালিবাই',
    questionBn: 'রাত ১২টার সময় আপনি ঠিক কোথায় ছিলেন এবং আপনার সাথে কে ছিল?',
  },
  {
    id: 'q_motive',
    labelBn: 'ভুক্তভোগীর সাথে সম্পর্ক',
    questionBn: 'ঘটনার রাতে ভুক্তভোগী ব্যক্তির সাথে আপনার শেষ কী কথা হয়েছিল?',
  },
  {
    id: 'q_witness',
    labelBn: 'সন্দেহজনক উপস্থিতি',
    questionBn: 'ঘটনাস্থলের আশপাশে কোনো অস্বাভাবিক আলো, ধোঁয়া বা শব্দ দেখতে পেয়েছিলেন কি?',
  },
  {
    id: 'q_tool',
    labelBn: 'অস্ত্র ও প্রমাণ সম্পর্কে জেরা',
    questionBn: 'আপনার কাছে কোনো ধারালো যন্ত্র, রাসায়নিক বা ভারী রেঞ্চ ব্যবহারের কারণ কী?',
  },
];

export const NishipurStoryGame: React.FC<NishipurStoryGameProps> = ({ onBackToLauncher }) => {
  const [phase, setPhase] = useState<'briefing' | 'round1' | 'round2' | 'round3' | 'verdict' | 'outcome'>('briefing');
  const [caseTruth, setCaseTruth] = useState<CaseTruth | null>(null);
  const [suspects, setSuspects] = useState<SuspectState[]>([]);
  const [selectedSuspect, setSelectedSuspect] = useState<SuspectState | null>(null);
  const [selectedQuestionId, setSelectedQuestionId] = useState<string>('q_alibi');
  const [questionsRemaining, setQuestionsRemaining] = useState<number>(5);
  const [currentDialogue, setCurrentDialogue] = useState<{ speaker: string; text: string } | null>(null);

  // Verdict state
  const [verdictCulpritId, setVerdictCulpritId] = useState<string>('');
  const [verdictToolId, setVerdictToolId] = useState<string>('');
  const [verdictArtifactId, setVerdictArtifactId] = useState<string>('');
  const [isVictory, setIsVictory] = useState<boolean>(false);
  const [defeatReason, setDefeatReason] = useState<string>('');

  // Robin & Tuha characters
  const robin = NISHIPUR_CHARACTERS.find((c) => c.id === 'robin') || NISHIPUR_CHARACTERS[0];
  const tuha = NISHIPUR_CHARACTERS.find((c) => c.id === 'tuha') || NISHIPUR_CHARACTERS[1];

  // Initialize a fresh case
  const initNewCase = () => {
    sound.playClick();
    const template = CASE_TEMPLATES[Math.floor(Math.random() * CASE_TEMPLATES.length)];

    // Pick 5 suspects from villagers (excluding Robin and Tuha)
    const pool = NISHIPUR_CHARACTERS.filter((c) => c.id !== 'robin' && c.id !== 'tuha');
    const shuffledPool = [...pool].sort(() => Math.random() - 0.5);
    const chosenVillagers = shuffledPool.slice(0, 5);

    // Pick culprit
    const culpritIndex = Math.floor(Math.random() * 5);
    const culpritChar = chosenVillagers[culpritIndex];

    // Pick Lethal Tool & Crime Artifact
    const randomTool = LETHAL_TOOLS[Math.floor(Math.random() * LETHAL_TOOLS.length)];
    const randomArtifact = CRIME_ARTIFACTS[Math.floor(Math.random() * CRIME_ARTIFACTS.length)];

    const truth: CaseTruth = {
      titleBn: template.titleBn,
      incidentBriefBn: template.incidentBriefBn,
      culpritId: culpritChar.id,
      lethalTool: randomTool,
      crimeArtifact: randomArtifact,
      crimeMotiveBn: template.motiveBn,
      forensicReportBn: `ফরেনসিক ল্যাবে তুহার পরীক্ষা: নিহতের দেহে '${randomTool.nameBn}' (${randomTool.attributeTag})-এর অকাট্য চিহ্ন এবং ঘটনাস্থলে '${randomArtifact.nameBn}' উদ্ধার করা হয়েছে।`,
    };

    const initialSuspects: SuspectState[] = chosenVillagers.map((c, idx) => ({
      character: c,
      isReleased: false,
      isCulprit: idx === culpritIndex,
      interrogationAnswers: generateAnswers(c, idx === culpritIndex, randomTool, randomArtifact),
    }));

    setCaseTruth(truth);
    setSuspects(initialSuspects);
    setSelectedSuspect(initialSuspects[0]);
    setPhase('briefing');
    setQuestionsRemaining(5);
    setVerdictCulpritId('');
    setVerdictToolId('');
    setVerdictArtifactId('');
    setIsVictory(false);
    setDefeatReason('');
    setCurrentDialogue({
      speaker: 'রবিন',
      text: `তুহা, নিশিপুরে এবার এক ভয়ানক রহস্যের সূচনা হয়েছে! ৫ জন বিশিষ্ট গ্রামবাসীর মধ্যে একজন আসল অপরাধী লুকিয়ে আছে। খুব সাবধানে জেরা করে একজনকে করে অব্যাহতি দিয়ে মূল খুনিকে পাকড়াও করতে হবে।`,
    });

    // Record play on server
    try {
      fetch('/api/shadowdetective/stats/record-play', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: 'solo_robin_' + Date.now() }),
      }).catch(() => {});
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    initNewCase();
  }, []);

  // Answer generator tailored to character personality and truth status
  function generateAnswers(
    char: NishipurCharacter,
    isCulprit: boolean,
    tool: ShadowCard,
    artifact: ShadowCard
  ): Record<string, string> {
    if (isCulprit) {
      return {
        q_alibi: `(কিছুটা ইতস্তত করে) আমি... রাত ১২টায় আমার ঘরে একাই ঘুমাচ্ছিলাম। বাইরে ঝড়-বৃষ্টির শব্দ ছাড়া আর কিছুই শুনিনি। তবে হ্যাঁ, কেউ আমাকে ঘরে দেখেনি...`,
        q_motive: `ভুক্তভোগী আমার দীর্ঘদিনের চেনা। আমাদের মাঝে সামান্য জমি ও হিসাবের মতবিরোধ থাকলেও আমি কেন ক্ষতি করতে যাব? (চোখ অন্যদিকে সরিয়ে নেয়)`,
        q_witness: `আমি কোনো শব্দ পাইনি বলছি তো! তবে নদীঘাটের দিকে কাউকে ছায়ার মতো যেতে দেখেছি বলে মনে হয়... অন্য কাউকে সন্দেহ করুন!`,
        q_tool: `আমার কাছে তো কেবল কাজের সাধারণ সরঞ্জাম থাকে। কিন্তু সেদিন '${tool.nameBn}'-এর মতো কোনো জিনিস আমার হাতে ছিল না, আমি শপথ করে বলছি! (হাত ঘামছে)`,
      };
    }

    return {
      q_alibi: `রাত ১২টায় আমি আমার সাধারণ কাজেই ব্যস্ত ছিলাম। গ্রামের দুজন সাক্ষী আমাকে স্পষ্ট দেখেছেন। আমার কথা আপনি যাচাই করে দেখতে পারেন।`,
      q_motive: `ভুক্তভোগীর সাথে আমার কোনো ব্যক্তিগত শত্রুতা ছিল না। আমরা তো একসাথে গ্রামের বিভিন্ন সালিশ ও উন্নয়নমূলক কাজ পরিচালনা করতাম।`,
      q_witness: `রাত সাড়ে এগারোটায় অন্ধকার পথে একজনকে ভারী কিছু হাতে দ্রুত হেঁটে যেতে দেখেছি। মুখ চেনা যায়নি, তবে গায়ের চাদরটা খুব অদ্ভুত লাগছিল।`,
      q_tool: `আমার কাছে এমন কোনো বিপজ্জনক বস্তু থাকার প্রশ্নই আসে না। আমি একজন সম্মানিত গ্রামবাসী, কোনোদিন অন্যায়কে প্রশ্রয় দিইনি।`,
    };
  }

  // Handle questioning a suspect
  const handleAskQuestion = (suspect: SuspectState, questionId: string) => {
    if (questionsRemaining <= 0) return;
    sound.playCardSelect();
    const ans = suspect.interrogationAnswers[questionId] || 'কোনো মন্তব্য নেই।';
    setCurrentDialogue({
      speaker: suspect.character.nameBn,
      text: ans,
    });
    setQuestionsRemaining((prev) => Math.max(0, prev - 1));
  };

  // Mandatory release of 1 suspect
  const handleReleaseSuspect = (suspectToRelease: SuspectState) => {
    sound.playClick();

    // Check if the user accidentally released the actual culprit!
    if (suspectToRelease.isCulprit) {
      // Immediate Defeat Rule: Releasing the true culprit dismisses the case!
      sound.playDefeat();
      setIsVictory(false);
      setDefeatReason(
        `মারাত্মক ভুল! আপনি আসল অপরাধী '${suspectToRelease.character.nameBn}'-কে নির্দোষ ভেবে ছেড়ে দিয়েছেন! অপরাধী নিশিপুর ছেড়ে নদীপথে চিরতরে পালিয়ে গেছে। তদন্ত ব্যর্থ হয়েছে!`
      );
      setPhase('outcome');
      return;
    }

    // Success in releasing an innocent: mark released
    const updated = suspects.map((s) =>
      s.character.id === suspectToRelease.character.id ? { ...s, isReleased: true } : s
    );
    setSuspects(updated);

    const activeRemaining = updated.filter((s) => !s.isReleased);
    setSelectedSuspect(activeRemaining[0]);

    if (phase === 'round1') {
      // Move to round 2: 4 suspects remain, 3 questions available
      setPhase('round2');
      setQuestionsRemaining(3);
      setCurrentDialogue({
        speaker: 'তুহা',
        text: `দারুণ রবিন ভাই! ${suspectToRelease.character.nameBn} নিশ্চিত নির্দোষ ছিলেন। এবার বাকি ৪ জনের জবানবন্দির অসঙ্গতিগুলো তীক্ষ্ণভাবে পর্যবেক্ষণ করুন। আরও ৩টি প্রশ্নের সুযোগ আছে!`,
      });
    } else if (phase === 'round2') {
      // Move to round 3: 3 suspects remain, Tuha unlocks forensic lab clues!
      setPhase('round3');
      setQuestionsRemaining(2);
      setCurrentDialogue({
        speaker: 'তুহা (ফরেনসিক রিপোর্টসহ)',
        text: `রবিন ভাই! আমি ফরেনসিক রিপোর্ট নিয়ে এসেছি! ল্যাব পরীক্ষায় প্রমাণিত হয়েছে যে ঘটনায় '${caseTruth?.lethalTool.nameBn}' ব্যবহার হয়েছে এবং '${caseTruth?.crimeArtifact.nameBn}' ফেলে যাওয়া হয়েছে। এবার শেষ জেরা করে চূড়ান্ত দুজনের তালিকা তৈরি করুন!`,
      });
    } else if (phase === 'round3') {
      // Move to final verdict showdown between Final Two
      setPhase('verdict');
      setCurrentDialogue({
        speaker: 'রবিন',
        text: `তদন্তের শেষ পর্যায়ে আমরা পৌঁছে গেছি! চূড়ান্ত দুজনের মধ্যে একজনই নিশিপুরকে কাঁপিয়ে দেওয়া আসল অপরাধী। সঠিক অপরাধী, অস্ত্র এবং আলামত নির্বাচন করে মামলা দাখিল করো!`,
      });
    }
  };

  // Submit Final Verdict
  const handleSubmitVerdict = () => {
    if (!verdictCulpritId || !verdictToolId || !verdictArtifactId) return;
    sound.playChallenge();

    const isCulpritMatch = verdictCulpritId === caseTruth?.culpritId;
    const isToolMatch = verdictToolId === caseTruth?.lethalTool.id;
    const isArtifactMatch = verdictArtifactId === caseTruth?.crimeArtifact.id;

    if (isCulpritMatch && isToolMatch && isArtifactMatch) {
      sound.playVictory();
      confetti({
        particleCount: 150,
        spread: 90,
        origin: { y: 0.6 },
      });
      setIsVictory(true);
      setPhase('outcome');
    } else {
      sound.playDefeat();
      setIsVictory(false);
      let mistakes = [];
      if (!isCulpritMatch) mistakes.push('অপরাধী ভুল চিহ্নিত হয়েছে');
      if (!isToolMatch) mistakes.push('অপরাধের হাতিয়ার মেলেনি');
      if (!isArtifactMatch) mistakes.push('আলামত মেলেনি');
      setDefeatReason(
        `আদালতে প্রমাণ অপ্রতুল! ${mistakes.join(
          ', '
        )}। আদালতের নির্দেশে অভিযুক্ত খালাস পেয়েছে এবং আসল অপরাধী ধরাছোঁয়ার বাইরে থেকে গেল।`
      );
      setPhase('outcome');
    }
  };

  const activeSuspects = suspects.filter((s) => !s.isReleased);

  return (
    <div className="min-h-[100dvh] w-full bg-slate-950 text-slate-100 flex flex-col justify-between font-sans select-none overflow-y-auto relative pb-16">
      {/* Background noir atmospheric glow */}
      <div className="fixed inset-0 bg-gradient-to-b from-cyan-950/20 via-slate-950 to-slate-950 pointer-events-none" />

      {/* Top Header */}
      <header className="sticky top-0 z-30 w-full bg-slate-950/95 backdrop-blur-md border-b border-cyan-500/20 px-4 py-3 flex items-center justify-between shadow-lg">
        <button
          onClick={onBackToLauncher}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-bengali cursor-pointer transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>লবিতে ফিরুন</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Compass className="w-4 h-4" />
          </div>
          <div className="text-center sm:text-left">
            <span className="font-black text-xs sm:text-base text-cyan-300 font-bengali block leading-tight">
              নিশিপুর কেস ফাইল — একক গোয়েন্দা অভিযান
            </span>
            <span className="text-[10px] text-slate-400 font-bengali hidden sm:block">
              রবিন ও তুহার রহস্য তদন্ত (AI Detective Mode)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={initNewCase}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-amber-300 text-xs font-bengali hover:bg-slate-800 cursor-pointer"
            title="নতুন মামলা তৈরি করুন"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">নতুন মামলা</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="relative z-10 max-w-5xl w-full mx-auto px-4 py-4 flex-1 flex flex-col gap-4">
        {/* Phase Indicator Stepper */}
        <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs font-bengali">
          <div className="flex items-center gap-2">
            <span
              className={`px-2.5 py-1 rounded-xl font-bold ${
                phase === 'briefing' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-400'
              }`}
            >
              ১. ঘটনা বিবরণী
            </span>
            <span
              className={`px-2.5 py-1 rounded-xl font-bold ${
                phase === 'round1' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-400'
              }`}
            >
              ২. পর্ব ১ জেরা (৫ জন)
            </span>
            <span
              className={`px-2.5 py-1 rounded-xl font-bold ${
                phase === 'round2' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-400'
              }`}
            >
              ৩. পর্ব ২ জেরা (৪ জন)
            </span>
            <span
              className={`px-2.5 py-1 rounded-xl font-bold ${
                phase === 'round3' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-400'
              }`}
            >
              ৪. তুহার ফরেনসিক ক্লু (৩ জন)
            </span>
            <span
              className={`px-2.5 py-1 rounded-xl font-bold ${
                phase === 'verdict' ? 'bg-rose-500 text-white' : 'bg-slate-950 text-slate-400'
              }`}
            >
              ৫. চূড়ান্ত রায় (Final 2)
            </span>
          </div>

          {(phase === 'round1' || phase === 'round2' || phase === 'round3') && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold">
              <Clock className="w-3.5 h-3.5" />
              <span>অবশিষ্ট প্রশ্ন: {questionsRemaining}টি</span>
            </div>
          )}
        </div>

        {/* Dynamic Robin & Tuha Investigation Dialogue Bubble */}
        {currentDialogue && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/40 border border-cyan-500/30 flex items-start gap-3 shadow-lg animate-fadeIn">
            <div className="w-10 h-10 rounded-2xl overflow-hidden border border-cyan-400 shrink-0 bg-slate-950">
              <img
                src={
                  currentDialogue.speaker === 'তুহা' || currentDialogue.speaker.includes('তুহা')
                    ? tuha.image
                    : currentDialogue.speaker === 'রবিন'
                    ? robin.image
                    : selectedSuspect?.character.image || robin.image
                }
                alt={currentDialogue.speaker}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <span className="text-xs font-bold text-cyan-400 font-bengali block">
                {currentDialogue.speaker}:
              </span>
              <p className="text-xs sm:text-sm text-slate-200 font-bengali leading-relaxed mt-0.5">
                {currentDialogue.text}
              </p>
            </div>
          </div>
        )}

        {/* 1. BRIEFING PHASE */}
        {phase === 'briefing' && caseTruth && (
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-5 animate-fadeIn">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold font-bengali">
                অফিসিয়াল কেস ফাইল
              </span>
              <h2 className="text-lg sm:text-xl font-black text-white font-bengali mt-2">
                {caseTruth.titleBn}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 font-bengali leading-relaxed mt-2">
                {caseTruth.incidentBriefBn}
              </p>
            </div>

            {/* Suspect Roster Presentation */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 font-bengali mb-3">
                তদন্তে তালিকাভুক্ত ৫ জন সন্দেহভাজন:
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {suspects.map((s) => (
                  <div
                    key={s.character.id}
                    className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col items-center text-center gap-2 hover:border-cyan-500/50 transition-all"
                  >
                    <div className="w-16 h-20 rounded-xl overflow-hidden border border-slate-700 bg-slate-900">
                      <img
                        src={s.character.image}
                        alt={s.character.nameBn}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-white font-bengali">
                        {s.character.nameBn}
                      </h4>
                      <p className="text-[10px] text-cyan-400 font-bengali">
                        {s.character.roleBn}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                setPhase('round1');
                setCurrentDialogue({
                  speaker: 'রবিন',
                  text: 'জেরা শুরু হোক! প্রতি সন্দেহভাজনকে প্রশ্ন করে তাদের বক্তব্যের সত্যতা যাচাই করুন। পর্ব ১ শেষে অবশ্যই ১ জনকে অব্যাহতি দিতে হবে—সাবধান, অপরাধীকে ছেড়ে দিলে মামলা ভেস্তে যাবে!',
                });
              }}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm font-bengali shadow-xl shadow-cyan-500/20 cursor-pointer flex items-center justify-center gap-2"
            >
              <span>তদন্ত ও জেরা শুরু করুন</span>
            </button>
          </div>
        )}

        {/* 2. INTERROGATION ROUNDS (1, 2, 3) */}
        {(phase === 'round1' || phase === 'round2' || phase === 'round3') && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Left: Active Suspects List */}
            <div className="md:col-span-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-300 font-bengali">
                  সন্দেহভাজনদের তালিকা ({activeSuspects.length} জন অবশিষ্ট)
                </h3>
                <span className="text-[11px] text-slate-500 font-bengali">
                  ক্লিক করে নির্বাচন করুন
                </span>
              </div>

              <div className="space-y-2">
                {activeSuspects.map((s) => {
                  const isSelected = selectedSuspect?.character.id === s.character.id;
                  return (
                    <div
                      key={s.character.id}
                      onClick={() => {
                        sound.playCardSelect();
                        setSelectedSuspect(s);
                      }}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-cyan-950/50 border-cyan-400 ring-2 ring-cyan-500/20 shadow-lg'
                          : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-14 rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shrink-0">
                          <img
                            src={s.character.image}
                            alt={s.character.nameBn}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="font-bold text-xs sm:text-sm text-white font-bengali">
                            {s.character.nameBn}
                          </h4>
                          <span className="text-[11px] text-cyan-400 font-bengali block">
                            {s.character.roleBn}
                          </span>
                        </div>
                      </div>

                      {/* Release Action Button for this suspect */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleReleaseSuspect(s);
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/80 hover:text-rose-300 hover:border-rose-500/50 border border-slate-700 text-slate-300 text-[11px] font-bengali font-bold transition-all flex items-center gap-1 cursor-pointer"
                        title="এই সন্দেহভাজনকে নির্দোষ ঘোষণা করে অব্যাহতি দিন"
                      >
                        <UserX className="w-3.5 h-3.5" />
                        <span>অব্যাহতি</span>
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Tuha's Evidence Clue Card for Phase 3 */}
              {phase === 'round3' && caseTruth && (
                <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/50 space-y-2 animate-fadeIn">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs font-bengali">
                    <Sparkles className="w-4 h-4 fill-current" />
                    <span>তুহার ল্যাব রিপোর্ট আনলক হয়েছে!</span>
                  </div>
                  <p className="text-[11px] text-slate-300 font-bengali leading-relaxed">
                    {caseTruth.forensicReportBn}
                  </p>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bengali">
                      হাতিয়ার: {caseTruth.lethalTool.nameBn}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bengali">
                      আলামত: {caseTruth.crimeArtifact.nameBn}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Right: Selected Suspect Dossier & Questioning Panel */}
            <div className="md:col-span-7 p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between gap-4">
              {selectedSuspect ? (
                <>
                  <div className="flex items-start gap-4 pb-3 border-b border-slate-800">
                    <div className="w-20 h-24 rounded-2xl overflow-hidden border-2 border-cyan-500/50 bg-slate-950 shrink-0 shadow-lg">
                      <img
                        src={selectedSuspect.character.image}
                        alt={selectedSuspect.character.nameBn}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-black text-sm sm:text-base text-white font-bengali">
                          {selectedSuspect.character.nameBn}
                        </h3>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bengali">
                          {selectedSuspect.character.roleBn}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 font-bengali leading-relaxed mt-1">
                        {selectedSuspect.character.bioBn}
                      </p>
                    </div>
                  </div>

                  {/* Interrogation Questions */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-300 font-bengali block">
                      সন্দেহভাজনকে প্রশ্ন করুন (অবশিষ্ট সুযোগ: {questionsRemaining}টি):
                    </label>
                    <div className="grid grid-cols-1 gap-2">
                      {QUESTIONS_BANK.map((q) => (
                        <button
                          key={q.id}
                          disabled={questionsRemaining <= 0}
                          onClick={() => handleAskQuestion(selectedSuspect, q.id)}
                          className="w-full p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-left transition-all flex items-center justify-between gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          <div>
                            <span className="text-[11px] font-bold text-cyan-400 font-bengali block">
                              {q.labelBn}
                            </span>
                            <span className="text-xs text-slate-300 font-bengali">
                              "{q.questionBn}"
                            </span>
                          </div>
                          <span className="text-xs text-cyan-400 font-bold shrink-0 font-bengali">
                            জিজ্ঞেস করুন →
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Mandatory Release Callout */}
                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div className="text-xs font-bengali text-slate-300">
                      <span className="font-bold text-rose-400">বাধ্যতামূলক নিয়ম:</span> পর্ব সমাপ্ত করতে ১ জন নির্দোষকে অব্যাহতি দিতে হবে।
                    </div>
                    <button
                      onClick={() => handleReleaseSuspect(selectedSuspect)}
                      className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs font-bengali transition-all shadow-lg shadow-rose-600/30 cursor-pointer"
                    >
                      {selectedSuspect.character.nameBn}-কে অব্যাহতি দিন
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center py-10 text-slate-500 font-bengali">
                  বাম তালিকা থেকে একজন সন্দেহভাজন নির্বাচন করুন।
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3. FINAL VERDICT PHASE (Final Two Showdown) */}
        {phase === 'verdict' && caseTruth && (
          <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-rose-500/60 shadow-2xl space-y-6 animate-fadeIn">
            <div className="text-center border-b border-slate-800 pb-3">
              <span className="text-xs px-3 py-1 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 font-bold font-bengali">
                চূড়ান্ত রায় পর্যায় — দ্বৈরথ
              </span>
              <h2 className="text-xl font-black text-white font-bengali mt-2">
                নিশিপুরের অপরাধী কে?
              </h2>
              <p className="text-xs text-slate-300 font-bengali mt-1">
                চূড়ান্ত দুজন সন্দেহভাজনের মধ্যে আসল খুনি, ব্যবহৃত হাতিয়ার এবং ঘটনাস্থলের আলামত চিহ্নিত করুন।
              </p>
            </div>

            {/* Final Two Culprit Selector */}
            <div>
              <label className="text-xs font-bold text-slate-300 font-bengali block mb-2">
                ১. আসল অপরাধী নির্বাচন করুন (চূড়ান্ত দুইজন):
              </label>
              <div className="grid grid-cols-2 gap-4">
                {activeSuspects.map((s) => {
                  const isSelected = verdictCulpritId === s.character.id;
                  return (
                    <div
                      key={s.character.id}
                      onClick={() => {
                        sound.playCardSelect();
                        setVerdictCulpritId(s.character.id);
                      }}
                      className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-center gap-3 ${
                        isSelected
                          ? 'bg-rose-950/60 border-rose-500 ring-4 ring-rose-500/30 shadow-xl'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="w-14 h-18 rounded-xl overflow-hidden border border-slate-700 bg-slate-900 shrink-0">
                        <img
                          src={s.character.image}
                          alt={s.character.nameBn}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-white font-bengali">
                          {s.character.nameBn}
                        </h4>
                        <span className="text-xs text-cyan-400 font-bengali block">
                          {s.character.roleBn}
                        </span>
                        {isSelected && (
                          <span className="text-[10px] text-rose-400 font-bold font-bengali mt-1 block">
                            অভিযুক্ত হিসেবে চিহ্নিত ✓
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Lethal Weapon Selector */}
            <div>
              <label className="text-xs font-bold text-cyan-300 font-bengali block mb-2">
                ২. ব্যবহৃত লিথাল টুল (অস্ত্র):
              </label>
              <div className="flex flex-wrap gap-2.5">
                {LETHAL_TOOLS.slice(0, 6).map((tool) => (
                  <ShadowDetectiveCard
                    key={tool.id}
                    card={tool}
                    size="sm"
                    isSelected={verdictToolId === tool.id}
                    onClick={() => {
                      sound.playCardSelect();
                      setVerdictToolId(tool.id);
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Crime Artifact Selector */}
            <div>
              <label className="text-xs font-bold text-amber-300 font-bengali block mb-2">
                ৩. ঘটনাস্থলের আলামত (Artifact):
              </label>
              <div className="flex flex-wrap gap-2.5">
                {CRIME_ARTIFACTS.slice(0, 6).map((art) => (
                  <ShadowDetectiveCard
                    key={art.id}
                    card={art}
                    size="sm"
                    isSelected={verdictArtifactId === art.id}
                    onClick={() => {
                      sound.playCardSelect();
                      setVerdictArtifactId(art.id);
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Submit Final Verdict */}
            <button
              onClick={handleSubmitVerdict}
              disabled={!verdictCulpritId || !verdictToolId || !verdictArtifactId}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500 text-white font-black text-sm font-bengali shadow-2xl shadow-rose-600/40 hover:scale-[1.01] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Gavel className="w-4 h-4" />
              <span>চূড়ান্ত রায় দাখিল করুন (Submit Verdict)</span>
            </button>
          </div>
        )}

        {/* 4. OUTCOME / RESULT SCREEN */}
        {phase === 'outcome' && caseTruth && (
          <div
            className={`p-6 sm:p-8 rounded-3xl border-2 shadow-2xl text-center space-y-5 animate-scaleIn ${
              isVictory
                ? 'bg-gradient-to-b from-slate-900 via-emerald-950/30 to-slate-950 border-emerald-500/60'
                : 'bg-gradient-to-b from-slate-900 via-rose-950/30 to-slate-950 border-rose-500/60'
            }`}
          >
            <div className="w-16 h-16 rounded-3xl mx-auto flex items-center justify-center shadow-2xl border">
              {isVictory ? (
                <div className="w-full h-full rounded-3xl bg-emerald-500/20 border-emerald-400 flex items-center justify-center text-emerald-400">
                  <CheckCircle className="w-8 h-8" />
                </div>
              ) : (
                <div className="w-full h-full rounded-3xl bg-rose-500/20 border-rose-400 flex items-center justify-center text-rose-400">
                  <XCircle className="w-8 h-8" />
                </div>
              )}
            </div>

            <div>
              <h2 className="text-2xl font-black text-white font-bengali">
                {isVictory ? 'মামলা সমাধান সম্পন্ন! বিজয়!' : 'মামলা খারিজ — তদন্ত ব্যর্থ!'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-1 max-w-lg mx-auto leading-relaxed">
                {isVictory
                  ? `অভিনন্দন প্রধান গোয়েন্দা রবিন! আপনি নিশিপুরের রহস্যময় অপরাধী ও তার সমস্ত প্রমাণ হাতেনাতে ধরেছেন। গ্রামে ন্যায়বিচার প্রতিষ্ঠিত হলো!`
                  : defeatReason}
              </p>
            </div>

            {/* Revealed Truth Details */}
            <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 max-w-md mx-auto text-left space-y-2">
              <span className="text-[11px] font-bold text-amber-300 font-bengali block border-b border-slate-800 pb-1">
                মামলার আসল সত্য উদঘাটন:
              </span>
              <div className="text-xs font-bengali space-y-1">
                <div>
                  <span className="text-slate-400">আসল খুনি: </span>
                  <span className="text-rose-400 font-bold">
                    {NISHIPUR_CHARACTERS.find((c) => c.id === caseTruth.culpritId)?.nameBn}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">ব্যবহৃত হাতিয়ার: </span>
                  <span className="text-cyan-400 font-bold">{caseTruth.lethalTool.nameBn}</span>
                </div>
                <div>
                  <span className="text-slate-400">আলামত: </span>
                  <span className="text-amber-400 font-bold">{caseTruth.crimeArtifact.nameBn}</span>
                </div>
                <div className="pt-1">
                  <span className="text-slate-400">উদ্দেশ্য (Motive): </span>
                  <span className="text-slate-200">{caseTruth.crimeMotiveBn}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={initNewCase}
                className="px-5 py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs sm:text-sm font-bengali shadow-lg cursor-pointer"
              >
                নতুন নিশিপুর কেস খেলুন
              </button>
              <button
                onClick={onBackToLauncher}
                className="px-5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs sm:text-sm font-bengali cursor-pointer"
              >
                লবিতে ফিরুন
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Mandatory Signature Footer: Strictly "RI Rahat" */}
      <footer className="relative z-10 py-3 text-center border-t border-slate-900 bg-slate-950/80">
        <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 font-bengali">
          <span>খেলাঘর • শ্যাডো ডিটেক্টিভ</span>
          <span className="text-slate-600">•</span>
          <span className="font-semibold tracking-wide text-cyan-400 font-mono">
            RI Rahat
          </span>
        </div>
      </footer>
    </div>
  );
};
