import React, { useState } from 'react';
import { ShadowPlayerPublic, ShadowCard } from '../../types/shadowDetective';
import { SPECIAL_POWERS } from '../../data/shadowDetectiveCards';
import { ShadowDetectiveCard } from './ShadowDetectiveCard';
import { X, Zap, Check } from 'lucide-react';

interface PowerCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  players: ShadowPlayerPublic[];
  myPlayerId: string;
  usedPowers?: string[];
  onUsePower: (powerId: string, targetPlayerId?: string) => void;
}

export const PowerCardModal: React.FC<PowerCardModalProps> = ({
  isOpen,
  onClose,
  players,
  myPlayerId,
  usedPowers = [],
  onUsePower,
}) => {
  const [selectedPowerId, setSelectedPowerId] = useState<string>('');
  const [selectedTargetId, setSelectedTargetId] = useState<string>('');

  if (!isOpen) return null;

  const requiresTarget = selectedPowerId === 'wiretap_pass' || selectedPowerId === 'alibi_check';
  const availableTargets = players.filter((p) => p.id !== myPlayerId);

  const canUse = selectedPowerId && (!requiresTarget || selectedTargetId);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-xl w-full bg-slate-900 border-2 border-purple-500/60 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white font-bengali">
                বিশেষ পাওয়ার কার্ড (Special Power Cards)
              </h3>
              <p className="text-[11px] text-slate-400 font-bengali">
                খেলায় একবারের মতো বিশেষ গোয়েন্দা কৌশল বা নজরদারি ব্যবহার করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Powers List */}
        <div className="mt-4 space-y-3">
          <label className="text-xs font-bold text-purple-300 font-bengali block">
            পাওয়ার কার্ড নির্বাচন করুন:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {SPECIAL_POWERS.map((card) => {
              const isUsed = usedPowers.includes(card.id);
              const isSelected = selectedPowerId === card.id;

              return (
                <div
                  key={card.id}
                  onClick={() => {
                    if (!isUsed) {
                      setSelectedPowerId(card.id);
                    }
                  }}
                  className={`p-2 rounded-2xl border transition-all flex flex-col items-center text-center cursor-pointer ${
                    isUsed
                      ? 'opacity-40 bg-slate-950/40 border-slate-800 cursor-not-allowed'
                      : isSelected
                      ? 'bg-purple-950/60 border-purple-400 ring-2 ring-purple-500/40'
                      : 'bg-slate-950/70 hover:bg-slate-800 border-slate-800'
                  }`}
                >
                  <ShadowDetectiveCard card={card} size="sm" isSelected={isSelected} />
                  <span className="text-[10px] font-bold text-slate-300 font-bengali mt-2">
                    {card.nameBn}
                  </span>
                  {isUsed && (
                    <span className="text-[9px] text-slate-500 font-bengali mt-0.5">
                      (ব্যবহৃত হয়েছে)
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Step 2: Choose Target if required */}
        {requiresTarget && (
          <div className="mt-4 pt-4 border-t border-slate-800 space-y-2">
            <label className="text-xs font-bold text-slate-300 font-bengali block">
              লক্ষ্য খেলোয়াড় (Target Suspect) নির্বাচন করুন:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {availableTargets.map((p) => {
                const isSelected = selectedTargetId === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedTargetId(p.id)}
                    className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center cursor-pointer ${
                      isSelected
                        ? 'bg-purple-950/80 border-purple-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span className="text-xl">{p.avatar}</span>
                    <span className="text-[11px] font-bengali truncate w-full">{p.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Action Button */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bengali text-xs font-bold hover:bg-slate-700 cursor-pointer"
          >
            বাতিল
          </button>
          <button
            onClick={() => {
              if (canUse) {
                onUsePower(selectedPowerId, requiresTarget ? selectedTargetId : undefined);
                onClose();
              }
            }}
            disabled={!canUse}
            className={`px-5 py-2.5 rounded-xl font-bengali font-bold text-xs flex items-center gap-1.5 transition-all shadow-xl ${
              canUse
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white cursor-pointer shadow-purple-600/30'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            <Check className="w-4 h-4" />
            <span>পাওয়ার সক্রিয় করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
