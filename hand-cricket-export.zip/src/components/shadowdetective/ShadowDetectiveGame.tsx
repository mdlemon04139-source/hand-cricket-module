import React, { useState, useEffect, useRef } from 'react';
import {
  ShadowDetectiveClientState,
  ShadowDetectiveRole,
  ForensicCategoryKey,
  ShadowCard,
} from '../../types/shadowDetective';
import { ROLE_INFO } from '../../data/shadowDetectiveCards';
import { ShadowDetectiveLobby } from './ShadowDetectiveLobby';
import { ForensicBoard } from './ForensicBoard';
import { ShadowDetectiveCard } from './ShadowDetectiveCard';
import { ChatWheelModal } from './ChatWheelModal';
import { CaseSubmissionModal } from './CaseSubmissionModal';
import { WitnessHuntModal } from './WitnessHuntModal';
import { PowerCardModal } from './PowerCardModal';
import { ShadowDetectiveManualModal } from './ShadowDetectiveManualModal';
import { QuickChatModal } from '../common/QuickChatModal';
import { NearbyMultiplayerTest } from '../multiplayer/NearbyMultiplayerTest';
import confetti from 'canvas-confetti';
import {
  Clock,
  Shield,
  Gavel,
  Radio,
  Zap,
  MessageSquare,
  HelpCircle,
  Skull,
  Crosshair,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  BookOpen,
  Wifi,
} from 'lucide-react';

interface ShadowDetectiveGameProps {
  roomId: string;
  playerId: string;
  onBackToPlatform: () => void;
}

export const ShadowDetectiveGame: React.FC<ShadowDetectiveGameProps> = ({
  roomId,
  playerId,
  onBackToPlatform,
}) => {
  const [gameState, setGameState] = useState<ShadowDetectiveClientState | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Crime Setup (Killer)
  const [selectedKillerTool, setSelectedKillerTool] = useState<string>('');
  const [selectedKillerArtifact, setSelectedKillerArtifact] = useState<string>('');

  // Modals
  const [showChatWheel, setShowChatWheel] = useState(false);
  const [showAccusationModal, setShowAccusationModal] = useState(false);
  const [showPowerModal, setShowPowerModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showChatDrawer, setShowChatDrawer] = useState(true);
  const [showManualModal, setShowManualModal] = useState(false);
  const [showQuickChatModal, setShowQuickChatModal] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  // Discussion countdown
  const [discussionSecondsLeft, setDiscussionSecondsLeft] = useState<number>(180);

  // Chat input
  const [chatInputText, setChatInputText] = useState('');

  // Auto-scroll chat ref
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // SSE Subscription
  useEffect(() => {
    let isMounted = true;
    let eventSource: EventSource | null = null;

    const setupSSE = () => {
      eventSource = new EventSource(`/api/shadowdetective/rooms/${roomId}/events?playerId=${playerId}`);

      eventSource.onmessage = (event) => {
        if (!isMounted) return;
        try {
          const data: ShadowDetectiveClientState = JSON.parse(event.data);
          setGameState(data);
        } catch {
          // ignore
        }
      };

      eventSource.onerror = () => {
        // Fallback polling
        fetchState();
      };
    };

    const fetchState = async () => {
      try {
        const res = await fetch(`/api/shadowdetective/rooms/${roomId}/state?playerId=${playerId}`);
        if (res.ok && isMounted) {
          const data: ShadowDetectiveClientState = await res.json();
          setGameState(data);
        }
      } catch {
        // ignore
      }
    };

    fetchState();
    setupSSE();

    const pollInterval = setInterval(fetchState, 3000);

    return () => {
      isMounted = false;
      if (eventSource) eventSource.close();
      clearInterval(pollInterval);
    };
  }, [roomId, playerId]);

  // Discussion timer ticker
  useEffect(() => {
    if (!gameState || gameState.phase !== 'DISCUSSION' || !gameState.discussionDeadline) return;

    const updateTimer = () => {
      const remaining = Math.max(0, Math.ceil((gameState.discussionDeadline! - Date.now()) / 1000));
      setDiscussionSecondsLeft(remaining);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [gameState?.phase, gameState?.discussionDeadline]);

  // Victory Confetti
  useEffect(() => {
    if (gameState?.phase === 'GAME_OVER') {
      if (gameState.winnerTeam === 'detectives') {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    }
  }, [gameState?.phase, gameState?.winnerTeam]);

  // Scroll chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [gameState?.chatMessages]);

  if (!gameState) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-center select-none">
        <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 animate-spin mb-4">
          <Crosshair className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-white font-bengali">তদন্ত কক্ষ লোড হচ্ছে...</h3>
        <p className="text-xs text-slate-400 font-bengali mt-1">অনুগ্রহ করে অপেক্ষা করুন</p>
      </div>
    );
  }

  // --- LOBBY PHASE ---
  if (gameState.phase === 'LOBBY') {
    return (
      <ShadowDetectiveLobby
        roomState={gameState}
        myPlayerId={playerId}
        onAddBot={() => {
          fetch(`/api/shadowdetective/rooms/${roomId}/add-bot`, { method: 'POST' });
        }}
        onRemovePlayer={(pId) => {
          fetch(`/api/shadowdetective/rooms/${roomId}/remove-player`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ playerId: pId }),
          });
        }}
        onStartGame={() => {
          fetch(`/api/shadowdetective/rooms/${roomId}/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ requesterId: playerId }),
          });
        }}
        onLeaveRoom={onBackToPlatform}
      />
    );
  }

  const me = gameState.players.find((p) => p.id === playerId);
  const myRole = gameState.myRole;
  const roleInfo = ROLE_INFO[myRole];
  const isChief = myRole === 'chief_investigator';
  const isKiller = myRole === 'shadow_killer';

  // Handlers
  const handleCommitCrime = async () => {
    if (!selectedKillerTool || !selectedKillerArtifact) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/setup-crime`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          killerId: playerId,
          lethalToolId: selectedKillerTool,
          crimeArtifactId: selectedKillerArtifact,
        }),
      });
    } catch {
      setErrorMsg('অপরাধ জমা দেওয়া যায়নি।');
    }
  };

  const handleSaveForensicHints = async (markers: Partial<Record<ForensicCategoryKey, string>>) => {
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/forensic-hints`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chiefId: playerId,
          markers,
        }),
      });
    } catch {
      setErrorMsg('ফরেনসিক ক্লু জমা দেওয়া যায়নি।');
    }
  };

  const handleSendMessage = async (text: string, isWheel = false) => {
    if (!text.trim()) return;
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: playerId,
          textBn: text,
          isWheel,
        }),
      });
      setChatInputText('');
    } catch {
      // ignore
    }
  };

  const handleSubmitAccusation = async (accusedId: string, toolId: string, artifactId: string) => {
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/accuse`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accuserId: playerId,
          accusedPlayerId: accusedId,
          suspectedToolId: toolId,
          suspectedArtifactId: artifactId,
        }),
      });
    } catch {
      setErrorMsg('মামলা দাখিল করা যায়নি।');
    }
  };

  const handleHuntWitness = async (targetId: string) => {
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/witness-hunt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          killerId: playerId,
          targetPlayerId: targetId,
        }),
      });
    } catch {
      setErrorMsg('উইটনেস হান্ট সম্পন্ন করা যায়নি।');
    }
  };

  const handleUsePower = async (powerId: string, targetId?: string) => {
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/use-power`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerId,
          powerCardId: powerId,
          targetPlayerId: targetId,
        }),
      });
    } catch {
      setErrorMsg('পাওয়ার কার্ড ব্যবহার করা যায়নি।');
    }
  };

  const handleRestart = async () => {
    try {
      await fetch(`/api/shadowdetective/rooms/${roomId}/restart`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requesterId: playerId }),
      });
    } catch {
      // ignore
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-slate-950 text-slate-100 flex flex-col font-sans select-none overflow-y-auto overscroll-y-contain relative">
      {/* Background noir ambience */}
      <div className="fixed inset-0 bg-gradient-to-b from-indigo-950/20 via-slate-950 to-slate-950 pointer-events-none" />

      {/* Header bar - Sticky top */}
      <header className="sticky top-0 z-30 w-full border-b border-slate-800/80 bg-slate-950/95 backdrop-blur-md px-3 sm:px-6 py-2.5 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Crosshair className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-black text-xs sm:text-sm text-cyan-300 font-bengali flex items-center gap-2">
              <span>শ্যাডো ডিটেক্টিভ</span>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded-full border border-slate-800">
                #{gameState.roomCode}
              </span>
            </h2>
          </div>
        </div>

        {/* Action Controls & Secret Role Badge */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* How to Play Manual Button */}
          <button
            onClick={() => setShowManualModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bengali font-bold flex items-center gap-1.5 cursor-pointer shadow transition-all"
            title="গেম ম্যানুয়াল ও নিয়মাবলী"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">খেলার নিয়ম</span>
          </button>

          {/* Nearby Diagnostics */}
          <button
            onClick={() => setShowDiagnostics(true)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bengali flex items-center gap-1 cursor-pointer transition-all"
            title="কাছাকাছি সংযোগ পরীক্ষা"
          >
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">কানেকশন টেস্ট</span>
          </button>

          {/* Secret Role Badge Button */}
          <button
            onClick={() => setShowRoleModal(true)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bengali font-bold flex items-center gap-1.5 cursor-pointer shadow transition-all ${roleInfo.badgeColor}`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ভূমিকা:</span>
            <span>{roleInfo.nameBn}</span>
          </button>

          <button
            onClick={onBackToPlatform}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs font-bengali cursor-pointer"
          >
            হোম
          </button>
        </div>
      </header>

      {/* Main Playing Stage - Clean touch scrolling with safe area padding */}
      <main className="relative z-10 flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 pb-36 flex flex-col gap-5">
        {/* Error notification */}
        {errorMsg && (
          <div className="p-3 rounded-2xl bg-red-950/90 border border-red-500/60 text-red-200 text-xs font-bengali text-center">
            {errorMsg}
          </div>
        )}

        {/* Phase Status Banner */}
        <div className="p-3 sm:p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400 font-bold">
              {gameState.phase === 'CRIME_SETUP'
                ? '১'
                : gameState.phase === 'FORENSIC_HINTS'
                ? '২'
                : gameState.phase === 'DISCUSSION'
                ? '৩'
                : gameState.phase === 'WITNESS_HUNT'
                ? '⚡'
                : '★'}
            </div>
            <div>
              <h4 className="font-black text-xs sm:text-sm text-white font-bengali">
                {gameState.phase === 'CRIME_SETUP'
                  ? 'অপরাধ সেটআপ পর্যায় (Crime Setup)'
                  : gameState.phase === 'FORENSIC_HINTS'
                  ? 'ফরেনসিক ক্লু স্থাপন (Forensic Investigation)'
                  : gameState.phase === 'DISCUSSION'
                  ? 'তদন্ত আলোচনা ও ক্লু বিশ্লেষণ (Discussion & deduction)'
                  : gameState.phase === 'WITNESS_HUNT'
                  ? 'উইটনেস হান্ট (Witness Hunt)!'
                  : 'খেলা সমাপ্ত (Game Over)'}
              </h4>
              <p className="text-[11px] text-slate-400 font-bengali">
                {gameState.phase === 'CRIME_SETUP'
                  ? isKiller
                    ? 'আপনার হাতের কার্ড থেকে ১টি অস্ত্র এবং ১টি আলামত গোপনে নির্বাচন করুন।'
                    : 'ছায়া খুনি তার অপরাধের অস্ত্র ও প্রমাণ নির্ধারণ করছেন...'
                  : gameState.phase === 'FORENSIC_HINTS'
                  ? isChief
                    ? 'ফরেনসিক বোর্ডে ৩টি উপযুক্ত ক্লু মার্কার নির্বাচন করে দলকে নির্দেশনা দিন।'
                    : 'প্রধান গোয়েন্দা ঘটনাস্থল পরিদর্শন করে ক্লু মার্কার স্থাপন করছেন...'
                  : gameState.phase === 'DISCUSSION'
                  ? 'বোর্ডের মার্কার ও সন্দেহভাজনদের জবানবন্দি মিলিয়ে খুনি ও প্রমাণ আবিষ্কার করুন।'
                  : 'তদন্ত সমাপ্ত হয়েছে।'}
              </p>
            </div>
          </div>

          {/* Discussion Timer & Attempts Counter */}
          {gameState.phase === 'DISCUSSION' && (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-amber-300">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {Math.floor(discussionSecondsLeft / 60)}:
                  {String(discussionSecondsLeft % 60).padStart(2, '0')}
                </span>
              </div>

              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-rose-300">
                <Gavel className="w-3.5 h-3.5 text-rose-400" />
                <span>মামলা সুযোগ: {gameState.remainingSubmissionAttempts}/৩</span>
              </div>
            </div>
          )}
        </div>

        {/* 1. CRIME SETUP FOR KILLER */}
        {gameState.phase === 'CRIME_SETUP' && isKiller && (
          <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/90 border-2 border-red-500/60 shadow-2xl space-y-4 animate-fadeIn">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="font-black text-sm sm:text-base text-red-400 font-bengali flex items-center gap-2">
                <Crosshair className="w-5 h-5" />
                <span>গোপন অপরাধ নির্ধারণ (Commit Crime)</span>
              </h3>
              <p className="text-xs text-slate-300 font-bengali mt-0.5">
                আপনার হাত থেকে ১টি অস্ত্র এবং ১টি আলামত গোপনে নির্বাচন করুন যা আপনার খুনের সমাধান হবে।
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-cyan-300 font-bengali block mb-2">
                  অস্ত্র (Lethal Tool):
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {me?.cards
                    .filter((c) => c.type === 'lethal_tool')
                    .map((card) => (
                      <ShadowDetectiveCard
                        key={card.id}
                        card={card}
                        size="md"
                        isSelected={selectedKillerTool === card.id}
                        onClick={() => setSelectedKillerTool(card.id)}
                      />
                    ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-amber-300 font-bengali block mb-2">
                  আলামত (Crime Artifact):
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {me?.cards
                    .filter((c) => c.type === 'crime_artifact')
                    .map((card) => (
                      <ShadowDetectiveCard
                        key={card.id}
                        card={card}
                        size="md"
                        isSelected={selectedKillerArtifact === card.id}
                        onClick={() => setSelectedKillerArtifact(card.id)}
                      />
                    ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={handleCommitCrime}
                disabled={!selectedKillerTool || !selectedKillerArtifact}
                className={`px-6 py-3 rounded-2xl font-bengali font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-xl ${
                  selectedKillerTool && selectedKillerArtifact
                    ? 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white cursor-pointer shadow-red-600/40 hover:scale-105'
                    : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                }`}
              >
                <span>অপরাধ নিশ্চিত করুন (Commit Secret Crime)</span>
              </button>
            </div>
          </div>
        )}

        {/* 2. FORENSIC CLUE BOARD */}
        <ForensicBoard
          markers={gameState.forensicBoardMarkers}
          isChief={isChief}
          canEdit={gameState.phase === 'FORENSIC_HINTS' && isChief}
          onSaveMarkers={handleSaveForensicHints}
        />

        {/* 3. SUSPECT PLAYERS & PUBLIC CARDS TABLE */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs sm:text-sm text-slate-300 font-bengali flex items-center gap-2">
              <span>সন্দেহভাজনদের হাতের আলামত ও অস্ত্র (Public Evidence on Table)</span>
            </h3>

            {/* In Discussion: Quick Actions Bar */}
            {gameState.phase === 'DISCUSSION' && !isChief && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowChatWheel(true)}
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bengali font-bold flex items-center gap-1.5 cursor-pointer shadow"
                >
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  <span>চ্যাট হুইল</span>
                </button>

                <button
                  onClick={() => setShowPowerModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-bengali font-bold flex items-center gap-1.5 cursor-pointer shadow"
                >
                  <Zap className="w-3.5 h-3.5 text-purple-400" />
                  <span>পাওয়ার কার্ড</span>
                </button>

                <button
                  onClick={() => setShowAccusationModal(true)}
                  className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bengali font-bold flex items-center gap-1.5 cursor-pointer shadow-lg shadow-rose-600/30"
                >
                  <Gavel className="w-3.5 h-3.5" />
                  <span>মামলা দাখিল</span>
                </button>
              </div>
            )}
          </div>

          {/* Player Evidence Rows */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gameState.players
              .filter((p) => p.cards.length > 0)
              .map((p) => {
                const isMe = p.id === playerId;
                return (
                  <div
                    key={p.id}
                    className={`p-3.5 rounded-3xl border transition-all flex flex-col justify-between ${
                      isMe
                        ? 'bg-slate-900/90 border-cyan-500/50 ring-2 ring-cyan-500/20'
                        : 'bg-slate-900/70 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{p.avatar}</span>
                        <div>
                          <div className="font-bold text-xs text-white font-bengali flex items-center gap-1">
                            <span>{p.name}</span>
                            {p.isOnline === false && (
                              <span className="text-[8px] font-bengali px-1 rounded bg-rose-500/20 text-rose-300">
                                অফলাইন
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Role indicator if known */}
                      {gameState.myRoleKnowledge?.knownKillerId === p.id && (
                        <span className="text-[9px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bengali font-bold">
                          খুনি!
                        </span>
                      )}
                      {gameState.myRoleKnowledge?.knownSyndicateIds?.includes(p.id) && (
                        <span className="text-[9px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bengali font-bold">
                          অপরাধী সন্দেহভাজন
                        </span>
                      )}
                    </div>

                    {/* Cards grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1">
                      {p.cards.map((c) => (
                        <ShadowDetectiveCard key={c.id} card={c} size="sm" />
                      ))}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* 4. CHAT & DEDUCTION LOG DRAWER */}
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-3 shadow-md">
          <div
            onClick={() => setShowChatDrawer(!showChatDrawer)}
            className="flex items-center justify-between cursor-pointer text-xs font-bold font-bengali text-slate-300"
          >
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <span>তদন্ত ও কথোপকথন লগ (Deduction Log)</span>
            </div>
            {showChatDrawer ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>

          {showChatDrawer && (
            <div className="mt-3 space-y-2">
              <div className="max-h-52 overflow-y-auto space-y-2 pr-1 text-xs font-bengali">
                {gameState.chatMessages.map((msg) => {
                  const isMe = msg.senderId === playerId;
                  const isSystem = msg.senderId === 'system';

                  if (isSystem) {
                    return (
                      <div
                        key={msg.id}
                        className="py-1 px-3 mx-auto max-w-lg rounded-full bg-slate-950/90 border border-slate-800 text-[11px] font-bengali text-amber-300 text-center flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" />
                        <span className="truncate">{msg.textBn}</span>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={msg.id}
                      className={`p-2.5 rounded-2xl border flex items-start gap-2.5 max-w-[90%] transition-all ${
                        isMe
                          ? 'ml-auto bg-cyan-950/40 border-cyan-500/40 text-cyan-100 flex-row-reverse'
                          : msg.isWheel
                          ? 'mr-auto bg-indigo-950/30 border-indigo-500/30 text-white'
                          : 'mr-auto bg-slate-950/80 border-slate-800 text-white'
                      }`}
                    >
                      <span className="text-lg shrink-0 p-1 rounded-xl bg-slate-900 border border-slate-800">
                        {msg.senderAvatar || '👤'}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span
                            className={`font-bold text-[11px] font-bengali ${
                              isMe ? 'text-cyan-300' : 'text-amber-300'
                            }`}
                          >
                            {msg.senderName} {isMe ? '(আপনি)' : ''}
                          </span>
                          {msg.timestamp && (
                            <span className="text-[9px] font-mono text-slate-500">
                              {new Date(msg.timestamp).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          )}
                          {msg.isWheel && (
                            <span className="text-[8px] font-mono px-1 rounded bg-cyan-500/20 text-cyan-300">
                              QUICK
                            </span>
                          )}
                        </div>
                        <div className="text-xs font-bengali leading-relaxed text-slate-200">
                          {msg.textBn}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={chatBottomRef} />
              </div>

              {/* Chat Input & Quick-Chat for Active Players */}
              {!isChief && gameState.phase === 'DISCUSSION' && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(chatInputText);
                  }}
                  className="flex items-center gap-2 pt-2 border-t border-slate-800"
                >
                  <button
                    type="button"
                    onClick={() => setShowQuickChatModal(true)}
                    className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500 text-cyan-300 text-xs font-bengali font-bold flex items-center gap-1 cursor-pointer transition-all shrink-0"
                    title="দ্রুত চ্যাট মেনু"
                  >
                    <Radio className="w-4 h-4 text-cyan-400" />
                    <span className="hidden sm:inline">কুইক-চ্যাট</span>
                  </button>

                  <input
                    type="text"
                    value={chatInputText}
                    onChange={(e) => setChatInputText(e.target.value)}
                    placeholder="আপনার যুক্তি বা সন্দেহ প্রকাশ করুন..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bengali text-white focus:outline-none focus:border-cyan-500 min-w-0"
                  />
                  <button
                    type="submit"
                    disabled={!chatInputText.trim()}
                    className={`px-4 py-2 rounded-xl font-bengali font-bold text-xs transition-all shrink-0 ${
                      chatInputText.trim()
                        ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer shadow-md'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    পাঠান
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </main>

      {/* --- MODALS --- */}

      {/* Role Knowledge Modal */}
      {showRoleModal && (
        <div
          onClick={() => setShowRoleModal(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-md w-full bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${roleInfo.badgeColor}`}>
                {roleInfo.nameBn} ({roleInfo.nameEn})
              </span>
              <button
                onClick={() => setShowRoleModal(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300 font-bengali leading-relaxed">
              {roleInfo.descriptionBn}
            </p>

            {/* Secret Knowledge Preview */}
            {gameState.myRoleKnowledge?.solution && (
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-[10px] font-bold text-amber-400 font-bengali block">
                  গোপন অপরাধ সমাধান (Secret Solution):
                </span>
                <div className="text-xs font-bengali text-white">
                  খুনি: <strong className="text-red-400">{gameState.myRoleKnowledge.solution.killerName}</strong>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <ShadowDetectiveCard card={gameState.myRoleKnowledge.solution.lethalTool} size="sm" />
                  <ShadowDetectiveCard card={gameState.myRoleKnowledge.solution.crimeArtifact} size="sm" />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Chat Modal */}
      <QuickChatModal
        isOpen={showQuickChatModal || showChatWheel}
        onClose={() => {
          setShowQuickChatModal(false);
          setShowChatWheel(false);
        }}
        onSendMessage={(msg) => handleSendMessage(msg, true)}
        gameType="shadowdetective"
        otherPlayers={gameState.players.filter((p) => p.id !== playerId)}
      />

      {/* Official Game Manual Modal */}
      <ShadowDetectiveManualModal
        isOpen={showManualModal}
        onClose={() => setShowManualModal(false)}
      />

      {/* Nearby Connection Diagnostics Modal */}
      <NearbyMultiplayerTest
        isOpen={showDiagnostics}
        onClose={() => setShowDiagnostics(false)}
      />

      {/* Case Submission Modal */}
      <CaseSubmissionModal
        isOpen={showAccusationModal}
        onClose={() => setShowAccusationModal(false)}
        players={gameState.players}
        myPlayerId={playerId}
        remainingAttempts={gameState.remainingSubmissionAttempts}
        onSubmitAccusation={handleSubmitAccusation}
      />

      {/* Witness Hunt Modal */}
      <WitnessHuntModal
        isOpen={gameState.phase === 'WITNESS_HUNT'}
        isKiller={isKiller}
        deadline={gameState.witnessHuntDeadline}
        players={gameState.players}
        myPlayerId={playerId}
        onHuntWitness={handleHuntWitness}
      />

      {/* Power Card Modal */}
      <PowerCardModal
        isOpen={showPowerModal}
        onClose={() => setShowPowerModal(false)}
        players={gameState.players}
        myPlayerId={playerId}
        usedPowers={me?.powerCardsUsed}
        onUsePower={handleUsePower}
      />

      {/* --- GAME OVER REVEAL SCREEN --- */}
      {gameState.phase === 'GAME_OVER' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn overflow-y-auto">
          <div className="relative max-w-xl w-full bg-slate-900 border-2 border-amber-400/80 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center my-auto">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-3xl shadow-xl mb-3">
              {gameState.winnerTeam === 'detectives' ? '🏆' : '💀'}
            </div>

            <h3 className="text-2xl sm:text-3xl font-black text-amber-300 font-bengali">
              {gameState.winnerTeam === 'detectives'
                ? 'তদন্তকারী দল বিজয়ী!'
                : 'অপরাধ সিন্ডিকেট বিজয়ী!'}
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-2 max-w-md leading-relaxed">
              {gameState.winReasonBn}
            </p>

            {/* Revealed Crime Solution */}
            {gameState.crimeSolutionRevealed && (
              <div className="my-5 p-4 rounded-2xl bg-slate-950/80 border border-slate-800 w-full space-y-2">
                <span className="text-xs font-bold text-amber-400 font-bengali block">
                  আসল অপরাধের সমাধান (The Crime Solution):
                </span>
                <div className="text-xs text-white font-bengali">
                  খুনি ছিল:{' '}
                  <strong className="text-red-400 text-sm">
                    {gameState.crimeSolutionRevealed.killerName}
                  </strong>
                </div>
                <div className="flex items-center justify-center gap-3 pt-2">
                  <ShadowDetectiveCard card={gameState.crimeSolutionRevealed.lethalTool} size="sm" />
                  <ShadowDetectiveCard card={gameState.crimeSolutionRevealed.crimeArtifact} size="sm" />
                </div>
              </div>
            )}

            {/* Revealed Roles */}
            <div className="w-full space-y-1.5 mb-5 text-left">
              <span className="text-xs font-bold text-slate-400 font-bengali block">
                খেলোয়াড়দের আসল ভূমিকা:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {gameState.players.map((p) => {
                  const r = p.revealedRole ? ROLE_INFO[p.revealedRole] : null;
                  return (
                    <div key={p.id} className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                      <div className="font-bold text-white truncate font-bengali">{p.name}</div>
                      <div className="text-[10px] text-cyan-300 font-bengali">{r?.nameBn || 'গোয়েন্দা'}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 w-full">
              {me?.isHost && (
                <button
                  onClick={handleRestart}
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs sm:text-sm font-bengali shadow-xl cursor-pointer"
                >
                  আবার খেলুন (Play Again)
                </button>
              )}
              <button
                onClick={onBackToPlatform}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm font-bengali cursor-pointer"
              >
                খেলাঘর হোমে ফিরুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mandatory Signature Footer: Strictly "RI Rahat" */}
      <footer className="relative z-10 py-3 text-center border-t border-slate-900 bg-slate-950/80">
        <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 font-bengali">
          <span>খেলাঘর • শ্যাডো ডিটেক্টিভ</span>
          <span className="text-slate-600">•</span>
          <span className="font-semibold tracking-wide text-cyan-400 font-mono">
            RI Rahat
          </span>
        </div>
      </footer>
    </div>
  );
};
