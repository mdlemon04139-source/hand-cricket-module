import React, { useState } from 'react';
import { ShadowPlayerPublic, ShadowCard } from '../../types/shadowDetective';
import { ShadowDetectiveCard } from './ShadowDetectiveCard';
import { X, Gavel, AlertTriangle, Check } from 'lucide-react';

interface CaseSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  players: ShadowPlayerPublic[];
  myPlayerId: string;
  remainingAttempts: number;
  onSubmitAccusation: (accusedPlayerId: string, toolId: string, artifactId: string) => void;
}

export const CaseSubmissionModal: React.FC<CaseSubmissionModalProps> = ({
  isOpen,
  onClose,
  players,
  myPlayerId,
  remainingAttempts,
  onSubmitAccusation,
}) => {
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>('');
  const [selectedToolId, setSelectedToolId] = useState<string>('');
  const [selectedArtifactId, setSelectedArtifactId] = useState<string>('');

  if (!isOpen) return null;

  // The accused cannot be yourself or chief (chief is facilitator)
  const candidatePlayers = players.filter(
    (p) => p.id !== myPlayerId && p.cards.length > 0
  );

  const targetPlayer = players.find((p) => p.id === selectedPlayerId);
  const targetTools = targetPlayer?.cards.filter((c) => c.type === 'lethal_tool') || [];
  const targetArtifacts = targetPlayer?.cards.filter((c) => c.type === 'crime_artifact') || [];

  const canSubmit = selectedPlayerId && selectedToolId && selectedArtifactId;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-2xl w-full bg-slate-900 border-2 border-rose-500/60 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <Gavel className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base sm:text-lg text-white font-bengali flex items-center gap-2">
                <span>চূড়ান্ত মামলা দাখিল (Official Accusation)</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-mono">
                  সুযোগ: {remainingAttempts}/৩
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-bengali">
                খুনি, অপরাধের অস্ত্র ও আলামত মিলিয়ে আনুষ্ঠানিক অভিযোগ আনুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Warning Badge */}
        <div className="mt-3 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200 font-bengali">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <span>
            সতর্কতা: পুরো দলের কাছে মাত্র ৩টি মামলা দাখিলের সুযোগ রয়েছে। ভুল অভিযোগ আনলে সুযোগ নষ্ট হবে এবং ৩টি ব্যর্থতায় সিন্ডিকেট জয়ী হবে!
          </span>
        </div>

        {/* Step 1: Choose Suspect Player */}
        <div className="mt-4 space-y-2">
          <label className="text-xs font-bold text-slate-300 font-bengali block">
            ধাপ ১: সন্দেহভাজন খুনি নির্বাচন করুন:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {candidatePlayers.map((p) => {
              const isSelected = selectedPlayerId === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setSelectedPlayerId(p.id);
                    setSelectedToolId('');
                    setSelectedArtifactId('');
                  }}
                  className={`p-2.5 rounded-2xl border text-center transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    isSelected
                      ? 'bg-rose-950/70 border-rose-400 ring-2 ring-rose-500/40 text-white font-bold'
                      : 'bg-slate-950/60 hover:bg-slate-800 border-slate-800 text-slate-300'
                  }`}
                >
                  <span className="text-2xl">{p.avatar}</span>
                  <span className="text-xs font-bengali truncate w-full">{p.name}</span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {p.cards.length}টি কার্ড
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2 & 3: Choose Weapon & Artifact from Target's hand */}
        {targetPlayer && (
          <div className="mt-5 space-y-4 pt-4 border-t border-slate-800">
            {/* Lethal Tools */}
            <div>
              <label className="text-xs font-bold text-cyan-300 font-bengali block mb-2">
                ধাপ ২: ব্যবহৃত মারাত্মক অস্ত্র (Lethal Tool) নির্বাচন করুন:
              </label>
              <div className="flex flex-wrap gap-2.5">
                {targetTools.map((card) => (
                  <ShadowDetectiveCard
                    key={card.id}
                    card={card}
                    size="sm"
                    isSelected={selectedToolId === card.id}
                    onClick={() => setSelectedToolId(card.id)}
                  />
                ))}
              </div>
            </div>

            {/* Crime Artifacts */}
            <div>
              <label className="text-xs font-bold text-amber-300 font-bengali block mb-2">
                ধাপ ৩: অপরাধস্থলের ক্রাইম আলামত (Crime Artifact) নির্বাচন করুন:
              </label>
              <div className="flex flex-wrap gap-2.5">
                {targetArtifacts.map((card) => (
                  <ShadowDetectiveCard
                    key={card.id}
                    card={card}
                    size="sm"
                    isSelected={selectedArtifactId === card.id}
                    onClick={() => setSelectedArtifactId(card.id)}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Submit Accusation Button */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bengali text-xs font-bold cursor-pointer hover:bg-slate-700"
          >
            বাতিল
          </button>
          <button
            onClick={() => {
              if (canSubmit) {
                onSubmitAccusation(selectedPlayerId, selectedToolId, selectedArtifactId);
                onClose();
              }
            }}
            disabled={!canSubmit}
            className={`px-5 py-2.5 rounded-xl font-bengali font-bold text-xs flex items-center gap-1.5 transition-all shadow-xl ${
              canSubmit
                ? 'bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white cursor-pointer shadow-rose-600/30'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            <Check className="w-4 h-4" />
            <span>আনুষ্ঠানিক মামলা দাখিল করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
