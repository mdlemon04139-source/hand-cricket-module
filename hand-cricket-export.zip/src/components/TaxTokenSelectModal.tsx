import React from 'react';
import { CharacterId } from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';
import { CardView } from './CardView';
import { ShieldCheck, Coins } from 'lucide-react';
import { sound } from '../utils/sound';

interface TaxTokenSelectModalProps {
  selectedCharacters: CharacterId[];
  currentTaxedCharacter?: CharacterId;
  onSelectCharacter: (charId: CharacterId) => void;
}

export const TaxTokenSelectModal: React.FC<TaxTokenSelectModalProps> = ({
  selectedCharacters,
  currentTaxedCharacter,
  onSelectCharacter,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative z-10 w-full max-w-2xl bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950 border-2 border-emerald-500/60 rounded-3xl p-5 sm:p-7 shadow-2xl text-center">
        <div className="w-12 h-12 rounded-full bg-emerald-600/30 border border-emerald-500 flex items-center justify-center mx-auto mb-3">
          <Coins className="w-6 h-6 text-emerald-400" />
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-emerald-300 font-bengali">
          খাজনাদার: ‘ট্যাক্স টোকেন’ স্থাপন করুন
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-1">
          কোন চরিত্রের ওপর ট্যাক্স বসাতে চান? যে খেলোয়াড় সেই চরিত্র দাবি করবে, তাকে প্রতিবার ১টি মুদ্রা শুল্ক হিসেবে প্রদান করতে হবে।
        </p>

        {/* Characters Grid */}
        <div className="my-5 grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-xl mx-auto">
          {selectedCharacters.map((charId) => {
            const char = ALL_CHARACTERS[charId];
            const isCurrent = currentTaxedCharacter === charId;

            return (
              <div
                key={charId}
                onClick={() => {
                  sound.playCoin();
                  onSelectCharacter(charId);
                }}
                className={`flex flex-col items-center p-2 rounded-2xl cursor-pointer transition-all hover:scale-105 ${
                  isCurrent
                    ? 'ring-2 ring-emerald-400 bg-emerald-950/40'
                    : 'hover:bg-slate-800/80 bg-slate-900/60 border border-slate-800'
                }`}
              >
                <CardView
                  characterId={charId}
                  size="sm"
                  hasTaxToken={isCurrent}
                  className="w-full max-w-[110px]"
                />
                <div className="mt-1.5 text-xs font-bold font-bengali text-amber-200">
                  {char.nameBn}
                </div>
                {isCurrent && (
                  <span className="text-[9px] text-emerald-400 font-bengali">
                    বর্তমান ট্যাক্স
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
