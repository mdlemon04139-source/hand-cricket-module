import React, { useState, useEffect } from 'react';
import { CharacterDef, CharacterId, GameSettings } from '../types/game';
import { ALL_CHARACTERS, CHARACTER_LIST, PRESETS } from '../data/characters';
import { CardView } from './CardView';
import { CardModal } from './CardModal';
import {
  Shuffle,
  Volume2,
  VolumeX,
  BookOpen,
  CheckCircle2,
  Play,
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  Info,
} from 'lucide-react';
import { sound } from '../utils/sound';

interface CharacterSelectScreenProps {
  onStartGame: (selectedCharacters: CharacterId[], settings: GameSettings) => void;
  onOpenRules: () => void;
  onBackToPlatform: () => void;
  initialSettings: GameSettings;
}

export const CharacterSelectScreen: React.FC<CharacterSelectScreenProps> = ({
  onStartGame,
  onOpenRules,
  onBackToPlatform,
  initialSettings,
}) => {
  const [selected, setSelected] = useState<CharacterId[]>([
    'nawab',
    'guptoghatok',
    'guptochor',
    'dosyu_sordar',
    'khajnadar',
  ]);
  const [inspectChar, setInspectChar] = useState<CharacterDef | null>(null);
  const [settings, setSettings] = useState<GameSettings>(initialSettings);
  const [isStoryOpen, setIsStoryOpen] = useState(false);

  // Stop character audio preview when unmounting
  useEffect(() => {
    return () => {
      sound.stopCharacterTheme();
    };
  }, []);

  const toggleSelect = (charId: CharacterId) => {
    // Play character audio theme preview
    sound.playCharacterTheme(charId);

    if (selected.includes(charId)) {
      if (selected.length > 1) {
        setSelected(selected.filter((id) => id !== charId));
      }
    } else {
      if (selected.length < 5) {
        setSelected([...selected, charId]);
      } else {
        const [, ...rest] = selected;
        setSelected([...rest, charId]);
      }
    }
  };

  const applyPreset = (presetIds: CharacterId[]) => {
    sound.playClick();
    setSelected([...presetIds]);
    if (presetIds[0]) {
      sound.playCharacterTheme(presetIds[0]);
    }
  };

  const selectRandom = () => {
    sound.playClick();
    const shuffled = [...CHARACTER_LIST].sort(() => 0.5 - Math.random());
    const newSelected = shuffled.slice(0, 5).map((c) => c.id);
    setSelected(newSelected);
    if (newSelected[0]) {
      sound.playCharacterTheme(newSelected[0]);
    }
  };

  const isReady = selected.length === 5;

  const handleStart = () => {
    if (!isReady) return;
    sound.stopCharacterTheme();
    sound.playCardDeal();
    onStartGame(selected, settings);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#130b10] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-black">
      {/* Game Header */}
      <header className="border-b border-amber-500/20 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30 px-4 py-2.5 sm:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.stopCharacterTheme();
              sound.playClick();
              onBackToPlatform();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:border-amber-400 text-xs font-bengali transition-all cursor-pointer"
            title="খেলাঘর হোমে ফিরুন"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">খেলাঘর</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-amber-300 tracking-wide font-bengali">
                চালবাজি
              </h1>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono font-bold">
                লবি
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => {
              sound.playClick();
              onOpenRules();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-300 hover:bg-amber-500/20 text-xs sm:text-sm font-bengali transition-all cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span className="hidden sm:inline">নিয়মাবলি</span>
            <span className="sm:hidden">নিয়ম</span>
          </button>

          <button
            onClick={() => {
              const next = !settings.soundEnabled;
              sound.setEnabled(next);
              sound.playClick();
              setSettings((s) => ({ ...s, soundEnabled: next }));
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-200 hover:text-white transition-all cursor-pointer"
            title="শব্দ"
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 py-4 sm:px-6 w-full flex-1 flex flex-col justify-between">
        {/* Top Controls & Presets */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-3">
          {/* Counter */}
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold font-bengali text-amber-200">
              চরিত্র নির্বাচন:
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/50 text-amber-300 font-mono font-bold text-xs sm:text-sm">
              {selected.length} / ৫
            </span>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5">
            {PRESETS.map((p, idx) => (
              <button
                key={idx}
                onClick={() => applyPreset(p.ids)}
                className="px-2.5 py-1 rounded-lg text-xs font-bengali bg-slate-900 border border-slate-700 text-slate-300 hover:border-amber-400 hover:text-amber-200 transition-all cursor-pointer"
              >
                {p.nameBn.split(' ')[0]}
              </button>
            ))}
            <button
              onClick={selectRandom}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bengali bg-purple-950/60 border border-purple-500/40 text-purple-200 hover:bg-purple-900 transition-all cursor-pointer"
            >
              <Shuffle className="w-3 h-3" />
              <span>এলোমেলো</span>
            </button>
          </div>
        </div>

        {/* 9 Cards Selection Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2 sm:gap-3 my-auto">
          {CHARACTER_LIST.map((char) => {
            const isChosen = selected.includes(char.id);
            return (
              <div
                key={char.id}
                onClick={() => toggleSelect(char.id)}
                className={`group relative flex flex-col items-center rounded-2xl p-1.5 transition-all duration-200 cursor-pointer select-none ${
                  isChosen
                    ? 'ring-2 ring-amber-400 bg-amber-500/10 scale-[1.02] shadow-xl shadow-amber-500/20'
                    : 'bg-slate-950/40 border border-slate-800/80 hover:border-slate-600 opacity-65 hover:opacity-100 hover:scale-[1.01]'
                }`}
              >
                {isChosen && (
                  <div className="absolute top-2 left-2 z-20 bg-amber-400 text-slate-950 rounded-full p-0.5 shadow-lg">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                )}

                <div className="w-full flex justify-center">
                  <CardView
                    characterId={char.id}
                    isSelected={isChosen}
                    size="md"
                    className="w-full"
                  />
                </div>

                <div className="w-full text-center mt-1">
                  <span className="font-extrabold text-xs sm:text-sm text-amber-300 font-bengali block truncate">
                    {char.nameBn}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.playCharacterTheme(char.id);
                      setInspectChar(char);
                    }}
                    className="text-[10px] text-slate-400 hover:text-amber-200 font-bengali underline cursor-pointer"
                  >
                    বিবরণ
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Collapsible Story Placeholder */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 max-w-4xl mx-auto w-full">
          <button
            onClick={() => setIsStoryOpen(!isStoryOpen)}
            className="flex items-center justify-between w-full p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 hover:text-amber-300 hover:border-amber-500/30 transition-all font-bengali cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Info className="w-3.5 h-3.5 text-amber-400" />
              <span>গল্প ও পটভূমি</span>
            </div>
            {isStoryOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {isStoryOpen && (
            <div className="mt-2 p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs text-slate-400 font-bengali leading-relaxed text-center">
              খেলার বিস্তারিত গল্প ও পটভূমি শীঘ্রই যুক্ত করা হবে।
            </div>
          )}
        </div>
      </main>

      {/* Footer Start Game Bar */}
      <footer className="sticky bottom-0 z-30 bg-slate-950/95 border-t border-amber-500/30 backdrop-blur-lg px-4 py-3 sm:px-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <div className="text-xs text-slate-400 font-bengali hidden sm:block">
            {isReady
              ? '৫টি চরিত্র নির্ধারিত হয়েছে। টেবিল প্রস্তুত করতে শুরু করুন।'
              : `আরও ${5 - selected.length} টি চরিত্র নির্বাচন করুন`}
          </div>

          <button
            onClick={handleStart}
            disabled={!isReady}
            className={`w-full sm:w-auto px-8 py-2.5 rounded-2xl font-black text-sm sm:text-base flex items-center justify-center gap-2 transition-all shadow-xl font-bengali cursor-pointer ${
              isReady
                ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 hover:brightness-110 shadow-amber-500/30 scale-100 hover:scale-105 active:scale-95'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            <Play className="w-4 h-4 fill-current" />
            <span>
              {isReady
                ? 'খেলা প্রস্তুত'
                : `${5 - selected.length}টি চরিত্র নির্বাচন করুন`}
            </span>
          </button>
        </div>
      </footer>

      {/* Inspect Modal */}
      {inspectChar && (
        <CardModal character={inspectChar} onClose={() => setInspectChar(null)} />
      )}
    </div>
  );
};
