import React from 'react';
import { Card, CharacterId } from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';
import { CardBack } from './CardBack';
import { Maximize2 } from 'lucide-react';

interface CardViewProps {
  card?: Card;
  characterId?: CharacterId;
  isFaceDown?: boolean;
  isDead?: boolean;
  isSelected?: boolean;
  isHighlighted?: boolean;
  hasTaxToken?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  onClick?: () => void;
  onInspect?: () => void;
  className?: string;
  showInspectButton?: boolean;
}

export const CardView: React.FC<CardViewProps> = ({
  card,
  characterId,
  isFaceDown = false,
  isDead = false,
  isSelected = false,
  isHighlighted = false,
  hasTaxToken = false,
  size = 'md',
  onClick,
  onInspect,
  className = '',
  showInspectButton = false,
}) => {
  const activeCharId = characterId || card?.characterId;
  const charDef = activeCharId ? ALL_CHARACTERS[activeCharId] : null;
  const dead = isDead || !!card?.isRevealed;

  // Determine width based on size
  const sizeClasses = {
    sm: 'w-20 sm:w-24',
    md: 'w-28 sm:w-32 md:w-36',
    lg: 'w-40 sm:w-48 md:w-52',
    xl: 'w-52 sm:w-60 md:w-64',
  }[size];

  if (isFaceDown || (!charDef && !dead)) {
    return (
      <div
        onClick={onClick}
        className={`relative cursor-pointer transition-transform duration-200 hover:-translate-y-1 ${sizeClasses} ${className}`}
      >
        <CardBack isDead={dead} />
      </div>
    );
  }

  if (!charDef) {
    return (
      <div
        className={`relative aspect-[5/7] rounded-2xl border-2 border-dashed border-amber-500/30 bg-slate-900/60 flex items-center justify-center p-2 text-center text-xs text-amber-200/50 ${sizeClasses} ${className}`}
      >
        কার্ড নেই
      </div>
    );
  }

  return (
    <div
      onClick={onClick}
      className={`group relative rounded-2xl transition-all duration-300 select-none ${
        onClick ? 'cursor-pointer' : ''
      } ${
        isSelected
          ? 'ring-4 ring-amber-400 scale-[1.03] shadow-xl shadow-amber-500/30'
          : isHighlighted
          ? 'ring-4 ring-cyan-400 animate-pulse shadow-xl shadow-cyan-500/40'
          : 'hover:-translate-y-1 hover:shadow-2xl hover:shadow-amber-500/20'
      } ${dead ? 'grayscale opacity-60' : ''} ${sizeClasses} ${className}`}
      style={{
        aspectRatio: '5/7',
      }}
    >
      {/* 
        Transparent background card container:
        Preserves original approved artwork with transparent outer margin.
      */}
      <div className="w-full h-full rounded-2xl overflow-hidden bg-transparent flex items-center justify-center relative drop-shadow-xl">
        <img
          src={charDef.image}
          alt={charDef.nameBn}
          className="w-full h-full object-contain pointer-events-none drop-shadow-lg"
          loading="eager"
        />

        {/* Dead Discard Stamp */}
        {dead && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-[1px] rounded-2xl flex flex-col items-center justify-center pointer-events-none p-2">
            <div className="border-2 border-red-500 text-red-400 font-bold px-2 py-1 rounded rotate-[-12deg] tracking-wider uppercase text-xs sm:text-sm font-bengali shadow-lg">
              খারিজ / মৃত
            </div>
            <span className="text-[10px] text-red-300/80 mt-1 font-bengali">
              {charDef.nameBn}
            </span>
          </div>
        )}

        {/* Active Tax Token Marker */}
        {hasTaxToken && !dead && (
          <div className="absolute top-2 right-2 bg-gradient-to-r from-emerald-600 to-green-700 text-amber-200 font-bold text-[10px] sm:text-xs px-2 py-0.5 rounded-full border border-amber-300 shadow-lg flex items-center gap-1 z-10 animate-bounce">
            <span className="w-2 h-2 rounded-full bg-amber-300 inline-block" />
            <span className="font-bengali">ট্যাক্স টোকেন</span>
          </div>
        )}

        {/* Optional Zoom Button if explicitly enabled */}
        {showInspectButton && onInspect && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onInspect();
            }}
            className="absolute bottom-2 right-2 p-1.5 rounded-full bg-black/75 text-amber-300 hover:text-white hover:bg-amber-600/90 transition-all opacity-0 group-hover:opacity-100 z-20 backdrop-blur-sm shadow-md"
            title="কার্ড বিস্তারিত দেখুন"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
