import React from 'react';
import { Card } from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';
import { CardView } from './CardView';
import { Skull, AlertOctagon } from 'lucide-react';
import { sound } from '../utils/sound';

interface DiscardCardModalProps {
  cards: Card[];
  reasonBn: string;
  onSelectDiscard: (cardUid: string) => void;
}

export const DiscardCardModal: React.FC<DiscardCardModalProps> = ({
  cards,
  reasonBn,
  onSelectDiscard,
}) => {
  const activeCards = cards.filter((c) => !c.isRevealed);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative z-10 w-full max-w-lg bg-gradient-to-b from-red-950/90 via-slate-900 to-slate-950 border-2 border-red-500/60 rounded-3xl p-5 sm:p-7 shadow-2xl text-center">
        {/* Skull Icon */}
        <div className="w-12 h-12 rounded-full bg-red-600/30 border border-red-500 flex items-center justify-center mx-auto mb-3 animate-bounce">
          <Skull className="w-6 h-6 text-red-400" />
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-red-400 font-bengali">
          আপনি ১টি জীবন হারিয়েছেন!
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 font-bengali mt-1">
          {reasonBn}
        </p>
        <p className="text-xs text-amber-300 font-bengali mt-2">
          নিচের হাতের কার্ডগুলো থেকে একটি কার্ড বেছে নিন যা প্রকাশ্যভাবে টেবিলে খারিজ করা হবে:
        </p>

        {/* Available Active Cards to Discard */}
        <div className="my-6 flex justify-center gap-4 sm:gap-6">
          {activeCards.map((card, idx) => {
            const charDef = ALL_CHARACTERS[card.characterId];
            return (
              <div
                key={card.uid}
                onClick={() => {
                  sound.playLifeLost();
                  onSelectDiscard(card.uid);
                }}
                className="group flex flex-col items-center cursor-pointer transition-transform hover:scale-105 active:scale-95"
              >
                <CardView
                  characterId={card.characterId}
                  size="md"
                  className="w-28 sm:w-36 group-hover:ring-4 group-hover:ring-red-500"
                />
                <div className="mt-2 font-bengali font-bold text-sm text-amber-200">
                  {charDef.nameBn}
                </div>
                <button
                  type="button"
                  className="mt-1 px-3 py-1 rounded-lg bg-red-700 hover:bg-red-600 text-white font-bengali text-xs shadow-md"
                >
                  এটি খারিজ করুন
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
