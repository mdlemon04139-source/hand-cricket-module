import React, { useState } from 'react';
import { ALL_CHARACTERS, CHARACTER_LIST } from '../data/characters';
import { X, BookOpen, Shield, Swords, Coins, AlertTriangle, Eye, CheckCircle2 } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'basics' | 'characters' | 'challenges' | 'ai'>('basics');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-slate-900 via-[#0d1627] to-slate-950 border border-amber-500/40 rounded-3xl p-4 sm:p-6 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-amber-300 font-bengali">
                চালবাজি: খেলার সম্পূর্ণ নিয়মাবলি (Game Rules)
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Official Bengali Bluffing & Strategy Card Game Manual
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800 text-amber-200 hover:text-white hover:bg-red-600 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 py-3 border-b border-slate-800 overflow-x-auto">
          {[
            { id: 'basics', labelBn: 'মূল নিয়মাবলি (Basics)', icon: Coins },
            { id: 'characters', labelBn: '৯টি চরিত্রের ক্ষমতা (Characters)', icon: Swords },
            { id: 'challenges', labelBn: 'চালবাজি ও চ্যালেঞ্জ (Bluff & Block)', icon: AlertTriangle },
            { id: 'ai', labelBn: 'রোবট ব্যক্তিত্ব (AI Personalities)', icon: Eye },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bengali transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.labelBn}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto py-4 pr-1 text-slate-200 font-bengali space-y-4">
          {activeTab === 'basics' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30">
                <h3 className="font-bold text-amber-300 text-base mb-1">
                  🎯 খেলার মূল উদ্দেশ্য
                </h3>
                <p className="leading-relaxed text-slate-300">
                  চালবাজি একটি কৌশল ও ছলনার খেলা। ৪ জন খেলোয়াড়ের মধ্যে শেষ জীবিত খেলোয়াড় হিসেবে বিজয়ী হওয়াই মূল লক্ষ্য। প্রতিটি খেলোয়াড় ২টি কার্ড (২টি জীবন) এবং ২টি মুদ্রা নিয়ে যাত্রা শুরু করে।
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-1.5">
                    <Coins className="w-4 h-4 text-amber-400" />
                    সাধারণ একশন ১: রাজস্ব (Income)
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    ব্যাংক থেকে ১টি মুদ্রা গ্রহণ করুন। এই সাধারণ একশনে কেউ কোনো চ্যালেঞ্জ বা ব্লক করতে পারবে না।
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <h4 className="font-bold text-red-400 mb-1 flex items-center gap-1.5">
                    <Swords className="w-4 h-4 text-red-400" />
                    সাধারণ একশন ২: সুপ্রিম নিধন (Coup / Assassination)
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    ৭টি মুদ্রা ব্যাংকে জমা দিয়ে যেকোনো ১ জন প্রতিপক্ষকে সরাসরি ১টি জীবন হারাতে বাধ্য করুন। এই আক্রমণ চ্যালেঞ্জ বা ব্লক করা যায় না! (১০টি মুদ্রা হলে এই আক্রমণ বাধ্যতামূলক)।
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
                <h4 className="font-bold text-amber-300 mb-2">
                  🃏 ডেক ও জীবন নিয়ম (Deck & Lives)
                </h4>
                <ul className="list-disc list-inside space-y-1.5 text-xs text-slate-300">
                  <li>খেলা শুরুর আগে ৯টি চরিত্রের মধ্য থেকে ৫টি চরিত্র বাছাই করা হয়।</li>
                  <li>প্রতিটি চরিত্রের ৩টি করে মোট ১৫টি কার্ড দিয়ে ডেক তৈরি হয়।</li>
                  <li>একটি জীবন হারালে খেলোয়াড়কে তার হাত থেকে যেকোনো একটি কার্ড প্রকাশ্যভাবে খারিজ করতে হয়।</li>
                  <li>উভয় কার্ড প্রকাশ হয়ে গেলে খেলোয়াড় নির্মূল (Eliminated) হয়ে যান।</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'characters' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CHARACTER_LIST.map((char) => (
                <div
                  key={char.id}
                  className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-all flex gap-3"
                >
                  <img
                    src={char.image}
                    alt={char.nameBn}
                    className="w-16 h-22 object-contain rounded-lg border border-amber-500/30 shrink-0 bg-slate-950"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-sm text-amber-300">
                        {char.nameBn}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        ({char.nameEn})
                      </span>
                    </div>
                    <div className="text-[10px] text-amber-400/90 font-semibold mt-0.5">
                      {char.coinCost > 0
                        ? `খরচ: ${char.coinCost} মুদ্রা`
                        : char.coinGain > 0
                        ? `মুদ্রা লাভ: +${char.coinGain}`
                        : 'বিশেষ কৌশলগত চাল'}
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-snug">
                      {char.descriptionBn}
                    </p>
                    {char.canBlock && (
                      <span className="inline-block mt-1 text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-500/30">
                        🛡️ চুরি ও ডাকাতি প্রতিরোধ করতে পারে
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'challenges' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30">
                <h3 className="font-bold text-amber-300 text-base mb-1">
                  🎭 চালবাজি (Bluffing) ও চ্যালেঞ্জের নিয়ম
                </h3>
                <p className="text-slate-300 leading-relaxed">
                  আপনার হাতে কার্ডটি না থাকলেও আপনি যেকোনো চরিত্রের ক্ষমতার দাবি করতে পারেন! প্রতিবার দাবি করার সাথে সাথে ৪ সেকেন্ডের প্রতিক্রিয়া উইন্ডো খোলে।
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30">
                  <h4 className="font-bold text-emerald-300 mb-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    দাবি সত্য হলে (Claim Proven True)
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs">
                    <li>দাবিকারী তার আসল কার্ড টেবিলকে দেখিয়ে প্রমাণ দেন।</li>
                    <li><strong>চ্যালেঞ্জকারী সাথে সাথে ১টি জীবন হারায়!</strong></li>
                    <li>প্রমাণিত কার্ডটি ডেকে ফেরত দিয়ে ডেক শুফেল হয় এবং নতুন গোপন কার্ড তোলা হয়।</li>
                    <li>ঘোষিত একশনটি সফলভাবে কার্যকর হয়।</li>
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/30">
                  <h4 className="font-bold text-rose-300 mb-2 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    চালবাজি ধরা পড়লে (Caught Bluffing)
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs">
                    <li>দাবিকারীর কাছে উক্ত কার্ড না থাকলে চালবাজি ফাঁস হয়!</li>
                    <li><strong>দাবিকারী তাৎক্ষণিকভাবে ১টি জীবন হারায়।</strong></li>
                    <li>ঘোষিত একশনটি বাতিল হয়ে যায়।</li>
                  </ul>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                <h4 className="font-bold text-amber-300 mb-1">
                  🛡️ ব্লকিং (প্রতিরক্ষা) চ্যালেঞ্জ
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  কোন খেলোয়াড় আপনার আক্রমণ বা চুরির বিরুদ্ধে চরিত্র দাবি করে ব্লক করতে চাইলে আপনি সেই ব্লকের বিরুদ্ধেও চ্যালেঞ্জ করতে পারেন। ব্লকার কার্ড দেখাতে পারলে আপনি জীবন হারাবেন, আর ব্লকার মিথ্যা বললে ব্লক বাতিল হবে ও তিনি জীবন হারাবেন।
                </p>
              </div>
            </div>
          )}

          {activeTab === 'ai' && (
            <div className="space-y-3 text-xs sm:text-sm">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="font-bold text-blue-400 text-base mb-1">
                  🛡️ জাফর খান (AI 1 — Cautious / সতর্ক)
                </h4>
                <p className="text-slate-300 text-xs">
                  নিশ্চিত প্রমাণ ছাড়া কখনোই অনর্থক চ্যালেঞ্জ করেন না। নিজের মুদ্রা ও কার্ড বাঁচিয়ে নিরাপদ পথে চলেন। খুব কমই মিথ্যা দাবি করেন।
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="font-bold text-red-400 text-base mb-1">
                  ⚔️ রশিদ খাঁ (AI 2 — Aggressive / আক্রমণাত্মক)
                </h4>
                <p className="text-slate-300 text-xs">
                  সন্দেহজনক দাবির বিরুদ্ধে চটজলদি চ্যালেঞ্জ ছুঁড়ে দেন। কয়েন হলেই আক্রমণ ও চুরি চালান এবং প্রতিপক্ষকে নির্মূল করতে ঝুঁকিপূর্ণ চাল দিতে পিছপা হন না।
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="font-bold text-purple-400 text-base mb-1">
                  🧠 শাহজাদা মির্জা (AI 3 — Strategic / কৌশলী)
                </h4>
                <p className="text-slate-300 text-xs">
                  টেবিলে পড়ে থাকা কার্ড, প্রতিপক্ষের বর্তমান কয়েন এবং পরিসংখ্যান গণনা করে চলেন। কখন চালবাজি করতে হবে আর কখন চ্যালেঞ্জ করতে হবে তা গভীরভাবে বিশ্লেষণ করেন।
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm font-bengali transition-all cursor-pointer"
          >
            বুঝেছি, খেলায় ফিরুন
          </button>
        </div>
      </div>
    </div>
  );
};
