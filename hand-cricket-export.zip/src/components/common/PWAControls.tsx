import React, { useState } from 'react';
import { usePWAInstall, useOnlineStatus } from '../../hooks/usePWAInstall';
import { Download, WifiOff, Share2, PlusSquare, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // Suppress button if already installed as standalone PWA
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop standard install
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bengali font-bold text-xs shadow-lg shadow-emerald-500/20 cursor-pointer transition-all hover:scale-105 active:scale-95"
      >
        <Download className="w-3.5 h-3.5" />
        <span>অ্যাপ ইনস্টল</span>
      </button>
    );
  }

  // iOS Safari "Add to Home Screen" instructions
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-cyan-300 hover:text-white text-xs font-bengali cursor-pointer transition-all"
        >
          <Download className="w-3.5 h-3.5" />
          <span>iOS ইনস্টল</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
            <div className="w-full max-w-sm rounded-3xl bg-slate-900 border-2 border-cyan-500/50 p-6 shadow-2xl text-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-base font-bold text-white font-bengali flex items-center gap-2">
                  <span>আইফোন / আইপ্যাডে ইনস্টল করুন</span>
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-xs font-bengali text-slate-300">
                <div className="flex items-start gap-2.5 p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                  <div className="w-7 h-7 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                    <Share2 className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block">১. সাফারি ব্রাউজারের শেয়ার বোতাম চাপুন</strong>
                    <span>স্ক্রিনের নিচে থাকা Share আইকনটিতে ট্যাপ করুন।</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                  <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <PlusSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block">২. "Add to Home Screen" নির্বাচন করুন</strong>
                    <span>মেনু স্ক্রোল করে 'Add to Home Screen' বাটনে ক্লিক করুন।</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-bengali text-xs cursor-pointer shadow-lg"
              >
                বুঝেছি (Close)
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineStatusIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-3 left-3 z-50 flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-amber-500/90 text-slate-950 border border-amber-300 shadow-xl backdrop-blur-md text-xs font-bengali font-bold animate-pulse">
      <WifiOff className="w-4 h-4 text-slate-950" />
      <span>অফলাইন মোড — ক্যাশ করা লোকাল ডাটা ও বট খেলা সক্রিয়</span>
    </div>
  );
};
