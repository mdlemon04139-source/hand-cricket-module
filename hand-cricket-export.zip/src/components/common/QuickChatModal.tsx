import React, { useState } from 'react';
import {
  MessageSquare,
  X,
  Search,
  DollarSign,
  Send,
  ThumbsUp,
  ThumbsDown,
  HelpCircle,
  Sparkles,
} from 'lucide-react';

export interface QuickChatCategory {
  id: 'general' | 'investigation' | 'negotiation';
  nameBn: string;
  nameEn: string;
}

export interface NegotiationPlayer {
  id: string;
  name: string;
  avatar?: string;
}

interface QuickChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendMessage: (text: string, isNegotiation?: boolean, offerData?: { targetId?: string; amount?: number }) => void;
  gameType?: 'shadowdetective' | 'borderpass' | 'calbaji' | 'general';
  otherPlayers?: NegotiationPlayer[];
  currencySymbol?: string;
  minOffer?: number;
  maxOffer?: number;
}

export const QuickChatModal: React.FC<QuickChatModalProps> = ({
  isOpen,
  onClose,
  onSendMessage,
  gameType = 'general',
  otherPlayers = [],
  currencySymbol = '$',
  minOffer = 10,
  maxOffer = 500,
}) => {
  const [activeTab, setActiveTab] = useState<'general' | 'investigation' | 'negotiation'>(
    gameType === 'shadowdetective' ? 'investigation' : gameType === 'borderpass' ? 'negotiation' : 'general'
  );

  // Negotiation composer state
  const [offerAmount, setOfferAmount] = useState<number>(50);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>(
    otherPlayers[0]?.id || ''
  );
  const [offerNote, setOfferNote] = useState<string>('কাস্টমস ফি বা অফার');

  if (!isOpen) return null;

  const generalPhrases = [
    { bn: 'সবাইকে স্বাগতম!', en: 'Hello everyone!' },
    { bn: 'সবাই প্রস্তুত তো?', en: 'Ready to start?' },
    { bn: 'শুভকামনা সবার জন্য!', en: 'Good luck!' },
    { bn: 'আমি একমত।', en: 'I agree.' },
    { bn: 'আমি দ্বিমত পোষণ করছি।', en: 'I disagree.' },
    { bn: 'আমাকে একটু ভাবতে দিন...', en: 'Let me think...' },
    { bn: 'দয়া করে বিস্তারিত ব্যাখ্যা করুন।', en: 'Please explain.' },
    { bn: 'এখন আপনার চাল/পালা।', en: 'Your turn.' },
    { bn: 'চমৎকার চাল ছিল!', en: 'Well played!' },
    { bn: 'ভালো খেলা হয়েছে!', en: 'Good game!' },
  ];

  const investigationPhrases = [
    { bn: 'আমার কাছে একটি সম্ভাব্য থিওরি আছে।', en: 'I have a theory.' },
    { bn: 'আমি একটি রহস্যজনক আলামত খুঁজে পেয়েছি!', en: 'I found a suspicious clue.' },
    { bn: 'চলুন সব প্রমাণ আবার মিলিয়ে দেখি।', en: "Let's review the evidence." },
    { bn: 'সবার মতামত শুনতে চাই।', en: "I want to hear everyone's opinion." },
    { bn: 'এই অভিযোগের সাথে আমি একমত নই!', en: 'I disagree with this accusation.' },
    { bn: 'আমি মামলা দাখিলের জন্য প্রস্তুত!', en: 'I am ready to submit a case.' },
    { bn: 'এই খেলোয়াড়ের আলিবাই সন্দেহজনক!', en: "This suspect's alibi looks fake!" },
    { bn: 'ফরেনসিক বোর্ডের সংকেতের সাথে কার মিল বেশি?', en: 'Who matches the forensic board pins?' },
  ];

  const negotiationPhrases = [
    { bn: 'আমার একটি বিশেষ প্রস্তাব আছে।', en: 'I have an offer.' },
    { bn: 'দাম বা অফার কিছুটা কমানো সম্ভব?', en: 'Can you lower the price?' },
    { bn: 'আমি অফারটি গ্রহণ করছি। ডিল!', en: 'I accept your offer. Deal!' },
    { bn: 'আমি এই অফারটি প্রত্যাখ্যান করছি।', en: 'I reject this offer.' },
    { bn: 'দয়া করে একটি পাল্টা প্রস্তাব দিন।', en: 'Please make a counteroffer.' },
    { bn: 'এটাই আমার চূড়ান্ত প্রস্তাব।', en: 'My final offer.' },
    { bn: 'চলুন আরেকবার দর কষাকষি করি।', en: "Let's negotiate again." },
  ];

  const handleSendQuickText = (textBn: string) => {
    onSendMessage(textBn, false);
    onClose();
  };

  const handleSendOffer = () => {
    const targetPlayer = otherPlayers.find((p) => p.id === selectedRecipientId);
    const targetName = targetPlayer ? targetPlayer.name : 'সকলের উদ্দেশ্যে';
    const message = `[অফার] ${targetName}-কে ${currencySymbol}${offerAmount} প্রস্তাব করা হলো (${offerNote})`;
    onSendMessage(message, true, {
      targetId: selectedRecipientId || undefined,
      amount: offerAmount,
    });
    onClose();
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-lg w-full bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-5 shadow-2xl space-y-4 text-slate-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white font-bengali">
                দ্রুত চ্যাট ও প্রস্তাবনা (Quick-Chat)
              </h3>
              <p className="text-[10px] text-slate-400 font-bengali">
                টাইপ না করেই এক ট্যাপে মেসেজ বা অফার পাঠান
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab categories */}
        <div className="flex rounded-2xl bg-slate-950 p-1 border border-slate-800 gap-1 text-xs font-bengali">
          <button
            onClick={() => setActiveTab('general')}
            className={`flex-1 py-1.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'general'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>সাধারণ</span>
          </button>

          {(gameType === 'shadowdetective' || gameType === 'general') && (
            <button
              onClick={() => setActiveTab('investigation')}
              className={`flex-1 py-1.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'investigation'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>তদন্ত ও ক্লু</span>
            </button>
          )}

          {(gameType === 'borderpass' || gameType === 'calbaji' || gameType === 'general') && (
            <button
              onClick={() => setActiveTab('negotiation')}
              className={`flex-1 py-1.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'negotiation'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>দর কষাকষি</span>
            </button>
          )}
        </div>

        {/* Tab 1: General Phrases */}
        {activeTab === 'general' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
            {generalPhrases.map((phrase, idx) => (
              <button
                key={idx}
                onClick={() => handleSendQuickText(phrase.bn)}
                className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-left transition-all cursor-pointer group"
              >
                <div className="text-xs font-bengali text-slate-200 group-hover:text-cyan-300 font-semibold">
                  {phrase.bn}
                </div>
                <div className="text-[10px] text-slate-500 font-sans">{phrase.en}</div>
              </button>
            ))}
          </div>
        )}

        {/* Tab 2: Investigation Phrases */}
        {activeTab === 'investigation' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
            {investigationPhrases.map((phrase, idx) => (
              <button
                key={idx}
                onClick={() => handleSendQuickText(phrase.bn)}
                className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-left transition-all cursor-pointer group"
              >
                <div className="text-xs font-bengali text-slate-200 group-hover:text-cyan-300 font-semibold">
                  {phrase.bn}
                </div>
                <div className="text-[10px] text-slate-500 font-sans">{phrase.en}</div>
              </button>
            ))}
          </div>
        )}

        {/* Tab 3: Dynamic Negotiation & Offer Composer */}
        {activeTab === 'negotiation' && (
          <div className="space-y-3">
            {/* Quick negotiation phrases */}
            <div className="grid grid-cols-2 gap-1.5">
              {negotiationPhrases.slice(0, 4).map((phrase, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendQuickText(phrase.bn)}
                  className="p-2 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-left text-xs font-bengali text-slate-300 hover:text-amber-300 cursor-pointer"
                >
                  {phrase.bn}
                </button>
              ))}
            </div>

            {/* Dynamic Offer Form */}
            <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/40 space-y-3">
              <span className="text-xs font-bold text-amber-300 font-bengali block">
                লাইভ অফার কম্পোজার (Send Custom Offer):
              </span>

              {/* Recipient Selector */}
              {otherPlayers.length > 0 && (
                <div>
                  <label className="text-[11px] text-slate-400 font-bengali block mb-1">
                    প্রস্তাব প্রাপক:
                  </label>
                  <select
                    value={selectedRecipientId}
                    onChange={(e) => setSelectedRecipientId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bengali text-white focus:outline-none focus:border-amber-500"
                  >
                    {otherPlayers.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.avatar || '👤'} {p.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Amount Selector */}
              <div>
                <div className="flex justify-between items-center text-[11px] font-bengali text-slate-300 mb-1">
                  <span>অফারের পরিমাণ:</span>
                  <span className="font-mono font-bold text-amber-400 text-sm">
                    {currencySymbol}{offerAmount}
                  </span>
                </div>
                <input
                  type="range"
                  min={minOffer}
                  max={maxOffer}
                  step={10}
                  value={offerAmount}
                  onChange={(e) => setOfferAmount(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex justify-between text-[9px] font-mono text-slate-500">
                  <span>{currencySymbol}{minOffer}</span>
                  <span>{currencySymbol}{maxOffer / 2}</span>
                  <span>{currencySymbol}{maxOffer}</span>
                </div>
              </div>

              {/* Send Offer Button */}
              <button
                onClick={handleSendOffer}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs font-bengali flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/20"
              >
                <Send className="w-3.5 h-3.5" />
                <span>অফার পাঠান ({currencySymbol}{offerAmount})</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
