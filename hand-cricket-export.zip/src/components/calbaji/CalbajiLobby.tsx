import React, { useState, useEffect } from 'react';
import {
  Users,
  Plus,
  Play,
  Copy,
  Check,
  Bot,
  User,
  Crown,
  Trash2,
  ArrowLeft,
  BookOpen,
  Sparkles,
  Sword,
  Shield,
  Layers,
  UserCheck,
} from 'lucide-react';
import { CalbajiClientView } from '../../server/calbajiRoomManager';
import { ALL_CHARACTERS } from '../../data/characters';
import { sound } from '../../utils/sound';

interface CalbajiLobbyProps {
  onBackToPlatform: () => void;
  onOpenRules: () => void;
  onStartSolo: () => void;
  onRoomReady: (roomId: string, playerId: string) => void;
}

export const CalbajiLobby: React.FC<CalbajiLobbyProps> = ({
  onBackToPlatform,
  onOpenRules,
  onStartSolo,
  onRoomReady,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'join' | 'solo'>('create');
  const [playerName, setPlayerName] = useState(() => {
    try {
      return localStorage.getItem('calbaji_player_name') || 'খেলোয়াড়';
    } catch {
      return 'খেলোয়াড়';
    }
  });
  const [playerAvatar, setPlayerAvatar] = useState(() => {
    try {
      return localStorage.getItem('calbaji_player_avatar') || '👑';
    } catch {
      return '👑';
    }
  });
  const [joinCode, setJoinCode] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // In-room state if inside a created/joined room
  const [currentRoomId, setCurrentRoomId] = useState<string | null>(null);
  const [myPlayerId, setMyPlayerId] = useState<string | null>(null);
  const [roomState, setRoomState] = useState<CalbajiClientView | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const avatars = ['👑', '⚔️', '🛡️', '🧠', '🗡️', '🥷', '🐅', '🦚'];

  // Save profile info to localStorage
  const handleNameChange = (val: string) => {
    setPlayerName(val);
    try {
      localStorage.setItem('calbaji_player_name', val);
    } catch {}
  };

  const handleAvatarChange = (val: string) => {
    sound.playClick();
    setPlayerAvatar(val);
    try {
      localStorage.setItem('calbaji_player_avatar', val);
    } catch {}
  };

  // Create Room
  const handleCreateRoom = async () => {
    sound.playClick();
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/calbaji/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: playerName, avatar: playerAvatar }),
      });
      const data = await res.json();
      setCurrentRoomId(data.roomId);
      setMyPlayerId(data.playerId);
      sound.playRoomJoin();
      subscribeToRoom(data.roomId, data.playerId);
    } catch (err: any) {
      setErrorMsg('রুম তৈরিতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsLoading(false);
    }
  };

  // Join Room
  const handleJoinRoom = async () => {
    sound.playClick();
    if (!joinCode.trim()) {
      setErrorMsg('অনুগ্রহ করে রুম কোড লিখুন।');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch(`/api/calbaji/rooms/${joinCode.trim().toUpperCase()}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: playerName, avatar: playerAvatar }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setErrorMsg(data.error || 'রুমে প্রবেশ করা যায়নি।');
        return;
      }
      setCurrentRoomId(data.roomId || joinCode.trim().toUpperCase());
      setMyPlayerId(data.playerId);
      sound.playRoomJoin();
      subscribeToRoom(data.roomId || joinCode.trim().toUpperCase(), data.playerId);
    } catch (err: any) {
      setErrorMsg('সার্ভারে সংযোগ ব্যর্থ হয়েছে। কোড পরীক্ষা করুন।');
    } finally {
      setIsLoading(false);
    }
  };

  // Subscribe to SSE
  const subscribeToRoom = (roomId: string, playerId: string) => {
    let sse: EventSource | null = null;
    try {
      sse = new EventSource(`/api/calbaji/rooms/${roomId}/events?playerId=${playerId}`);
      sse.onmessage = (e) => {
        try {
          const data: CalbajiClientView = JSON.parse(e.data);
          setRoomState(data);

          // If game moved out of lobby, transition to board
          if (data.phase !== 'LOBBY') {
            sound.playMatchStart();
            onRoomReady(roomId, playerId);
          }
        } catch {
          // ignore
        }
      };
    } catch {
      // Fallback polling
    }

    // Backup Polling
    const poller = setInterval(async () => {
      try {
        const res = await fetch(`/api/calbaji/rooms/${roomId}/state?playerId=${playerId}`);
        if (res.ok) {
          const data: CalbajiClientView = await res.json();
          setRoomState(data);
          if (data.phase !== 'LOBBY') {
            sound.playMatchStart();
            onRoomReady(roomId, playerId);
          }
        }
      } catch {
        // ignore
      }
    }, 1500);

    return () => {
      if (sse) sse.close();
      clearInterval(poller);
    };
  };

  // Add Bot
  const handleAddBot = async () => {
    if (!currentRoomId) return;
    sound.playClick();
    try {
      await fetch(`/api/calbaji/rooms/${currentRoomId}/add-bot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ personality: 'strategic' }),
      });
      sound.playRoomJoin();
    } catch {
      // ignore
    }
  };

  // Remove Player/Bot
  const handleRemovePlayer = async (pId: string) => {
    if (!currentRoomId) return;
    sound.playClick();
    try {
      await fetch(`/api/calbaji/rooms/${currentRoomId}/remove-player`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: pId }),
      });
    } catch {
      // ignore
    }
  };

  // Toggle Ready
  const handleToggleReady = async () => {
    if (!currentRoomId || !myPlayerId) return;
    sound.playClick();
    try {
      await fetch(`/api/calbaji/rooms/${currentRoomId}/toggle-ready`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: myPlayerId }),
      });
    } catch {
      // ignore
    }
  };

  // Start Game (Host only)
  const handleStartGame = async () => {
    if (!currentRoomId || !myPlayerId) return;
    sound.playClick();
    setIsLoading(true);
    try {
      const res = await fetch(`/api/calbaji/rooms/${currentRoomId}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requesterId: myPlayerId }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setErrorMsg(data.error || 'খেলা শুরু করা সম্ভব হয়নি।');
      } else {
        sound.playMatchStart();
        onRoomReady(currentRoomId, myPlayerId);
      }
    } catch {
      setErrorMsg('সার্ভার যোগাযোগে ব্যর্থতা।');
    } finally {
      setIsLoading(false);
    }
  };

  // Leave Room
  const handleLeaveRoom = () => {
    sound.playClick();
    if (currentRoomId && myPlayerId) {
      handleRemovePlayer(myPlayerId);
    }
    setCurrentRoomId(null);
    setMyPlayerId(null);
    setRoomState(null);
  };

  // Copy Room Code
  const handleCopyCode = () => {
    if (!roomState?.code) return;
    sound.playClick();
    navigator.clipboard.writeText(roomState.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const isHost = roomState?.players.find((p) => p.id === myPlayerId)?.isHost;
  const myPlayer = roomState?.players.find((p) => p.id === myPlayerId);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#140b10] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-black">
      {/* Header */}
      <header className="border-b border-amber-500/20 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30 px-4 py-3 sm:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              if (currentRoomId) handleLeaveRoom();
              else onBackToPlatform();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-500 transition-all cursor-pointer text-xs sm:text-sm font-bengali"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{currentRoomId ? 'রুম ত্যাগ' : 'মূল পাতা'}</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-lg sm:text-xl font-black text-amber-400 font-bengali">
              চালবাজি
            </span>
            <span className="text-[10px] tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono font-bold uppercase">
              MULTIPLAYER
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onOpenRules();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-amber-300 hover:border-amber-400/50 hover:bg-slate-800 text-xs sm:text-sm font-bengali transition-all cursor-pointer shadow"
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-400" />
          <span>নিয়মাবলী</span>
        </button>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-6 sm:px-6 w-full flex-1 flex flex-col justify-center">
        {!currentRoomId ? (
          // ==========================================
          // 1. OUT-OF-ROOM: CREATE / JOIN / SOLO MODES
          // ==========================================
          <div className="space-y-6">
            <div className="text-center max-w-md mx-auto">
              <h1 className="text-2xl sm:text-3xl font-black text-amber-400 font-bengali">
                চালবাজি মাল্টিপ্লেয়ার লবি
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 font-bengali">
                অনলাইনে বন্ধুদের সাথে অথবা একাকী এআই-এর বিরুদ্ধে খেলুন
              </p>
            </div>

            {/* Navigation Tabs */}
            <div className="flex rounded-2xl bg-slate-900/90 p-1 border border-amber-500/30 max-w-md mx-auto">
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveTab('create');
                }}
                className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold font-bengali transition-all cursor-pointer ${
                  activeTab === 'create'
                    ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-lg shadow-amber-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                রুম তৈরি করুন
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveTab('join');
                }}
                className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold font-bengali transition-all cursor-pointer ${
                  activeTab === 'join'
                    ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-lg shadow-amber-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                রুমে যোগ দিন
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveTab('solo');
                }}
                className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold font-bengali transition-all cursor-pointer ${
                  activeTab === 'solo'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                একাকী (Solo)
              </button>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="max-w-md mx-auto p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs sm:text-sm font-bengali text-center">
                {errorMsg}
              </div>
            )}

            {/* Tab: CREATE ROOM */}
            {activeTab === 'create' && (
              <div className="max-w-md mx-auto p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-amber-500/40 shadow-xl space-y-4">
                <div>
                  <label className="block text-xs text-amber-300 font-bold font-bengali mb-1.5">
                    আপনার নাম
                  </label>
                  <input
                    type="text"
                    value={playerName}
                    onChange={(e) => handleNameChange(e.target.value)}
                    maxLength={16}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 text-white text-sm font-bengali outline-none"
                    placeholder="নাম লিখুন..."
                  />
                </div>

                <div>
                  <label className="block text-xs text-amber-300 font-bold font-bengali mb-1.5">
                    অবতার বেছে নিন
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {avatars.map((av) => (
                      <button
                        key={av}
                        onClick={() => handleAvatarChange(av)}
                        className={`p-2.5 rounded-xl text-xl transition-all cursor-pointer flex items-center justify-center ${
                          playerAvatar === av
                            ? 'bg-amber-500/20 border-2 border-amber-400 scale-105 shadow-md shadow-amber-500/20'
                            : 'bg-slate-950/60 border border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {av}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleCreateRoom}
                    disabled={isLoading}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-black font-black font-bengali text-sm shadow-xl shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4 text-black stroke-[3]" />
                    <span>{isLoading ? 'রুম তৈরি হচ্ছে...' : 'নতুন রুম তৈরি করুন'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Tab: JOIN ROOM */}
            {activeTab === 'join' && (
              <div className="max-w-md mx-auto p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-amber-500/40 shadow-xl space-y-4">
                <div>
                  <label className="block text-xs text-amber-300 font-bold font-bengali mb-1.5">
                    আপনার নাম
                  </label>
                  <input
                    type="text"
                    value={playerName}
                    onChange={(e) => handleNameChange(e.target.value)}
                    maxLength={16}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 text-white text-sm font-bengali outline-none"
                    placeholder="নাম লিখুন..."
                  />
                </div>

                <div>
                  <label className="block text-xs text-amber-300 font-bold font-bengali mb-1.5">
                    অবতার বেছে নিন
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {avatars.map((av) => (
                      <button
                        key={av}
                        onClick={() => handleAvatarChange(av)}
                        className={`p-2.5 rounded-xl text-xl transition-all cursor-pointer flex items-center justify-center ${
                          playerAvatar === av
                            ? 'bg-amber-500/20 border-2 border-amber-400 scale-105 shadow-md shadow-amber-500/20'
                            : 'bg-slate-950/60 border border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {av}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-amber-300 font-bold font-bengali mb-1.5">
                    রুম কোড (৬ অক্ষরের কোড)
                  </label>
                  <input
                    type="text"
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    maxLength={8}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 text-white text-center font-mono font-bold tracking-widest text-lg outline-none uppercase"
                    placeholder="CAL-XXX"
                  />
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleJoinRoom}
                    disabled={isLoading}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-black font-black font-bengali text-sm shadow-xl shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Users className="w-4 h-4 text-black stroke-[3]" />
                    <span>{isLoading ? 'রুমে প্রবেশ করা হচ্ছে...' : 'রুমে প্রবেশ করুন'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Tab: SOLO OFFLINE VS BOTS */}
            {activeTab === 'solo' && (
              <div className="max-w-md mx-auto p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-indigo-500/40 shadow-xl space-y-4 text-center">
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center mx-auto text-indigo-400">
                  <Bot className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-bold text-white font-bengali">একাকী ম্যাচ (Solo vs Bots)</h3>
                <p className="text-xs text-slate-300 font-bengali leading-relaxed">
                  ইন্টারনেট ছাড়াই ৩ জন কৃত্রিম বুদ্ধিমত্তা (AI) প্রতিপক্ষের বিরুদ্ধে খেলুন। আপনি নিজেই আপনার পছন্দের ৫টি চরিত্র নির্বাচন করতে পারবেন।
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => {
                      sound.playClick();
                      onStartSolo();
                    }}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-600 hover:from-indigo-400 hover:to-purple-500 text-white font-black font-bengali text-sm shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>সোলো খেলা শুরু করুন</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          // ==========================================
          // 2. IN-ROOM: WAITING LOBBY (Real Multiplayer)
          // ==========================================
          <div className="space-y-6 max-w-2xl mx-auto w-full">
            {/* Room Banner */}
            <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-900 border border-amber-500/50 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider font-mono">
                  ROOM CODE
                </span>
                <div className="text-2xl sm:text-3xl font-black font-mono tracking-widest text-amber-400 flex items-center gap-3">
                  <span>{roomState?.code}</span>
                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 transition-all cursor-pointer"
                    title="কোড কপি করুন"
                  >
                    {copiedCode ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4 text-amber-300" />
                    )}
                  </button>
                </div>
                {copiedCode && (
                  <span className="text-[11px] text-emerald-400 font-bengali block mt-0.5">
                    কোড কপি করা হয়েছে! বন্ধুদের দিন।
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3">
                <div className="px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs font-bengali text-slate-300 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span>
                    খেলোয়াড়: {roomState?.players.length || 1}/4
                  </span>
                </div>
                {isHost && (roomState?.players.length || 0) < 4 && (
                  <button
                    onClick={handleAddBot}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-300 hover:text-white text-xs font-bengali transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>বট যোগ করুন</span>
                  </button>
                )}
              </div>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs sm:text-sm font-bengali text-center">
                {errorMsg}
              </div>
            )}

            {/* Players Grid (Slots 1 to 4) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {[0, 1, 2, 3].map((slotIdx) => {
                const player = roomState?.players[slotIdx];
                if (player) {
                  const isMe = player.id === myPlayerId;
                  return (
                    <div
                      key={player.id}
                      className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${
                        isMe
                          ? 'bg-amber-950/40 border-amber-500/60 shadow-lg shadow-amber-500/10'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-2xl p-2 rounded-xl bg-slate-950 border border-slate-800">
                          {player.avatar}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-bold text-white font-bengali">
                              {player.name}
                            </span>
                            {player.isHost && (
                              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                            )}
                            {player.isBot && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
                                BOT
                              </span>
                            )}
                            {isMe && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bengali font-bold">
                                আপনি
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-400 font-bengali block">
                            সিট #{player.seatNumber + 1}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {player.isReady ? (
                          <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bengali font-bold">
                            <Check className="w-3.5 h-3.5" />
                            <span>প্রস্তুত</span>
                          </div>
                        ) : (
                          <div className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-400 text-xs font-bengali">
                            অপেক্ষারত
                          </div>
                        )}

                        {isHost && !isMe && (
                          <button
                            onClick={() => handleRemovePlayer(player.id)}
                            className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-800/40 transition-all cursor-pointer"
                            title="সরান"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                }

                // Empty Slot
                return (
                  <div
                    key={`empty_${slotIdx}`}
                    className="p-4 rounded-2xl border border-dashed border-slate-800/80 bg-slate-950/30 flex items-center justify-between text-slate-500"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-900/60 border border-dashed border-slate-800 flex items-center justify-center">
                        <Users className="w-4 h-4 text-slate-600" />
                      </div>
                      <div>
                        <span className="text-xs font-bengali block text-slate-500">
                          সিট #{slotIdx + 1} খালি
                        </span>
                        <span className="text-[10px] text-slate-600 font-bengali">
                          বন্ধুকে আমন্ত্রণ জানান
                        </span>
                      </div>
                    </div>

                    {isHost && (
                      <button
                        onClick={handleAddBot}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-all cursor-pointer font-bengali flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" />
                        <span>বট</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Selected Characters Indicator */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span className="text-xs text-slate-300 font-bengali font-bold">
                  খেলার চরিত্র (৫টি):
                </span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap justify-end">
                {(roomState?.selectedCharacters || []).map((cId) => (
                  <span
                    key={cId}
                    className="text-[11px] px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 font-bengali"
                  >
                    {ALL_CHARACTERS[cId]?.nameBn || cId}
                  </span>
                ))}
              </div>
            </div>

            {/* Controls */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              {!isHost && (
                <button
                  onClick={handleToggleReady}
                  className={`w-full sm:flex-1 py-3.5 rounded-2xl font-bold font-bengali text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    myPlayer?.isReady
                      ? 'bg-slate-800 text-slate-300 border border-slate-700'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/25'
                  }`}
                >
                  <UserCheck className="w-4 h-4" />
                  <span>{myPlayer?.isReady ? 'প্রস্তুত বাতিল' : 'আমি প্রস্তুত (Ready)'}</span>
                </button>
              )}

              {isHost ? (
                <button
                  onClick={handleStartGame}
                  disabled={isLoading || (roomState?.players.length || 0) < 2}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-black font-black font-bengali text-base shadow-xl shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-5 h-5 fill-black" />
                  <span>
                    {(roomState?.players.length || 0) < 2
                      ? 'কমপক্ষে ২ জন খেলোয়াড় প্রয়োজন'
                      : isLoading
                      ? 'খেলা শুরু হচ্ছে...'
                      : 'খেলা শুরু করুন (Start Match)'}
                  </span>
                </button>
              ) : (
                <div className="w-full text-center text-xs text-amber-300 font-bengali py-2 animate-pulse">
                  হোস্ট খেলা শুরু করার জন্য অপেক্ষা করা হচ্ছে...
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
