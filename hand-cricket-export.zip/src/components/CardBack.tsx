import React from 'react';

interface CardBackProps {
  className?: string;
  isDead?: boolean;
}

export const CardBack: React.FC<CardBackProps> = ({ className = '', isDead = false }) => {
  return (
    <div
      className={`relative w-full h-full rounded-2xl overflow-hidden shadow-2xl border-2 transition-all duration-300 select-none ${
        isDead
          ? 'border-red-950/80 grayscale opacity-40 bg-slate-950'
          : 'border-amber-500/80 shadow-amber-950/50'
      } ${className}`}
      style={{
        aspectRatio: '5/7',
        background: isDead
          ? 'radial-gradient(circle at 50% 50%, #1c1917 0%, #0c0a09 100%)'
          : 'radial-gradient(circle at 50% 40%, #1e1b4b 0%, #0f172a 65%, #020617 100%)',
      }}
    >
      {/* Intricate decorative border layers */}
      <div className="absolute inset-1.5 rounded-xl border border-amber-400/40 pointer-events-none" />
      <div className="absolute inset-2.5 rounded-lg border border-dashed border-amber-500/30 pointer-events-none" />

      {/* Geometric lattice background overlay */}
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, rgba(245, 158, 11, 0.4) 1px, transparent 0)`,
          backgroundSize: '16px 16px',
        }}
      />

      {/* Decorative corner motifs */}
      <div className="absolute top-2 left-2 text-amber-400/70 text-xs font-serif leading-none select-none">❖</div>
      <div className="absolute top-2 right-2 text-amber-400/70 text-xs font-serif leading-none select-none">❖</div>
      <div className="absolute bottom-2 left-2 text-amber-400/70 text-xs font-serif leading-none select-none">❖</div>
      <div className="absolute bottom-2 right-2 text-amber-400/70 text-xs font-serif leading-none select-none">❖</div>

      {/* Center Medallion: Official KHELGHOR Seal */}
      <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
        {/* Emblem outer ring */}
        <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-amber-400/70 bg-gradient-to-br from-indigo-900/60 via-purple-900/40 to-slate-950/80 flex items-center justify-center shadow-lg shadow-amber-950/50">
          <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full border border-amber-400/40 flex flex-col items-center justify-center bg-slate-950/60">
            {/* Khelghor Emblem Diamond / Crown Icon */}
            <svg
              className="w-6 h-6 sm:w-7 sm:h-7 text-amber-300 drop-shadow-[0_2px_4px_rgba(245,158,11,0.5)]"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.75"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polygon points="12 2 19 8.5 12 15 5 8.5 12 2" fill="currentColor" fillOpacity="0.25" />
              <polygon points="12 9 19 15.5 12 22 5 15.5 12 9" fill="currentColor" fillOpacity="0.15" />
              <circle cx="12" cy="12" r="2" fill="currentColor" />
            </svg>
          </div>
        </div>

        {/* KHELGHOR Bengali & English Identity */}
        <div className="mt-2.5 sm:mt-3 flex flex-col items-center">
          <span className="text-xs sm:text-sm font-black text-amber-300 tracking-wide block font-bengali drop-shadow-sm">
            {isDead ? 'মৃত কার্ড' : 'খেলাঘর'}
          </span>
          <span className="text-[8px] sm:text-[9px] text-amber-400/75 tracking-[0.25em] font-mono font-bold uppercase block mt-0.5">
            {isDead ? 'ELIMINATED' : 'KHELGHOR'}
          </span>
        </div>
      </div>
    </div>
  );
};

