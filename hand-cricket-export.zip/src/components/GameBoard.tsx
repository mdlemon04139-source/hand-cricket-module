import React, { useState, useEffect, useRef } from 'react';
import {
  ActionType,
  Card,
  CharacterDef,
  CharacterId,
  GameLogEntry,
  GameSettings,
  PendingAction,
  PendingBlock,
  PendingChallenge,
  Player,
  ReactionPhaseType,
} from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';
import { CardView } from './CardView';
import { CardBack } from './CardBack';
import { CardFlip } from './CardFlip';
import { CardModal } from './CardModal';
import { GuptochorInspectModal, JyotishiInspectModal } from './CardInspectModal';
import { NishachorBribeModal } from './NishachorBribeModal';
import { DiscardCardModal } from './DiscardCardModal';
import { TaxTokenSelectModal } from './TaxTokenSelectModal';
import { ActionTrajectory } from './ActionTrajectory';
import { AIEngine } from '../utils/ai';
import { sound } from '../utils/sound';
import confetti from 'canvas-confetti';
import {
  Coins,
  Heart,
  Shield,
  Swords,
  Clock,
  RotateCcw,
  Volume2,
  VolumeX,
  BookOpen,
  AlertTriangle,
  History,
  CheckCircle,
  Eye,
  Info,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight,
  Layers,
  ArrowLeft,
  RotateCw,
  Smartphone,
  Copy,
  Check,
} from 'lucide-react';
import { CalbajiClientView } from '../server/calbajiRoomManager';

export type GamePhase =
  | 'match_ready' // Players seated, 15 cards in center deck, hands empty
  | 'deck_shuffling' // Animate shuffling deck
  | 'dealing_cards' // Dealing 2 cards to each player one by one
  | 'turn_announcement' // Brief announcement banner of whose turn it is
  | 'action_declared' // Action announced, waiting for challenge/block
  | 'block_declared' // Block announced, waiting for challenge of block
  | 'resolving_challenge' // Challenge being checked & proven/caught
  | 'executing_action' // Action effect being applied (coins, life)
  | 'human_inspecting' // Human inspecting card via Guptochor/Jyotishi
  | 'game_over'; // Champion crowned

interface GameBoardProps {
  selectedCharacters: CharacterId[];
  settings: GameSettings;
  onOpenRules: () => void;
  onRestart: () => void;
  onBackToPlatform: () => void;
  roomId?: string;
  playerId?: string;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  selectedCharacters,
  settings: initialSettings,
  onOpenRules,
  onRestart,
  onBackToPlatform,
  roomId,
  playerId,
}) => {
  const isMultiplayer = Boolean(roomId && playerId);
  const [multiplayerRoomCode, setMultiplayerRoomCode] = useState<string | null>(null);
  const [multiplayerCopied, setMultiplayerCopied] = useState(false);
  const [settings, setSettings] = useState<GameSettings>(initialSettings);
  const [gamePhase, setGamePhase] = useState<GamePhase>('match_ready');

  // Full 15-card deck
  const [fullDeck, setFullDeck] = useState<Card[]>(() => {
    const list: Card[] = [];
    selectedCharacters.forEach((charId) => {
      for (let i = 0; i < 3; i++) {
        list.push({
          uid: `${charId}_${i}_${Math.random().toString(36).substring(2, 6)}`,
          characterId: charId,
          isRevealed: false,
        });
      }
    });
    // Initial shuffle
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }
    return list;
  });

  // Players initially with empty hands
  const [players, setPlayers] = useState<Player[]>([
    {
      id: 'p1',
      nameBn: 'আপনি',
      nameEn: 'You',
      isHuman: true,
      avatar: '👑',
      coins: 2,
      cards: [],
      isEliminated: false,
    },
    {
      id: 'ai_1',
      nameBn: 'জাফর খান',
      nameEn: 'Zafar Khan',
      isHuman: false,
      avatar: '🛡️',
      personality: 'cautious',
      coins: 2,
      cards: [],
      isEliminated: false,
    },
    {
      id: 'ai_2',
      nameBn: 'রশিদ খাঁ',
      nameEn: 'Rashid Khan',
      isHuman: false,
      avatar: '⚔️',
      personality: 'aggressive',
      coins: 2,
      cards: [],
      isEliminated: false,
    },
    {
      id: 'ai_3',
      nameBn: 'শাহজাদা মির্জা',
      nameEn: 'Shahzada Mirza',
      isHuman: false,
      avatar: '🧠',
      personality: 'strategic',
      coins: 2,
      cards: [],
      isEliminated: false,
    },
  ]);

  const [drawDeck, setDrawDeck] = useState<Card[]>([]);
  const [discardPile, setDiscardPile] = useState<Card[]>([]);
  const [bankCoins, setBankCoins] = useState<number>(50 - 8);
  const [currentTurnIndex, setCurrentTurnIndex] = useState<number>(0);
  const [turnCount, setTurnCount] = useState<number>(1);
  const [winner, setWinner] = useState<Player | null>(null);

  // Trajectory animation for attacks & spells
  const [activeTrajectory, setActiveTrajectory] = useState<{
    actorId: string;
    targetId: string;
    characterId: CharacterId;
  } | null>(null);

  // Dealing animation state: index of player currently receiving a card (0..3)
  const [dealingStep, setDealingStep] = useState<{ playerIndex: number; cardNum: number } | null>(null);
  const [isShuffleAnimated, setIsShuffleAnimated] = useState(false);

  // Action & Reaction State
  const [pendingAction, setPendingAction] = useState<PendingAction | null>(null);
  const [pendingBlock, setPendingBlock] = useState<PendingBlock | null>(null);

  // Shared 10-20 Second Response Window with individual skip tracking and staggered AI timings
  const [countdown, setCountdown] = useState<{
    secondsLeft: number;
    totalSeconds: number;
    titleBn: string;
    descriptionBn: string;
    eligiblePlayerIds: string[];
    respondersStatus: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'>;
    timeoutOutcomeBn: string;
    aiTargetSeconds?: Record<string, number>;
  } | null>(null);

  // Dynamic Reaction Window between 10-20 seconds (randomized each time: "ek ek somoy ek ek time e")
  const getRandomReactionSeconds = (): number => {
    return Math.floor(Math.random() * 11) + 10;
  };

  // Staggered AI response delays within the 10-20s reaction window
  const generateAIReplyTimings = (
    eligibleIds: string[],
    totalDuration: number
  ): Record<string, number> => {
    const timings: Record<string, number> = {};
    const aiIds = eligibleIds.filter((id) => id !== 'p1');
    aiIds.forEach((id, idx) => {
      // Natural staggered response time:
      // Minimum 2-3 seconds, maximum strictly within totalDuration - 2 seconds
      const minSec = 2 + idx;
      const maxSec = Math.max(minSec + 1, Math.min(totalDuration - 2, 5 + idx * 2));
      timings[id] = Math.floor(Math.random() * (maxSec - minSec + 1)) + minSec;
    });
    return timings;
  };

  const handleToggleRotate = async () => {
    sound.playClick();
    try {
      if (!document.fullscreenElement) {
        if (document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
        }
        if (screen.orientation && 'lock' in screen.orientation) {
          await (screen.orientation as any).lock('landscape').catch(() => {});
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        }
      }
    } catch {
      // browser orientation fallback
    }
  };

  const handleHumanChallenge = () => {
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setCountdown(null);

    if (isMultiplayer && roomId && playerId) {
      sound.playChallenge();
      fetch(`/api/calbaji/rooms/${roomId}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          responderId: playerId,
          response: 'challenge',
        }),
      });
      return;
    }

    if (pendingBlock) {
      resolveChallenge({
        challengerId: 'p1',
        challengedPlayerId: pendingBlock.blockerId,
        claimedCharacter: pendingBlock.claimedCharacter,
        isBlockChallenge: true,
      });
    } else if (pendingAction && pendingAction.claimedCharacter) {
      resolveChallenge({
        challengerId: 'p1',
        challengedPlayerId: pendingAction.actorId,
        claimedCharacter: pendingAction.claimedCharacter,
        isBlockChallenge: false,
      });
    }
  };

  const handleHumanSkip = () => {
    sound.playClick();

    if (isMultiplayer && roomId && playerId) {
      fetch(`/api/calbaji/rooms/${roomId}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          responderId: playerId,
          response: 'skip',
        }),
      });
      return;
    }

    setCountdown((prev) => {
      if (!prev) return null;
      const nextStatuses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'> = {
        ...prev.respondersStatus,
        p1: 'skipped',
      };
      const allSkipped = prev.eligiblePlayerIds.every(
        (id) => nextStatuses[id] === 'skipped'
      );
      if (allSkipped) {
        if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        if (gamePhase === 'action_declared' && pendingAction) {
          executeActionEffect(pendingAction);
        } else if (gamePhase === 'block_declared') {
          advanceTurn();
        }
        return null;
      }
      return {
        ...prev,
        respondersStatus: nextStatuses,
      };
    });
  };

  const handleHumanBlock = () => {
    if (!pendingAction) return;
    sound.playChallenge();

    if (isMultiplayer && roomId && playerId) {
      fetch(`/api/calbaji/rooms/${roomId}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          responderId: playerId,
          response: 'block',
          claimedBlockCharacter: 'dosyu_sordar',
        }),
      });
      return;
    }

    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setPendingBlock({
      blockerId: 'p1',
      claimedCharacter: 'dosyu_sordar',
    });
    setGamePhase('block_declared');
    const blockDuration = getRandomReactionSeconds();
    const blockEligible = players
      .filter((p) => !p.isEliminated && p.id !== 'p1')
      .map((p) => p.id);
    const blockStatuses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'> = {};
    blockEligible.forEach((id) => {
      blockStatuses[id] = 'pending';
    });
    const blockTimings = generateAIReplyTimings(blockEligible, blockDuration);
    setCountdown({
      secondsLeft: blockDuration,
      totalSeconds: blockDuration,
      titleBn: `ব্লক যাচাই সময় — ${blockDuration} সেকেন্ড`,
      descriptionBn: 'আপনি দস্যু সর্দার দাবি করে ডাকাতি আটকেছেন। কেউ কি আপনার ব্লককে চ্যালেঞ্জ করতে চায়?',
      eligiblePlayerIds: blockEligible,
      respondersStatus: blockStatuses,
      timeoutOutcomeBn: 'সময় শেষ হলে বা সবাই এড়িয়ে গেলে ডাকাতি বাতিল হবে।',
      aiTargetSeconds: blockTimings,
    });
  };

  const [showAudioSettings, setShowAudioSettings] = useState(false);
  const [musicVolume, setMusicVolume] = useState<number>(() => sound.getMusicVolume());
  const [sfxVolume, setSfxVolume] = useState<number>(() => sound.getSfxVolume());

  // Ensure any character preview theme stops immediately when match begins
  useEffect(() => {
    sound.stopCharacterTheme();
    return () => {
      sound.stopCharacterTheme();
    };
  }, []);

  // ==========================================
  // MULTIPLAYER ROOM REAL-TIME SYNCHRONIZATION
  // ==========================================
  useEffect(() => {
    if (!roomId || !playerId) return;

    let isMounted = true;
    let sse: EventSource | null = null;

    const handleRoomUpdate = (data: CalbajiClientView) => {
      if (!isMounted) return;
      setMultiplayerRoomCode(data.code);

      // Map players
      const mappedPlayers: Player[] = data.players.map((p) => {
        const isMe = p.id === playerId;
        // For opponent and bot hands, build placeholder unrevealed cards so cards in hand are visually rendered
        const hiddenCards: Card[] = Array.from({ length: p.cardCount }).map((_, idx) => ({
          uid: `unrevealed_${p.id}_${idx}`,
          characterId: 'unknown' as any,
          isRevealed: false,
        }));

        return {
          id: p.id,
          nameBn: p.name,
          nameEn: p.name,
          isHuman: isMe,
          isOnline: p.isOnline !== false,
          avatar: p.avatar,
          coins: p.coins,
          cards: isMe ? data.myCards : [...hiddenCards, ...(p.revealedCards || [])],
          isEliminated: p.isEliminated,
        };
      });
      setPlayers(mappedPlayers);

      // Turn progress
      const turnIdx = data.players.findIndex((p) => p.id === data.currentTurnPlayerId);
      if (turnIdx !== -1) {
        setCurrentTurnIndex(turnIdx);
      }
      setTurnCount(data.turnCount);
      setBankCoins(data.bankCoins);

      if (data.discardPile) {
        setDiscardPile(data.discardPile);
      }
      if (data.activeTaxToken) {
        setActiveTaxToken({
          characterId: data.activeTaxToken.characterId,
          placedBy: data.activeTaxToken.placedBy,
        });
      }

      // Sync Phase
      if (data.phase === 'MATCH_STARTING') {
        setGamePhase('dealing_cards');
      } else if (data.phase === 'ACTION_DECLARED') {
        setGamePhase('action_declared');
      } else if (data.phase === 'BLOCK_DECLARED') {
        setGamePhase('block_declared');
      } else if (data.phase === 'MATCH_OVER') {
        setGamePhase('game_over');
      }

      // Reaction Countdown
      if (data.reaction) {
        const secsLeft = Math.max(0, Math.ceil((data.reaction.deadline - Date.now()) / 1000));
        const eligible = Object.keys(data.reaction.responses);
        const charDef = data.reaction.claimedCharacter
          ? ALL_CHARACTERS[data.reaction.claimedCharacter]
          : null;

        setCountdown({
          secondsLeft: secsLeft,
          totalSeconds: data.reaction.totalDuration,
          titleBn: data.reaction.isBlock ? 'ব্লক প্রতিক্রিয়া' : 'একশন প্রতিক্রিয়া',
          descriptionBn: `${charDef?.nameBn || 'একশন'} ঘোষণা করা হয়েছে।`,
          eligiblePlayerIds: eligible,
          respondersStatus: data.reaction.responses,
          timeoutOutcomeBn: 'চাল কার্যকর হবে',
        });
        setPendingAction(data.pendingAction || null);
        setPendingBlock(data.pendingBlock || null);
      } else {
        setCountdown(null);
        setPendingAction(null);
        setPendingBlock(null);
      }

      // Discard choice for human player
      if (data.discardPendingPlayerId === playerId) {
        setDiscardModalData({
          playerId,
          reasonBn: 'জীবন হারিয়েছেন! একটি কার্ড খারিজ করুন।',
          callback: () => {},
        });
      } else if (!data.discardPendingPlayerId) {
        setDiscardModalData(null);
      }

      // Game Logs
      if (data.gameLogs && data.gameLogs.length > 0) {
        setGameLogs(data.gameLogs);
      }

      // Winner
      if (data.winner) {
        const winPlayer: Player = {
          id: data.winner.id,
          nameBn: data.winner.name,
          nameEn: data.winner.name,
          isHuman: data.winner.id === playerId,
          avatar: data.winner.avatar,
          coins: 0,
          cards: [],
          isEliminated: false,
        };
        setWinner(winPlayer);
        setGamePhase('game_over');
        if (data.winner.id === playerId) {
          sound.playVictory();
        }
      }
    };

    // 1. Initial State Fetch
    fetch(`/api/calbaji/rooms/${roomId}/state?playerId=${playerId}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && isMounted) handleRoomUpdate(data);
      })
      .catch(() => {});

    // 2. SSE Subscription
    try {
      sse = new EventSource(`/api/calbaji/rooms/${roomId}/events?playerId=${playerId}`);
      sse.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          handleRoomUpdate(data);
        } catch {}
      };
    } catch {}

    // 3. Fallback Polling
    const poller = setInterval(() => {
      fetch(`/api/calbaji/rooms/${roomId}/state?playerId=${playerId}`)
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (data && isMounted) handleRoomUpdate(data);
        })
        .catch(() => {});
    }, 1500);

    return () => {
      isMounted = false;
      if (sse) sse.close();
      clearInterval(poller);
    };
  }, [roomId, playerId]);

  // Active Tax Token
  const [activeTaxToken, setActiveTaxToken] = useState<{
    characterId: CharacterId;
    placedBy: string;
  } | null>(null);

  // Modals
  const [inspectCharacter, setInspectCharacter] = useState<CharacterDef | null>(null);
  const [showLogDrawer, setShowLogDrawer] = useState<boolean>(false);
  const [selectedActionForTarget, setSelectedActionForTarget] = useState<ActionType | null>(null);
  const [guptochorDrawnCard, setGuptochorDrawnCard] = useState<Card | null>(null);
  const [jyotishiDrawnCards, setJyotishiDrawnCards] = useState<Card[]>([]);
  const [showTaxTokenPicker, setShowTaxTokenPicker] = useState<boolean>(false);
  const [showNishachorBribe, setShowNishachorBribe] = useState<boolean>(false);
  const [discardModalData, setDiscardModalData] = useState<{
    playerId: string;
    reasonBn: string;
    callback: () => void;
  } | null>(null);

  // Logs
  const [gameLogs, setGameLogs] = useState<GameLogEntry[]>([
    {
      id: 'init_start',
      timestamp: Date.now(),
      turnNumber: 1,
      textBn: '১৫টি কার্ডের রাজকীয় ডেক টেবিলের কেন্দ্রে প্রস্তুত। খেলা শুরু করতে কার্ড শুফেল ও বিতরণ করুন।',
      textEn: '15-card Royal deck is ready in center. Shuffle & Deal to begin match.',
      type: 'system',
    },
  ]);

  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const logContainerRef = useRef<HTMLDivElement | null>(null);

  const addLog = (
    textBn: string,
    textEn: string,
    type: GameLogEntry['type'] = 'action',
    actorId?: string,
    targetId?: string,
    cardImage?: string
  ) => {
    const entry: GameLogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      turnNumber: turnCount,
      textBn,
      textEn,
      type,
      actorId,
      targetId,
      cardImage,
    };
    setGameLogs((prev) => [entry, ...prev]);
  };

  const activePlayer = players[currentTurnIndex] || players[0];
  const humanPlayer = players.find((p) => p.isHuman) || players[0];
  const opponents = players.filter((p) => p.id !== humanPlayer?.id);
  const isMyTurn = activePlayer?.id === humanPlayer?.id;

  // ==========================================
  // SHUFFLE & DEAL ANIMATION FLOW
  // ==========================================
  const startShuffleAndDeal = () => {
    if (gamePhase !== 'match_ready') return;
    sound.playCardDeal();
    setGamePhase('deck_shuffling');
    setIsShuffleAnimated(true);

    addLog(
      'রাজকীয় ডেক শুফেল করা হচ্ছে...',
      'Shuffling the royal deck...',
      'system'
    );

    // Shuffle visual duration
    setTimeout(() => {
      setIsShuffleAnimated(false);
      setGamePhase('dealing_cards');

      // Deal 2 cards to each of the 4 players sequentially
      // 8 cards total dealt one by one
      const deckCopy = [...fullDeck];
      // Real shuffle
      for (let i = deckCopy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deckCopy[i], deckCopy[j]] = [deckCopy[j], deckCopy[i]];
      }

      const pCards: Card[][] = [[], [], [], []];
      let stepIndex = 0;
      const totalSteps = 8; // 4 players * 2 rounds

      const dealInterval = setInterval(() => {
        if (stepIndex >= totalSteps) {
          clearInterval(dealInterval);
          setDealingStep(null);

          // Finalize dealing into players state
          setPlayers((prev) =>
            prev.map((p, idx) => ({
              ...p,
              cards: pCards[idx],
            }))
          );
          setDrawDeck(deckCopy); // remaining 7 cards in draw deck

          addLog(
            'সকল খেলোয়াড়কে ২টি করে গোপন কার্ড ও ২টি মুদ্রা বিতরণ সম্পন্ন হয়েছে।',
            'Dealt 2 secret cards and 2 coins to each player.',
            'system'
          );

          // Transition to first turn
          setTimeout(() => {
            setGamePhase('turn_announcement');
            setTimeout(() => {
              setGamePhase('action_declared'); // ready for action selection
            }, 1200);
          }, 600);

          return;
        }

        const playerIdx = stepIndex % 4;
        const cardNum = Math.floor(stepIndex / 4) + 1;
        const dealtCard = deckCopy.pop()!;
        pCards[playerIdx].push(dealtCard);

        sound.playCardDeal();
        setDealingStep({ playerIndex: playerIdx, cardNum });

        // Update active player's cards visually
        setPlayers((prev) =>
          prev.map((p, idx) =>
            idx === playerIdx
              ? { ...p, cards: [...pCards[playerIdx]] }
              : p
          )
        );

        stepIndex++;
      }, 350);
    }, 1400);
  };

  // ==========================================
  // TURN PASSING & ELIMINATION (Strictly Clockwise)
  // ==========================================
  const advanceTurn = () => {
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setCountdown(null);
    setPendingAction(null);
    setPendingBlock(null);
    setSelectedActionForTarget(null);

    setPlayers((prev) => {
      const living = prev.filter((p) => !p.isEliminated);
      if (living.length <= 1) {
        setGamePhase('game_over');
        const champion = living[0] || null;
        setWinner(champion);
        if (champion?.isHuman) {
          sound.playVictory();
          confetti({ particleCount: 140, spread: 90, origin: { y: 0.6 } });
        }
        return prev;
      }

      // Strictly deterministic clockwise progression: (currIndex + 1) % 4
      setCurrentTurnIndex((currIndex) => {
        let nextIndex = (currIndex + 1) % prev.length;
        let checked = 0;
        while (prev[nextIndex].isEliminated && checked < prev.length) {
          nextIndex = (nextIndex + 1) % prev.length;
          checked++;
        }
        return nextIndex;
      });

      setTurnCount((c) => c + 1);

      setGamePhase('turn_announcement');
      setTimeout(() => {
        setGamePhase('action_declared');
      }, 1000);

      return prev;
    });
  };

  // Life Loss Handler
  const handlePlayerLoseLife = (
    playerId: string,
    reasonBn: string,
    onAfterDiscard?: () => void
  ) => {
    const player = players.find((p) => p.id === playerId);
    if (!player || player.isEliminated) {
      onAfterDiscard?.();
      return;
    }

    sound.playLifeLost();

    if (player.isHuman) {
      setDiscardModalData({
        playerId,
        reasonBn,
        callback: () => {
          setDiscardModalData(null);
          onAfterDiscard?.();
        },
      });
    } else {
      const cardToDiscard = AIEngine.pickCardToDiscard(player);
      discardCardFromPlayer(playerId, cardToDiscard.uid);
      addLog(
        `${player.nameBn} ১টি জীবন হারালেন এবং [${ALL_CHARACTERS[cardToDiscard.characterId].nameBn}] কার্ড খারিজ করলেন।`,
        `${player.nameEn} lost 1 life and discarded [${ALL_CHARACTERS[cardToDiscard.characterId].nameEn}].`,
        'elimination',
        player.id,
        undefined,
        ALL_CHARACTERS[cardToDiscard.characterId].image
      );
      onAfterDiscard?.();
    }
  };

  const discardCardFromPlayer = (pId: string, cardUid: string) => {
    if (isMultiplayer && roomId && playerId) {
      fetch(`/api/calbaji/rooms/${roomId}/discard`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerId: pId,
          cardUid,
        }),
      });
    }

    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id !== pId) return p;
        const newCards = p.cards.map((c) =>
          c.uid === cardUid ? { ...c, isRevealed: true } : c
        );
        const aliveCards = newCards.filter((c) => !c.isRevealed);
        const eliminated = aliveCards.length === 0;

        if (eliminated) {
          addLog(
            `💀 ${p.nameBn} খেলা থেকে নির্মূল (Eliminated) হয়ে গেছেন!`,
            `💀 ${p.nameEn} has been eliminated!`,
            'elimination'
          );
        }

        return {
          ...p,
          cards: newCards,
          isEliminated: eliminated,
        };
      })
    );

    const cardObj = players.flatMap((p) => p.cards).find((c) => c.uid === cardUid);
    if (cardObj) {
      setDiscardPile((prev) => [...prev, { ...cardObj, isRevealed: true }]);
    }
  };

  const replaceClaimantCard = (claimantId: string, charId: CharacterId) => {
    setPlayers((prevPlayers) => {
      const claimant = prevPlayers.find((p) => p.id === claimantId);
      if (!claimant) return prevPlayers;

      const cardIndex = claimant.cards.findIndex(
        (c) => !c.isRevealed && c.characterId === charId
      );
      if (cardIndex === -1) return prevPlayers;

      const cardToShuffleBack = claimant.cards[cardIndex];

      setDrawDeck((prevDeck) => {
        const deckWithReturned = [...prevDeck, cardToShuffleBack];
        for (let i = deckWithReturned.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [deckWithReturned[i], deckWithReturned[j]] = [
            deckWithReturned[j],
            deckWithReturned[i],
          ];
        }
        const newDrawn = deckWithReturned.pop();
        if (!newDrawn) return deckWithReturned;

        setPlayers((curr) =>
          curr.map((p) => {
            if (p.id !== claimantId) return p;
            const updatedHand = [...p.cards];
            updatedHand[cardIndex] = newDrawn;
            return { ...p, cards: updatedHand };
          })
        );

        return deckWithReturned;
      });

      return prevPlayers;
    });
  };

  // ==========================================
  // ACTION EXECUTION LOGIC
  // ==========================================
  const executeActionEffect = (action: PendingAction) => {
    setGamePhase('executing_action');
    const actor = players.find((p) => p.id === action.actorId);
    if (!actor || actor.isEliminated) {
      advanceTurn();
      return;
    }

    // If targeted action, animate trajectory before applying effect
    if (action.targetId) {
      const charId: CharacterId =
        action.claimedCharacter ||
        (action.actionType === 'coup' ? 'guptoghatok' : 'dosyu_sordar');
      setActiveTrajectory({
        actorId: action.actorId,
        targetId: action.targetId,
        characterId: charId,
      });
      sound.playCharacterAction(charId);

      setTimeout(() => {
        setActiveTrajectory(null);
        applyActionLogic(action);
      }, 1050);
      return;
    }

    // Play action audio for untargeted actions
    if (action.claimedCharacter) {
      sound.playCharacterAction(action.claimedCharacter);
    }
    applyActionLogic(action);
  };

  const applyActionLogic = (action: PendingAction) => {
    const actor = players.find((p) => p.id === action.actorId);
    if (!actor || actor.isEliminated) {
      advanceTurn();
      return;
    }

    let cost = 0;
    if (action.actionType === 'coup') cost = 7;
    else if (action.actionType === 'assassinate') cost = 3;
    else if (action.actionType === 'nishachor_strike') cost = 5;

    let taxDeducted = 0;
    if (
      activeTaxToken &&
      action.claimedCharacter &&
      activeTaxToken.characterId === action.claimedCharacter
    ) {
      taxDeducted = 1;
      addLog(
        `🏛️ ট্যাক্স টোকেনের জন্য ${actor.nameBn} কে ১টি মুদ্রা কর দিতে হলো।`,
        `🏛️ ${actor.nameEn} paid 1 coin tax for using taxed character.`,
        'action'
      );
    }

    switch (action.actionType) {
      case 'income': {
        sound.playCoin();
        setPlayers((prev) =>
          prev.map((p) => (p.id === actor.id ? { ...p, coins: p.coins + 1 } : p))
        );
        setBankCoins((b) => Math.max(0, b - 1));
        addLog(
          `${actor.nameBn} রাজস্ব গ্রহণ করে ১টি মুদ্রা নিলেন।`,
          `${actor.nameEn} took 1 coin as Income.`,
          'action'
        );
        setTimeout(advanceTurn, 1000);
        break;
      }

      case 'coup': {
        sound.playLifeLost();
        setPlayers((prev) =>
          prev.map((p) => (p.id === actor.id ? { ...p, coins: p.coins - 7 } : p))
        );
        setBankCoins((b) => b + 7);
        const target = players.find((p) => p.id === action.targetId);
        addLog(
          `⚔️ ${actor.nameBn} ৭টি মুদ্রা দিয়ে ${target?.nameBn}-এর বিরুদ্ধে সুপ্রিম নিধন (Coup) জারি করলেন!`,
          `⚔️ ${actor.nameEn} launched a Coup against ${target?.nameEn}!`,
          'action'
        );
        if (target) {
          handlePlayerLoseLife(target.id, 'সুপ্রিম নিধনে লক্ষ্যবস্তু হয়েছেন!', () => {
            setTimeout(advanceTurn, 1000);
          });
        } else {
          advanceTurn();
        }
        break;
      }

      case 'nawab_tax': {
        sound.playCoin();
        const gain = 3 - taxDeducted;
        setPlayers((prev) =>
          prev.map((p) =>
            p.id === actor.id ? { ...p, coins: p.coins + gain } : p
          )
        );
        setBankCoins((b) => Math.max(0, b - gain));
        addLog(
          `👑 ${actor.nameBn} নবাব দাবি করে ব্যাংক থেকে ${gain}টি মুদ্রা নিলেন।`,
          `👑 ${actor.nameEn} claimed Nawab and took ${gain} coins.`,
          'action',
          actor.id,
          undefined,
          ALL_CHARACTERS.nawab.image
        );
        setTimeout(advanceTurn, 1000);
        break;
      }

      case 'sodagor_trade': {
        sound.playCoin();
        const gain = 4 - taxDeducted;
        setPlayers((prev) =>
          prev.map((p) =>
            p.id === actor.id ? { ...p, coins: p.coins + gain } : p
          )
        );
        setBankCoins((b) => Math.max(0, b - gain));
        addLog(
          `⛵ ${actor.nameBn} সদাগর দাবি করে ৪টি মুদ্রা বাণিজ্য লাভ করলেন।`,
          `⛵ ${actor.nameEn} claimed Sodagor and gained ${gain} coins.`,
          'action',
          actor.id,
          undefined,
          ALL_CHARACTERS.sodagor.image
        );
        setTimeout(advanceTurn, 1000);
        break;
      }

      case 'assassinate': {
        sound.playLifeLost();
        const totalPaid = cost + taxDeducted;
        setPlayers((prev) =>
          prev.map((p) =>
            p.id === actor.id ? { ...p, coins: Math.max(0, p.coins - totalPaid) } : p
          )
        );
        setBankCoins((b) => b + totalPaid);
        const target = players.find((p) => p.id === action.targetId);
        addLog(
          `🗡️ ${actor.nameBn} গুপ্তঘাতক দিয়ে ${target?.nameBn}-কে হত্যা করলেন!`,
          `🗡️ ${actor.nameEn} assassinated ${target?.nameEn}!`,
          'action',
          actor.id,
          target?.id,
          ALL_CHARACTERS.guptoghatok.image
        );
        if (target) {
          handlePlayerLoseLife(target.id, 'গুপ্তঘাতকের আঘাতে জীবন হারিয়েছেন!', () => {
            setTimeout(advanceTurn, 1000);
          });
        } else {
          advanceTurn();
        }
        break;
      }

      case 'nishachor_strike': {
        sound.playLifeLost();
        const totalPaid = cost + taxDeducted;
        setPlayers((prev) =>
          prev.map((p) =>
            p.id === actor.id ? { ...p, coins: Math.max(0, p.coins - totalPaid) } : p
          )
        );
        setBankCoins((b) => b + totalPaid);
        const target = players.find((p) => p.id === action.targetId);
        addLog(
          `👹 ${actor.nameBn} নিশাচরের হামলায় ${target?.nameBn}-এর ১টি জীবন কেড়ে নিলেন!`,
          `👹 ${actor.nameEn}'s Nishachor strike eliminated a life from ${target?.nameEn}!`,
          'action',
          actor.id,
          target?.id,
          ALL_CHARACTERS.nishachor.image
        );
        if (target) {
          handlePlayerLoseLife(target.id, 'নিশাচরের হামলায় জীবন হারিয়েছেন!', () => {
            setTimeout(advanceTurn, 1000);
          });
        } else {
          advanceTurn();
        }
        break;
      }

      case 'dosyu_steal': {
        sound.playCoin();
        const target = players.find((p) => p.id === action.targetId);
        if (target && target.coins > 0) {
          const stolen = Math.min(2, target.coins);
          const finalGain = stolen - taxDeducted;
          setPlayers((prev) =>
            prev.map((p) => {
              if (p.id === target.id) return { ...p, coins: p.coins - stolen };
              if (p.id === actor.id) return { ...p, coins: p.coins + finalGain };
              return p;
            })
          );
          addLog(
            `💰 ${actor.nameBn} দস্যু সর্দার দাবি করে ${target.nameBn}-এর কাছ থেকে ${stolen}টি মুদ্রা ছিনতাই করলেন!`,
            `💰 ${actor.nameEn} claimed Dosyu Sordar and stole ${stolen} coins from ${target.nameEn}.`,
            'action',
            actor.id,
            target.id,
            ALL_CHARACTERS.dosyu_sordar.image
          );
        }
        setTimeout(advanceTurn, 1000);
        break;
      }

      case 'sidhel_raid': {
        sound.playCoin();
        let totalStolen = 0;
        setPlayers((prev) => {
          const updated = prev.map((p) => {
            if (p.id !== actor.id && !p.isEliminated && p.coins > 0) {
              totalStolen += 1;
              return { ...p, coins: p.coins - 1 };
            }
            return p;
          });
          return updated.map((p) =>
            p.id === actor.id
              ? { ...p, coins: p.coins + totalStolen - taxDeducted }
              : p
          );
        });
        addLog(
          `🌙 ${actor.nameBn} সিঁধেল চোর দাবি করে টেবিলের সবার কাছ থেকে ১টি করে মুদ্রা চুরি করলেন!`,
          `🌙 ${actor.nameEn} claimed Sidhel Chor and stole 1 coin from each player.`,
          'action',
          actor.id,
          undefined,
          ALL_CHARACTERS.sidhel_chor.image
        );
        setTimeout(advanceTurn, 1000);
        break;
      }

      case 'guptochor_spy': {
        sound.playCardDeal();
        if (actor.isHuman) {
          if (drawDeck.length > 0) {
            const inspectCard = drawDeck[drawDeck.length - 1];
            setGuptochorDrawnCard(inspectCard);
            setGamePhase('human_inspecting');
          } else {
            advanceTurn();
          }
        } else {
          if (drawDeck.length > 0) {
            const topCard = drawDeck[drawDeck.length - 1];
            const duplicateHand = actor.cards.some(
              (c) => !c.isRevealed && c.characterId === topCard.characterId
            );
            if (!duplicateHand && Math.random() < 0.6) {
              setDrawDeck((prevDeck) => {
                const newDeck = [...prevDeck];
                const drawn = newDeck.pop()!;
                const activeCardIdx = actor.cards.findIndex((c) => !c.isRevealed);
                if (activeCardIdx !== -1) {
                  const oldCard = actor.cards[activeCardIdx];
                  newDeck.push(oldCard);
                  setPlayers((prev) =>
                    prev.map((p) => {
                      if (p.id !== actor.id) return p;
                      const hand = [...p.cards];
                      hand[activeCardIdx] = drawn;
                      return { ...p, cards: hand };
                    })
                  );
                }
                return newDeck;
              });
            }
          }
          addLog(
            `🦅 ${actor.nameBn} গুপ্তচর দাবি করে ডেক থেকে ১টি কার্ড গোপনে পরিদর্শন করলেন।`,
            `🦅 ${actor.nameEn} claimed Guptochor and inspected 1 card.`,
            'exchange',
            actor.id,
            undefined,
            ALL_CHARACTERS.guptochor.image
          );
          setTimeout(advanceTurn, 1000);
        }
        break;
      }

      case 'jyotishi_divine': {
        sound.playCardDeal();
        if (actor.isHuman) {
          if (drawDeck.length >= 2) {
            const drawn = [drawDeck[drawDeck.length - 1], drawDeck[drawDeck.length - 2]];
            setJyotishiDrawnCards(drawn);
            setGamePhase('human_inspecting');
          } else {
            advanceTurn();
          }
        } else {
          addLog(
            `🔮 ${actor.nameBn} জ্যোতিষী দাবি করে ডেক থেকে ২টি কার্ড গোপনে দেখে সাজালেন।`,
            `🔮 ${actor.nameEn} claimed Jyotishi and inspected 2 cards.`,
            'exchange',
            actor.id,
            undefined,
            ALL_CHARACTERS.jyotishi.image
          );
          setTimeout(advanceTurn, 1000);
        }
        break;
      }

      case 'khajnadar_tax': {
        sound.playCoin();
        if (actor.isHuman) {
          setShowTaxTokenPicker(true);
        } else {
          const chosenTarget = AIEngine.pickTaxTokenTarget(
            selectedCharacters,
            activeTaxToken?.characterId
          );
          setActiveTaxToken({ characterId: chosenTarget, placedBy: actor.nameBn });
          addLog(
            `⚖️ ${actor.nameBn} খাজনাদার দাবি করে [${ALL_CHARACTERS[chosenTarget].nameBn}]-এর ওপর ট্যাক্স টোকেন বসালেন!`,
            `⚖️ ${actor.nameEn} placed Tax Token on [${ALL_CHARACTERS[chosenTarget].nameEn}].`,
            'action',
            actor.id,
            undefined,
            ALL_CHARACTERS.khajnadar.image
          );
          setTimeout(advanceTurn, 1000);
        }
        break;
      }

      default:
        advanceTurn();
    }
  };

  // ==========================================
  // CHALLENGE RESOLUTION
  // ==========================================
  const resolveChallenge = (challenge: PendingChallenge) => {
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setCountdown(null);
    setGamePhase('resolving_challenge');
    sound.playChallenge();

    const challenger = players.find((p) => p.id === challenge.challengerId);
    const challenged = players.find((p) => p.id === challenge.challengedPlayerId);

    if (!challenger || !challenged) {
      advanceTurn();
      return;
    }

    const hasCard = challenged.cards.some(
      (c) => !c.isRevealed && c.characterId === challenge.claimedCharacter
    );
    const charDef = ALL_CHARACTERS[challenge.claimedCharacter];

    setTimeout(() => {
      if (hasCard) {
        sound.playProofSuccess();
        addLog(
          `✨ চ্যালেঞ্জ ব্যর্থ! ${challenged.nameBn} আসল [${charDef.nameBn}] কার্ড টেবিলে দেখিয়ে প্রমাণ দিলেন!`,
          `✨ Challenge failed! ${challenged.nameEn} proved holding [${charDef.nameEn}]!`,
          'challenge',
          challenged.id,
          challenger.id,
          charDef.image
        );
        addLog(
          `💥 মিথ্যা অপবাদ দেওয়ায় ${challenger.nameBn} ১টি জীবন হারালেন!`,
          `💥 ${challenger.nameEn} lost 1 life for false accusation!`,
          'elimination'
        );

        replaceClaimantCard(challenged.id, challenge.claimedCharacter);

        handlePlayerLoseLife(challenger.id, 'চ্যালেঞ্জ ব্যর্থ হওয়ায় জীবন হারিয়েছেন!', () => {
          if (!challenge.isBlockChallenge) {
            if (pendingAction) executeActionEffect(pendingAction);
            else advanceTurn();
          } else {
            addLog(
              `🛡️ ব্লক সফল হয়েছে! একশন বাতিল হলো।`,
              'Block succeeded! Action was prevented.',
              'block'
            );
            setTimeout(advanceTurn, 1000);
          }
        });
      } else {
        sound.playBluffCaught();
        addLog(
          `🚨 ধরা পড়েছে! ${challenged.nameBn}-এর কাছে কোনো [${charDef.nameBn}] ছিল না! চালবাজি ফাঁস!`,
          `🚨 Bluff exposed! ${challenged.nameEn} did NOT hold [${charDef.nameEn}]!`,
          'challenge',
          challenged.id,
          challenger.id,
          charDef.image
        );
        addLog(
          `💥 চালবাজি ধরা পড়ায় ${challenged.nameBn} ১টি জীবন হারালেন এবং একশন বাতিল হলো।`,
          `💥 ${challenged.nameEn} lost 1 life and action cancelled.`,
          'elimination'
        );

        handlePlayerLoseLife(challenged.id, 'চালবাজি ফাঁস হওয়ায় জীবন হারিয়েছেন!', () => {
          if (challenge.isBlockChallenge) {
            if (pendingAction) executeActionEffect(pendingAction);
            else advanceTurn();
          } else {
            setTimeout(advanceTurn, 1000);
          }
        });
      }
    }, 1200);
  };

  // ==========================================
  // ACTION INITIATION & COUNTDOWN EXPLANATIONS
  // ==========================================
  const initiateAction = (actionType: ActionType, targetId?: string) => {
    const actor = activePlayer;
    if (!actor) return;

    sound.playClick();
    setSelectedActionForTarget(null);

    const charMap: Partial<Record<ActionType, CharacterId>> = {
      nawab_tax: 'nawab',
      sodagor_trade: 'sodagor',
      assassinate: 'guptoghatok',
      nishachor_strike: 'nishachor',
      guptochor_spy: 'guptochor',
      jyotishi_divine: 'jyotishi',
      dosyu_steal: 'dosyu_sordar',
      sidhel_raid: 'sidhel_chor',
      khajnadar_tax: 'khajnadar',
    };

    const claimedChar = charMap[actionType];

    if (isMultiplayer && roomId && playerId) {
      sound.playClick();
      fetch(`/api/calbaji/rooms/${roomId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          actorId: playerId,
          actionType,
          claimedCharacter: claimedChar,
          targetId,
        }),
      });
      return;
    }

    const actionData: PendingAction = {
      actorId: actor.id,
      actionType,
      claimedCharacter: claimedChar,
      targetId,
    };

    setPendingAction(actionData);

    if (actionType === 'income' || actionType === 'coup') {
      executeActionEffect(actionData);
      return;
    }

    if (actionType === 'nishachor_strike' && targetId === 'p1') {
      sound.playChallenge();
      setShowNishachorBribe(true);
      return;
    }

    // Open Explained Countdown Window
    sound.playChallenge();
    const charDef = claimedChar ? ALL_CHARACTERS[claimedChar] : null;
    const targetObj = targetId ? players.find((p) => p.id === targetId) : null;

    addLog(
      `📢 ${actor.nameBn} দাবি করেছেন: [${charDef?.nameBn}]! ${
        targetObj ? `(লক্ষ্য: ${targetObj.nameBn})` : ''
      }`,
      `📢 ${actor.nameEn} claimed: [${charDef?.nameEn}]!`,
      'action',
      actor.id,
      targetId,
      charDef?.image
    );

    setGamePhase('action_declared');

    // START DYNAMIC 10-20 SECOND REACTION COUNTDOWN (Randomized each time)
    const duration = getRandomReactionSeconds();
    const eligible = players
      .filter((p) => !p.isEliminated && p.id !== actor.id)
      .map((p) => p.id);
    const initialStatuses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'> = {};
    eligible.forEach((id) => {
      initialStatuses[id] = 'pending';
    });

    // Stagger AI replies dynamically across the 10-20s window
    const aiTimings = generateAIReplyTimings(eligible, duration);

    setCountdown({
      secondsLeft: duration,
      totalSeconds: duration,
      titleBn: `প্রতিক্রিয়া সময় — ${duration} সেকেন্ড: [${charDef?.nameBn}]`,
      descriptionBn: `${actor.nameBn} [${charDef?.nameBn}] ক্ষমতার দাবি তুলেছেন। টেবিলে কেউ এই দাবি চ্যালেঞ্জ বা প্রতিহত করতে চাইলে সিদ্ধান্ত নিন।`,
      eligiblePlayerIds: eligible,
      respondersStatus: initialStatuses,
      timeoutOutcomeBn: 'সময় শেষ হলে বা সবাই এড়িয়ে গেলে চালটি বাস্তবায়িত হবে।',
      aiTargetSeconds: aiTimings,
    });
  };

  // Countdown Interval Effect (Dynamic 10-20 Second Timer with organic AI evaluation)
  useEffect(() => {
    if (!countdown) return;

    countdownIntervalRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (!prev) return null;

        // 1. Check if all eligible players have skipped
        const allSkipped = prev.eligiblePlayerIds.every(
          (id) => prev.respondersStatus[id] === 'skipped'
        );

        if (allSkipped || prev.secondsLeft <= 1) {
          clearInterval(countdownIntervalRef.current!);
          if (gamePhase === 'action_declared' && pendingAction) {
            executeActionEffect(pendingAction);
          } else if (gamePhase === 'block_declared') {
            addLog(
              `🛡️ ব্লক সর্বসম্মতভাবে মেনে নেওয়া হয়েছে। চাল প্রতিহত হলো।`,
              `🛡️ Block unanimously accepted. Action prevented.`,
              'block'
            );
            setTimeout(advanceTurn, 1000);
          }
          return null;
        }

        // 2. AI Opponents dynamically evaluate during countdown based on assigned timings
        const nextStatuses = { ...prev.respondersStatus };
        const pendingAIs = players.filter(
          (p) =>
            !p.isHuman &&
            !p.isEliminated &&
            prev.eligiblePlayerIds.includes(p.id) &&
            nextStatuses[p.id] === 'pending'
        );

        const elapsed = prev.totalSeconds - prev.secondsLeft;

        for (const ai of pendingAIs) {
          const targetSecond = prev.aiTargetSeconds?.[ai.id] ?? 3;
          if (elapsed >= targetSecond) {
            if (gamePhase === 'action_declared' && pendingAction) {
              const dec = AIEngine.evaluateReaction(
                ai,
                activePlayer,
                pendingAction,
                discardPile,
                selectedCharacters
              );

              if (dec.type === 'challenge') {
                clearInterval(countdownIntervalRef.current!);
                addLog(
                  `⚡ ${ai.nameBn} [${ALL_CHARACTERS[pendingAction.claimedCharacter!].nameBn}] দাবি মিথ্যা বলে চ্যালেঞ্জ করলেন!`,
                  `⚡ ${ai.nameEn} challenged the claim!`,
                  'challenge'
                );
                resolveChallenge({
                  challengerId: ai.id,
                  challengedPlayerId: pendingAction.actorId,
                  claimedCharacter: pendingAction.claimedCharacter!,
                  isBlockChallenge: false,
                });
                return null;
              } else if (dec.type === 'block' && dec.claimedBlockCharacter) {
                clearInterval(countdownIntervalRef.current!);
                addLog(
                  `🛡️ ${ai.nameBn} [${ALL_CHARACTERS[dec.claimedBlockCharacter].nameBn}] দাবি করে প্রতিহত (Block) করেছেন!`,
                  `🛡️ ${ai.nameEn} blocked with [${ALL_CHARACTERS[dec.claimedBlockCharacter].nameEn}]!`,
                  'block'
                );
                setPendingBlock({
                  blockerId: ai.id,
                  claimedCharacter: dec.claimedBlockCharacter,
                });
                setGamePhase('block_declared');

                const blockEligible = players
                  .filter((p) => !p.isEliminated && p.id !== ai.id)
                  .map((p) => p.id);
                const blockStatuses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'> = {};
                blockEligible.forEach((id) => {
                  blockStatuses[id] = 'pending';
                });

                const blockDuration = getRandomReactionSeconds();
                const blockTimings = generateAIReplyTimings(blockEligible, blockDuration);

                setCountdown({
                  secondsLeft: blockDuration,
                  totalSeconds: blockDuration,
                  titleBn: `ব্লক যাচাইয়ের সময় — ${blockDuration} সেকেন্ড`,
                  descriptionBn: `${ai.nameBn} ব্লক দাবি করেছেন। আপনি কি এই ব্লককে মিথ্যা মনে করে চ্যালেঞ্জ করতে চান?`,
                  eligiblePlayerIds: blockEligible,
                  respondersStatus: blockStatuses,
                  timeoutOutcomeBn: 'সময় শেষ হলে বা সবাই এড়িয়ে গেলে ব্লক কার্যকর হবে।',
                  aiTargetSeconds: blockTimings,
                });
                return null;
              } else {
                nextStatuses[ai.id] = 'skipped';
              }
            } else if (gamePhase === 'block_declared' && pendingBlock) {
              const shouldChallenge = Math.random() < 0.25;
              if (shouldChallenge) {
                clearInterval(countdownIntervalRef.current!);
                addLog(
                  `⚡ ${ai.nameBn} ব্লককে মিথ্যা বলে চ্যালেঞ্জ করলেন!`,
                  `⚡ ${ai.nameEn} challenged the block!`,
                  'challenge'
                );
                resolveChallenge({
                  challengerId: ai.id,
                  challengedPlayerId: pendingBlock.blockerId,
                  claimedCharacter: pendingBlock.claimedCharacter,
                  isBlockChallenge: true,
                });
                return null;
              } else {
                nextStatuses[ai.id] = 'skipped';
              }
            }
          }
        }

        // Check again if all are now skipped after this tick
        const nowAllSkipped = prev.eligiblePlayerIds.every(
          (id) => nextStatuses[id] === 'skipped'
        );
        if (nowAllSkipped) {
          clearInterval(countdownIntervalRef.current!);
          if (gamePhase === 'action_declared' && pendingAction) {
            executeActionEffect(pendingAction);
          } else if (gamePhase === 'block_declared') {
            addLog(
              `🛡️ ব্লক সর্বসম্মতভাবে মেনে নেওয়া হয়েছে। চাল প্রতিহত হলো।`,
              `🛡️ Block accepted. Action prevented.`,
              'block'
            );
            setTimeout(advanceTurn, 1000);
          }
          return null;
        }

        return {
          ...prev,
          secondsLeft: prev.secondsLeft - 1,
          respondersStatus: nextStatuses,
        };
      });
    }, 1000);

    return () => {
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    };
  }, [countdown?.totalSeconds, gamePhase, pendingAction, pendingBlock]);

  // AI Turn Trigger (Solo offline mode only)
  useEffect(() => {
    if (!isMultiplayer && gamePhase === 'action_declared' && activePlayer && !activePlayer.isHuman && !activePlayer.isEliminated) {
      if (!countdown && !pendingAction) {
        const timer = setTimeout(() => {
          const aiAction = AIEngine.chooseAction(
            activePlayer,
            players,
            discardPile,
            selectedCharacters,
            activeTaxToken || undefined
          );
          initiateAction(aiAction.actionType, aiAction.targetId);
        }, 1200);

        return () => clearTimeout(timer);
      }
    }
  }, [gamePhase, activePlayer?.id, countdown, pendingAction]);

  return (
    <div className="min-h-screen h-screen w-screen max-w-full bg-gradient-to-b from-slate-950 via-[#0a0f1c] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-black overflow-x-hidden overflow-y-auto landscape:overflow-y-auto sm:overflow-hidden relative">
      {/* Table Background Radial Felt Atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_75%_55%_at_50%_48%,rgba(14,35,60,0.5),rgba(2,6,23,0.98))] pointer-events-none" />

      {/* Top Header Bar */}
      <header className="relative z-30 px-3 py-1.5 sm:px-6 bg-slate-950/80 border-b border-amber-500/20 backdrop-blur-md flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onBackToPlatform}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-slate-300 text-xs font-bengali transition-all cursor-pointer"
            title="খেলাঘর হোমে ফিরে যান"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">খেলাঘর</span>
          </button>

          <button
            onClick={onRestart}
            className="p-1 sm:p-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-amber-200 transition-all cursor-pointer"
            title="পুনরায় শুরু করুন"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center gap-1.5">
            <span className="font-extrabold text-sm sm:text-base text-amber-300 font-bengali">
              চালবাজি
            </span>
            <span className="text-[10px] text-amber-400/60 font-mono">
              পর্ব #{turnCount}
            </span>
            {multiplayerRoomCode && (
              <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/20 border border-amber-400/40 text-amber-300 font-mono text-[11px] font-bold">
                <span>{multiplayerRoomCode}</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(multiplayerRoomCode);
                    sound.playClick();
                    setMultiplayerCopied(true);
                    setTimeout(() => setMultiplayerCopied(false), 2000);
                  }}
                  className="cursor-pointer hover:text-white"
                  title="রুম কোড কপি করুন"
                >
                  {multiplayerCopied ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3 text-amber-300" />
                  )}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Turn Indicator */}
        <div className="flex items-center gap-2 px-3 py-0.5 rounded-full bg-slate-900/90 border border-amber-500/40 shadow-inner">
          <div
            className={`w-2 h-2 rounded-full ${
              activePlayer?.isHuman ? 'bg-amber-400 animate-ping' : 'bg-cyan-400 animate-pulse'
            }`}
          />
          <span className="text-xs font-bold font-bengali text-amber-200">
            {gamePhase === 'match_ready'
              ? 'ম্যাচ প্রস্তুতি'
              : gamePhase === 'deck_shuffling'
              ? 'ডেক শুফেল...'
              : gamePhase === 'dealing_cards'
              ? 'কার্ড বিতরণ...'
              : `${activePlayer?.nameBn}-এর চাল`}
          </span>
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => {
                sound.playClick();
                setShowAudioSettings((prev) => !prev);
              }}
              className={`p-1.5 rounded-xl bg-slate-900 border text-amber-200 transition-all cursor-pointer ${
                showAudioSettings
                  ? 'border-amber-400 bg-slate-800'
                  : 'border-slate-700 hover:border-slate-600'
              }`}
              title="শব্দ ও ভলিউম নিয়ন্ত্রণ"
            >
              {settings.soundEnabled ? (
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-slate-500" />
              )}
            </button>

            {/* Audio Settings Popover */}
            {showAudioSettings && (
              <div className="absolute right-0 top-full mt-2 w-56 p-3 rounded-2xl bg-slate-950/95 border border-amber-500/40 shadow-2xl backdrop-blur-xl z-50 text-left animate-scaleIn font-bengali">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold text-amber-300">শব্দ নিয়ন্ত্রণ</span>
                  <button
                    onClick={() => {
                      const next = !settings.soundEnabled;
                      sound.setEnabled(next);
                      sound.playClick();
                      setSettings((s) => ({ ...s, soundEnabled: next }));
                    }}
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer ${
                      settings.soundEnabled
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-red-500/20 text-red-300 border-red-500/40'
                    }`}
                  >
                    {settings.soundEnabled ? 'চালু' : 'নিঃশব্দ'}
                  </button>
                </div>

                {/* BGM Volume */}
                <div className="mt-2.5 space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-300">
                    <span>সঙ্গীত (BGM):</span>
                    <span className="font-mono text-[10px] text-amber-400">
                      {Math.round(musicVolume * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={musicVolume}
                    disabled={!settings.soundEnabled}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setMusicVolume(val);
                      sound.setMusicVolume(val);
                    }}
                    className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>

                {/* SFX Volume */}
                <div className="mt-2.5 space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-300">
                    <span>সাউন্ড এফেক্টস (SFX):</span>
                    <span className="font-mono text-[10px] text-amber-400">
                      {Math.round(sfxVolume * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={sfxVolume}
                    disabled={!settings.soundEnabled}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setSfxVolume(val);
                      sound.setSfxVolume(val);
                    }}
                    className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>

          <button
            onClick={handleToggleRotate}
            className="flex items-center gap-1 px-2 py-1 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-slate-300 text-xs font-bengali transition-all cursor-pointer"
            title="স্ক্রিন রোটেট / ফুলস্ক্রিন (Rotate Screen / Fullscreen)"
          >
            <RotateCw className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline">স্ক্রিন ঘোরান</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenRules();
            }}
            className="flex items-center gap-1 px-2 py-1 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-300 text-xs font-bengali hover:bg-amber-500/20 cursor-pointer"
          >
            <BookOpen className="w-3 h-3" />
            <span className="hidden sm:inline">নিয়ম</span>
          </button>
        </div>
      </header>

      {/* Main Playing Area (Viewport Responsive with Landscape Scroll Support) */}
      <main className="relative z-10 flex-1 w-full max-w-7xl mx-auto px-2 sm:px-4 py-1 sm:py-2 flex flex-col justify-between overflow-y-auto landscape:overflow-y-auto sm:overflow-hidden">
        {/* Animated Curved Action Trajectory between Actor and Target */}
        {activeTrajectory && (
          <ActionTrajectory
            actorId={activeTrajectory.actorId}
            targetId={activeTrajectory.targetId}
            characterId={activeTrajectory.characterId}
            onComplete={() => setActiveTrajectory(null)}
          />
        )}

        {/* Top AI Opponent Pod */}
        <div className="flex justify-center shrink-0">
          {opponents[0] && (
            <AIPod
              player={opponents[0]}
              isActiveTurn={activePlayer?.id === opponents[0].id && gamePhase !== 'match_ready'}
              isTargeted={pendingAction?.targetId === opponents[0].id}
              isDealing={dealingStep?.playerIndex === 1}
              responseStatus={countdown?.respondersStatus[opponents[0].id]}
              onInspectCard={(c) => setInspectCharacter(ALL_CHARACTERS[c.characterId])}
            />
          )}
        </div>

        {/* Central Arena Row: Left AI, Center Table, Right AI */}
        <div className="grid grid-cols-12 gap-2 sm:gap-4 items-center my-auto w-full">
          {/* Left AI Opponent Pod */}
          <div className="col-span-3 sm:col-span-3 flex justify-start">
            {opponents[1] && (
              <AIPod
                player={opponents[1]}
                isActiveTurn={activePlayer?.id === opponents[1].id && gamePhase !== 'match_ready'}
                isTargeted={pendingAction?.targetId === opponents[1].id}
                isDealing={dealingStep?.playerIndex === 2}
                responseStatus={countdown?.respondersStatus[opponents[1].id]}
                onInspectCard={(c) => setInspectCharacter(ALL_CHARACTERS[c.characterId])}
              />
            )}
          </div>

          {/* Central Table Centerpiece */}
          <div className="col-span-6 sm:col-span-6 flex flex-col items-center justify-center p-2.5 sm:p-4 rounded-3xl bg-slate-900/70 border border-amber-500/30 shadow-2xl relative backdrop-blur-md">
            {/* Center Felt Pattern */}
            <div className="absolute inset-2 rounded-2xl border border-dashed border-amber-500/20 pointer-events-none" />

            {/* When in Match Ready: Show Deck in Center with "Shuffle & Deal" Button */}
            {gamePhase === 'match_ready' && (
              <div className="z-10 flex flex-col items-center py-2 text-center animate-fadeIn">
                <div className="relative mb-3">
                  <CardBack className="w-20 sm:w-24 shadow-2xl ring-2 ring-amber-400" />
                  <div className="absolute -bottom-2 bg-slate-950 text-amber-300 border border-amber-400/50 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono">
                    ১৫টি কার্ড
                  </div>
                </div>

                <h3 className="text-sm sm:text-base font-black text-amber-300 font-bengali">
                  ডেক প্রস্তুত! খেলা শুরু করতে বিতরণ করুন
                </h3>
                <p className="text-[11px] text-slate-300/80 font-bengali mt-0.5 max-w-xs">
                  প্রত্যেক খেলোয়াড় ২টি করে গোপন কার্ড ও ২টি মুদ্রা পাবেন।
                </p>

                <button
                  onClick={startShuffleAndDeal}
                  className="mt-3 px-6 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs sm:text-sm font-bengali shadow-xl shadow-amber-500/30 hover:scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 fill-current" />
                  <span>কার্ড শুফেল ও বিতরণ (Shuffle & Deal)</span>
                </button>
              </div>
            )}

            {/* When Shuffling: Animated Shuffle Visual */}
            {gamePhase === 'deck_shuffling' && (
              <div className="z-10 flex flex-col items-center py-4 text-center">
                <div className="relative w-24 h-32 flex items-center justify-center">
                  <div className="absolute w-20 h-28 rounded-xl bg-amber-600/30 border border-amber-400 -rotate-12 animate-pulse" />
                  <div className="absolute w-20 h-28 rounded-xl bg-purple-600/30 border border-purple-400 rotate-12 animate-pulse" />
                  <CardBack className="w-20 h-28 shadow-2xl z-10 animate-bounce" />
                </div>
                <span className="text-xs font-bold text-amber-300 font-bengali mt-3 animate-pulse">
                  কার্ড শুফেল হচ্ছে...
                </span>
              </div>
            )}

            {/* Standard Play Stage: Bank, Deck, Discard */}
            {gamePhase !== 'match_ready' && gamePhase !== 'deck_shuffling' && (
              <div className="w-full flex flex-col items-center z-10">
                <div className="flex items-center justify-around w-full max-w-sm gap-3">
                  {/* Draw Deck */}
                  <div className="flex flex-col items-center">
                    <div className="relative">
                      <CardBack className="w-14 sm:w-16 shadow-lg" />
                      <div className="absolute -bottom-1.5 bg-slate-950 text-amber-300 border border-amber-400/50 px-1.5 py-0.2 rounded-full text-[9px] font-bold font-mono">
                        {drawDeck.length} কার্ড
                      </div>
                    </div>
                    <span className="text-[10px] text-amber-200/80 font-bengali mt-2">
                      ডেক
                    </span>
                  </div>

                  {/* Bank Coins */}
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-br from-amber-600 via-amber-500 to-yellow-600 flex flex-col items-center justify-center border-2 border-amber-300 shadow-xl shadow-amber-500/20">
                      <Coins className="w-4 h-4 text-slate-950" />
                      <span className="text-xs sm:text-sm font-black text-slate-950 font-mono">
                        {bankCoins}
                      </span>
                    </div>
                    <span className="text-[10px] text-amber-300 font-bold font-bengali mt-1">
                      ব্যাংক
                    </span>
                  </div>

                  {/* Discard Pile */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-14 sm:w-16 aspect-[5/7] rounded-xl border border-dashed border-red-500/40 bg-slate-950/80 flex items-center justify-center overflow-hidden">
                      {discardPile.length > 0 ? (
                        <CardView
                          characterId={discardPile[discardPile.length - 1].characterId}
                          isDead
                          size="sm"
                          className="w-full h-full"
                        />
                      ) : (
                        <span className="text-[9px] text-slate-500 font-bengali">
                          শূন্য
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-red-300/80 font-bengali mt-1">
                      খারিজ ({discardPile.length})
                    </span>
                  </div>
                </div>

                {/* Active Tax Token Marker */}
                {activeTaxToken && ALL_CHARACTERS[activeTaxToken.characterId] && (
                  <div className="mt-2 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-400/50 flex items-center gap-1.5 text-[10px] text-emerald-300 font-bengali z-10 animate-pulse">
                    <Coins className="w-3 h-3 text-amber-300" />
                    <span>
                      ট্যাক্স টোকেন: [
                      <strong>{ALL_CHARACTERS[activeTaxToken.characterId]?.nameBn}</strong>
                      ] ব্যবহারে ১ মুদ্রা শুল্ক
                    </span>
                  </div>
                )}

              </div>
            )}
          </div>

          {/* Right AI Opponent Pod */}
          <div className="col-span-3 sm:col-span-3 flex justify-end">
            {opponents[2] && (
              <AIPod
                player={opponents[2]}
                isActiveTurn={activePlayer?.id === opponents[2].id && gamePhase !== 'match_ready'}
                isTargeted={pendingAction?.targetId === opponents[2].id}
                isDealing={dealingStep?.playerIndex === 3}
                responseStatus={countdown?.respondersStatus[opponents[2].id]}
                onInspectCard={(c) => setInspectCharacter(ALL_CHARACTERS[c.characterId])}
              />
            )}
          </div>
        </div>

        {/* Bottom Section: Human Player Pod & Action Dock */}
        <div
          className={`w-full rounded-2xl p-2.5 sm:p-3 border shadow-2xl backdrop-blur-md shrink-0 transition-all duration-300 ${
            isMyTurn && gamePhase !== 'match_ready'
              ? 'bg-slate-900/95 border-2 border-cyan-400 ring-4 ring-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.4)]'
              : pendingAction?.targetId === humanPlayer?.id
              ? 'bg-rose-950/60 border-2 border-rose-500 ring-4 ring-rose-500/40 shadow-[0_0_25px_rgba(244,63,94,0.35)] animate-pulse'
              : 'bg-slate-900/85 border-amber-500/30'
          }`}
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-2.5 sm:gap-4">
            {/* Human Profile & 3D Flip Hand Cards */}
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="text-base sm:text-lg">👑</span>
                  <span className="font-extrabold text-xs sm:text-sm text-amber-300 font-bengali">
                    {humanPlayer?.nameBn || 'আপনি'}
                  </span>
                  {humanPlayer?.isEliminated && (
                    <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.2 rounded font-bengali">
                      নির্মূল
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/20 border border-amber-400/40 text-amber-300 font-mono font-bold text-xs">
                    <Coins className="w-3 h-3 text-amber-400" />
                    <span>{humanPlayer?.coins ?? 0}</span>
                  </div>

                  <div className="flex items-center gap-0.5">
                    {humanPlayer?.cards?.map((c, idx) => (
                      <Heart
                        key={idx}
                        className={`w-3.5 h-3.5 ${
                          c.isRevealed
                            ? 'text-slate-600 fill-slate-800'
                            : 'text-red-500 fill-red-500'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* 3D Flip Hand Cards (Prominent desktop size lg, click to flip card to read rules!) */}
              <div className="flex items-center gap-2 sm:gap-3">
                {humanPlayer?.cards?.map((card) => (
                  <CardFlip
                    key={card.uid}
                    card={card}
                    characterId={card.characterId}
                    isDead={card.isRevealed}
                    size="lg"
                    canFlip={!card.isRevealed}
                  />
                ))}
              </div>
            </div>

            {/* Target Picker Overlay (if targeted action initiated) */}
            {selectedActionForTarget && (
              <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-400/60 flex items-center gap-2 z-20">
                <span className="text-[11px] font-bengali font-bold text-amber-300">
                  লক্ষ্য বেছে নিন:
                </span>
                <div className="flex items-center gap-1">
                  {players
                    .filter((p) => p.id !== humanPlayer?.id && !p.isEliminated)
                    .map((target) => (
                      <button
                        key={target.id}
                        onClick={() => initiateAction(selectedActionForTarget, target.id)}
                        className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] font-bengali transition-all cursor-pointer shadow"
                      >
                        {target.nameBn} ({target.coins} মুদ্রা)
                      </button>
                    ))}
                  <button
                    onClick={() => setSelectedActionForTarget(null)}
                    className="px-2 py-1 rounded-lg bg-slate-800 text-slate-400 text-[10px] font-bengali"
                  >
                    বাতিল
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons Dock (Active Player: Human) */}
            {humanPlayer &&
              !humanPlayer.isEliminated &&
              isMyTurn &&
              gamePhase === 'action_declared' &&
              !countdown &&
              !selectedActionForTarget && (
                <div className="flex flex-wrap items-center justify-center md:justify-end gap-1.5 max-w-xl">
                  {/* Coup Mandatory Warning */}
                  {(humanPlayer.coins ?? 0) >= 10 && (
                    <div className="w-full text-center text-[11px] text-red-400 font-bengali font-bold">
                      ⚠️ আপনার ১০টি মুদ্রা আছে! সুপ্রিম নিধন (Coup) চাল বাধ্যতামূলক।
                    </div>
                  )}

                  {/* General Actions */}
                  {(humanPlayer.coins ?? 0) < 10 && (
                    <button
                      onClick={() => initiateAction('income')}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bengali font-bold transition-all shadow cursor-pointer"
                    >
                      রাজস্ব (+১)
                    </button>
                  )}

                  {(humanPlayer.coins ?? 0) >= 7 && (
                    <button
                      onClick={() => setSelectedActionForTarget('coup')}
                      className="px-3 py-1.5 rounded-xl bg-red-700 hover:bg-red-600 text-white text-xs font-bengali font-bold transition-all shadow cursor-pointer"
                    >
                      ⚔️ সুপ্রিম নিধন (৭)
                    </button>
                  )}

                  {/* Character Claims */}
                  {(humanPlayer.coins ?? 0) < 10 &&
                    selectedCharacters.map((charId) => {
                      const char = ALL_CHARACTERS[charId];
                      if (!char) return null;
                      const canAfford = (humanPlayer.coins ?? 0) >= char.coinCost;

                      return (
                        <button
                          key={charId}
                          disabled={!canAfford}
                          onClick={() => {
                            if (char.isTargeted) {
                              setSelectedActionForTarget(char.actionType);
                            } else {
                              initiateAction(char.actionType);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bengali font-bold flex items-center gap-1 transition-all shadow cursor-pointer ${
                            canAfford
                              ? 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-slate-950 border border-amber-300'
                              : 'bg-slate-800/60 text-slate-500 border border-slate-800 cursor-not-allowed'
                          }`}
                        >
                          <span>{char.nameBn}</span>
                          {char.coinCost > 0 ? (
                            <span className="text-[9px] bg-red-950/80 text-red-300 px-1 rounded">
                              -{char.coinCost}
                            </span>
                          ) : char.coinGain > 0 ? (
                            <span className="text-[9px] bg-emerald-950/80 text-emerald-300 px-1 rounded">
                              +{char.coinGain}
                            </span>
                          ) : null}
                        </button>
                      );
                    })}
                </div>
              )}
          </div>
        </div>

        {/* Collapsible Game Event Log Drawer */}
        <div className="w-full bg-slate-950/90 rounded-xl border border-slate-800 px-3 py-1 shrink-0">
          <div
            className="flex items-center justify-between cursor-pointer py-0.5"
            onClick={() => setShowLogDrawer(!showLogDrawer)}
          >
            <div className="flex items-center gap-1.5 text-[11px] font-bengali text-amber-300 font-bold">
              <History className="w-3 h-3" />
              <span>খেলার ঘটনাবলি ও ইতিহাস ({gameLogs.length})</span>
            </div>
            {showLogDrawer ? (
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            ) : (
              <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
            )}
          </div>

          {showLogDrawer && (
            <div
              ref={logContainerRef}
              className="mt-1 max-h-24 sm:max-h-28 overflow-y-auto space-y-1 pr-1 text-[11px] font-bengali"
            >
              {gameLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-1 rounded bg-slate-900/80 border border-slate-800/80 flex items-start gap-1.5"
                >
                  <span className="text-slate-500 text-[10px] font-mono">
                    #{log.turnNumber}
                  </span>
                  <div className="flex-1">
                    <span className="text-slate-200">{log.textBn}</span>
                    {settings.showEnglishSubs && (
                      <span className="text-slate-400 block text-[9px] font-sans">
                        {log.textEn}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Special Game Modals */}
      {/* Guptochor Inspection */}
      {gamePhase === 'human_inspecting' && guptochorDrawnCard && (
        <GuptochorInspectModal
          drawnCard={guptochorDrawnCard}
          handCards={humanPlayer.cards}
          onFinish={(swapIdx) => {
            if (swapIdx !== null) {
              const activeHandCards = humanPlayer.cards.filter((c) => !c.isRevealed);
              const cardToSwap = activeHandCards[swapIdx];
              setPlayers((prev) =>
                prev.map((p) => {
                  if (p.id !== 'p1') return p;
                  const newCards = p.cards.map((c) =>
                    c.uid === cardToSwap.uid ? guptochorDrawnCard : c
                  );
                  return { ...p, cards: newCards };
                })
              );
              setDrawDeck((prev) => [cardToSwap, ...prev.slice(0, -1)]);
              addLog(
                `🦅 আপনি ডেকে পাওয়া কার্ড দিয়ে আপনার হাতের ১টি কার্ড অদলবদল করেছেন।`,
                `🦅 You exchanged a card with the deck.`,
                'exchange'
              );
            }
            setGuptochorDrawnCard(null);
            advanceTurn();
          }}
        />
      )}

      {/* Jyotishi Inspection */}
      {gamePhase === 'human_inspecting' && jyotishiDrawnCards.length > 0 && (
        <JyotishiInspectModal
          drawnCards={jyotishiDrawnCards}
          handCards={humanPlayer.cards}
          onFinish={(keepUids) => {
            const allAvailable = [
              ...humanPlayer.cards.filter((c) => !c.isRevealed),
              ...jyotishiDrawnCards,
            ];
            const keptCards = allAvailable.filter((c) => keepUids.includes(c.uid));
            const returnToDeck = allAvailable.filter((c) => !keepUids.includes(c.uid));

            setPlayers((prev) =>
              prev.map((p) => {
                if (p.id !== 'p1') return p;
                const revealedCards = p.cards.filter((c) => c.isRevealed);
                return { ...p, cards: [...revealedCards, ...keptCards] };
              })
            );

            setDrawDeck((prev) => {
              const remainingDeck = prev.slice(0, -2);
              const reshuffled = [...remainingDeck, ...returnToDeck];
              for (let i = reshuffled.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [reshuffled[i], reshuffled[j]] = [reshuffled[j], reshuffled[i]];
              }
              return reshuffled;
            });

            addLog(
              `🔮 আপনি জ্যোতিষীর দৃষ্টিতে ২টি নতুন কার্ড পর্যবেক্ষণ করে ডেক সাজিয়েছেন।`,
              `🔮 You reorganized your hand using Jyotishi.`,
              'exchange'
            );

            setJyotishiDrawnCards([]);
            advanceTurn();
          }}
        />
      )}

      {/* Nishachor Bribe Modal */}
      {showNishachorBribe && pendingAction && (
        <NishachorBribeModal
          attackerNameBn={
            players.find((p) => p.id === pendingAction.actorId)?.nameBn || 'শত্রু'
          }
          targetCoins={humanPlayer.coins}
          onPayBribe={() => {
            sound.playCoin();
            setShowNishachorBribe(false);
            setPlayers((prev) =>
              prev.map((p) => {
                if (p.id === 'p1') return { ...p, coins: p.coins - 2 };
                if (p.id === pendingAction.actorId)
                  return { ...p, coins: p.coins + 2 };
                return p;
              })
            );
            addLog(
              `💰 আপনি ২ মুদ্রা ঘুষ দিয়ে নিশাচরের আক্রমণ বাতিল করলেন!`,
              `💰 You paid 2 coins bribe to cancel Nishachor attack.`,
              'action'
            );
            advanceTurn();
          }}
          onChallenge={() => {
            setShowNishachorBribe(false);
            resolveChallenge({
              challengerId: 'p1',
              challengedPlayerId: pendingAction.actorId,
              claimedCharacter: 'nishachor',
              isBlockChallenge: false,
            });
          }}
          onAcceptHit={() => {
            setShowNishachorBribe(false);
            executeActionEffect(pendingAction);
          }}
        />
      )}

      {/* Discard Modal */}
      {discardModalData && (
        <DiscardCardModal
          cards={humanPlayer.cards}
          reasonBn={discardModalData.reasonBn}
          onSelectDiscard={(cardUid) => {
            discardCardFromPlayer('p1', cardUid);
            const discardedChar = humanPlayer.cards.find(
              (c) => c.uid === cardUid
            )?.characterId;
            if (discardedChar) {
              addLog(
                `আপনি ১টি জীবন হারিয়েছেন এবং [${ALL_CHARACTERS[discardedChar].nameBn}] কার্ড খারিজ করলেন।`,
                `You lost 1 life and discarded [${ALL_CHARACTERS[discardedChar].nameEn}].`,
                'elimination',
                'p1',
                undefined,
                ALL_CHARACTERS[discardedChar].image
              );
            }
            discardModalData.callback();
          }}
        />
      )}

      {/* Khajnadar Tax Token Picker */}
      {showTaxTokenPicker && (
        <TaxTokenSelectModal
          selectedCharacters={selectedCharacters}
          currentTaxedCharacter={activeTaxToken?.characterId}
          onSelectCharacter={(charId) => {
            setShowTaxTokenPicker(false);
            setActiveTaxToken({ characterId: charId, placedBy: humanPlayer?.nameBn || 'আপনি' });
            addLog(
              `⚖️ আপনি খাজনাদার দাবি করে [${ALL_CHARACTERS[charId].nameBn}]-এর ওপর ট্যাক্স টোকেন বসালেন!`,
              `⚖️ You placed Tax Token on [${ALL_CHARACTERS[charId].nameEn}].`,
              'action',
              'p1',
              undefined,
              ALL_CHARACTERS.khajnadar.image
            );
            advanceTurn();
          }}
        />
      )}

      {/* Inspect Modal */}
      {inspectCharacter && (
        <CardModal
          character={inspectCharacter}
          hasTaxToken={activeTaxToken?.characterId === inspectCharacter.id}
          onClose={() => setInspectCharacter(null)}
        />
      )}

      {/* Centered Reaction Verification Modal (ALWAYS in the Middle of Screen) */}
      {countdown && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-fadeIn pointer-events-auto">
          <div className="w-full max-w-lg bg-slate-950/98 border-2 border-amber-400 rounded-3xl p-4 sm:p-5 shadow-[0_0_50px_rgba(0,0,0,0.9)] animate-scaleIn text-left font-bengali max-h-[92vh] overflow-y-auto">
            {/* Header with Title & Live Numeric Clock */}
            <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Clock
                  className={`w-5 h-5 ${
                    countdown.secondsLeft <= 4
                      ? 'text-red-400 animate-spin'
                      : 'text-amber-400 animate-pulse'
                  }`}
                />
                <div>
                  <h3 className="text-sm sm:text-base font-black text-amber-300 leading-tight">
                    {pendingBlock
                      ? 'ব্লক যাচাই — প্রতিক্রিয়া দিন'
                      : 'চালবাজি যাচাই — প্রতিক্রিয়া দিন'}
                  </h3>
                  <span className="text-[10px] text-slate-400">
                    {pendingAction?.targetId === 'p1'
                      ? '👉 আপনাকে সরাসরি লক্ষ্য করা হয়েছে!'
                      : 'টেবিল প্রতিক্রিয়া যাচাই পর্ব'}
                  </span>
                </div>
              </div>

              <span
                className={`text-xs sm:text-sm font-mono font-black px-3 py-1 rounded-full shadow ${
                  countdown.secondsLeft <= 4
                    ? 'bg-red-600 text-white animate-pulse shadow-red-600/50'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-400/50'
                }`}
              >
                ⏱️ {countdown.secondsLeft} সেকেন্ড
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-800 rounded-full h-1.5 sm:h-2 mb-3 overflow-hidden">
              <div
                className={`h-full transition-all duration-1000 ease-linear ${
                  countdown.secondsLeft <= 4
                    ? 'bg-red-500 animate-pulse'
                    : 'bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600'
                }`}
                style={{
                  width: `${(countdown.secondsLeft / countdown.totalSeconds) * 100}%`,
                }}
              />
            </div>

            {/* Structured 3-Column Info: কে (Actor) | কোন চরিত্র ও ক্ষমতা (Character) | কাকে (Target) */}
            {(() => {
              const actorObj = pendingAction ? players.find((p) => p.id === pendingAction.actorId) : null;
              const targetObj = pendingAction?.targetId ? players.find((p) => p.id === pendingAction.targetId) : null;
              const charObj = pendingAction?.claimedCharacter ? ALL_CHARACTERS[pendingAction.claimedCharacter] : null;

              let actionDescriptionBn = countdown.descriptionBn;
              if (pendingAction && actorObj) {
                if (pendingAction.actionType === 'nawab_tax') {
                  actionDescriptionBn = `${actorObj.nameBn} [নবাব] হিসেবে রাজকোষ থেকে ৩ মুদ্রা রাজস্ব সংগ্রহের দাবি করেছেন।`;
                } else if (pendingAction.actionType === 'sodagor_trade') {
                  actionDescriptionBn = `${actorObj.nameBn} [সদাগর] হিসেবে সমুদ্রবাণিজ্যের মাধ্যমে ব্যাংক থেকে ৪ মুদ্রা নিচ্ছেন।`;
                } else if (pendingAction.actionType === 'assassinate' && targetObj) {
                  actionDescriptionBn = `${actorObj.nameBn} ৩ মুদ্রা ব্যয় করে [গুপ্তঘাতক] দ্বারা ${targetObj.nameBn}-কে হত্যার নির্দেশ দিয়েছেন!`;
                } else if (pendingAction.actionType === 'nishachor_strike' && targetObj) {
                  actionDescriptionBn = `${actorObj.nameBn} ৫ মুদ্রা পরিশোধ করে [নিশাচর] হিসেবে ${targetObj.nameBn}-এর বিরুদ্ধে আক্রমণ ঘোষণা করেছেন!`;
                } else if (pendingAction.actionType === 'dosyu_steal' && targetObj) {
                  actionDescriptionBn = `${actorObj.nameBn} [দস্যু সর্দার] দাবি করে ${targetObj.nameBn}-এর কাছ থেকে ২ মুদ্রা ডাকাতি করছেন!`;
                } else if (pendingAction.actionType === 'sidhel_raid') {
                  actionDescriptionBn = `${actorObj.nameBn} [সিঁধেল চোর] দাবি করে টেবিলের প্রত্যেকের কাছ থেকে ১টি করে মুদ্রা চুরি করছেন!`;
                } else if (pendingAction.actionType === 'guptochor_spy') {
                  actionDescriptionBn = `${actorObj.nameBn} [গুপ্তচর] দাবি করে গোপন অনুসন্ধান ও ডেকের সাথে কার্ড অদলবদল করতে চান।`;
                } else if (pendingAction.actionType === 'jyotishi_divine') {
                  actionDescriptionBn = `${actorObj.nameBn} [জ্যোতিষী] দাবি করে ভবিষ্যৎ দৃষ্টির মাধ্যমে ডেকের ২টি কার্ড পর্যবেক্ষণ ও সাজাতে চান।`;
                } else if (pendingAction.actionType === 'khajnadar_tax') {
                  actionDescriptionBn = `${actorObj.nameBn} [খাজনাদার] হিসেবে চরিত্রের ওপর ট্যাক্স টোকেন বসিয়ে ১ মুদ্রা করে কর আদায় করতে চান।`;
                }
              } else if (pendingBlock) {
                const blockerObj = players.find((p) => p.id === pendingBlock.blockerId);
                const blockCharObj = ALL_CHARACTERS[pendingBlock.claimedCharacter];
                actionDescriptionBn = `${blockerObj?.nameBn} [${blockCharObj?.nameBn}] দাবি করে চালটি সম্পূর্ণ প্রতিহত (Block) করেছেন!`;
              }

              const isHumanTarget = pendingAction?.targetId === 'p1';
              const isHumanActor = pendingAction?.actorId === 'p1';
              const hasSpecificTarget = !!pendingAction?.targetId;

              return (
                <div className="space-y-2.5">
                  {/* 3-Column Visual Grid */}
                  <div className="grid grid-cols-3 gap-2 p-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
                    {/* কে (Actor) */}
                    <div className="flex flex-col items-center justify-center p-1 rounded-xl bg-slate-950/60 border border-slate-800/80">
                      <span className="text-[9px] text-slate-400 mb-0.5">কে (চালদাতা)</span>
                      <span className="text-xl sm:text-2xl">{actorObj?.avatar || '👤'}</span>
                      <span className="font-extrabold text-xs text-cyan-300 truncate w-full mt-0.5">
                        {actorObj?.nameBn || 'অজ্ঞাত'}
                      </span>
                    </div>

                    {/* কোন চরিত্র ও ক্ষমতা (Character) */}
                    <div className="flex flex-col items-center justify-center p-1 rounded-xl bg-slate-950/60 border border-slate-800/80">
                      <span className="text-[9px] text-slate-400 mb-0.5">চরিত্র ও ক্ষমতা</span>
                      {charObj ? (
                        <div className="relative w-8 h-10 rounded overflow-hidden border border-amber-400/80 shadow">
                          <img src={charObj.image} alt={charObj.nameBn} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <Sparkles className="w-6 h-6 text-amber-400 my-auto" />
                      )}
                      <span className="font-bold text-[10px] sm:text-[11px] text-amber-300 truncate w-full mt-0.5">
                        {charObj ? charObj.nameBn : pendingAction?.actionType || 'সাধারণ'}
                      </span>
                    </div>

                    {/* কাকে (Target) */}
                    <div className="flex flex-col items-center justify-center p-1 rounded-xl bg-slate-950/60 border border-slate-800/80">
                      <span className="text-[9px] text-slate-400 mb-0.5">কাকে (লক্ষ্য)</span>
                      <span className="text-xl sm:text-2xl">
                        {targetObj ? (targetObj.id === 'p1' ? '👑' : targetObj.avatar) : '🏛️'}
                      </span>
                      <span
                        className={`font-extrabold text-xs truncate w-full mt-0.5 ${
                          targetObj?.id === 'p1' ? 'text-red-400 animate-pulse font-black' : 'text-rose-300'
                        }`}
                      >
                        {targetObj ? (targetObj.id === 'p1' ? 'আপনি (Target)' : targetObj.nameBn) : 'ব্যাংক / সমগ্র টেবিল'}
                      </span>
                    </div>
                  </div>

                  {/* Complete Bengali Narrative */}
                  <div className="px-3 py-2 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200">
                    <span className="font-bold text-amber-300">বিবরণ: </span>
                    {actionDescriptionBn}
                  </div>

                  {/* Human Hand Quick Reference */}
                  <div className="flex items-center justify-between text-[11px] text-slate-300 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400">আপনার হাতের কার্ড:</span>
                    <div className="flex items-center gap-1.5 font-bold text-amber-300">
                      {humanPlayer.cards.map((c, i) => (
                        <span
                          key={i}
                          className={`px-2 py-0.5 rounded text-[10px] ${
                            c.isRevealed
                              ? 'bg-slate-800 text-slate-500 line-through'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {ALL_CHARACTERS[c.characterId]?.nameBn}
                        </span>
                      ))}
                      <span className="text-slate-400 font-mono text-[10px] ml-1">
                        ({humanPlayer.coins} মুদ্রা)
                      </span>
                    </div>
                  </div>

                  {/* Other Responders Live Status Tracker */}
                  <div className="flex flex-wrap items-center gap-1.5 py-1 text-[10px]">
                    <span className="text-slate-400">খেলোয়াড়দের প্রতিক্রিয়া:</span>
                    {countdown.eligiblePlayerIds
                      .filter((pid) => pid !== 'p1')
                      .map((pid) => {
                        const pl = players.find((p) => p.id === pid);
                        const st = countdown.respondersStatus[pid] || 'pending';
                        return (
                          <div
                            key={pid}
                            className={`px-2 py-0.5 rounded-lg border flex items-center gap-1 ${
                              st === 'pending'
                                ? 'bg-amber-950/40 border-amber-500/40 text-amber-300 animate-pulse'
                                : st === 'skipped'
                                ? 'bg-slate-900 border-slate-700 text-slate-400'
                                : 'bg-purple-950/60 border-purple-500/60 text-purple-300 font-bold'
                            }`}
                          >
                            <span>{pl?.nameBn}:</span>
                            <span>
                              {st === 'pending'
                                ? 'ভাবছে...'
                                : st === 'skipped'
                                ? 'পাস ✓'
                                : st === 'challenged'
                                ? 'চ্যালেঞ্জ! ⚡'
                                : 'ব্লক! 🛡️'}
                            </span>
                          </div>
                        );
                      })}
                  </div>

                  {/* ACTION CONTROLS */}
                  <div className="pt-2 border-t border-slate-800">
                    {/* If human already responded */}
                    {countdown.respondersStatus['p1'] === 'skipped' ? (
                      <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-center font-bold text-xs sm:text-sm flex items-center justify-center gap-2 animate-fadeIn">
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                        <span>✓ আপনি সিদ্ধান্ত দিয়েছেন — বাকিদের প্রতিক্রিয়া যাচাই হচ্ছে...</span>
                      </div>
                    ) : isHumanActor ? (
                      <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-center text-xs italic">
                        👀 আপনার চালের ওপর প্রতিপক্ষদের প্রতিক্রিয়া দেখা হচ্ছে...
                      </div>
                    ) : (
                      /* Human needs to choose */
                      <div className="space-y-2">
                        {/* CASE 1: Human IS the DIRECT TARGET */}
                        {isHumanTarget ? (
                          <div className="space-y-2">
                            <div className="text-center text-xs font-bold text-red-300 animate-pulse">
                              ⚠️ আক্রমণ আপনার ওপর প্রয়োগ হচ্ছে! চ্যালেঞ্জ বা গ্রহণ করুন:
                            </div>

                            <div className="grid grid-cols-2 gap-2.5">
                              {/* Challenge */}
                              <button
                                onClick={handleHumanChallenge}
                                className="py-3 px-3 rounded-xl bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 active:scale-95 text-white font-black text-xs sm:text-sm shadow-xl border border-purple-400/50 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all"
                              >
                                <div className="flex items-center gap-1.5">
                                  <Swords className="w-4 h-4 text-yellow-300" />
                                  <span>চ্যালেঞ্জ (CHALLENGE) ⚡</span>
                                </div>
                                <span className="text-[9px] text-purple-200 font-normal">দাবিটি সম্পূর্ণ মিথ্যা</span>
                              </button>

                              {/* Accept */}
                              <button
                                onClick={handleHumanSkip}
                                className="py-3 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-95 text-white font-black text-xs sm:text-sm shadow-xl border border-emerald-400/50 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all"
                              >
                                <div className="flex items-center gap-1.5">
                                  <CheckCircle className="w-4 h-4 text-emerald-200" />
                                  <span>মেনে নিন (ACCEPT) ✓</span>
                                </div>
                                <span className="text-[9px] text-emerald-200 font-normal">আক্রমণ স্বীকার করলাম</span>
                              </button>
                            </div>

                            {/* Block with Dosyu Sordar if steal target */}
                            {pendingAction?.actionType === 'dosyu_steal' && selectedCharacters.includes('dosyu_sordar') && (
                              <button
                                onClick={handleHumanBlock}
                                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs sm:text-sm shadow-xl border border-cyan-400/50 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
                              >
                                <Shield className="w-4 h-4 text-cyan-200" />
                                <span>দস্যু সর্দারে ব্লক করুন (BLOCK) 🛡️</span>
                              </button>
                            )}
                          </div>
                        ) : hasSpecificTarget && !isHumanTarget ? (
                          /* CASE 2: Action has a specific target, but human is NOT the target (Bystander) */
                          <div className="space-y-2">
                            <div className="text-center text-xs text-slate-300">
                              আক্রমণ {targetObj?.nameBn}-এর বিরুদ্ধে। আপনি সরাসরি লক্ষ্য নন:
                            </div>

                            <div className="flex items-center gap-2">
                              {/* Skip Button (Large Primary for Bystander) */}
                              <button
                                onClick={handleHumanSkip}
                                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600 text-amber-300 font-black text-xs sm:text-sm shadow-xl border border-amber-500/40 flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
                              >
                                <ArrowRight className="w-4 h-4 text-amber-400" />
                                <span>এড়িয়ে যান (SKIP / পাস করুন) ⏭️</span>
                              </button>

                              {/* Secondary Challenge Button if bystander wants to call bluff */}
                              <button
                                onClick={handleHumanChallenge}
                                className="py-3 px-3.5 rounded-xl bg-purple-900/80 hover:bg-purple-800 text-purple-200 text-xs font-bold border border-purple-500/40 cursor-pointer active:scale-95 transition-all"
                                title="দাবি সন্দেহজনক হলে চ্যালেঞ্জ করুন"
                              >
                                চ্যালেঞ্জ ⚡
                              </button>
                            </div>
                          </div>
                        ) : (
                          /* CASE 3: General Table/Bank Action (Nawab, Sodagor, Sidhel, etc.) or Block */
                          <div className="grid grid-cols-2 gap-2.5">
                            <button
                              onClick={handleHumanChallenge}
                              className="py-3 px-3 rounded-xl bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 active:scale-95 text-white font-black text-xs sm:text-sm shadow-xl border border-purple-400/50 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all"
                            >
                              <div className="flex items-center gap-1.5">
                                <Swords className="w-4 h-4 text-yellow-300" />
                                <span>{pendingBlock ? 'ব্লকে চ্যালেঞ্জ ⚡' : 'চ্যালেঞ্জ (CHALLENGE) ⚡'}</span>
                              </div>
                              <span className="text-[9px] text-purple-200 font-normal">দাবিটি ভুয়া</span>
                            </button>

                            <button
                              onClick={handleHumanSkip}
                              className="py-3 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-95 text-white font-black text-xs sm:text-sm shadow-xl border border-emerald-400/50 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all"
                            >
                              <div className="flex items-center gap-1.5">
                                <CheckCircle className="w-4 h-4 text-emerald-200" />
                                <span>{pendingBlock ? 'ব্লক মেনে নিন ✓' : 'মেনে নিন (ACCEPT) ✓'}</span>
                              </div>
                              <span className="text-[9px] text-emerald-200 font-normal">কোনো বাধা নেই</span>
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Game Over Victory / Defeat Overlay */}
      {gamePhase === 'game_over' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative z-10 w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-400 rounded-3xl p-6 text-center shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center mx-auto mb-3">
              <span className="text-3xl">{winner?.isHuman ? '🏆' : '💀'}</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-black text-amber-300 font-bengali">
              {winner?.isHuman ? 'অভিনন্দন! আপনি বিজয়ী!' : 'খেলা সমাপ্ত!'}
            </h3>
            <p className="text-sm text-slate-300 font-bengali mt-2">
              {winner?.isHuman
                ? 'আপনার বুদ্ধিমত্তা ও অসাধারণ চালবাজির কাছে রাজদরবারের সবাই পরাস্ত হয়েছে!'
                : `বিজয়ী হয়েছেন: ${winner?.nameBn}`}
            </p>

            <div className="my-4 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 font-bengali">
              মোট রাউন্ড চলেছে: {turnCount} পর্ব
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <button
                onClick={onRestart}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs sm:text-sm font-bengali shadow-xl transition-all cursor-pointer"
              >
                আবার খেলুন
              </button>
              <button
                onClick={onBackToPlatform}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm font-bengali transition-all cursor-pointer"
              >
                খেলাঘর হোমে ফিরুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Purpose-built miniature card for AI Opponent Pods
interface AIPodCardProps {
  card: Card;
  onInspect: (card: Card) => void;
}

const AIPodCard: React.FC<AIPodCardProps> = ({ card, onInspect }) => {
  if (card.isRevealed) {
    const char = ALL_CHARACTERS[card.characterId];
    return (
      <div
        onClick={() => onInspect(card)}
        className="relative w-7 h-10 sm:w-9 sm:h-13 rounded-md overflow-hidden border border-red-500/80 bg-slate-950 shadow-md cursor-pointer hover:scale-105 transition-all select-none group"
        title={`${char?.nameBn} (মৃত/খারিজ) - ক্লিক করে বিবরণ দেখুন`}
      >
        <img
          src={char?.image}
          alt={char?.nameBn}
          className="w-full h-full object-cover grayscale opacity-50"
        />
        <div className="absolute inset-0 bg-red-950/50 flex items-center justify-center">
          <span className="text-xs font-black text-red-400">✕</span>
        </div>
      </div>
    );
  }

  // Active hidden secret card: miniature royal playing card
  return (
    <div
      className="relative w-7 h-10 sm:w-9 sm:h-13 rounded-md overflow-hidden border border-amber-400/90 shadow-md bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 flex flex-col items-center justify-between p-0.5 select-none transition-transform hover:scale-105"
      title="গোপন কার্ড (Secret Card)"
    >
      <div className="absolute inset-0.5 rounded-[4px] border border-dashed border-amber-400/30 pointer-events-none" />
      <span className="text-[6px] text-amber-300/80 leading-none self-start ml-0.5 mt-0.5 select-none">❖</span>
      <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full border border-amber-400/70 bg-slate-950/80 flex items-center justify-center shadow-inner my-auto z-10">
        <Sparkles className="w-2 h-2 sm:w-2.5 sm:h-2.5 text-amber-300 fill-amber-300/40" />
      </div>
      <span className="text-[6px] text-amber-300/80 leading-none self-end mr-0.5 mb-0.5 select-none">❖</span>
    </div>
  );
};

// Compact AI Pod without personality titles and with clearly visible miniature cards
interface AIPodProps {
  player: Player;
  isActiveTurn: boolean;
  isTargeted?: boolean;
  isDealing?: boolean;
  responseStatus?: 'pending' | 'skipped' | 'challenged' | 'blocked';
  onInspectCard: (card: Card) => void;
}

const AIPod: React.FC<AIPodProps> = ({
  player,
  isActiveTurn,
  isTargeted,
  isDealing,
  responseStatus,
  onInspectCard,
}) => {
  return (
    <div
      className={`p-2 rounded-2xl transition-all duration-300 max-w-[200px] sm:max-w-[240px] w-full ${
        player.isEliminated
          ? 'bg-slate-950/60 border border-slate-800 opacity-40 grayscale'
          : isActiveTurn
          ? 'bg-slate-900/95 border-2 border-cyan-400 ring-4 ring-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.4)] scale-[1.02]'
          : isTargeted
          ? 'bg-rose-950/60 border-2 border-rose-500 ring-4 ring-rose-500/40 shadow-[0_0_25px_rgba(244,63,94,0.35)] animate-pulse scale-[1.02]'
          : isDealing
          ? 'bg-amber-500/10 border border-amber-400 animate-pulse'
          : 'bg-slate-900/70 border border-slate-800'
      }`}
    >
      <div className="flex items-center justify-between gap-1.5">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="text-base sm:text-xl shrink-0">{player.avatar}</span>
          <div className="min-w-0">
            <div className="font-extrabold text-[11px] sm:text-xs text-slate-100 font-bengali flex items-center gap-1 truncate">
              <span className="truncate">{player.nameBn}</span>
              {player.isOnline === false && (
                <span className="text-[7px] px-1 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bengali shrink-0">
                  অফলাইন (বট)
                </span>
              )}
              {isActiveTurn && (
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping inline-block shrink-0" />
              )}
            </div>
            {responseStatus && (
              <span
                className={`inline-block px-1.5 py-0.1 rounded text-[8px] font-bengali font-bold border mt-0.5 ${
                  responseStatus === 'pending'
                    ? 'bg-amber-950/80 text-amber-300 border-amber-500/40 animate-pulse'
                    : responseStatus === 'skipped'
                    ? 'bg-slate-800 text-slate-400 border-slate-700'
                    : 'bg-purple-900 text-purple-200 border-purple-500'
                }`}
              >
                {responseStatus === 'pending'
                  ? 'ভাবছে...'
                  : responseStatus === 'skipped'
                  ? 'পাস ✓'
                  : responseStatus === 'challenged'
                  ? 'চ্যালেঞ্জ! ⚡'
                  : 'ব্লক! 🛡️'}
              </span>
            )}
          </div>
        </div>

        {/* Coins & Lives count */}
        <div className="flex flex-col items-end shrink-0">
          <div className="flex items-center gap-1 text-[10px] font-mono font-bold text-amber-300 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20">
            <Coins className="w-2.5 h-2.5 text-amber-400" />
            <span>{player.coins}</span>
          </div>

          <div className="flex items-center gap-1 mt-0.5 text-[10px] text-red-300 font-bengali font-bold">
            <span>{player.cards.filter((c) => !c.isRevealed).length}</span>
            <Heart className="w-2.5 h-2.5 text-red-500 fill-red-500" />
          </div>
        </div>
      </div>

      {/* Cards: Real miniature cards clearly visible on all screen sizes */}
      <div className="mt-1.5 flex items-center justify-center gap-1.5 min-h-[42px]">
        {player.cards.length === 0 ? (
          <span className="text-[9px] text-slate-500 font-bengali">হাত খালি</span>
        ) : (
          player.cards.map((card) => (
            <AIPodCard key={card.uid} card={card} onInspect={onInspectCard} />
          ))
        )}
      </div>
    </div>
  );
};
