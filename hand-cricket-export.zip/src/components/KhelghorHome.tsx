import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Play,
  Volume2,
  VolumeX,
  BookOpen,
  Crown,
  Layers,
  ArrowRight,
  Wifi,
  Users,
  Flame,
} from 'lucide-react';
import { sound } from '../utils/sound';
import { PWAInstallButton, OfflineStatusIndicator } from './common/PWAControls';
import { NearbyMultiplayerTest } from './multiplayer/NearbyMultiplayerTest';
import { HandGestureIllustration } from '../handcricket/components/HandGestureIllustration';

interface GameStatsItem {
  totalPlays: number;
  totalUniquePlayers: number;
}

interface AllGameStats {
  calbaji: GameStatsItem;
  borderpass: GameStatsItem;
  shadowdetective: GameStatsItem;
  handcricket: GameStatsItem;
}

interface KhelghorHomeProps {
  onSelectGame: (
    gameId: 'calbaji' | 'borderpass' | 'shadowdetective' | 'handcricket'
  ) => void;
  onOpenRules: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const KhelghorHome: React.FC<KhelghorHomeProps> = ({
  onSelectGame,
  onOpenRules,
  soundEnabled,
  onToggleSound,
}) => {
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [stats, setStats] = useState<AllGameStats>({
    calbaji: { totalPlays: 18, totalUniquePlayers: 12 },
    borderpass: { totalPlays: 24, totalUniquePlayers: 15 },
    shadowdetective: { totalPlays: 32, totalUniquePlayers: 19 },
    handcricket: { totalPlays: 0, totalUniquePlayers: 0 },
  });

  useEffect(() => {
    fetch('/api/stats')
      .then((res) => {
        if (res.ok) return res.json();
        throw new Error('Stats fetch error');
      })
      .then((data) => {
        if (data && data.calbaji && data.borderpass && data.shadowdetective) {
          setStats({
            calbaji: data.calbaji,
            borderpass: data.borderpass,
            shadowdetective: data.shadowdetective,
            handcricket: data.handcricket || { totalPlays: 0, totalUniquePlayers: 0 },
          });
        }
      })
      .catch((err) => {
        console.warn('Could not fetch server stats:', err);
      });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-[#0a0f1d] to-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-black relative overflow-x-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-b from-indigo-900/20 via-purple-900/10 to-transparent blur-3xl pointer-events-none" />

      {/* Platform Header */}
      <header className="relative z-20 px-4 py-3 sm:px-8 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* KHELGHOR Platform Logo */}
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-600 via-purple-600 to-amber-500 p-0.5 shadow-lg shadow-indigo-600/30">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Gamepad2 className="w-5 h-5 text-amber-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl font-black tracking-tight text-white font-bengali">
                খেলাঘর
              </span>
              <span className="text-[10px] tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono font-bold uppercase">
                KHELGHOR
              </span>
            </div>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* PWA Install Button (Chromium prompt or iOS Safari guide) */}
          <PWAInstallButton />

          {/* Nearby Connection Diagnostics */}
          <button
            onClick={() => setShowDiagnostics(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-cyan-300 hover:border-cyan-400/50 hover:bg-slate-800 text-xs sm:text-sm font-bengali transition-all cursor-pointer shadow"
            title="কাছাকাছি অফলাইন মাল্টিপ্লেয়ার পরীক্ষা"
          >
            <Wifi className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">কানেকশন টেস্ট</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenRules();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-amber-300 hover:border-amber-400/50 hover:bg-slate-800 text-xs sm:text-sm font-bengali transition-all cursor-pointer shadow"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">খেলার নিয়ম</span>
            <span className="sm:hidden">নিয়ম</span>
          </button>

          <button
            onClick={onToggleSound}
            className="p-2 rounded-xl bg-slate-900 border border-slate-700/80 text-amber-200 hover:text-white hover:border-slate-600 transition-all cursor-pointer shadow"
            title="শব্দ (Sound)"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>
        </div>
      </header>

      {/* Offline Status Toast */}
      <OfflineStatusIndicator />

      {/* Diagnostics Modal */}
      <NearbyMultiplayerTest
        isOpen={showDiagnostics}
        onClose={() => setShowDiagnostics(false)}
      />

      {/* Main Game Grid */}
      <main className="relative z-10 max-w-5xl mx-auto px-4 py-8 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div className="text-center max-w-xl mx-auto mb-8 sm:mb-10">
          <h1 className="text-2xl sm:text-4xl font-black text-white font-bengali tracking-tight">
            গেম লাইব্রেরি
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 font-bengali">
            খেলা নির্বাচন করুন
          </p>
        </div>

        {/* Game Tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
          {/* Game Tile 1: CALBAJI */}
          <div
            onClick={() => {
              sound.playClick();
              onSelectGame('calbaji');
            }}
            className="group relative rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 bg-gradient-to-b from-[#1c1214] via-[#120b0e] to-slate-950 border-2 border-amber-500/60 hover:border-amber-400 hover:shadow-2xl hover:shadow-amber-500/20 hover:-translate-y-1 flex flex-col"
          >
            {/* Cover Visual */}
            <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-gradient-to-b from-amber-950/30 to-slate-950 flex items-center justify-center p-4">
              <div className="relative flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
                <img
                  src="/assets/cards/Regal_Nawab_Royalty_Card_796aa33b.png"
                  alt="নবাব"
                  className="w-18 h-26 sm:w-20 sm:h-28 object-contain rounded-xl shadow-xl -rotate-12 -mr-6 border border-amber-500/40"
                />
                <img
                  src="/assets/cards/Moonlit_Bengali_Assassin_Card_754927cd.png"
                  alt="গুপ্তঘাতক"
                  className="w-22 h-30 sm:w-24 sm:h-32 object-contain rounded-xl shadow-2xl z-10 border-2 border-amber-400"
                />
                <img
                  src="/assets/cards/Sodagor_s_Treasure_Harbor_Card_de67ed0b.png"
                  alt="সদাগর"
                  className="w-18 h-26 sm:w-20 sm:h-28 object-contain rounded-xl shadow-xl rotate-12 -ml-6 border border-amber-500/40"
                />
              </div>
            </div>

            {/* Game Info */}
            <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between bg-slate-950/90 border-t border-amber-500/20">
              <div>
                <span className="text-[11px] font-mono font-bold text-amber-400 uppercase tracking-wider block">
                  CALBAJI
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-amber-300 font-bengali mt-0.5 group-hover:text-amber-200 transition-colors">
                  চালবাজি
                </h3>
                <p className="text-xs text-slate-400 font-bengali mt-0.5">
                  ধোঁকা, প্রভাব ও কৌশলগত সামাজিক ব্লাফ খেলা
                </p>

                {/* Persistent Live Statistics */}
                <div className="mt-3 flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-950/40 border border-amber-500/30 text-[11px] text-amber-300 font-mono">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>মোট খেলা: <strong>{stats.calbaji.totalPlays}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700/80 text-[11px] text-slate-300 font-mono">
                    <Users className="w-3.5 h-3.5 text-amber-400" />
                    <span>খেলোয়াড়: <strong>{stats.calbaji.totalUniquePlayers}</strong></span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-amber-300 font-bengali font-bold flex items-center gap-1">
                  খেলুন
                </span>
                <div className="w-7 h-7 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-md group-hover:scale-110 group-hover:bg-amber-400 transition-all">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Game Tile 2: BORDER PASS */}
          <div
            onClick={() => {
              sound.playClick();
              onSelectGame('borderpass');
            }}
            className="group relative rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 bg-gradient-to-b from-[#101428] via-[#0b0e1d] to-slate-950 border-2 border-indigo-500/60 hover:border-indigo-400 hover:shadow-2xl hover:shadow-indigo-500/20 hover:-translate-y-1 flex flex-col"
          >
            {/* Cover Visual using authentic uploaded card assets */}
            <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-gradient-to-b from-indigo-950/40 to-slate-950 flex items-center justify-center p-4">
              <div className="relative flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
                <img
                  src="/assets/borderpass/gold_bullion.png"
                  alt="সোনার বার"
                  className="w-18 h-26 sm:w-20 sm:h-28 object-contain rounded-xl shadow-xl -rotate-12 -mr-6 border border-amber-500/40"
                />
                <img
                  src="/assets/borderpass/diplomatic_immunity.png"
                  alt="ডিপ্লোম্যাটিক পাসপোর্ট"
                  className="w-22 h-30 sm:w-24 sm:h-32 object-contain rounded-xl shadow-2xl z-10 border-2 border-indigo-400"
                />
                <img
                  src="/assets/borderpass/branded_watch.png"
                  alt="ঘড়ি"
                  className="w-18 h-26 sm:w-20 sm:h-28 object-contain rounded-xl shadow-xl rotate-12 -ml-6 border border-emerald-500/40"
                />
              </div>
            </div>

            {/* Game Info */}
            <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between bg-slate-950/90 border-t border-indigo-500/20">
              <div>
                <span className="text-[11px] font-mono font-bold text-indigo-400 uppercase tracking-wider block">
                  BORDER PASS
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-indigo-200 font-bengali mt-0.5 group-hover:text-white transition-colors">
                  বর্ডার পাস
                </h3>
                <p className="text-xs text-slate-400 font-bengali mt-0.5">
                  কাস্টমস ব্লাফ ও স্ট্র্যাটেজি গেম
                </p>

                {/* Persistent Live Statistics */}
                <div className="mt-3 flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-950/40 border border-indigo-500/30 text-[11px] text-indigo-300 font-mono">
                    <Flame className="w-3.5 h-3.5 text-indigo-400" />
                    <span>মোট খেলা: <strong>{stats.borderpass.totalPlays}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700/80 text-[11px] text-slate-300 font-mono">
                    <Users className="w-3.5 h-3.5 text-indigo-400" />
                    <span>খেলোয়াড়: <strong>{stats.borderpass.totalUniquePlayers}</strong></span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-indigo-300 font-bengali font-bold flex items-center gap-1">
                  খেলুন
                </span>
                <div className="w-7 h-7 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-md group-hover:scale-110 group-hover:bg-indigo-400 transition-all">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Game Tile 3: SHADOW DETECTIVE */}
          <div
            onClick={() => {
              sound.playClick();
              onSelectGame('shadowdetective');
            }}
            className="group relative rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 bg-gradient-to-b from-[#091a24] via-[#061118] to-slate-950 border-2 border-cyan-500/60 hover:border-cyan-400 hover:shadow-2xl hover:shadow-cyan-500/20 hover:-translate-y-1 flex flex-col"
          >
            {/* Cover Visual using authentic uploaded noir card assets */}
            <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-gradient-to-b from-cyan-950/40 to-slate-950 flex items-center justify-center p-4">
              <div className="relative flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
                <img
                  src="/assets/aistudio/Silenced_Pistol_Noir_Card_b979f8c9.png"
                  alt="সাইলেন্সড পিস্তল"
                  className="w-18 h-26 sm:w-20 sm:h-28 object-contain rounded-xl shadow-xl -rotate-12 -mr-6 border border-cyan-500/40"
                />
                <img
                  src="/assets/aistudio/Investigator_Robin_Bengali_Character_Card_f976d6f4.png"
                  alt="তদন্তকারী রবিন"
                  className="w-22 h-30 sm:w-24 sm:h-32 object-contain rounded-xl shadow-2xl z-10 border-2 border-cyan-400"
                />
                <img
                  src="/assets/aistudio/Toxic_Green_Gas_Vial_Card_8f6af168.png"
                  alt="বিষাক্ত গ্যাস"
                  className="w-18 h-26 sm:w-20 sm:h-28 object-contain rounded-xl shadow-xl rotate-12 -ml-6 border border-amber-500/40"
                />
              </div>
            </div>

            {/* Game Info */}
            <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between bg-slate-950/90 border-t border-cyan-500/20">
              <div>
                <span className="text-[11px] font-mono font-bold text-cyan-400 uppercase tracking-wider block">
                  SHADOW DETECTIVE
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-cyan-200 font-bengali mt-0.5 group-hover:text-white transition-colors">
                  শ্যাডো ডিটেক্টিভ: নিশিপুর
                </h3>
                <p className="text-xs text-slate-400 font-bengali mt-0.5">
                  নিশিপুরের রহস্যময় অপরাধ তদন্ত ও সোশ্যাল ডিডাকশন গেম
                </p>

                {/* Persistent Live Statistics */}
                <div className="mt-3 flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-[11px] text-cyan-300 font-mono">
                    <Flame className="w-3.5 h-3.5 text-cyan-400" />
                    <span>মোট খেলা: <strong>{stats.shadowdetective.totalPlays}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700/80 text-[11px] text-slate-300 font-mono">
                    <Users className="w-3.5 h-3.5 text-cyan-400" />
                    <span>খেলোয়াড়: <strong>{stats.shadowdetective.totalUniquePlayers}</strong></span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-cyan-300 font-bengali font-bold flex items-center gap-1">
                  তদন্তে যোগ দিন
                </span>
                <div className="w-7 h-7 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center shadow-md group-hover:scale-110 group-hover:bg-cyan-400 transition-all">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Game Tile 4: HAND CRICKET */}
          <div
            onClick={() => {
              sound.playClick();
              onSelectGame('handcricket');
            }}
            className="group relative rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 bg-gradient-to-b from-[#071f18] via-[#051410] to-slate-950 border-2 border-emerald-500/60 hover:border-emerald-400 hover:shadow-2xl hover:shadow-emerald-500/20 hover:-translate-y-1 flex flex-col"
          >
            {/* Cover Visual using semi-realistic Hand Gesture Illustrations */}
            <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-gradient-to-b from-emerald-950/40 to-slate-950 flex items-center justify-center p-4">
              <div className="relative flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
                <div className="w-18 h-26 sm:w-20 sm:h-28 rounded-xl bg-slate-900/95 shadow-xl -rotate-12 -mr-5 border border-emerald-500/40 flex flex-col items-center justify-center p-1.5">
                  <HandGestureIllustration gestureId="4A" size="sm" />
                  <span className="text-[10px] font-mono font-bold text-emerald-300 mt-1">
                    4 RUNS
                  </span>
                </div>

                <div className="w-22 h-30 sm:w-24 sm:h-32 rounded-xl bg-slate-900 shadow-2xl z-10 border-2 border-emerald-400 flex flex-col items-center justify-center p-2">
                  <HandGestureIllustration gestureId="6A" size="md" />
                  <span className="text-[11px] font-mono font-black text-amber-400 mt-1">
                    6 SIXER!
                  </span>
                </div>

                <div className="w-18 h-26 sm:w-20 sm:h-28 rounded-xl bg-slate-900/95 shadow-xl rotate-12 -ml-5 border border-amber-500/40 flex flex-col items-center justify-center p-1.5">
                  <HandGestureIllustration gestureId="1A" size="sm" />
                  <span className="text-[10px] font-mono font-bold text-amber-300 mt-1">
                    1 RUN
                  </span>
                </div>
              </div>
            </div>

            {/* Game Info */}
            <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between bg-slate-950/90 border-t border-emerald-500/20">
              <div>
                <span className="text-[11px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                  HAND CRICKET
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-emerald-200 font-bengali mt-0.5 group-hover:text-white transition-colors">
                  হ্যান্ড ক্রিকেট
                </h3>
                <p className="text-xs text-slate-400 font-bengali mt-0.5">
                  এআই, লাইভ মাল্টিপ্লেয়ার রুম, টেস্ট ম্যাচ ও পূর্ণাঙ্গ ক্যারিয়ার মোড
                </p>

                {/* Persistent Live Statistics */}
                <div className="mt-3 flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-[11px] text-emerald-300 font-mono">
                    <Flame className="w-3.5 h-3.5 text-emerald-400" />
                    <span>মোট খেলা: <strong>{stats.handcricket.totalPlays}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700/80 text-[11px] text-slate-300 font-mono">
                    <Users className="w-3.5 h-3.5 text-emerald-400" />
                    <span>খেলোয়াড়: <strong>{stats.handcricket.totalUniquePlayers}</strong></span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-emerald-300 font-bengali font-bold flex items-center gap-1">
                  মাঠে নামুন
                </span>
                <div className="w-7 h-7 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-md group-hover:scale-110 group-hover:bg-emerald-400 transition-all">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-20 px-4 py-3 border-t border-slate-800/80 bg-slate-950/80 text-center text-xs text-slate-400 font-bengali flex items-center justify-center gap-2">
        <span>খেলাঘর গেমিং প্ল্যাটফর্ম</span>
        <span className="text-slate-600">•</span>
        <span className="font-semibold text-cyan-400 font-mono">RI Rahat</span>
      </footer>
    </div>
  );
};
