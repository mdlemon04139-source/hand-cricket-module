import React, { useState } from 'react';
import { Card, CharacterId } from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';
import { CardBack } from './CardBack';
import { sound } from '../utils/sound';
import { Rotate3D, Coins, Shield, Swords, AlertCircle } from 'lucide-react';

interface CardFlipProps {
  card?: Card;
  characterId?: CharacterId;
  isDead?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  canFlip?: boolean; // only human hand cards can flip
}

export const CardFlip: React.FC<CardFlipProps> = ({
  card,
  characterId,
  isDead = false,
  className = '',
  size = 'md',
  canFlip = true,
}) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const activeCharId = characterId || card?.characterId;
  const charDef = activeCharId ? ALL_CHARACTERS[activeCharId] : null;
  const dead = isDead || !!card?.isRevealed;

  const handleCardClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!canFlip || dead) return;
    sound.playCardDeal();
    setIsFlipped(!isFlipped);
  };

  const sizeClasses = {
    sm: 'w-20 sm:w-24',
    md: 'w-26 sm:w-30 md:w-36',
    lg: 'w-32 sm:w-36 md:w-44 lg:w-48',
  }[size];

  if (!charDef) {
    return <CardBack isDead={dead} className={`${sizeClasses} ${className}`} />;
  }

  return (
    <div
      onClick={handleCardClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          handleCardClick(e as unknown as React.MouseEvent);
        }
      }}
      aria-label={`${charDef.nameBn} কার্ড - উল্টাতে ক্লিক করুন`}
      className={`group relative select-none cursor-pointer transition-transform duration-200 hover:-translate-y-1 ${sizeClasses} ${className}`}
      style={{
        aspectRatio: '5/7',
        perspective: '1000px',
      }}
    >
      {/* 3D Flip Container */}
      <div
        className="w-full h-full relative transition-transform duration-500 rounded-2xl shadow-xl"
        style={{
          transformStyle: 'preserve-3d',
          transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
        }}
      >
        {/* FRONT SIDE: Approved Character Artwork with Transparent Background */}
        <div
          className={`absolute inset-0 w-full h-full rounded-2xl overflow-hidden bg-slate-950/80 border border-amber-500/40 shadow-2xl flex items-center justify-center ${
            dead ? 'grayscale opacity-50' : ''
          }`}
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
          }}
        >
          <img
            src={charDef.image}
            alt={charDef.nameBn}
            className="w-full h-full object-contain pointer-events-none drop-shadow-md"
            loading="eager"
          />

          {/* Flip Hint Icon on Hover (Touch friendly) */}
          {canFlip && !dead && (
            <div className="absolute top-1.5 right-1.5 p-1 rounded-full bg-slate-900/80 text-amber-300 border border-amber-500/30 opacity-80 group-hover:opacity-100 transition-opacity backdrop-blur-xs">
              <Rotate3D className="w-3.5 h-3.5" />
            </div>
          )}

          {/* Dead Stamp */}
          {dead && (
            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-2 pointer-events-none">
              <div className="border-2 border-red-500 text-red-400 font-bold px-2 py-0.5 rounded rotate-[-12deg] tracking-wider uppercase text-xs font-bengali shadow-lg">
                খারিজ / মৃত
              </div>
            </div>
          )}
        </div>

        {/* REVERSE SIDE: Clear Bengali & English Ability/Rule Details */}
        <div
          className="absolute inset-0 w-full h-full rounded-2xl p-2.5 sm:p-3 bg-gradient-to-b from-[#1a111a] via-[#120a14] to-slate-950 border-2 border-amber-400/80 shadow-2xl flex flex-col justify-between text-left"
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
          }}
        >
          <div>
            {/* Header */}
            <div className="flex items-center justify-between pb-1 border-b border-amber-500/20">
              <span className="font-extrabold text-xs sm:text-sm text-amber-300 font-bengali">
                {charDef.nameBn}
              </span>
              <span className="text-[9px] font-mono text-slate-400 uppercase">
                {charDef.nameEn}
              </span>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-1 my-1.5 text-[9px] sm:text-[10px]">
              <div className="p-1 rounded bg-slate-900/80 border border-slate-800 flex items-center gap-1">
                <Coins className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                <span className="text-amber-200 truncate">
                  {charDef.coinCost > 0 ? `${charDef.coinCost} খরচ` : '০ খরচ'}
                </span>
              </div>
              <div className="p-1 rounded bg-slate-900/80 border border-slate-800 flex items-center gap-1">
                <Swords className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                <span className="text-emerald-200 truncate">
                  {charDef.coinGain > 0 ? `+${charDef.coinGain} লাভ` : 'বিশেষ চাল'}
                </span>
              </div>
            </div>

            {/* Ability Description */}
            <div className="p-1.5 rounded-lg bg-amber-950/20 border border-amber-500/20 text-[10px] sm:text-[11px] font-bengali text-slate-200 leading-tight">
              {charDef.descriptionBn}
            </div>

            {/* Block info if any */}
            {charDef.canBlock && charDef.canBlock.length > 0 && (
              <div className="mt-1 flex items-center gap-1 text-[9px] text-emerald-300 font-bengali">
                <Shield className="w-3 h-3 text-emerald-400 shrink-0" />
                <span>চুরি ও ডাকাতি প্রতিরোধ করতে পারে</span>
              </div>
            )}
          </div>

          {/* Footer flip back prompt */}
          <div className="pt-1 border-t border-amber-500/20 flex items-center justify-between text-[9px] text-amber-400/80 font-bengali">
            <span>ক্লিক করে ছবি দেখুন</span>
            <Rotate3D className="w-3 h-3" />
          </div>
        </div>
      </div>
    </div>
  );
};
