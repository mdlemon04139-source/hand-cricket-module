import {
  CardDefinition,
  CardInstance,
  CardTypeId,
  DutyFreeCardId,
  GamePhase,
  InspectionResult,
  NegotiationState,
  BorderPassPlayer,
  BorderPassPlayerPrivate,
  BorderPassRoomPublicState,
  SettlementEvent,
  SuitcaseContent,
  SuitcaseDeclaration,
  VaultItem,
} from '../types/borderpass';
import { BORDER_PASS_CARDS, DUTY_FREE_OPTIONS } from '../data/borderpassAssets';

export class BorderPassEngine {
  /**
   * Generates the canonical 81-card deck with unique instance IDs.
   */
  public static createCanonicalDeck(): CardInstance[] {
    const deck: CardInstance[] = [];
    const keys = Object.keys(BORDER_PASS_CARDS) as CardTypeId[];

    for (const key of keys) {
      const def = BORDER_PASS_CARDS[key];
      for (let i = 1; i <= def.count; i++) {
        deck.push({
          instanceId: `bp_${key}_${i}`,
          typeId: key,
        });
      }
    }

    if (deck.length !== 81) {
      throw new Error(`Deck creation error: Expected 81 cards, got ${deck.length}`);
    }

    return deck;
  }

  /**
   * Secure Fisher-Yates shuffle algorithm.
   */
  public static shuffleDeck<T>(items: T[]): T[] {
    const copy = [...items];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  /**
   * Calculate total rounds based on player count (2 rounds per player).
   */
  public static calculateTotalRounds(playerCount: number): number {
    return playerCount * 2;
  }

  /**
   * Determine the Customs Officer for a given round (1-indexed).
   * Clockwise rotation: player index = (round - 1) % playerCount.
   * Every player serves as officer exactly 2 times.
   */
  public static getOfficerForRound(players: BorderPassPlayer[], roundNumber: number): BorderPassPlayer {
    const index = (roundNumber - 1) % players.length;
    return players[index];
  }

  /**
   * Initialize a new player object with $500 cash, empty vault, and initial stats.
   */
  public static initializePlayer(
    id: string,
    name: string,
    avatar: string,
    seatNumber: number,
    isBot: boolean = false,
    botDifficulty?: 'easy' | 'normal' | 'hard'
  ): BorderPassPlayer {
    return {
      id,
      name,
      avatar,
      isBot,
      botDifficulty: isBot ? (botDifficulty || 'normal') : undefined,
      seatNumber,
      cash: 500,
      vault: [],
      vaultScoreAdjustment: 0,
      effectiveVaultValue: 0,
      netWorth: 500,
      role: 'passenger',
      officerTurnsCompleted: 0,
      isReady: false,
      hasPacked: false,
      handCount: 0,
      bribesPaid: 0,
      bribesReceived: 0,
      finesPaid: 0,
      compensationReceived: 0,
    };
  }

  /**
   * Deal initial 5 cards to each player from the draw deck.
   */
  public static dealInitialHands(
    players: BorderPassPlayer[],
    privateStore: Map<string, BorderPassPlayerPrivate>,
    drawDeck: CardInstance[]
  ): { drawDeck: CardInstance[] } {
    let currentDeck = [...drawDeck];

    for (const player of players) {
      const hand = currentDeck.slice(0, 5);
      currentDeck = currentDeck.slice(5);

      privateStore.set(player.id, {
        hand,
        suitcase: undefined,
      });

      player.handCount = hand.length;
    }

    return { drawDeck: currentDeck };
  }

  /**
   * Replenish each player's hand up to 5 cards at round start.
   * Only draws needed count. Reshuffles discard pile if draw deck is exhausted.
   */
  public static replenishHands(
    players: BorderPassPlayer[],
    privateStore: Map<string, BorderPassPlayerPrivate>,
    drawDeck: CardInstance[],
    discardPile: CardInstance[]
  ): { drawDeck: CardInstance[]; discardPile: CardInstance[] } {
    let deck = [...drawDeck];
    let discard = [...discardPile];

    for (const player of players) {
      const priv = privateStore.get(player.id);
      if (!priv) continue;

      const needed = 5 - priv.hand.length;
      if (needed <= 0) continue;

      for (let i = 0; i < needed; i++) {
        if (deck.length === 0) {
          if (discard.length === 0) {
            // No cards left anywhere to draw
            break;
          }
          deck = this.shuffleDeck(discard);
          discard = [];
        }

        const drawn = deck.shift();
        if (drawn) {
          priv.hand.push(drawn);
        }
      }

      player.handCount = priv.hand.length;
    }

    return { drawDeck: deck, discardPile: discard };
  }

  /**
   * Validates and submits a passenger's suitcase packing.
   */
  public static packSuitcase(
    player: BorderPassPlayer,
    priv: BorderPassPlayerPrivate,
    cardInstanceIds: string[],
    declaration: SuitcaseDeclaration
  ): { success: boolean; error?: string } {
    if (player.role === 'officer') {
      return { success: false, error: 'কাস্টমস অফিসার স্যুটকেস প্যাক করতে পারবেন না।' };
    }

    if (cardInstanceIds.length < 1 || cardInstanceIds.length > 4) {
      return { success: false, error: 'স্যুটকেসে ১ থেকে ৪টি কার্ড বেছে নিন।' };
    }

    // Check if player owns all chosen cards
    const handMap = new Map(priv.hand.map((c) => [c.instanceId, c]));
    const chosenCards: CardInstance[] = [];

    for (const id of cardInstanceIds) {
      const card = handMap.get(id);
      if (!card) {
        return { success: false, error: 'নির্বাচিত কার্ড আপনার হাতে নেই।' };
      }
      chosenCards.push(card);
    }

    // Validate declaration
    if (!DUTY_FREE_OPTIONS.includes(declaration.declaredItem)) {
      return { success: false, error: 'ঘোষণায় একটি বৈধ ডিউটি-ফ্রি আইটেম নির্বাচন করুন।' };
    }

    if (declaration.declaredQuantity !== chosenCards.length) {
      return {
        success: false,
        error: `ঘোষিত পরিমাণ (${declaration.declaredQuantity}) অবশ্যই স্যুটকেসের মোট কার্ড সংখ্যার (${chosenCards.length}) সমান হতে হবে।`,
      };
    }

    if (declaration.bribeOffer < 0 || declaration.bribeOffer > player.cash) {
      return {
        success: false,
        error: `ঘুষের প্রস্তাব $০ থেকে আপনার উপলব্ধ ক্যাশ ($${player.cash}) এর মধ্যে হতে হবে।`,
      };
    }

    // Remove chosen cards from hand
    const remainingHand = priv.hand.filter((c) => !cardInstanceIds.includes(c.instanceId));
    priv.hand = remainingHand;
    player.handCount = remainingHand.length;

    // Place into private suitcase
    priv.suitcase = {
      cards: chosenCards,
      declaration,
      submittedAt: Date.now(),
    };
    player.hasPacked = true;

    return { success: true };
  }

  /**
   * Auto-pack empty suitcase on timeout if player did not submit.
   */
  public static autoPackEmpty(player: BorderPassPlayer, priv: BorderPassPlayerPrivate): void {
    priv.suitcase = {
      cards: [],
      declaration: {
        declaredItem: 'duty_free_chocolates',
        declaredQuantity: 0,
        bribeOffer: 0,
      },
      submittedAt: Date.now(),
    };
    player.hasPacked = true;
  }

  /**
   * Resolve PASS action by Customs Officer on a passenger's suitcase.
   */
  public static resolvePassAction(
    officer: BorderPassPlayer,
    passenger: BorderPassPlayer,
    priv: BorderPassPlayerPrivate,
    acceptBribe: boolean,
    roundNumber: number,
    discardPile: CardInstance[]
  ): {
    settlement: SettlementEvent;
    discardPile: CardInstance[];
  } {
    const suitcase = priv.suitcase;
    if (!suitcase) {
      throw new Error('Suitcase not found for passenger');
    }

    let bribeTransferred = 0;
    if (acceptBribe && suitcase.declaration.bribeOffer > 0) {
      const amount = Math.min(suitcase.declaration.bribeOffer, passenger.cash);
      passenger.cash -= amount;
      officer.cash += amount;
      passenger.bribesPaid += amount;
      officer.bribesReceived += amount;
      bribeTransferred = amount;
    }

    // Check if suitcase contains Customs Clearance Seal
    const sealIndex = suitcase.cards.findIndex((c) => c.typeId === 'customs_clearance_seal');
    let sealApplied = false;
    let nextDiscard = [...discardPile];

    if (sealIndex >= 0) {
      sealApplied = true;
      nextDiscard.push(suitcase.cards[sealIndex]);
    }

    // Move all remaining cards to Passenger's Vault
    for (let i = 0; i < suitcase.cards.length; i++) {
      if (i === sealIndex) continue; // Seal consumed
      const card = suitcase.cards[i];
      const def = BORDER_PASS_CARDS[card.typeId];
      let val = def.baseVaultValue;

      // Seal boosts legal duty-free goods by +50%
      if (sealApplied && def.category === 'duty_free') {
        val = Math.floor(val * 1.5);
      }

      passenger.vault.push({
        instanceId: card.instanceId,
        typeId: card.typeId,
        baseValue: def.baseVaultValue,
        effectiveValue: val,
        sealBonusApplied: sealApplied && def.category === 'duty_free',
        roundSecured: roundNumber,
      });
    }

    // Clear suitcase
    priv.suitcase = undefined;
    this.updatePlayerNetWorth(passenger);
    this.updatePlayerNetWorth(officer);

    const settlement: SettlementEvent = {
      id: `set_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      round: roundNumber,
      passengerId: passenger.id,
      passengerName: passenger.name,
      officerId: officer.id,
      officerName: officer.name,
      action: acceptBribe ? 'pass_bribe_accepted' : 'pass_bribe_rejected',
      amountTransferred: bribeTransferred,
      finePaid: 0,
      compensationPaid: 0,
      contrabandConfiscatedCount: 0,
      descriptionBn: acceptBribe
        ? `অফিসার ${officer.name} $${bribeTransferred} ঘুষ গ্রহণ করে ${passenger.name}-এর স্যুটকেস তল্লাশি ছাড়াই পাস করেছেন।`
        : `অফিসার ${officer.name} ঘুষ প্রত্যাখ্যান করেছেন কিন্তু স্যুটকেস তল্লাশি ছাড়াই পাস করেছেন।`,
      timestamp: Date.now(),
    };

    return { settlement, discardPile: nextDiscard };
  }

  /**
   * Resolve INSPECTION action by Customs Officer.
   */
  public static resolveInspectionAction(
    officer: BorderPassPlayer,
    passenger: BorderPassPlayer,
    priv: BorderPassPlayerPrivate,
    roundNumber: number,
    discardPile: CardInstance[]
  ): {
    result: InspectionResult;
    settlement: SettlementEvent;
    discardPile: CardInstance[];
  } {
    const suitcase = priv.suitcase;
    if (!suitcase) {
      throw new Error('Suitcase not found for passenger');
    }

    const cards = [...suitcase.cards];
    const declaration = suitcase.declaration;
    let nextDiscard = [...discardPile];

    // Check honesty
    // Honest ONLY IF all cards are duty-free AND all match declared item AND count == declared quantity
    const allDutyFree = cards.every((c) => BORDER_PASS_CARDS[c.typeId].category === 'duty_free');
    const allMatchItem = cards.every((c) => c.typeId === declaration.declaredItem);
    const countMatches = cards.length === declaration.declaredQuantity;
    const isHonest = allDutyFree && allMatchItem && countMatches;

    // Check for Diplomatic Immunity Pass
    const immunityIndex = cards.findIndex((c) => c.typeId === 'diplomatic_immunity');
    const hasDiplomaticImmunity = immunityIndex >= 0;

    // Check for Customs Clearance Seal
    const sealIndex = cards.findIndex((c) => c.typeId === 'customs_clearance_seal');
    const hasSeal = sealIndex >= 0;

    let compensationPaid = 0;
    let totalFineCalculated = 0;
    let finePaidFromCash = 0;
    let fineDeficitToVault = 0;
    const confiscatedCards: CardInstance[] = [];
    const passedCards: CardInstance[] = [];

    if (isHonest) {
      // Honest Passenger!
      // Receives $150 compensation from Officer (bounded by officer's available cash)
      compensationPaid = Math.min(150, officer.cash);
      officer.cash -= compensationPaid;
      passenger.cash += compensationPaid;
      passenger.compensationReceived += compensationPaid;

      // Handle seal if present
      if (hasSeal) {
        nextDiscard.push(cards[sealIndex]);
      }

      for (let i = 0; i < cards.length; i++) {
        if (i === sealIndex) continue;
        const c = cards[i];
        const def = BORDER_PASS_CARDS[c.typeId];
        let val = def.baseVaultValue;
        if (hasSeal && def.category === 'duty_free') {
          val = Math.floor(val * 1.5);
        }

        passenger.vault.push({
          instanceId: c.instanceId,
          typeId: c.typeId,
          baseValue: def.baseVaultValue,
          effectiveValue: val,
          sealBonusApplied: hasSeal,
          roundSecured: roundNumber,
        });
        passedCards.push(c);
      }
    } else if (hasDiplomaticImmunity) {
      // Non-compliant but protected by Diplomatic Immunity Pass!
      // Consumes 1 immunity pass
      nextDiscard.push(cards[immunityIndex]);

      if (hasSeal) {
        nextDiscard.push(cards[sealIndex]);
      }

      // All cards pass safely into Vault without fines or confiscation
      for (let i = 0; i < cards.length; i++) {
        if (i === immunityIndex || i === sealIndex) continue;
        const c = cards[i];
        const def = BORDER_PASS_CARDS[c.typeId];
        let val = def.baseVaultValue;
        if (hasSeal && def.category === 'duty_free') {
          val = Math.floor(val * 1.5);
        }

        passenger.vault.push({
          instanceId: c.instanceId,
          typeId: c.typeId,
          baseValue: def.baseVaultValue,
          effectiveValue: val,
          sealBonusApplied: hasSeal && def.category === 'duty_free',
          roundSecured: roundNumber,
        });
        passedCards.push(c);
      }
    } else {
      // Smuggling or deceptive declaration WITHOUT immunity!
      if (hasSeal) {
        nextDiscard.push(cards[sealIndex]);
      }

      for (let i = 0; i < cards.length; i++) {
        if (i === sealIndex) continue;
        const c = cards[i];
        const def = BORDER_PASS_CARDS[c.typeId];

        if (def.category === 'contraband') {
          // Confiscated!
          confiscatedCards.push(c);
          nextDiscard.push(c);
          totalFineCalculated += def.seizureFine;
        } else if (def.category === 'duty_free') {
          // Legal goods safely enter vault
          let val = def.baseVaultValue;
          if (hasSeal) {
            val = Math.floor(val * 1.5);
          }
          passenger.vault.push({
            instanceId: c.instanceId,
            typeId: c.typeId,
            baseValue: def.baseVaultValue,
            effectiveValue: val,
            sealBonusApplied: hasSeal,
            roundSecured: roundNumber,
          });
          passedCards.push(c);
        } else {
          // Power card without immunity used
          nextDiscard.push(c);
        }
      }

      // Settle fine:
      // 1. Deduct as much as possible from Cash
      finePaidFromCash = Math.min(totalFineCalculated, passenger.cash);
      passenger.cash -= finePaidFromCash;
      passenger.finesPaid += finePaidFromCash;

      // 2. Deduct remaining deficit from Vault Value Score
      fineDeficitToVault = totalFineCalculated - finePaidFromCash;
      if (fineDeficitToVault > 0) {
        passenger.vaultScoreAdjustment += fineDeficitToVault;
      }
    }

    // Clear suitcase
    priv.suitcase = undefined;
    this.updatePlayerNetWorth(passenger);
    this.updatePlayerNetWorth(officer);

    let summaryBn = '';
    if (isHonest) {
      summaryBn = `সততা প্রমাণিত! ${passenger.name} কোনো চোরাচালান করেননি। ভুল তল্লাশির জন্য অফিসার $${compensationPaid} ক্ষতিপূরণ প্রদান করেছেন।`;
    } else if (hasDiplomaticImmunity) {
      summaryBn = `ডিপ্লোম্যাটিক ইমিউনিটি সক্রিয়! ${passenger.name}-এর পাসপোর্ট কার্যকর হওয়ায় সমস্ত পণ্য ও চোরাচালান নিরাপদে পার হয়েছে (কোনো জরিমানা বা বাজেয়াপ্ত হয়নি)।`;
    } else {
      summaryBn = `চোরাচালান উদঘাটিত! ${confiscatedCards.length}টি নিষিদ্ধ পণ্য বাজেয়াপ্ত করা হয়েছে। মোট জরিমানা $${totalFineCalculated} (ক্যাশ থেকে $${finePaidFromCash}, ভল্ট থেকে $${fineDeficitToVault})।`;
    }

    const result: InspectionResult = {
      passengerId: passenger.id,
      passengerName: passenger.name,
      isHonest,
      cards,
      declaration,
      hasDiplomaticImmunity,
      confiscatedCards,
      passedCards,
      compensationPaid,
      totalFineCalculated,
      finePaidFromCash,
      fineDeficitToVault,
      sealBonusApplied: hasSeal,
      summaryBn,
    };

    const settlement: SettlementEvent = {
      id: `set_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      round: roundNumber,
      passengerId: passenger.id,
      passengerName: passenger.name,
      officerId: officer.id,
      officerName: officer.name,
      action: isHonest
        ? 'inspected_honest'
        : hasDiplomaticImmunity
        ? 'inspected_immunity'
        : 'inspected_contraband',
      amountTransferred: 0,
      finePaid: totalFineCalculated,
      compensationPaid,
      contrabandConfiscatedCount: confiscatedCards.length,
      descriptionBn: summaryBn,
      timestamp: Date.now(),
    };

    return { result, settlement, discardPile: nextDiscard };
  }

  /**
   * Settle agreed negotiation counter-offer.
   * Transfers negotiated amount from Passenger to Officer and passes suitcase uninspected.
   */
  public static resolveNegotiationAgreed(
    officer: BorderPassPlayer,
    passenger: BorderPassPlayer,
    priv: BorderPassPlayerPrivate,
    agreedAmount: number,
    roundNumber: number,
    discardPile: CardInstance[]
  ): {
    settlement: SettlementEvent;
    discardPile: CardInstance[];
  } {
    const suitcase = priv.suitcase;
    if (!suitcase) {
      throw new Error('Suitcase not found for passenger');
    }

    const transfer = Math.min(agreedAmount, passenger.cash);
    passenger.cash -= transfer;
    officer.cash += transfer;
    passenger.bribesPaid += transfer;
    officer.bribesReceived += transfer;

    // Check Customs Clearance Seal
    const sealIndex = suitcase.cards.findIndex((c) => c.typeId === 'customs_clearance_seal');
    const sealApplied = sealIndex >= 0;
    const nextDiscard = [...discardPile];

    if (sealApplied) {
      nextDiscard.push(suitcase.cards[sealIndex]);
    }

    // All cards pass into Vault
    for (let i = 0; i < suitcase.cards.length; i++) {
      if (i === sealIndex) continue;
      const card = suitcase.cards[i];
      const def = BORDER_PASS_CARDS[card.typeId];
      let val = def.baseVaultValue;
      if (sealApplied && def.category === 'duty_free') {
        val = Math.floor(val * 1.5);
      }

      passenger.vault.push({
        instanceId: card.instanceId,
        typeId: card.typeId,
        baseValue: def.baseVaultValue,
        effectiveValue: val,
        sealBonusApplied: sealApplied && def.category === 'duty_free',
        roundSecured: roundNumber,
      });
    }

    priv.suitcase = undefined;
    this.updatePlayerNetWorth(passenger);
    this.updatePlayerNetWorth(officer);

    const settlement: SettlementEvent = {
      id: `set_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      round: roundNumber,
      passengerId: passenger.id,
      passengerName: passenger.name,
      officerId: officer.id,
      officerName: officer.name,
      action: 'negotiation_agreed',
      amountTransferred: transfer,
      finePaid: 0,
      compensationPaid: 0,
      contrabandConfiscatedCount: 0,
      descriptionBn: `নেগোসিয়েশন সম্পন্ন! $${transfer} প্রদানের বিনিময়ে ${passenger.name}-এর স্যুটকেস তল্লাশি ছাড়াই পাস হয়েছে।`,
      timestamp: Date.now(),
    };

    return { settlement, discardPile: nextDiscard };
  }

  /**
   * Apply Customs Clearance Seal (+50%) to an eligible item in the player's vault.
   */
  public static applySealToVaultItem(
    player: BorderPassPlayer,
    priv: BorderPassPlayerPrivate,
    sealInstanceId: string,
    vaultItemInstanceId: string,
    discardPile: CardInstance[]
  ): { success: boolean; error?: string; discardPile: CardInstance[] } {
    // Check if player owns the seal in hand
    const sealIndex = priv.hand.findIndex((c) => c.instanceId === sealInstanceId && c.typeId === 'customs_clearance_seal');
    if (sealIndex < 0) {
      return { success: false, error: 'কাস্টমস ক্লিয়ারেন্স সিল আপনার হাতে নেই।', discardPile };
    }

    // Check vault item
    const vaultItem = player.vault.find((v) => v.instanceId === vaultItemInstanceId);
    if (!vaultItem) {
      return { success: false, error: 'ভল্ট আইটেম পাওয়া যায়নি।', discardPile };
    }

    const def = BORDER_PASS_CARDS[vaultItem.typeId];
    if (def.category !== 'duty_free') {
      return { success: false, error: 'সিল শুধুমাত্র আইনি ডিউটি-ফ্রি পণ্যের ওপর প্রয়োগ করা যায়।', discardPile };
    }

    if (vaultItem.sealBonusApplied) {
      return { success: false, error: 'এই পণ্যের ওপর ইতিমধ্যেই সিল বোনাস প্রয়োগ করা হয়েছে।', discardPile };
    }

    // Apply +50% bonus
    vaultItem.effectiveValue = Math.floor(vaultItem.baseValue * 1.5);
    vaultItem.sealBonusApplied = true;

    // Discard the seal card
    const [consumedSeal] = priv.hand.splice(sealIndex, 1);
    player.handCount = priv.hand.length;
    const nextDiscard = [...discardPile, consumedSeal];

    this.updatePlayerNetWorth(player);

    return { success: true, discardPile: nextDiscard };
  }

  /**
   * Recalculates effective vault value and total net worth.
   * Net Worth = Cash + Effective Vault Value.
   * Effective Vault Value = max(0, sum(vault item values) - vaultScoreAdjustment).
   */
  public static updatePlayerNetWorth(player: BorderPassPlayer): void {
    player.cash = Math.max(0, player.cash);
    const grossVault = player.vault.reduce((sum, item) => sum + item.effectiveValue, 0);
    player.effectiveVaultValue = Math.max(0, grossVault - player.vaultScoreAdjustment);
    player.netWorth = player.cash + player.effectiveVaultValue;
  }

  /**
   * Determine final winner and ranked leaderboard.
   */
  public static calculateFinalResults(players: BorderPassPlayer[]): {
    ranked: BorderPassPlayer[];
    winner: { playerId: string; playerName: string; netWorth: number; tieBreakReason?: string };
  } {
    // Ensure up-to-date net worth
    players.forEach((p) => this.updatePlayerNetWorth(p));

    const ranked = [...players].sort((a, b) => {
      if (b.netWorth !== a.netWorth) {
        return b.netWorth - a.netWorth;
      }
      if (b.effectiveVaultValue !== a.effectiveVaultValue) {
        return b.effectiveVaultValue - a.effectiveVaultValue;
      }
      return b.cash - a.cash;
    });

    const top = ranked[0];
    const second = ranked[1];
    let tieBreakReason: string | undefined;

    if (second && top.netWorth === second.netWorth) {
      if (top.effectiveVaultValue > second.effectiveVaultValue) {
        tieBreakReason = `নেট ওয়ার্থ সমান হলেও ভল্ট মানে এগিয়ে থাকায় বিজয়ী (${top.effectiveVaultValue} বনাম ${second.effectiveVaultValue})`;
      } else if (top.cash > second.cash) {
        tieBreakReason = `নেট ওয়ার্থ সমান হলেও ক্যাশে এগিয়ে থাকায় বিজয়ী ($${top.cash} বনাম $${second.cash})`;
      } else {
        tieBreakReason = 'যৌথ বিজয়ী (সকল মান সমান)';
      }
    }

    return {
      ranked,
      winner: {
        playerId: top.id,
        playerName: top.name,
        netWorth: top.netWorth,
        tieBreakReason,
      },
    };
  }
}
