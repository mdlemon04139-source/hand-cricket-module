import {
  BorderPassPlayer,
  BorderPassPlayerPrivate,
  BorderPassRoomPublicState,
  BorderPassClientState,
  GamePhase,
  CardInstance,
  SuitcaseDeclaration,
  NegotiationState,
  SettlementEvent,
  InspectionResult,
  DutyFreeCardId,
  PlayerRole,
} from '../types/borderpass';
import { BorderPassEngine } from '../engine/borderpassEngine';
import { BORDER_PASS_CARDS } from '../data/borderpassAssets';
import { gameStatsManager } from './gameStatsManager';

interface ActiveRoom {
  roomId: string;
  roomCode: string;
  hostId: string;
  phase: GamePhase;
  currentRound: number;
  totalRounds: number;
  currentOfficerId: string;
  currentReviewPassengerId?: string;
  reviewPassengerQueue: string[];
  players: BorderPassPlayer[];
  drawDeck: CardInstance[];
  discardPile: CardInstance[];
  activeNegotiation?: NegotiationState;
  lastInspectionResult?: InspectionResult;
  recentSettlements: SettlementEvent[];
  phaseDeadline?: number;
  botReviewReadyAt?: number;
  botNegotiationRespondAt?: number;
  botThinkingMessage?: string;
  winner?: {
    playerId: string;
    playerName: string;
    netWorth: number;
    tieBreakReason?: string;
  };
  privateStore: Map<string, BorderPassPlayerPrivate>;
  subscribers: Set<(state: BorderPassClientState) => void>;
}

export class BorderPassRoomManager {
  private rooms: Map<string, ActiveRoom> = new Map();
  private codeToRoomId: Map<string, string> = new Map();

  constructor() {
    setInterval(() => this.processBotTurns(), 1000);
  }

  public createRoom(hostName: string, hostAvatar: string): { roomId: string; roomCode: string; playerId: string } {
    const roomId = `room_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const roomCode = Math.random().toString(36).substring(2, 6).toUpperCase();
    const hostPlayerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;

    const host = BorderPassEngine.initializePlayer(hostPlayerId, hostName, hostAvatar, 0, false);
    host.isReady = true;

    const room: ActiveRoom = {
      roomId,
      roomCode,
      hostId: hostPlayerId,
      phase: 'LOBBY',
      currentRound: 0,
      totalRounds: 0,
      currentOfficerId: '',
      reviewPassengerQueue: [],
      players: [host],
      drawDeck: [],
      discardPile: [],
      recentSettlements: [],
      privateStore: new Map(),
      subscribers: new Set(),
    };

    room.privateStore.set(hostPlayerId, { hand: [], suitcase: undefined });
    this.rooms.set(roomId, room);
    this.codeToRoomId.set(roomCode, roomId);

    return { roomId, roomCode, playerId: hostPlayerId };
  }

  public getRoom(roomIdOrCode: string): ActiveRoom | undefined {
    const id = this.codeToRoomId.get(roomIdOrCode.toUpperCase()) || roomIdOrCode;
    return this.rooms.get(id);
  }

  public joinRoom(roomIdOrCode: string, name: string, avatar: string): { success: boolean; playerId?: string; error?: string } {
    const room = this.getRoom(roomIdOrCode);
    if (!room) {
      return { success: false, error: 'রুম কোডটি সঠিক নয় বা রুম খুঁজে পাওয়া যায়নি।' };
    }

    if (room.phase !== 'LOBBY') {
      return { success: false, error: 'খেলা ইতিমধ্যেই শুরু হয়ে গেছে।' };
    }

    if (room.players.length >= 6) {
      return { success: false, error: 'রুমে সর্বাধিক ৬ জন খেলোয়াড় পূর্ণ হয়েছে।' };
    }

    const playerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
    const player = BorderPassEngine.initializePlayer(playerId, name, avatar, room.players.length, false);
    player.isReady = true;

    room.players.push(player);
    room.privateStore.set(playerId, { hand: [], suitcase: undefined });

    this.notifySubscribers(room);
    return { success: true, playerId };
  }

  public addBot(roomId: string, difficulty: 'easy' | 'normal' | 'hard' = 'normal'): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };
    if (room.phase !== 'LOBBY') return { success: false, error: 'Game already in progress' };
    if (room.players.length >= 6) return { success: false, error: 'Room is full (max 6 players)' };

    const botAvatars = ['🤖', '🕵️‍♂️', '🧳', '💼', '🥷', '🧑‍✈️'];
    const botNames = ['কাস্টমস আলী', 'রহিম ট্রাভেলার', 'রফিক সওদাগর', 'আসিফ এজেন্ট', 'শফিক ডিটেক্টিভ', 'তারিক স্মাগলার'];

    const botId = `bot_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
    const usedNames = new Set(room.players.map((p) => p.name));
    const availableName = botNames.find((n) => !usedNames.has(n)) || `বট #${room.players.length + 1}`;
    const botAvatar = botAvatars[room.players.length % botAvatars.length];

    const bot = BorderPassEngine.initializePlayer(botId, availableName, botAvatar, room.players.length, true, difficulty);
    bot.isReady = true;

    room.players.push(bot);
    room.privateStore.set(botId, { hand: [], suitcase: undefined });

    this.notifySubscribers(room);
    return { success: true };
  }

  public removePlayer(roomId: string, playerId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };

    if (room.phase !== 'LOBBY') {
      // In-match disconnect: mark offline and enable AI bot takeover
      const player = room.players.find((p) => p.id === playerId);
      if (player) {
        player.isOnline = false;
        player.isBot = true;
        if (!player.name.includes('(বট)')) {
          player.name = `${player.name} (বট)`;
        }
        this.notifySubscribers(room);
        return { success: true };
      }
      return { success: false, error: 'Player not found in active game' };
    }

    if (playerId === room.hostId && room.players.length > 1) {
      const next = room.players.find((p) => p.id !== playerId);
      if (next) room.hostId = next.id;
    }

    room.players = room.players.filter((p) => p.id !== playerId);
    room.privateStore.delete(playerId);
    room.players.forEach((p, idx) => (p.seatNumber = idx));

    if (room.players.length === 0) {
      this.rooms.delete(roomId);
      this.codeToRoomId.delete(room.roomCode);
    } else {
      this.notifySubscribers(room);
    }

    return { success: true };
  }

  public startGame(roomId: string, requesterId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };
    if (requesterId !== room.hostId) return { success: false, error: 'কেবলমাত্র রুমের হোস্ট খেলা শুরু করতে পারবেন।' };
    if (room.players.length < 3) return { success: false, error: 'খেলা শুরু করতে অন্তত ৩ জন খেলোয়াড় প্রয়োজন (বট যোগ করতে পারেন)।' };
    if (room.players.length > 6) return { success: false, error: 'সর্বাধিক ৬ জন খেলোয়াড় অনুমোদিত।' };

    room.players.forEach((p, idx) => {
      p.seatNumber = idx;
      p.cash = 500;
      p.vault = [];
      p.vaultScoreAdjustment = 0;
      p.effectiveVaultValue = 0;
      p.netWorth = 500;
      p.officerTurnsCompleted = 0;
      p.bribesPaid = 0;
      p.bribesReceived = 0;
      p.finesPaid = 0;
      p.compensationReceived = 0;
      p.hasPacked = false;
      p.role = 'passenger';
    });

    room.drawDeck = BorderPassEngine.shuffleDeck(BorderPassEngine.createCanonicalDeck());
    room.discardPile = [];
    room.totalRounds = BorderPassEngine.calculateTotalRounds(room.players.length);
    room.currentRound = 0;
    room.recentSettlements = [];

    const deal = BorderPassEngine.dealInitialHands(room.players, room.privateStore, room.drawDeck);
    room.drawDeck = deal.drawDeck;

    this.startRound(room, 1);
    gameStatsManager.recordMatchStart('borderpass', roomId, requesterId);
    return { success: true };
  }

  private startRound(room: ActiveRoom, roundNum: number): void {
    if (roundNum > room.totalRounds) {
      this.endMatch(room);
      return;
    }

    room.currentRound = roundNum;
    room.phase = 'ROUND_START';

    // Strictly deterministic clockwise Officer rotation by seat number
    const sortedBySeat = [...room.players].sort((a, b) => a.seatNumber - b.seatNumber);
    const officerIndex = (roundNum - 1) % sortedBySeat.length;
    const officer = sortedBySeat[officerIndex];
    room.currentOfficerId = officer.id;

    // Reset player roles and CLEAR all suitcases
    room.players.forEach((p) => {
      const isCurrentOfficer = p.id === officer.id;
      p.role = isCurrentOfficer ? 'officer' : 'passenger';
      p.hasPacked = false;

      const priv = room.privateStore.get(p.id);
      if (priv) {
        priv.suitcase = undefined;
      }
    });

    // Replenish hands up to 5 cards
    const replen = BorderPassEngine.replenishHands(room.players, room.privateStore, room.drawDeck, room.discardPile);
    room.drawDeck = replen.drawDeck;
    room.discardPile = replen.discardPile;

    // Queue consists ONLY of passengers (Officer is NEVER in the queue)
    room.reviewPassengerQueue = sortedBySeat.filter((p) => p.id !== officer.id).map((p) => p.id);
    room.currentReviewPassengerId = undefined;
    room.activeNegotiation = undefined;
    room.lastInspectionResult = undefined;
    room.botThinkingMessage = undefined;

    // Transition to PASSENGER_PACKING
    room.phase = 'PASSENGER_PACKING';
    room.phaseDeadline = Date.now() + 35000;

    this.notifySubscribers(room);
  }

  public packSuitcase(
    roomId: string,
    playerId: string,
    cardInstanceIds: string[],
    declaration: SuitcaseDeclaration
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };
    if (room.phase !== 'PASSENGER_PACKING') return { success: false, error: 'প্যাকিং পর্ব শেষ হয়ে গেছে।' };

    const player = room.players.find((p) => p.id === playerId);
    if (!player) return { success: false, error: 'Player not found' };
    if (player.role === 'officer' || playerId === room.currentOfficerId) {
      return { success: false, error: 'কাস্টমস অফিসার হিসেবে আপনার কোনো স্যুটকেস নেই।' };
    }
    if (player.hasPacked) return { success: false, error: 'আপনি ইতিমধ্যেই আপনার স্যুটকেস জমা দিয়েছেন।' };

    const priv = room.privateStore.get(playerId);
    if (!priv) return { success: false, error: 'Private state not found' };

    const res = BorderPassEngine.packSuitcase(player, priv, cardInstanceIds, declaration);
    if (!res.success) return res;

    this.checkAllPacked(room);
    this.notifySubscribers(room);
    return { success: true };
  }

  private checkAllPacked(room: ActiveRoom): void {
    const passengers = room.players.filter((p) => p.role === 'passenger');
    const allPacked = passengers.every((p) => p.hasPacked);

    if (allPacked && room.phase === 'PASSENGER_PACKING') {
      room.phase = 'CUSTOMS_REVIEW';
      this.advanceToNextPassengerReview(room);
    }
  }

  private advanceToNextPassengerReview(room: ActiveRoom): void {
    if (room.reviewPassengerQueue.length === 0) {
      // Completed all passenger reviews in this round
      const officer = room.players.find((p) => p.id === room.currentOfficerId);
      if (officer) {
        officer.officerTurnsCompleted += 1;
      }
      this.endRound(room);
      return;
    }

    const nextId = room.reviewPassengerQueue.shift()!;
    room.currentReviewPassengerId = nextId;
    room.phase = 'CUSTOMS_REVIEW';
    room.phaseDeadline = Date.now() + 30000;
    room.activeNegotiation = undefined;
    room.lastInspectionResult = undefined;

    const officer = room.players.find((p) => p.id === room.currentOfficerId);
    if (officer && officer.isBot) {
      room.botReviewReadyAt = Date.now() + 3500; // Bot thinks 3.5s
      const target = room.players.find((p) => p.id === nextId);
      room.botThinkingMessage = `অফিসার ${officer.name} যাত্রী ${target?.name || ''}-এর লাগেজ ও ঘোষণা যাচাই করছেন...`;
    } else {
      room.botReviewReadyAt = undefined;
      room.botThinkingMessage = undefined;
    }

    this.notifySubscribers(room);
  }

  public officerAction(
    roomId: string,
    officerId: string,
    action: 'pass' | 'inspect' | 'negotiate',
    payload?: { acceptBribe?: boolean; counterOffer?: number }
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };
    if (room.phase !== 'CUSTOMS_REVIEW') return { success: false, error: 'নিয়ম বহির্ভূত অ্যাকশন বা সময় শেষ।' };
    if (room.currentOfficerId !== officerId) return { success: false, error: 'আপনি বর্তমান কাস্টমস অফিসার নন।' };
    if (!room.currentReviewPassengerId) return { success: false, error: 'কোনো যাত্রী পর্যালোচনার অধীনে নেই।' };
    if (officerId === room.currentReviewPassengerId) {
      return { success: false, error: 'কাস্টমস অফিসার কখনো নিজের স্যুটকেস পর্যালোচনা করতে পারেন না।' };
    }

    const passengerId = room.currentReviewPassengerId;
    const officer = room.players.find((p) => p.id === officerId)!;
    const passenger = room.players.find((p) => p.id === passengerId)!;
    const priv = room.privateStore.get(passengerId)!;
    room.botThinkingMessage = undefined;

    if (action === 'pass') {
      const acceptBribe = payload?.acceptBribe ?? true;
      const res = BorderPassEngine.resolvePassAction(
        officer,
        passenger,
        priv,
        acceptBribe,
        room.currentRound,
        room.discardPile
      );
      room.discardPile = res.discardPile;
      room.recentSettlements.unshift(res.settlement);
      if (room.recentSettlements.length > 20) room.recentSettlements.pop();

      this.advanceToNextPassengerReview(room);
      return { success: true };
    }

    if (action === 'inspect') {
      const res = BorderPassEngine.resolveInspectionAction(
        officer,
        passenger,
        priv,
        room.currentRound,
        room.discardPile
      );
      room.discardPile = res.discardPile;
      room.lastInspectionResult = res.result;
      room.recentSettlements.unshift(res.settlement);
      if (room.recentSettlements.length > 20) room.recentSettlements.pop();

      room.phase = 'INSPECTION_REVEAL';
      this.notifySubscribers(room);

      setTimeout(() => {
        if (room.phase === 'INSPECTION_REVEAL') {
          this.advanceToNextPassengerReview(room);
        }
      }, 4500);

      return { success: true };
    }

    if (action === 'negotiate') {
      const amount = payload?.counterOffer ?? 50;
      if (amount < 0 || amount > passenger.cash) {
        return { success: false, error: `কাউন্টার অফার $০ থেকে যাত্রীর ক্যাশ ($${passenger.cash}) এর মধ্যে হতে হবে।` };
      }

      room.phase = 'NEGOTIATION_PENDING';
      room.phaseDeadline = Date.now() + 30000;
      room.activeNegotiation = {
        id: `neg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        passengerId,
        officerId,
        currentOfferBy: 'officer',
        amount,
        demandedBribe: amount,
        currentOffer: amount,
        exchangeCount: 1,
        deadline: room.phaseDeadline,
        startedAt: Date.now(),
        expiresAt: room.phaseDeadline,
        isSettled: false,
      };

      if (passenger.isBot) {
        room.botNegotiationRespondAt = Date.now() + 2500;
      }

      this.notifySubscribers(room);
      return { success: true };
    }

    return { success: false, error: 'Unknown action' };
  }

  public respondToNegotiation(
    roomId: string,
    passengerId: string,
    accepted: boolean
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };
    if (room.phase !== 'NEGOTIATION_PENDING') return { success: false, error: 'নেগোসিয়েশন পর্ব সক্রিয় নেই।' };
    if (!room.activeNegotiation || room.activeNegotiation.passengerId !== passengerId) {
      return { success: false, error: 'অননুমোদিত প্রতিক্রিয়া।' };
    }
    if (room.activeNegotiation.isSettled) {
      return { success: false, error: 'এই নেগোসিয়েশন ইতিমধ্যেই সম্পন্ন হয়েছে।' };
    }

    room.activeNegotiation.isSettled = true;
    const officer = room.players.find((p) => p.id === room.currentOfficerId)!;
    const passenger = room.players.find((p) => p.id === passengerId)!;
    const priv = room.privateStore.get(passengerId)!;
    const amount = room.activeNegotiation.amount;

    if (accepted) {
      const res = BorderPassEngine.resolveNegotiationAgreed(
        officer,
        passenger,
        priv,
        amount,
        room.currentRound,
        room.discardPile
      );
      room.discardPile = res.discardPile;
      room.recentSettlements.unshift(res.settlement);
      room.activeNegotiation = undefined;
      this.advanceToNextPassengerReview(room);
    } else {
      room.activeNegotiation = undefined;
      const res = BorderPassEngine.resolveInspectionAction(
        officer,
        passenger,
        priv,
        room.currentRound,
        room.discardPile
      );
      room.discardPile = res.discardPile;
      room.lastInspectionResult = res.result;
      room.recentSettlements.unshift(res.settlement);

      room.phase = 'INSPECTION_REVEAL';
      this.notifySubscribers(room);

      setTimeout(() => {
        if (room.phase === 'INSPECTION_REVEAL') {
          this.advanceToNextPassengerReview(room);
        }
      }, 4500);
    }

    return { success: true };
  }

  public applySeal(
    roomId: string,
    playerId: string,
    sealInstanceId: string,
    vaultItemInstanceId: string
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'Room not found' };

    const player = room.players.find((p) => p.id === playerId);
    if (!player) return { success: false, error: 'Player not found' };

    const priv = room.privateStore.get(playerId);
    if (!priv) return { success: false, error: 'Private data not found' };

    const res = BorderPassEngine.applySealToVaultItem(
      player,
      priv,
      sealInstanceId,
      vaultItemInstanceId,
      room.discardPile
    );
    if (!res.success) return res;

    room.discardPile = res.discardPile;
    this.notifySubscribers(room);
    return { success: true };
  }

  private endRound(room: ActiveRoom): void {
    room.phase = 'ROUND_END';
    this.notifySubscribers(room);

    setTimeout(() => {
      this.startRound(room, room.currentRound + 1);
    }, 3500);
  }

  private endMatch(room: ActiveRoom): void {
    room.phase = 'MATCH_END';
    const final = BorderPassEngine.calculateFinalResults(room.players);
    room.winner = final.winner;
    this.notifySubscribers(room);
  }

  public restartMatch(roomId: string, requesterId: string): { success: boolean; error?: string } {
    return this.startGame(roomId, requesterId);
  }

  public getClientState(roomId: string, playerId: string): BorderPassClientState | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;

    const myRole: PlayerRole = playerId === room.currentOfficerId ? 'officer' : 'passenger';
    const priv = room.privateStore.get(playerId);
    const myHand = priv ? priv.hand : [];

    // The Customs Officer NEVER has a suitcase!
    const mySuitcase = myRole === 'officer' ? undefined : (priv ? priv.suitcase : undefined);

    let reviewPassengerSuitcaseDeclaration: SuitcaseDeclaration | undefined;
    if (room.currentReviewPassengerId) {
      const reviewPriv = room.privateStore.get(room.currentReviewPassengerId);
      if (reviewPriv && reviewPriv.suitcase) {
        reviewPassengerSuitcaseDeclaration = reviewPriv.suitcase.declaration;
      }
    }

    return {
      roomId: room.roomId,
      hostId: room.hostId,
      phase: room.phase,
      currentRound: room.currentRound,
      totalRounds: room.totalRounds,
      currentOfficerId: room.currentOfficerId,
      currentReviewPassengerId: room.currentReviewPassengerId,
      players: room.players,
      drawDeckCount: room.drawDeck.length,
      discardPileCount: room.discardPile.length,
      discardPileTop: room.discardPile[room.discardPile.length - 1]?.typeId,
      activeNegotiation: room.activeNegotiation,
      lastInspectionResult: room.lastInspectionResult,
      recentSettlements: room.recentSettlements,
      phaseDeadline: room.phaseDeadline,
      botThinkingMessage: room.botThinkingMessage,
      winner: room.winner,
      myPlayerId: playerId,
      myRole,
      myHand,
      mySuitcase,
      reviewPassengerSuitcaseDeclaration,
    };
  }

  public subscribe(roomId: string, playerId: string, callback: (state: BorderPassClientState) => void): () => void {
    const room = this.rooms.get(roomId);
    if (!room) return () => {};

    const wrapped = () => {
      const state = this.getClientState(roomId, playerId);
      if (state) callback(state);
    };

    room.subscribers.add(wrapped);
    wrapped();

    return () => {
      room.subscribers.delete(wrapped);
    };
  }

  private notifySubscribers(room: ActiveRoom): void {
    room.subscribers.forEach((fn) => {
      try {
        fn({} as any);
      } catch {
        // ignore
      }
    });
  }

  private processBotTurns(): void {
    const now = Date.now();

    for (const room of this.rooms.values()) {
      if (room.phase === 'LOBBY' || room.phase === 'MATCH_END') continue;

      // 1. Bot Passengers Packing Phase
      if (room.phase === 'PASSENGER_PACKING') {
        const botPassengers = room.players.filter((p) => p.isBot && p.role === 'passenger' && !p.hasPacked);
        for (const bot of botPassengers) {
          const priv = room.privateStore.get(bot.id);
          if (!priv || priv.hand.length === 0) continue;

          const countToPack = Math.min(priv.hand.length, Math.floor(Math.random() * 2) + 2);
          const chosenCards = priv.hand.slice(0, countToPack);

          const dutyFreeInChosen = chosenCards.find((c) => BORDER_PASS_CARDS[c.typeId].category === 'duty_free');
          const declaredItem: DutyFreeCardId = (dutyFreeInChosen?.typeId as DutyFreeCardId) || 'branded_watch';

          const maxAfford = Math.min(bot.cash, 40);
          const bribeOffer = Math.floor(Math.random() * (maxAfford / 10)) * 10;

          this.packSuitcase(room.roomId, bot.id, chosenCards.map((c) => c.instanceId), {
            declaredItem,
            declaredQuantity: countToPack,
            bribeOffer,
          });
        }
      }

      // 2. Bot Customs Officer Action (With pacing!)
      if (room.phase === 'CUSTOMS_REVIEW' && room.currentReviewPassengerId) {
        const officer = room.players.find((p) => p.id === room.currentOfficerId);
        if (officer && officer.isBot) {
          if (room.botReviewReadyAt && now < room.botReviewReadyAt) {
            continue;
          }

          const passengerId = room.currentReviewPassengerId;
          const reviewPriv = room.privateStore.get(passengerId);
          if (!reviewPriv || !reviewPriv.suitcase) continue;

          const decl = reviewPriv.suitcase.declaration;
          if (decl.bribeOffer >= 30) {
            this.officerAction(room.roomId, officer.id, 'pass', { acceptBribe: true });
          } else if (decl.declaredQuantity >= 3 && decl.bribeOffer === 0) {
            if (Math.random() < 0.6) {
              this.officerAction(room.roomId, officer.id, 'inspect');
            } else {
              this.officerAction(room.roomId, officer.id, 'negotiate', { counterOffer: 30 });
            }
          } else {
            if (Math.random() < 0.3) {
              this.officerAction(room.roomId, officer.id, 'inspect');
            } else {
              this.officerAction(room.roomId, officer.id, 'pass', { acceptBribe: decl.bribeOffer > 0 });
            }
          }
        }
      }

      // 3. Bot Passenger Negotiation Response
      if (room.phase === 'NEGOTIATION_PENDING' && room.activeNegotiation && !room.activeNegotiation.isSettled) {
        const passId = room.activeNegotiation.passengerId;
        const passenger = room.players.find((p) => p.id === passId);
        if (passenger && passenger.isBot) {
          if (room.botNegotiationRespondAt && now < room.botNegotiationRespondAt) {
            continue;
          }

          const offer = room.activeNegotiation.amount;
          const priv = room.privateStore.get(passId);
          const hasContraband = priv?.suitcase?.cards.some((c) => BORDER_PASS_CARDS[c.typeId].category === 'contraband');

          if (hasContraband) {
            this.respondToNegotiation(room.roomId, passId, offer <= passenger.cash);
          } else {
            if (offer > 30) {
              this.respondToNegotiation(room.roomId, passId, false);
            } else {
              this.respondToNegotiation(room.roomId, passId, true);
            }
          }
        }
      }

      // 4. Server-controlled Timeouts
      if (room.phaseDeadline && now > room.phaseDeadline) {
        if (room.phase === 'PASSENGER_PACKING') {
          room.players
            .filter((p) => p.role === 'passenger' && !p.hasPacked)
            .forEach((p) => {
              const priv = room.privateStore.get(p.id);
              if (priv) BorderPassEngine.autoPackEmpty(p, priv);
            });
          this.checkAllPacked(room);
          this.notifySubscribers(room);
        } else if (room.phase === 'CUSTOMS_REVIEW') {
          const off = room.players.find((p) => p.id === room.currentOfficerId);
          if (off) {
            this.officerAction(room.roomId, off.id, 'pass', { acceptBribe: false });
          }
        } else if (room.phase === 'NEGOTIATION_PENDING' && room.activeNegotiation && !room.activeNegotiation.isSettled) {
          this.respondToNegotiation(room.roomId, room.activeNegotiation.passengerId, false);
        }
      }
    }
  }
}

export const borderPassRoomManager = new BorderPassRoomManager();
