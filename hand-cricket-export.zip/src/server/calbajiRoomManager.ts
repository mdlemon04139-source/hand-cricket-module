import {
  ActionType,
  Card,
  CharacterId,
  GameLogEntry,
  PendingAction,
  PendingBlock,
  PendingChallenge,
  Player,
} from '../types/game';
import { ALL_CHARACTERS, DEFAULT_PRESET_5 } from '../data/characters';
import { AIEngine } from '../utils/ai';
import { gameStatsManager } from './gameStatsManager';

export interface CalbajiRoomPlayer {
  id: string;
  name: string;
  avatar: string;
  isHost: boolean;
  isBot: boolean;
  botPersonality?: 'cautious' | 'aggressive' | 'strategic';
  isReady: boolean;
  isOnline?: boolean;
  seatNumber: number;
  coins: number;
  cards: Card[];
  isEliminated: boolean;
}

export type CalbajiPhase =
  | 'LOBBY'
  | 'MATCH_STARTING'
  | 'ACTION_DECLARED'
  | 'BLOCK_DECLARED'
  | 'CHALLENGE_REVEALING'
  | 'DISCARD_CHOICE'
  | 'MATCH_OVER';

export interface CalbajiReactionState {
  actorId: string;
  actionType: ActionType;
  claimedCharacter?: CharacterId;
  targetId?: string;
  isBlock?: boolean;
  blockerId?: string;
  claimedBlockCharacter?: CharacterId;
  deadline: number;
  totalDuration: number;
  responses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'>;
}

export interface CalbajiRoomState {
  roomId: string;
  code: string;
  hostId: string;
  phase: CalbajiPhase;
  selectedCharacters: CharacterId[];
  players: CalbajiRoomPlayer[];
  currentTurnPlayerId: string;
  turnCount: number;
  bankCoins: number;
  drawDeck: Card[];
  discardPile: Card[];
  activeTaxToken?: { characterId: CharacterId; placedBy: string };
  pendingAction?: PendingAction;
  pendingBlock?: PendingBlock;
  pendingChallenge?: PendingChallenge;
  reaction?: CalbajiReactionState;
  discardPendingPlayerId?: string;
  gameLogs: GameLogEntry[];
  winner?: {
    id: string;
    name: string;
    avatar: string;
  };
  createdAt: number;
  lastActive: number;
}

export interface CalbajiClientView {
  roomId: string;
  code: string;
  hostId: string;
  phase: CalbajiPhase;
  selectedCharacters: CharacterId[];
  myPlayerId: string;
  myCards: Card[];
  players: {
    id: string;
    name: string;
    avatar: string;
    isHost: boolean;
    isBot: boolean;
    isReady: boolean;
    isOnline?: boolean;
    seatNumber: number;
    coins: number;
    cardCount: number;
    revealedCards: Card[];
    isEliminated: boolean;
  }[];
  currentTurnPlayerId: string;
  turnCount: number;
  bankCoins: number;
  drawDeckCount: number;
  discardPile: Card[];
  activeTaxToken?: { characterId: CharacterId; placedBy: string };
  pendingAction?: PendingAction;
  pendingBlock?: PendingBlock;
  reaction?: CalbajiReactionState;
  discardPendingPlayerId?: string;
  gameLogs: GameLogEntry[];
  winner?: {
    id: string;
    name: string;
    avatar: string;
  };
}

class CalbajiRoomManager {
  private rooms: Map<string, CalbajiRoomState> = new Map();
  private subscribers: Map<string, Map<string, (state: CalbajiClientView) => void>> = new Map();
  private botIntervals: Map<string, NodeJS.Timeout> = new Map();

  constructor() {
    // Background garbage collection for inactive rooms (> 4 hours)
    setInterval(() => {
      const now = Date.now();
      for (const [id, room] of this.rooms.entries()) {
        if (now - room.lastActive > 4 * 60 * 60 * 1000) {
          this.destroyRoom(id);
        }
      }
    }, 15 * 60 * 1000);
  }

  private generateCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'CAL-';
    for (let i = 0; i < 3; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  public createRoom(
    hostName: string,
    hostAvatar: string,
    characters: CharacterId[] = DEFAULT_PRESET_5
  ): { roomId: string; code: string; playerId: string } {
    const roomId = `cal_room_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const code = this.generateCode();
    const hostId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    const hostPlayer: CalbajiRoomPlayer = {
      id: hostId,
      name: hostName.trim() || 'হোস্ট',
      avatar: hostAvatar || '👑',
      isHost: true,
      isBot: false,
      isReady: true,
      seatNumber: 0,
      coins: 2,
      cards: [],
      isEliminated: false,
    };

    const room: CalbajiRoomState = {
      roomId,
      code,
      hostId,
      phase: 'LOBBY',
      selectedCharacters: characters.length === 5 ? characters : DEFAULT_PRESET_5,
      players: [hostPlayer],
      currentTurnPlayerId: hostId,
      turnCount: 1,
      bankCoins: 50 - 2,
      drawDeck: [],
      discardPile: [],
      gameLogs: [
        {
          id: `log_${Date.now()}`,
          timestamp: Date.now(),
          turnNumber: 0,
          textBn: `লবি তৈরি হয়েছে। রুম কোড: ${code}`,
          textEn: `Lobby created. Room code: ${code}`,
          type: 'system',
        },
      ],
      createdAt: Date.now(),
      lastActive: Date.now(),
    };

    this.rooms.set(roomId, room);
    this.rooms.set(code, room); // Lookup by code alias
    this.startBotLoop(roomId);

    return { roomId, code, playerId: hostId };
  }

  public joinRoom(
    roomIdentifier: string,
    playerName: string,
    playerAvatar: string
  ): { success: boolean; roomId?: string; playerId?: string; error?: string } {
    const room = this.rooms.get(roomIdentifier.toUpperCase()) || this.rooms.get(roomIdentifier);
    if (!room) {
      return { success: false, error: 'রুম পাওয়া যায়নি। কোড চেক করুন।' };
    }

    if (room.phase !== 'LOBBY') {
      return { success: false, error: 'খেলা ইতিমধ্যে শুরু হয়ে গেছে।' };
    }

    if (room.players.length >= 4) {
      return { success: false, error: 'রুমে সর্বোচ্চ ৪ জন খেলোয়াড় পূর্ণ রয়েছে।' };
    }

    const playerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newPlayer: CalbajiRoomPlayer = {
      id: playerId,
      name: playerName.trim() || `খেলোয়াড় ${room.players.length + 1}`,
      avatar: playerAvatar || '⚔️',
      isHost: false,
      isBot: false,
      isReady: false,
      seatNumber: room.players.length,
      coins: 2,
      cards: [],
      isEliminated: false,
    };

    room.players.push(newPlayer);
    room.lastActive = Date.now();
    this.addLog(room, `${newPlayer.name} রুমে প্রবেশ করেছেন।`, `${newPlayer.name} joined the room.`);
    this.broadcast(room.roomId);

    return { success: true, roomId: room.roomId, playerId };
  }

  public addBot(
    roomId: string,
    personality: 'cautious' | 'aggressive' | 'strategic' = 'strategic'
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.phase !== 'LOBBY') return { success: false, error: 'খেলা ইতিমধ্যে শুরু হয়েছে।' };
    if (room.players.length >= 4) return { success: false, error: 'রুম পূর্ণ।' };

    const botNames = [
      { name: 'জাফর খান (বট)', avatar: '🛡️', p: 'cautious' },
      { name: 'রশিদ খাঁ (বট)', avatar: '⚔️', p: 'aggressive' },
      { name: 'শাহজাদা মির্জা (বট)', avatar: '🧠', p: 'strategic' },
    ];
    const unused = botNames.filter((b) => !room.players.some((p) => p.name.includes(b.name)));
    const botPick = unused[0] || {
      name: `বট ${room.players.length + 1}`,
      avatar: '🤖',
      p: personality,
    };

    const botPlayer: CalbajiRoomPlayer = {
      id: `bot_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      name: botPick.name,
      avatar: botPick.avatar,
      isHost: false,
      isBot: true,
      botPersonality: (botPick.p as any) || personality,
      isReady: true,
      seatNumber: room.players.length,
      coins: 2,
      cards: [],
      isEliminated: false,
    };

    room.players.push(botPlayer);
    room.lastActive = Date.now();
    this.addLog(room, `${botPlayer.name} রুমে যোগ দিয়েছেন।`, `${botPlayer.name} added to lobby.`);
    this.broadcast(roomId);

    return { success: true };
  }

  public removePlayer(roomId: string, playerId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };

    const idx = room.players.findIndex((p) => p.id === playerId);
    if (idx === -1) return { success: false, error: 'প্লেয়ার পাওয়া যায়নি।' };

    if (room.phase !== 'LOBBY') {
      // In-match disconnect: mark offline and enable bot takeover so game proceeds smoothly
      const player = room.players[idx];
      player.isOnline = false;
      player.isBot = true;
      if (!player.name.includes('(বট)')) {
        player.name = `${player.name} (বট)`;
      }
      this.addLog(
        room,
        `⚠️ ${player.name} সংযোগ বিচ্ছিন্ন হয়েছেন। বট দায়িত্ব নিয়েছে।`,
        `⚠️ ${player.name} disconnected. Bot taking over.`
      );
      this.broadcast(roomId);
      return { success: true };
    }

    const removed = room.players[idx];
    room.players.splice(idx, 1);

    // Reassign seat numbers
    room.players.forEach((p, i) => {
      p.seatNumber = i;
    });

    // If host was removed, assign next human player as host
    if (removed.isHost && room.players.length > 0) {
      const nextHost = room.players.find((p) => !p.isBot) || room.players[0];
      nextHost.isHost = true;
      room.hostId = nextHost.id;
    }

    room.lastActive = Date.now();
    this.addLog(room, `${removed.name} রুম ত্যাগ করেছেন।`, `${removed.name} left the room.`);
    this.broadcast(roomId);

    return { success: true };
  }

  public toggleReady(roomId: string, playerId: string): { success: boolean } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false };
    const player = room.players.find((p) => p.id === playerId);
    if (player) {
      player.isReady = !player.isReady;
      this.broadcast(roomId);
    }
    return { success: true };
  }

  public updateCharacters(roomId: string, hostId: string, chars: CharacterId[]): { success: boolean } {
    const room = this.rooms.get(roomId);
    if (!room || room.hostId !== hostId || room.phase !== 'LOBBY') return { success: false };
    if (chars.length === 5) {
      room.selectedCharacters = chars;
      this.broadcast(roomId);
    }
    return { success: true };
  }

  public startGame(roomId: string, hostId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== hostId) return { success: false, error: 'শুধুমাত্র রুম হোস্ট খেলা শুরু করতে পারেন।' };
    if (room.players.length < 2) return { success: false, error: 'খেলতে কমপক্ষে ২ জন খেলোয়াড় প্রয়োজন।' };

    // Create 15 canonical cards: 3 copies of each selected character
    const deck: Card[] = [];
    room.selectedCharacters.forEach((charId) => {
      for (let i = 0; i < 3; i++) {
        deck.push({
          uid: `${charId}_${i}_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          characterId: charId,
          isRevealed: false,
        });
      }
    });

    // Shuffle deck
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }

    // Deal 2 cards to each player
    room.players.forEach((p) => {
      p.cards = deck.splice(0, 2);
      p.coins = 2;
      p.isEliminated = false;
    });

    room.drawDeck = deck;
    room.discardPile = [];
    room.bankCoins = 50 - room.players.length * 2;
    room.phase = 'MATCH_STARTING';
    room.currentTurnPlayerId = room.players[0].id;
    room.turnCount = 1;
    room.lastActive = Date.now();
    gameStatsManager.recordMatchStart('calbaji', roomId, hostId);

    this.addLog(
      room,
      'খেলা শুরু হয়েছে! সবাইকে ২টি করে কার্ড ও ২ কয়েন দেওয়া হয়েছে।',
      'Match started! Each player dealt 2 cards and 2 coins.'
    );

    this.broadcast(roomId);

    // Transition from match starting to active turn after deal animation
    setTimeout(() => {
      if (room.phase === 'MATCH_STARTING') {
        room.phase = 'ACTION_DECLARED';
        this.broadcast(roomId);
      }
    }, 1500);

    return { success: true };
  }

  public declareAction(
    roomId: string,
    actorId: string,
    actionType: ActionType,
    claimedCharacter?: CharacterId,
    targetId?: string
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.currentTurnPlayerId !== actorId) {
      return { success: false, error: 'এখন আপনার চাল নয়।' };
    }

    const actor = room.players.find((p) => p.id === actorId);
    if (!actor || actor.isEliminated) return { success: false, error: 'অবৈধ খেলোয়াড়।' };

    // General Action 1: Income (+1 coin from bank)
    if (actionType === 'income') {
      if (room.bankCoins > 0) {
        actor.coins += 1;
        room.bankCoins -= 1;
      }
      this.addLog(room, `${actor.name} রাজস্ব থেকে ১ কয়েন সংগ্রহ করেছেন।`, `${actor.name} collected 1 Income.`);
      this.advanceTurn(room);
      this.broadcast(roomId);
      return { success: true };
    }

    // General Action 2: Coup (-7 coins, unchallengeable assassination)
    if (actionType === 'coup') {
      if (actor.coins < 7) {
        return { success: false, error: 'সুপ্রিম নিধনের জন্য ৭টি কয়েন প্রয়োজন।' };
      }
      if (!targetId) return { success: false, error: 'টার্গেট নির্বাচন করুন।' };
      const target = room.players.find((p) => p.id === targetId);
      if (!target || target.isEliminated) return { success: false, error: 'অবৈধ টার্গেট।' };

      actor.coins -= 7;
      room.bankCoins += 7;

      this.addLog(
        room,
        `${actor.name} ${target.name}-এর বিরুদ্ধে সুপ্রিম নিধন (Coup) করেছেন!`,
        `${actor.name} launched a Coup against ${target.name}!`
      );

      this.promptCardDiscard(room, target.id);
      this.broadcast(roomId);
      return { success: true };
    }

    // Character Claim Actions:
    const charDef = ALL_CHARACTERS[claimedCharacter as CharacterId];
    if (!charDef) return { success: false, error: 'অবৈধ চরিত্র দাবি।' };

    if (charDef.coinCost > 0 && actor.coins < charDef.coinCost) {
      return { success: false, error: `এই চালের জন্য ${charDef.coinCost}টি কয়েন প্রয়োজন।` };
    }

    // Setup Reaction window
    const duration = 15; // 15s window
    const responses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'> = {};
    room.players
      .filter((p) => !p.isEliminated && p.id !== actorId)
      .forEach((p) => {
        responses[p.id] = 'pending';
      });

    room.pendingAction = {
      actorId,
      actionType,
      claimedCharacter,
      targetId,
    };

    room.reaction = {
      actorId,
      actionType,
      claimedCharacter,
      targetId,
      deadline: Date.now() + duration * 1000,
      totalDuration: duration,
      responses,
    };

    room.phase = 'ACTION_DECLARED';
    this.addLog(
      room,
      `${actor.name} '${charDef.nameBn}' চরিত্রের দাবি করেছেন।`,
      `${actor.name} claimed ${charDef.nameEn}.`
    );

    this.broadcast(roomId);
    return { success: true };
  }

  public respondToReaction(
    roomId: string,
    responderId: string,
    response: 'challenge' | 'block' | 'skip',
    claimedBlockCharacter?: CharacterId
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room || !room.reaction) return { success: false, error: 'কোনো সক্রিয় প্রতিক্রিয়া নেই।' };

    const responder = room.players.find((p) => p.id === responderId);
    if (!responder || responder.isEliminated) return { success: false, error: 'অবৈধ প্লেয়ার।' };

    if (response === 'skip') {
      room.reaction.responses[responderId] = 'skipped';
      // If all eligible players skipped, auto-execute
      const allDone = Object.values(room.reaction.responses).every((r) => r === 'skipped');
      if (allDone) {
        this.resolveActionOutcome(room);
      }
      this.broadcast(roomId);
      return { success: true };
    }

    if (response === 'challenge') {
      room.reaction.responses[responderId] = 'challenged';
      this.resolveChallenge(room, responderId);
      this.broadcast(roomId);
      return { success: true };
    }

    if (response === 'block') {
      if (!claimedBlockCharacter) {
        return { success: false, error: 'ব্লক করার চরিত্র বেছে নিন।' };
      }
      room.pendingBlock = {
        blockerId: responderId,
        claimedCharacter: claimedBlockCharacter,
      };

      // Set block challenge window
      const duration = 12;
      const responses: Record<string, 'pending' | 'skipped' | 'challenged' | 'blocked'> = {};
      room.players
        .filter((p) => !p.isEliminated && p.id !== responderId)
        .forEach((p) => {
          responses[p.id] = 'pending';
        });

      room.reaction = {
        actorId: room.pendingAction!.actorId,
        actionType: room.pendingAction!.actionType,
        isBlock: true,
        blockerId: responderId,
        claimedBlockCharacter,
        deadline: Date.now() + duration * 1000,
        totalDuration: duration,
        responses,
      };

      room.phase = 'BLOCK_DECLARED';
      this.addLog(
        room,
        `${responder.name} '${ALL_CHARACTERS[claimedBlockCharacter]?.nameBn || claimedBlockCharacter}' দিয়ে ব্লক দাবি করেছেন।`,
        `${responder.name} claimed block with ${claimedBlockCharacter}.`
      );

      this.broadcast(roomId);
      return { success: true };
    }

    return { success: true };
  }

  private resolveChallenge(room: CalbajiRoomState, challengerId: string) {
    const challenger = room.players.find((p) => p.id === challengerId)!;
    const isBlockChallenge = !!room.reaction?.isBlock;
    const claimedChar = isBlockChallenge
      ? room.reaction!.claimedBlockCharacter!
      : room.reaction!.claimedCharacter!;
    const defender = isBlockChallenge
      ? room.players.find((p) => p.id === room.reaction!.blockerId)!
      : room.players.find((p) => p.id === room.reaction!.actorId)!;

    // Check if defender actually holds the claimed character
    const matchingCardIndex = defender.cards.findIndex(
      (c) => !c.isRevealed && c.characterId === claimedChar
    );

    if (matchingCardIndex !== -1) {
      // Defender was NOT bluffing! Defender proves it.
      // Defender swaps card with fresh card from draw deck
      const revealedCard = defender.cards[matchingCardIndex];
      room.drawDeck.push(revealedCard);
      // Shuffle draw deck
      const newCard = room.drawDeck.shift()!;
      defender.cards[matchingCardIndex] = newCard;

      this.addLog(
        room,
        `${defender.name} সত্য প্রমাণ করেছেন! ${challenger.name} চ্যালেঞ্জে হেরে জীবন হারিয়েছেন।`,
        `${defender.name} proved truth! ${challenger.name} lost the challenge and loses a life.`
      );

      // Challenger loses 1 card
      this.promptCardDiscard(room, challenger.id, () => {
        if (!isBlockChallenge) {
          this.executeConsequentialAction(room);
        } else {
          // Block succeeded
          this.advanceTurn(room);
        }
      });
    } else {
      // Defender was BLUFFING and caught!
      this.addLog(
        room,
        `ধরা পড়েছে! ${defender.name}-এর কাছে '${ALL_CHARACTERS[claimedChar]?.nameBn || claimedChar}' কার্ড নেই!`,
        `Caught! ${defender.name} was bluffing without ${claimedChar}!`
      );

      // Defender loses a life
      this.promptCardDiscard(room, defender.id, () => {
        this.advanceTurn(room);
      });
    }
  }

  private resolveActionOutcome(room: CalbajiRoomState) {
    if (room.phase === 'BLOCK_DECLARED') {
      // Block accepted without challenge
      this.addLog(room, 'ব্লক সফল হয়েছে। আক্রমণ প্রতিহত হয়েছে।', 'Block succeeded. Action negated.');
      this.advanceTurn(room);
      return;
    }

    this.executeConsequentialAction(room);
  }

  private executeConsequentialAction(room: CalbajiRoomState) {
    if (!room.pendingAction) {
      this.advanceTurn(room);
      return;
    }

    const { actorId, actionType, claimedCharacter, targetId } = room.pendingAction;
    const actor = room.players.find((p) => p.id === actorId)!;
    const target = targetId ? room.players.find((p) => p.id === targetId) : undefined;

    switch (actionType) {
      case 'nawab_tax': {
        const gain = Math.min(3, room.bankCoins);
        actor.coins += gain;
        room.bankCoins -= gain;
        this.addLog(room, `${actor.name} নবাবের কর হিসেবে ৩ কয়েন পেলেন।`, `${actor.name} collected 3 Tax.`);
        this.advanceTurn(room);
        break;
      }

      case 'sodagor_trade': {
        const gain = Math.min(4, room.bankCoins);
        actor.coins += gain;
        room.bankCoins -= gain;
        this.addLog(room, `${actor.name} সদাগরী বাণিজ্যে ৪ কয়েন পেলেন।`, `${actor.name} collected 4 Trade.`);
        this.advanceTurn(room);
        break;
      }

      case 'assassinate': {
        actor.coins -= 3;
        room.bankCoins += 3;
        if (target && !target.isEliminated) {
          this.addLog(
            room,
            `${actor.name} গুপ্তঘাতক দিয়ে ${target.name}-কে আঘাত করলেন!`,
            `${actor.name} assassinated ${target.name}!`
          );
          this.promptCardDiscard(room, target.id);
        } else {
          this.advanceTurn(room);
        }
        break;
      }

      case 'dosyu_steal': {
        if (target && !target.isEliminated) {
          const stolen = Math.min(2, target.coins);
          target.coins -= stolen;
          actor.coins += stolen;
          this.addLog(
            room,
            `${actor.name} দস্যু সর্দারের শক্তিতে ${target.name}-এর কাছ থেকে ${stolen} কয়েন ছিনিয়ে নিলেন!`,
            `${actor.name} stole ${stolen} coins from ${target.name}!`
          );
        }
        this.advanceTurn(room);
        break;
      }

      case 'sidhel_raid': {
        let total = 0;
        room.players
          .filter((p) => !p.isEliminated && p.id !== actor.id)
          .forEach((p) => {
            if (p.coins > 0) {
              p.coins -= 1;
              total += 1;
            }
          });
        actor.coins += total;
        this.addLog(
          room,
          `${actor.name} সিঁধেল চোরের ডাকে সবার কাছ থেকে মোট ${total} কয়েন নিলেন!`,
          `${actor.name} raided ${total} coins across all players!`
        );
        this.advanceTurn(room);
        break;
      }

      case 'khajnadar_tax': {
        if (claimedCharacter) {
          room.activeTaxToken = {
            characterId: claimedCharacter,
            placedBy: actor.id,
          };
          this.addLog(
            room,
            `${actor.name} খাজনাদারের সিল '${ALL_CHARACTERS[claimedCharacter]?.nameBn || claimedCharacter}'-এর উপর স্থাপন করেছেন।`,
            `${actor.name} placed Tax Token on ${claimedCharacter}.`
          );
        }
        this.advanceTurn(room);
        break;
      }

      default: {
        this.advanceTurn(room);
      }
    }
  }

  private promptCardDiscard(room: CalbajiRoomState, targetPlayerId: string, onDone?: () => void) {
    const target = room.players.find((p) => p.id === targetPlayerId);
    if (!target || target.isEliminated) {
      if (onDone) onDone();
      else this.advanceTurn(room);
      return;
    }

    const liveCards = target.cards.filter((c) => !c.isRevealed);
    if (liveCards.length <= 1) {
      // Target only has 1 life left -> eliminated!
      if (liveCards.length === 1) {
        liveCards[0].isRevealed = true;
        room.discardPile.push(liveCards[0]);
      }
      target.isEliminated = true;
      this.addLog(room, `💀 ${target.name} খেলা থেকে অপসারিত হয়েছেন!`, `💀 ${target.name} has been eliminated!`);

      this.checkWinCondition(room);
      if (room.phase !== 'MATCH_OVER') {
        if (onDone) onDone();
        else this.advanceTurn(room);
      }
      return;
    }

    if (target.isBot) {
      // Bot chooses first card to discard
      const chosen = liveCards[0];
      chosen.isRevealed = true;
      room.discardPile.push(chosen);
      this.addLog(
        room,
        `${target.name} একটি কার্ড ('${ALL_CHARACTERS[chosen.characterId]?.nameBn || chosen.characterId}') প্রকাশ করে জীবন হারিয়েছেন।`,
        `${target.name} lost 1 life (${chosen.characterId}).`
      );
      if (onDone) onDone();
      else this.advanceTurn(room);
      return;
    }

    // Human player must choose card to discard
    room.phase = 'DISCARD_CHOICE';
    room.discardPendingPlayerId = target.id;
  }

  public discardCard(roomId: string, playerId: string, cardUid: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.discardPendingPlayerId !== playerId) return { success: false, error: 'এখন আপনার কার্ড ছাড়ার কথা নয়।' };

    const player = room.players.find((p) => p.id === playerId);
    if (!player) return { success: false, error: 'প্লেয়ার পাওয়া যায়নি।' };

    const card = player.cards.find((c) => c.uid === cardUid && !c.isRevealed);
    if (!card) return { success: false, error: 'অবৈধ কার্ড।' };

    card.isRevealed = true;
    room.discardPile.push(card);
    room.discardPendingPlayerId = undefined;

    const remainingLive = player.cards.filter((c) => !c.isRevealed);
    if (remainingLive.length === 0) {
      player.isEliminated = true;
      this.addLog(room, `💀 ${player.name} অপসারিত হয়েছেন!`, `💀 ${player.name} eliminated!`);
    } else {
      this.addLog(
        room,
        `${player.name} '${ALL_CHARACTERS[card.characterId]?.nameBn || card.characterId}' হারিয়েছেন।`,
        `${player.name} lost 1 life (${card.characterId}).`
      );
    }

    this.checkWinCondition(room);
    if (room.phase !== 'MATCH_OVER') {
      this.advanceTurn(room);
    }

    this.broadcast(roomId);
    return { success: true };
  }

  private checkWinCondition(room: CalbajiRoomState): boolean {
    const active = room.players.filter((p) => !p.isEliminated);
    if (active.length === 1) {
      const winner = active[0];
      room.phase = 'MATCH_OVER';
      room.winner = {
        id: winner.id,
        name: winner.name,
        avatar: winner.avatar,
      };
      this.addLog(
        room,
        `🏆 বিজয়ী ঘোষিত! ${winner.name} চালবাজিতে অপরাজিত চ্যাম্পিয়ন!`,
        `🏆 Winner! ${winner.name} won the match!`
      );
      return true;
    }
    return false;
  }

  private advanceTurn(room: CalbajiRoomState) {
    room.pendingAction = undefined;
    room.pendingBlock = undefined;
    room.pendingChallenge = undefined;
    room.reaction = undefined;
    room.discardPendingPlayerId = undefined;

    if (this.checkWinCondition(room)) {
      return;
    }

    // Find next active player clockwise
    const activePlayers = room.players.filter((p) => !p.isEliminated);
    const currentIndex = room.players.findIndex((p) => p.id === room.currentTurnPlayerId);

    let nextIndex = (currentIndex + 1) % room.players.length;
    while (room.players[nextIndex].isEliminated) {
      nextIndex = (nextIndex + 1) % room.players.length;
    }

    room.currentTurnPlayerId = room.players[nextIndex].id;
    room.turnCount += 1;
    room.phase = 'ACTION_DECLARED';
    room.lastActive = Date.now();

    const nextPlayer = room.players[nextIndex];
    this.addLog(
      room,
      `চাল ${room.turnCount}: ${nextPlayer.name}-এর পালা।`,
      `Turn ${room.turnCount}: ${nextPlayer.name}'s turn.`
    );
  }

  private startBotLoop(roomId: string) {
    if (this.botIntervals.has(roomId)) return;

    const interval = setInterval(() => {
      const room = this.rooms.get(roomId);
      if (!room || room.phase === 'LOBBY' || room.phase === 'MATCH_OVER') return;

      const now = Date.now();

      // 1. Reaction Countdown Check
      if (room.reaction && now >= room.reaction.deadline) {
        this.addLog(room, 'সময় সমাপ্ত! চাল অনুমোদিত হয়েছে।', 'Reaction window expired. Action accepted.');
        this.resolveActionOutcome(room);
        this.broadcast(roomId);
        return;
      }

      // 2. Active Turn Bot Action
      const currentTurnPlayer = room.players.find((p) => p.id === room.currentTurnPlayerId);
      if (
        currentTurnPlayer &&
        currentTurnPlayer.isBot &&
        !currentTurnPlayer.isEliminated &&
        room.phase === 'ACTION_DECLARED' &&
        !room.reaction
      ) {
        // Run bot turn logic
        this.executeBotTurn(room, currentTurnPlayer);
        this.broadcast(roomId);
        return;
      }

      // 3. Bot Reaction Response
      if (room.reaction) {
        const pendingBots = room.players.filter(
          (p) =>
            p.isBot &&
            !p.isEliminated &&
            p.id !== room.reaction!.actorId &&
            room.reaction!.responses[p.id] === 'pending'
        );

        if (pendingBots.length > 0) {
          const bot = pendingBots[0];
          // 85% chance bot passes, 15% chance challenges
          const shouldChallenge = Math.random() < 0.15;
          if (shouldChallenge) {
            this.respondToReaction(roomId, bot.id, 'challenge');
          } else {
            this.respondToReaction(roomId, bot.id, 'skip');
          }
        }
      }
    }, 1500);

    this.botIntervals.set(roomId, interval);
  }

  private executeBotTurn(room: CalbajiRoomState, bot: CalbajiRoomPlayer) {
    const targets = room.players.filter((p) => !p.isEliminated && p.id !== bot.id);
    const randomTarget = targets[Math.floor(Math.random() * targets.length)];

    // Coup if coins >= 10 (mandatory rule in Calbaji/Coup when 10+ coins)
    if (bot.coins >= 7) {
      if (randomTarget) {
        this.declareAction(room.roomId, bot.id, 'coup', undefined, randomTarget.id);
        return;
      }
    }

    // Pick action based on cards or bluff
    const liveCards = bot.cards.filter((c) => !c.isRevealed);
    const hasChar = (cId: CharacterId) => liveCards.some((c) => c.characterId === cId);

    if (hasChar('nawab') && Math.random() < 0.8) {
      this.declareAction(room.roomId, bot.id, 'nawab_tax', 'nawab');
      return;
    }

    if (hasChar('sodagor') && Math.random() < 0.7) {
      this.declareAction(room.roomId, bot.id, 'sodagor_trade', 'sodagor');
      return;
    }

    if (hasChar('assassinate' as any) || (hasChar('guptoghatok') && bot.coins >= 3 && randomTarget)) {
      this.declareAction(room.roomId, bot.id, 'assassinate', 'guptoghatok', randomTarget?.id);
      return;
    }

    if (hasChar('dosyu_sordar') && randomTarget && randomTarget.coins >= 2) {
      this.declareAction(room.roomId, bot.id, 'dosyu_steal', 'dosyu_sordar', randomTarget.id);
      return;
    }

    // Default to income
    this.declareAction(room.roomId, bot.id, 'income');
  }

  public restartMatch(roomId: string, requesterId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== requesterId) return { success: false, error: 'শুধুমাত্র হোস্ট রিস্টার্ট করতে পারেন।' };

    return this.startGame(roomId, requesterId);
  }

  public getClientState(roomId: string, playerId: string): CalbajiClientView | null {
    const room = this.rooms.get(roomId);
    if (!room) return null;

    const me = room.players.find((p) => p.id === playerId);
    const myCards = me ? me.cards : [];

    const publicPlayers = room.players.map((p) => ({
      id: p.id,
      name: p.name,
      avatar: p.avatar,
      isHost: p.isHost,
      isBot: p.isBot,
      isReady: p.isReady,
      isOnline: p.isOnline !== false,
      seatNumber: p.seatNumber,
      coins: p.coins,
      cardCount: p.cards.filter((c) => !c.isRevealed).length,
      revealedCards: p.cards.filter((c) => c.isRevealed),
      isEliminated: p.isEliminated,
    }));

    return {
      roomId: room.roomId,
      code: room.code,
      hostId: room.hostId,
      phase: room.phase,
      selectedCharacters: room.selectedCharacters,
      myPlayerId: playerId,
      myCards,
      players: publicPlayers,
      currentTurnPlayerId: room.currentTurnPlayerId,
      turnCount: room.turnCount,
      bankCoins: room.bankCoins,
      drawDeckCount: room.drawDeck.length,
      discardPile: room.discardPile,
      activeTaxToken: room.activeTaxToken,
      pendingAction: room.pendingAction,
      pendingBlock: room.pendingBlock,
      reaction: room.reaction,
      discardPendingPlayerId: room.discardPendingPlayerId,
      gameLogs: room.gameLogs.slice(-15),
      winner: room.winner,
    };
  }

  public subscribe(
    roomId: string,
    playerId: string,
    callback: (state: CalbajiClientView) => void
  ): () => void {
    if (!this.subscribers.has(roomId)) {
      this.subscribers.set(roomId, new Map());
    }

    const roomSubs = this.subscribers.get(roomId)!;
    roomSubs.set(playerId, callback);

    // Send immediate state
    const current = this.getClientState(roomId, playerId);
    if (current) {
      callback(current);
    }

    return () => {
      const subs = this.subscribers.get(roomId);
      if (subs) {
        subs.delete(playerId);
        if (subs.size === 0) {
          this.subscribers.delete(roomId);
        }
      }
    };
  }

  private broadcast(roomId: string) {
    const roomSubs = this.subscribers.get(roomId);
    if (!roomSubs) return;

    for (const [playerId, callback] of roomSubs.entries()) {
      const state = this.getClientState(roomId, playerId);
      if (state) {
        callback(state);
      }
    }
  }

  private addLog(room: CalbajiRoomState, textBn: string, textEn: string) {
    room.gameLogs.push({
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      timestamp: Date.now(),
      turnNumber: room.turnCount,
      textBn,
      textEn,
      type: 'action',
    });
  }

  private destroyRoom(roomId: string) {
    const interval = this.botIntervals.get(roomId);
    if (interval) {
      clearInterval(interval);
      this.botIntervals.delete(roomId);
    }
    const room = this.rooms.get(roomId);
    if (room) {
      this.rooms.delete(room.code);
      this.rooms.delete(roomId);
    }
    this.subscribers.delete(roomId);
  }
}

export const calbajiRoomManager = new CalbajiRoomManager();
