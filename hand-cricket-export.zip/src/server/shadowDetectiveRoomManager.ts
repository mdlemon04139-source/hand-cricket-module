import {
  GameMode,
  PlayerCountOption,
  ShadowPhase,
  ShadowPlayer,
  ShadowRoomClientState,
  NishipurCaseTruth,
  CaseQuestion,
  VerifiedStatement,
} from '../shadowdetective/types/shadowDetective';
import {
  NishipurCaseGenerator,
  CASE_QUESTIONS_CATALOG,
} from '../shadowdetective/engine/caseGenerator';
import { NISHIPUR_CHARACTERS } from '../data/nishipurCharacters';
import { gameStatsManager } from './gameStatsManager';

export interface InternalShadowRoom {
  roomId: string;
  roomCode: string;
  hostId: string;
  phase: ShadowPhase;
  mode: GameMode;
  targetPlayerCount: PlayerCountOption;
  players: ShadowPlayer[];
  caseTruth: NishipurCaseTruth;
  currentPhaseNumber: number;
  questionsRemainingInPhase: number;
  activeSuspectIds: string[];
  releasedSuspectIds: string[];
  finalTwoSuspectIds?: [string, string];
  activeInterrogation?: {
    targetSuspectId: string;
    question: CaseQuestion;
    waitingForAnswer: boolean;
  };
  evidenceNotebook: {
    publicEvidence: NishipurCaseTruth['evidenceList'];
    verifiedStatements: VerifiedStatement[];
  };
  tuhaUnlocked: boolean;
  finalVerdictResult?: ShadowRoomClientState['finalVerdictResult'];
  gameLogs: ShadowRoomClientState['gameLogs'];
  createdAt: number;
  lastActive: number;
}

export class ShadowDetectiveRoomManager {
  private rooms: Map<string, InternalShadowRoom> = new Map();
  private codeToRoomId: Map<string, string> = new Map();
  private subscribers: Map<string, Map<string, (state: ShadowRoomClientState) => void>> = new Map();
  private botTimeouts: Map<string, NodeJS.Timeout> = new Map();

  constructor() {
    // Cleanup stale rooms periodically (older than 3 hours)
    const cleanupInterval = setInterval(() => {
      const now = Date.now();
      for (const [roomId, room] of this.rooms.entries()) {
        if (now - room.lastActive > 3 * 60 * 60 * 1000) {
          this.codeToRoomId.delete(room.roomCode);
          this.rooms.delete(roomId);
          this.subscribers.delete(roomId);
        }
      }
    }, 60 * 1000);
    if (cleanupInterval.unref) {
      cleanupInterval.unref();
    }
  }

  public createRoom(
    hostName: string,
    hostAvatar: string,
    mode: GameMode = 'human_ai_multiplayer',
    targetPlayerCount: PlayerCountOption = 5
  ): { roomId: string; roomCode: string; playerId: string; state: ShadowRoomClientState | null } {
    const roomId = `nishipur_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const roomCode = Math.random().toString(36).substring(2, 6).toUpperCase();
    const hostPlayerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;

    const hostPlayer: ShadowPlayer = {
      id: hostPlayerId,
      nickname: hostName.trim() || 'প্রধান গোয়েন্দা রবিন',
      avatar: hostAvatar || '🕵️‍♂️',
      isHost: true,
      isBot: false,
      isOnline: true,
      isReady: true,
      assignedRole: 'robin',
      characterId: 'robin',
      isReleased: false,
    };

    const initialCase = NishipurCaseGenerator.generateCase(targetPlayerCount);

    const room: InternalShadowRoom = {
      roomId,
      roomCode,
      hostId: hostPlayerId,
      phase: mode === 'ai_solo' ? 'STORY_INTRO' : 'ROOM_LOBBY',
      mode,
      targetPlayerCount,
      players: [hostPlayer],
      caseTruth: initialCase,
      currentPhaseNumber: 1,
      questionsRemainingInPhase: 5,
      activeSuspectIds: [...initialCase.coreSuspectIds],
      releasedSuspectIds: [],
      evidenceNotebook: {
        publicEvidence: initialCase.evidenceList.filter((e) => e.isInitialClue),
        verifiedStatements: [],
      },
      tuhaUnlocked: false,
      gameLogs: [
        {
          id: `log_${Date.now()}`,
          textBn: `নিশিপুর শ্যাডো ডিটেক্টিভ শুরু হয়েছে। রুম কোড: ${roomCode}`,
          type: 'system',
          timestamp: Date.now(),
        },
      ],
      createdAt: Date.now(),
      lastActive: Date.now(),
    };

    // If AI Solo, automatically populate all other suspect seats with bots and deal roles immediately
    if (mode === 'ai_solo') {
      this.populateAiSoloBots(room);
      gameStatsManager.recordMatchStart('shadowdetective', roomId, hostPlayerId);
    }

    this.rooms.set(roomId, room);
    this.codeToRoomId.set(roomCode, roomId);

    const clientState = this.getClientState(roomId, hostPlayerId);
    return { roomId, roomCode, playerId: hostPlayerId, state: clientState };
  }

  private populateAiSoloBots(room: InternalShadowRoom) {
    const suspects = [...room.caseTruth.coreSuspectIds];
    if (room.caseTruth.supportingCharacterIds && room.caseTruth.supportingCharacterIds.length > 0) {
      suspects.push(...room.caseTruth.supportingCharacterIds);
    }

    for (let i = 0; i < suspects.length; i++) {
      const charId = suspects[i];
      const charData = NISHIPUR_CHARACTERS[charId];
      const botId = `bot_${charId}_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;

      room.players.push({
        id: botId,
        nickname: charData?.nameBn || `সন্দেহভাজন ${i + 1}`,
        avatar: charData?.avatarIcon || '👤',
        isHost: false,
        isBot: true,
        isOnline: true,
        isReady: true,
        assignedRole: 'suspect',
        characterId: charId,
        isReleased: false,
      });
    }

    room.activeSuspectIds = [...suspects];

    room.gameLogs.push({
      id: `log_solo_ready_${Date.now()}`,
      textBn: `একক অনুসন্ধানী খেলা প্রস্তুত: ${suspects.length} জন প্রধান সন্দেহভাজনকে নিশিপুর থানায় তলব করা হয়েছে।`,
      type: 'system',
      timestamp: Date.now(),
    });
  }

  public getRoom(roomIdOrCode: string): InternalShadowRoom | undefined {
    const id = this.codeToRoomId.get(roomIdOrCode.toUpperCase()) || roomIdOrCode;
    return this.rooms.get(id);
  }

  public joinRoom(
    roomIdentifier: string,
    playerName: string,
    playerAvatar: string
  ): { success: boolean; roomId?: string; playerId?: string; error?: string } {
    const room = this.getRoom(roomIdentifier);
    if (!room) {
      return { success: false, error: 'রুম কোডটি সঠিক নয় বা রুম খুঁজে পাওয়া যায়নি।' };
    }
    if (room.phase !== 'ROOM_LOBBY') {
      return { success: false, error: 'খেলা ইতিমধ্যেই শুরু হয়ে গেছে।' };
    }
    if (room.players.length >= room.targetPlayerCount) {
      return { success: false, error: `রুমে নির্ধারিত সর্বাধিক ${room.targetPlayerCount} জন আসন পূর্ণ রয়েছে।` };
    }

    const playerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newPlayer: ShadowPlayer = {
      id: playerId,
      nickname: playerName.trim() || `গ্রামবাসী ${room.players.length + 1}`,
      avatar: playerAvatar || '🕵️',
      isHost: false,
      isBot: false,
      isOnline: true,
      isReady: false,
      assignedRole: 'suspect',
      isReleased: false,
    };

    room.players.push(newPlayer);
    room.lastActive = Date.now();

    room.gameLogs.push({
      id: `log_join_${Date.now()}`,
      textBn: `${newPlayer.nickname} রুমে যুক্ত হয়েছেন।`,
      type: 'system',
      timestamp: Date.now(),
    });

    this.broadcast(room.roomId);
    return { success: true, roomId: room.roomId, playerId };
  }

  public addBot(roomId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.phase !== 'ROOM_LOBBY') return { success: false, error: 'খেলা শুরু হওয়ার পর নতুন বট যোগ করা যাবে না।' };
    if (room.players.length >= room.targetPlayerCount) {
      return { success: false, error: `সর্বোচ্চ ${room.targetPlayerCount} জন আসন পূর্ণ।` };
    }

    // Pick an available character from Nishipur suspects
    const assignedIds = new Set(room.players.map((p) => p.characterId).filter(Boolean));
    const available = NISHIPUR_CHARACTERS.map((c) => c.id).filter(
      (cid) => cid !== 'robin' && cid !== 'tuha' && !assignedIds.has(cid)
    );
    const chosenCid = available[0] || 'kalu_chor';
    const charData = NISHIPUR_CHARACTERS[chosenCid];

    const botId = `bot_${chosenCid}_${Date.now()}`;
    room.players.push({
      id: botId,
      nickname: charData.nameBn,
      avatar: charData.avatarIcon || '👤',
      isHost: false,
      isBot: true,
      isOnline: true,
      isReady: true,
      assignedRole: 'suspect',
      characterId: chosenCid,
      isReleased: false,
    });

    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  public removePlayer(roomId: string, playerId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.phase !== 'ROOM_LOBBY') {
      // In mid-game, mark player as offline and keep seat as bot
      this.setPlayerOnline(roomId, playerId, false);
      return { success: true };
    }

    const idx = room.players.findIndex((p) => p.id === playerId);
    if (idx === -1) return { success: false, error: 'খেলোয়াড় পাওয়া যায়নি।' };

    room.players.splice(idx, 1);
    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  public setPlayerOnline(roomId: string, playerId: string, isOnline: boolean): void {
    const room = this.rooms.get(roomId);
    if (!room) return;

    const player = room.players.find((p) => p.id === playerId);
    if (player) {
      player.isOnline = isOnline;
      if (!isOnline) {
        room.gameLogs.push({
          id: `log_offline_${Date.now()}`,
          textBn: `${player.nickname} সাময়িক অফলাইনে চলে গেছেন। তার বিকল্প হিসেবে সার্ভার এআই খেলবে।`,
          type: 'system',
          timestamp: Date.now(),
        });

        // If it was waiting for this player's interrogation answer, trigger bot answer
        if (
          room.activeInterrogation &&
          room.activeInterrogation.waitingForAnswer &&
          room.activeInterrogation.targetSuspectId === player.characterId
        ) {
          this.triggerBotAnswer(room, player.characterId);
        }
      } else {
        room.gameLogs.push({
          id: `log_online_${Date.now()}`,
          textBn: `${player.nickname} পুনরায় খেলায় ফিরে এসেছেন।`,
          type: 'system',
          timestamp: Date.now(),
        });
      }
      this.broadcast(roomId);
    }
  }

  public toggleReady(roomId: string, playerId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    const p = room.players.find((pl) => pl.id === playerId);
    if (!p) return { success: false, error: 'খেলোয়াড় খুঁজে পাওয়া যায়নি।' };

    p.isReady = !p.isReady;
    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  public updateTargetCount(
    roomId: string,
    hostId: string,
    count: PlayerCountOption
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== hostId) return { success: false, error: 'শুধুমাত্র হোস্ট খেলোয়াড় সংখ্যা পরিবর্তন করতে পারেন।' };

    room.targetPlayerCount = count;
    // Regenerate case for this count
    room.caseTruth = NishipurCaseGenerator.generateCase(count);
    room.activeSuspectIds = [...room.caseTruth.coreSuspectIds];
    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  public startGame(roomId: string, requesterId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== requesterId) return { success: false, error: 'শুধুমাত্র হোস্ট খেলা শুরু করতে পারেন।' };

    // Fill remaining spots with bots if needed
    const needed = room.targetPlayerCount - room.players.length;
    if (needed > 0) {
      for (let i = 0; i < needed; i++) {
        this.addBot(roomId);
      }
    }

    // Role and Character Assignment
    const suspects = [...room.caseTruth.coreSuspectIds];
    if (room.caseTruth.supportingCharacterIds && room.caseTruth.supportingCharacterIds.length > 0) {
      suspects.push(...room.caseTruth.supportingCharacterIds);
    }

    let suspectIdx = 0;
    room.players.forEach((p) => {
      if (p.id === room.hostId) {
        p.assignedRole = 'robin';
        p.characterId = 'robin';
      } else {
        p.assignedRole = 'suspect';
        p.characterId = suspects[suspectIdx++] || 'kalu_chor';
        // Sync nickname & avatar with canonical Nishipur characters
        const charData = NISHIPUR_CHARACTERS[p.characterId];
        if (charData) {
          if (p.isBot) {
            p.nickname = charData.nameBn;
          } else {
            p.nickname = `${p.nickname} [${charData.nameBn}]`;
          }
          p.avatar = charData.avatarIcon || p.avatar;
        }
      }
    });

    // If there are more suspects than human players + bots, add remaining bots
    while (suspectIdx < suspects.length) {
      const charId = suspects[suspectIdx++];
      const charData = NISHIPUR_CHARACTERS[charId];
      const botId = `bot_${charId}_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
      room.players.push({
        id: botId,
        nickname: charData?.nameBn || `সন্দেহভাজন ${suspectIdx}`,
        avatar: charData?.avatarIcon || '👤',
        isHost: false,
        isBot: true,
        isOnline: true,
        isReady: true,
        assignedRole: 'suspect',
        characterId: charId,
        isReleased: false,
      });
    }

    room.phase = 'STORY_INTRO';
    room.currentPhaseNumber = 1;
    room.questionsRemainingInPhase = 5;
    room.activeSuspectIds = [...suspects];
    room.releasedSuspectIds = [];
    room.evidenceNotebook = {
      publicEvidence: room.caseTruth.evidenceList.filter((e) => e.isInitialClue),
      verifiedStatements: [],
    };
    room.tuhaUnlocked = false;
    room.finalVerdictResult = undefined;

    room.gameLogs.push({
      id: `log_start_${Date.now()}`,
      textBn: `তদন্ত আনুষ্ঠানিকভাবে শুরু হয়েছে! নিশিপুরবাসীর সম্মুখে রবিন ও তুহা উপস্থিত।`,
      type: 'system',
      timestamp: Date.now(),
    });

    gameStatsManager.recordMatchStart('shadowdetective', roomId, requesterId);

    this.broadcast(roomId);
    return { success: true };
  }

  public advanceFromStoryIntro(roomId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    room.phase = 'ROLE_BRIEFING';
    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  public advanceFromRoleBriefing(roomId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    room.phase = 'PHASE_1_INTERROGATION';
    room.questionsRemainingInPhase = 5;
    room.lastActive = Date.now();

    room.gameLogs.push({
      id: `log_phase1_${Date.now()}`,
      textBn: `প্রথম পর্যায় শুরু: ৫ জন প্রধান সন্দেহভাজনকে ৫টি প্রশ্ন করার সুযোগ রয়েছে।`,
      type: 'system',
      timestamp: Date.now(),
    });

    this.broadcast(roomId);
    return { success: true };
  }

  // Interrogation: Robin asks a question
  public askQuestion(
    roomId: string,
    requesterId: string,
    targetSuspectId: string,
    questionId: string
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (
      room.phase !== 'PHASE_1_INTERROGATION' &&
      room.phase !== 'PHASE_2_INTERROGATION' &&
      room.phase !== 'PHASE_3_TUHA'
    ) {
      return { success: false, error: 'বর্তমানে জিজ্ঞাসাবাদের পর্যায় সক্রিয় নয়।' };
    }
    if (room.hostId !== requesterId) {
      return { success: false, error: 'শুধুমাত্র প্রধান গোয়েন্দা রবিন জিজ্ঞাসাবাদ করতে পারেন।' };
    }
    if (!room.activeSuspectIds.includes(targetSuspectId)) {
      return { success: false, error: 'এই সন্দেহভাজন সক্রিয় তালিকায় নেই।' };
    }
    if (room.questionsRemainingInPhase <= 0) {
      return { success: false, error: 'এই পর্যায়ের প্রশ্ন করার কোটা শেষ হয়েছে।' };
    }

    const question = CASE_QUESTIONS_CATALOG.find((q) => q.id === questionId);
    if (!question) {
      return { success: false, error: 'প্রশ্নটি তালিকায় পাওয়া যায়নি।' };
    }

    room.activeInterrogation = {
      targetSuspectId,
      question,
      waitingForAnswer: true,
    };
    room.lastActive = Date.now();

    const suspectPlayer = room.players.find((p) => p.characterId === targetSuspectId);
    const targetName = suspectPlayer ? suspectPlayer.nickname : NISHIPUR_CHARACTERS[targetSuspectId]?.nameBn || targetSuspectId;

    room.gameLogs.push({
      id: `log_ask_${Date.now()}`,
      textBn: `রবিন ${targetName}-কে প্রশ্ন করেছেন: "${question.promptBn}"`,
      type: 'interrogation',
      timestamp: Date.now(),
    });

    this.broadcast(roomId);

    // If target suspect is a Bot OR an offline human player, trigger automated answer
    if (!suspectPlayer || suspectPlayer.isBot || !suspectPlayer.isOnline) {
      this.triggerBotAnswer(room, targetSuspectId);
    }

    return { success: true };
  }

  private triggerBotAnswer(room: InternalShadowRoom, targetSuspectId: string) {
    if (this.botTimeouts.has(room.roomId)) {
      clearTimeout(this.botTimeouts.get(room.roomId)!);
    }

    const timeout = setTimeout(() => {
      const q = room.activeInterrogation?.question;
      if (!q || !room.activeInterrogation?.waitingForAnswer) return;

      const story = room.caseTruth.characterStories[targetSuspectId];
      let answerText = 'আমি এই বিষয়ে কিছু জানি না।';

      if (story && story.answers[q.id]) {
        const ans = story.answers[q.id];
        // If culprit and has bluff options, sometimes use bluff
        if (story.isCulprit && ans.bluffOptionsBn && ans.bluffOptionsBn.length > 0 && Math.random() > 0.4) {
          answerText = ans.bluffOptionsBn[Math.floor(Math.random() * ans.bluffOptionsBn.length)];
        } else {
          answerText = ans.truthBn;
        }
      }

      this.submitAnswer(room.roomId, targetSuspectId, answerText);
    }, 1200);

    if (timeout.unref) {
      timeout.unref();
    }
    this.botTimeouts.set(room.roomId, timeout);
  }

  // Answer submission (human or bot)
  public submitAnswer(
    roomId: string,
    characterId: string,
    answerText: string
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (!room.activeInterrogation || !room.activeInterrogation.waitingForAnswer) {
      return { success: false, error: 'কোনো সক্রিয় প্রশ্নের অপেক্ষা করা হচ্ছে না।' };
    }
    if (room.activeInterrogation.targetSuspectId !== characterId) {
      return { success: false, error: 'এই উত্তরটি আপনার জন্য নয়।' };
    }

    const q = room.activeInterrogation.question;
    const suspectPlayer = room.players.find((p) => p.characterId === characterId);
    const charName = suspectPlayer ? suspectPlayer.nickname : NISHIPUR_CHARACTERS[characterId]?.nameBn || characterId;

    const statement: VerifiedStatement = {
      id: `stmt_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      suspectId: characterId,
      suspectNameBn: charName,
      questionPromptBn: q.promptBn,
      answerTextBn: answerText,
      recordedPhase: room.currentPhaseNumber,
      timestamp: Date.now(),
    };

    room.evidenceNotebook.verifiedStatements.push(statement);
    room.questionsRemainingInPhase -= 1;
    room.activeInterrogation.waitingForAnswer = false;
    room.lastActive = Date.now();

    room.gameLogs.push({
      id: `log_ans_${Date.now()}`,
      textBn: `${charName} জবানবন্দি দিয়েছেন: "${answerText}"`,
      type: 'interrogation',
      timestamp: Date.now(),
    });

    // Phase transition checks
    if (room.questionsRemainingInPhase <= 0) {
      if (room.phase === 'PHASE_1_INTERROGATION') {
        room.phase = 'PHASE_1_RELEASE';
        room.gameLogs.push({
          id: `log_rel1_${Date.now()}`,
          textBn: `প্রথম পর্যায় সম্পন্ন! রবিনকে এখন ১ জন সন্দেহভাজনকে মুক্তি দিতে হবে। সতর্ক থাকুন: আসল অপরাধীকে ছাড়লে পরাজয়!`,
          type: 'system',
          timestamp: Date.now(),
        });
      } else if (room.phase === 'PHASE_2_INTERROGATION') {
        room.phase = 'PHASE_2_RELEASE';
        room.gameLogs.push({
          id: `log_rel2_${Date.now()}`,
          textBn: `দ্বিতীয় পর্যায় সম্পন্ন! রবিনকে আরও ১ জন সন্দেহভাজনকে মুক্তি দিতে হবে।`,
          type: 'system',
          timestamp: Date.now(),
        });
      } else if (room.phase === 'PHASE_3_TUHA') {
        room.phase = 'PHASE_3_RELEASE';
        room.gameLogs.push({
          id: `log_rel3_${Date.now()}`,
          textBn: `তৃতীয় পর্যায় সম্পন্ন! রবিনকে ১ জন সন্দেহভাজনকে মুক্তি দিয়ে চূড়ান্ত ২ জনে পৌঁছাতে হবে।`,
          type: 'system',
          timestamp: Date.now(),
        });
      }
    }

    this.broadcast(roomId);
    return { success: true };
  }

  // Mandatory Release of a suspect
  public releaseSuspect(
    roomId: string,
    requesterId: string,
    suspectId: string
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== requesterId) {
      return { success: false, error: 'শুধুমাত্র রবিন কাউকে মুক্তি দেওয়ার সিদ্ধান্ত নিতে পারেন।' };
    }
    if (
      room.phase !== 'PHASE_1_RELEASE' &&
      room.phase !== 'PHASE_2_RELEASE' &&
      room.phase !== 'PHASE_3_RELEASE'
    ) {
      return { success: false, error: 'বর্তমানে কাউকে মুক্তি দেওয়ার পর্যায় সক্রিয় নয়।' };
    }
    if (!room.activeSuspectIds.includes(suspectId)) {
      return { success: false, error: 'এই চরিত্রটি সক্রিয় সন্দেহভাজনের তালিকায় নেই।' };
    }

    const charName = NISHIPUR_CHARACTERS[suspectId]?.nameBn || suspectId;

    // CRITICAL RULE: If Robin releases the TRUE CULPRIT during any release phase -> IMMEDIATE DEFEAT!
    if (suspectId === room.caseTruth.culpritCharacterId) {
      room.phase = 'CASE_RESOLVED';
      room.finalVerdictResult = {
        declaredGuiltyId: 'NONE_RELEASED_CULPRIT',
        declaredInnocentId: suspectId,
        isVictory: false,
        trueCulpritId: room.caseTruth.culpritCharacterId,
        motiveBn: room.caseTruth.motiveBn,
        timelineBn: room.caseTruth.timelineBn,
        keyContradictionsBn: room.caseTruth.keyContradictionsBn,
        finalCaseExplanationBn: `বিপর্যয়! আপনি ভুলবশত আসল অপরাধী (${charName})-কে মুক্তি দিয়েছেন! সুযোগ পেয়ে সে নিশিপুর সীমান্ত অতিক্রম করে চিরতরে পালিয়েছে। তদন্ত সম্পূর্ণ ব্যর্থ হয়েছে।`,
      };

      room.gameLogs.push({
        id: `log_defeat_release_${Date.now()}`,
        textBn: `❌ বিপর্যয়! আপনি আসল অপরাধী ${charName}-কে ছেড়ে দিয়েছেন! নিশিপুরের রহস্য অমীমাংসিত রয়ে গেল।`,
        type: 'verdict',
        timestamp: Date.now(),
      });

      this.broadcast(roomId);
      return { success: true };
    }

    // Innocent suspect is released
    room.activeSuspectIds = room.activeSuspectIds.filter((id) => id !== suspectId);
    room.releasedSuspectIds.push(suspectId);
    const releasedPlayer = room.players.find((p) => p.characterId === suspectId);
    if (releasedPlayer) releasedPlayer.isReleased = true;

    room.gameLogs.push({
      id: `log_rel_succ_${Date.now()}`,
      textBn: `সন্দেহমুক্ত হয়ে ${charName} নিশিপুর থানা থেকে মুক্তি পেয়েছেন।`,
      type: 'release',
      timestamp: Date.now(),
    });

    // Advance to next phase based on current phase
    if (room.activeSuspectIds.length <= 2) {
      // Reached final two suspects!
      room.phase = 'FINAL_VERDICT';
      room.finalTwoSuspectIds = [room.activeSuspectIds[0], room.activeSuspectIds[1] || room.activeSuspectIds[0]];
      room.gameLogs.push({
        id: `log_final_two_${Date.now()}`,
        textBn: `চূড়ান্ত দ্বৈরথ! শেষ ২ জন সন্দেহভাজন: ${NISHIPUR_CHARACTERS[room.finalTwoSuspectIds[0]]?.nameBn} এবং ${NISHIPUR_CHARACTERS[room.finalTwoSuspectIds[1]]?.nameBn}। চূড়ান্ত রায় ঘোষণা করুন!`,
        type: 'system',
        timestamp: Date.now(),
      });
    } else if (room.phase === 'PHASE_1_RELEASE') {
      room.phase = 'PHASE_2_INTERROGATION';
      room.currentPhaseNumber = 2;
      room.questionsRemainingInPhase = 3;
      // Unlock phase 2 evidence
      const phase2Clues = room.caseTruth.evidenceList.filter((e) => e.unlockedInPhase === 2);
      phase2Clues.forEach((c) => {
        if (!room.evidenceNotebook.publicEvidence.some((e) => e.id === c.id)) {
          room.evidenceNotebook.publicEvidence.push(c);
        }
      });
    } else if (room.phase === 'PHASE_2_RELEASE') {
      room.phase = 'PHASE_3_TUHA';
      room.currentPhaseNumber = 3;
      room.questionsRemainingInPhase = 1;
      room.tuhaUnlocked = true;
      // Unlock phase 3 evidence
      const phase3Clues = room.caseTruth.evidenceList.filter((e) => e.unlockedInPhase === 3);
      phase3Clues.forEach((c) => {
        if (!room.evidenceNotebook.publicEvidence.some((e) => e.id === c.id)) {
          room.evidenceNotebook.publicEvidence.push(c);
        }
      });
      room.gameLogs.push({
        id: `log_tuha_unlock_${Date.now()}`,
        textBn: `সহকারী তুহা নতুন ফরেনসিক তথ্য ও রাসায়নিক ল্যাব রিপোর্ট নিয়ে উপস্থিত হয়েছেন!`,
        type: 'tuha',
        timestamp: Date.now(),
      });
    } else if (room.phase === 'PHASE_3_RELEASE') {
      room.phase = 'FINAL_VERDICT';
      room.finalTwoSuspectIds = [room.activeSuspectIds[0], room.activeSuspectIds[1] || room.activeSuspectIds[0]];
      room.gameLogs.push({
        id: `log_final_two_${Date.now()}`,
        textBn: `চূড়ান্ত দ্বৈরথ! শেষ ২ জন সন্দেহভাজন: ${NISHIPUR_CHARACTERS[room.finalTwoSuspectIds[0]]?.nameBn} এবং ${NISHIPUR_CHARACTERS[room.finalTwoSuspectIds[1]]?.nameBn}। চূড়ান্ত রায় ঘোষণা করুন!`,
        type: 'system',
        timestamp: Date.now(),
      });
    }

    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  // Final Verdict: Choose Guilty and Innocent from Final Two
  public submitFinalVerdict(
    roomId: string,
    requesterId: string,
    guiltySuspectId: string,
    innocentSuspectId: string
  ): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== requesterId) {
      return { success: false, error: 'শুধুমাত্র রবিন চূড়ান্ত রায় দিতে পারেন।' };
    }
    if (room.phase !== 'FINAL_VERDICT') {
      return { success: false, error: 'বর্তমানে চূড়ান্ত রায়ের পর্যায় নয়।' };
    }

    const isVictory = guiltySuspectId === room.caseTruth.culpritCharacterId;
    const guiltyName = NISHIPUR_CHARACTERS[guiltySuspectId]?.nameBn || guiltySuspectId;
    const innocentName = NISHIPUR_CHARACTERS[innocentSuspectId]?.nameBn || innocentSuspectId;

    room.phase = 'CASE_RESOLVED';
    room.finalVerdictResult = {
      declaredGuiltyId: guiltySuspectId,
      declaredInnocentId: innocentSuspectId,
      isVictory,
      trueCulpritId: room.caseTruth.culpritCharacterId,
      motiveBn: room.caseTruth.motiveBn,
      timelineBn: room.caseTruth.timelineBn,
      keyContradictionsBn: room.caseTruth.keyContradictionsBn,
      finalCaseExplanationBn: isVictory
        ? `অসাধারণ বুদ্ধিমত্তা! রবিন ও তুহার যৌথ তদন্তে নিশিপুরের রহস্য সমাধান হলো। ${guiltyName}-এর সমস্ত অসঙ্গতি ও অপরাধ প্রমাণ হয়েছে!`
        : `তদন্তে ভ্রান্তি! ${innocentName} ছিলেন নির্দোষ গ্রামবাসী। আসল অপরাধী ছিল ${NISHIPUR_CHARACTERS[room.caseTruth.culpritCharacterId]?.nameBn}।`,
    };

    room.gameLogs.push({
      id: `log_verdict_${Date.now()}`,
      textBn: isVictory
        ? `🎉 মহাবিজয়! রবিন সফলভাবে আসল অপরাধী ${guiltyName}-কে শনাক্ত করেছেন!`
        : `💔 পরাজয়! নির্দোষ ব্যক্তিকে অভিযুক্ত করা হয়েছে। আসল অপরাধী নিশিপুরে অবাধে ঘুরছে।`,
      type: 'verdict',
      timestamp: Date.now(),
    });

    room.lastActive = Date.now();
    this.broadcast(roomId);
    return { success: true };
  }

  public restartMatch(roomId: string, requesterId: string): { success: boolean; error?: string } {
    const room = this.rooms.get(roomId);
    if (!room) return { success: false, error: 'রুম পাওয়া যায়নি।' };
    if (room.hostId !== requesterId) return { success: false, error: 'শুধুমাত্র হোস্ট রিস্টার্ট করতে পারেন।' };

    // Generate fresh case
    room.caseTruth = NishipurCaseGenerator.generateCase(room.targetPlayerCount);
    room.phase = room.mode === 'ai_solo' ? 'STORY_INTRO' : 'ROOM_LOBBY';
    room.currentPhaseNumber = 1;
    room.questionsRemainingInPhase = 5;
    room.activeSuspectIds = [...room.caseTruth.coreSuspectIds];
    room.releasedSuspectIds = [];
    room.finalTwoSuspectIds = undefined;
    room.finalVerdictResult = undefined;
    room.tuhaUnlocked = false;
    room.activeInterrogation = undefined;
    room.evidenceNotebook = {
      publicEvidence: room.caseTruth.evidenceList.filter((e) => e.isInitialClue),
      verifiedStatements: [],
    };
    room.players.forEach((p) => {
      p.isReleased = false;
    });

    if (room.mode === 'ai_solo') {
      const host = room.players.find((p) => p.isHost)!;
      room.players = [host];
      this.populateAiSoloBots(room);
    }

    room.gameLogs.push({
      id: `log_restart_${Date.now()}`,
      textBn: `একটি নতুন মামলা নথিভুক্ত হয়েছে। নিশিপুরের পরবর্তী রহস্য উন্মোচনের প্রস্তুতি চলছে!`,
      type: 'system',
      timestamp: Date.now(),
    });

    gameStatsManager.recordMatchStart('shadowdetective', roomId, requesterId);

    this.broadcast(roomId);
    return { success: true };
  }

  // Subscribe to real-time events
  public subscribe(
    roomId: string,
    playerId: string,
    callback: (state: ShadowRoomClientState) => void
  ): () => void {
    if (!this.subscribers.has(roomId)) {
      this.subscribers.set(roomId, new Map());
    }
    const roomSubs = this.subscribers.get(roomId)!;
    roomSubs.set(playerId, callback);

    // Immediately push initial state
    const state = this.getClientState(roomId, playerId);
    if (state) callback(state);

    return () => {
      roomSubs.delete(playerId);
      if (roomSubs.size === 0) {
        this.subscribers.delete(roomId);
      }
    };
  }

  private broadcast(roomId: string) {
    const roomSubs = this.subscribers.get(roomId);
    if (!roomSubs) return;

    for (const [playerId, callback] of roomSubs.entries()) {
      const state = this.getClientState(roomId, playerId);
      if (state) callback(state);
    }
  }

  // Secure client state generation with Information Isolation
  public getClientState(roomId: string, playerId: string): ShadowRoomClientState | null {
    const room = this.rooms.get(roomId);
    if (!room) return null;

    let me = room.players.find((p) => p.id === playerId);
    if (!me) {
      // Allow spectator or host
      me = {
        id: playerId,
        nickname: 'দর্শক',
        avatar: '👀',
        isHost: false,
        isBot: false,
        isOnline: true,
        isReady: true,
        assignedRole: 'suspect',
        isReleased: false,
      };
    }

    // Role briefing information isolation:
    // Only provide private briefing to the character player
    let myPrivateBriefing: ShadowRoomClientState['myPrivateBriefing'] = undefined;
    if (me.characterId && me.characterId !== 'robin' && me.characterId !== 'tuha') {
      const story = room.caseTruth.characterStories[me.characterId];
      if (story) {
        myPrivateBriefing = {
          characterId: me.characterId,
          characterNameBn: NISHIPUR_CHARACTERS[me.characterId]?.nameBn || me.characterId,
          roleInCaseBn: story.roleInCaseBn,
          privateBriefingStoryBn: story.privateBriefingStoryBn,
          secretBn: story.secretBn,
          alibiBn: story.alibiBn,
          bluffTokensRemaining: story.bluffTokensRemaining,
          canBluff: story.canBluff,
        };
      }
    }

    // Prepare active interrogation answers if player is the target suspect
    let activeInterrogation: ShadowRoomClientState['activeInterrogation'] = undefined;
    if (room.activeInterrogation) {
      let availableAnswers: string[] | undefined = undefined;
      if (
        me.characterId === room.activeInterrogation.targetSuspectId &&
        room.activeInterrogation.waitingForAnswer
      ) {
        const story = room.caseTruth.characterStories[me.characterId];
        const qid = room.activeInterrogation.question.id;
        if (story && story.answers[qid]) {
          availableAnswers = [story.answers[qid].truthBn];
          if (story.isCulprit && story.answers[qid].bluffOptionsBn) {
            availableAnswers.push(...story.answers[qid].bluffOptionsBn!);
          }
        }
      }

      activeInterrogation = {
        targetSuspectId: room.activeInterrogation.targetSuspectId,
        question: room.activeInterrogation.question,
        waitingForAnswer: room.activeInterrogation.waitingForAnswer,
        availableAnswers,
      };
    }

    // Tuha assistance: only show hints if phase 3 unlocked
    let tuhaAssistance: ShadowRoomClientState['tuhaAssistance'] = undefined;
    if (room.tuhaUnlocked) {
      tuhaAssistance = {
        isUnlocked: true,
        hintBn: room.caseTruth.tuhaHintBn,
        evidenceAnalysisBn: room.caseTruth.tuhaEvidenceAnalysisBn,
      };
    }

    return {
      roomId: room.roomId,
      roomCode: room.roomCode,
      hostId: room.hostId,
      phase: room.phase,
      mode: room.mode,
      targetPlayerCount: room.targetPlayerCount,
      myPlayerId: playerId,
      myPlayer: me,
      players: room.players,
      caseOverview: {
        caseId: room.caseTruth.caseId,
        titleBn: room.caseTruth.titleBn,
        categoryNameBn: room.caseTruth.categoryNameBn,
        locationNameBn: room.caseTruth.locationNameBn,
        incidentTimeBn: room.caseTruth.incidentTimeBn,
        shortPublicStoryPages: room.caseTruth.shortPublicStoryPages,
        coreSuspectIds: room.caseTruth.coreSuspectIds,
        supportingCharacterIds: room.caseTruth.supportingCharacterIds,
      },
      myPrivateBriefing,
      currentPhaseNumber: room.currentPhaseNumber,
      questionsRemainingInPhase: room.questionsRemainingInPhase,
      releasedSuspectIds: room.releasedSuspectIds,
      activeSuspectIds: room.activeSuspectIds,
      finalTwoSuspectIds: room.finalTwoSuspectIds,
      activeInterrogation,
      evidenceNotebook: room.evidenceNotebook,
      tuhaAssistance,
      finalVerdictResult: room.finalVerdictResult,
      gameLogs: room.gameLogs.slice(-30),
    };
  }
}

export const shadowDetectiveRoomManager = new ShadowDetectiveRoomManager();
