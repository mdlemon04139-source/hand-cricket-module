import {
  ActionType,
  AIPersonality,
  Card,
  CharacterId,
  PendingAction,
  Player,
} from '../types/game';
import { ALL_CHARACTERS } from '../data/characters';

export interface AIDecision {
  actionType: ActionType;
  claimedCharacter?: CharacterId;
  targetId?: string;
  isBluff: boolean;
}

export interface AIReactionDecision {
  type: 'challenge' | 'block' | 'pass';
  claimedBlockCharacter?: CharacterId;
}

/**
 * AI Decision Engine implementing distinct personalities:
 * - Cautious (সতর্ক)
 * - Aggressive (আক্রমণাত্মক)
 * - Strategic (কৌশলী)
 *
 * Rules: AI NEVER cheats or peeks at hidden cards in other players' hands or deck.
 * It only uses its own hand, the public discard pile, coin counts, and past actions.
 */
export class AIEngine {
  /**
   * Helper: Count how many copies of characterId the AI personally knows about
   * (in AI's own hand + dead discarded cards from all players).
   */
  private static getKnownCopiesCount(
    aiPlayer: Player,
    discardedCards: Card[],
    characterId: CharacterId
  ): number {
    const inHand = aiPlayer.cards.filter(
      (c) => !c.isRevealed && c.characterId === characterId
    ).length;
    const inDiscard = discardedCards.filter(
      (c) => c.characterId === characterId
    ).length;
    return inHand + inDiscard;
  }

  /**
   * AI selects which action to take on its turn.
   */
  public static chooseAction(
    aiPlayer: Player,
    allPlayers: Player[],
    discardedCards: Card[],
    selectedCharacters: CharacterId[],
    activeTaxToken?: { characterId: CharacterId; placedBy: string }
  ): AIDecision {
    const livingOpponents = allPlayers.filter(
      (p) => !p.isEliminated && p.id !== aiPlayer.id
    );

    // If AI has 10 or more coins, mandatory Coup (সুপ্রিম নিধন)
    if (aiPlayer.coins >= 10) {
      const target = this.pickTarget(aiPlayer, livingOpponents, 'coup');
      return {
        actionType: 'coup',
        targetId: target.id,
        isBluff: false,
      };
    }

    const personality = aiPlayer.personality || 'strategic';
    const activeHand = aiPlayer.cards.filter((c) => !c.isRevealed);
    const handCharIds = activeHand.map((c) => c.characterId);

    // Check if AI can and wants to do Coup at 7+ coins
    if (aiPlayer.coins >= 7) {
      // Aggressive always coups at 7 coins; others coup if an opponent has 1 life or high coins
      const highThreat = livingOpponents.some(
        (p) => p.coins >= 6 || p.cards.filter((c) => !c.isRevealed).length === 1
      );
      if (personality === 'aggressive' || highThreat || Math.random() < 0.75) {
        const target = this.pickTarget(aiPlayer, livingOpponents, 'coup');
        return {
          actionType: 'coup',
          targetId: target.id,
          isBluff: false,
        };
      }
    }

    // List all legal character abilities available in this game
    const legalCharacters = selectedCharacters
      .map((id) => ALL_CHARACTERS[id])
      .filter(Boolean);

    // Check affordable options
    const candidates: {
      actionType: ActionType;
      characterId?: CharacterId;
      targetId?: string;
      weight: number;
      isBluff: boolean;
    }[] = [];

    // Always can do Income (cannot be challenged/blocked)
    candidates.push({
      actionType: 'income',
      weight: personality === 'cautious' ? 25 : 12,
      isBluff: false,
    });

    legalCharacters.forEach((char) => {
      // Check coin affordability
      if (aiPlayer.coins < char.coinCost) return;

      const hasCard = handCharIds.includes(char.id);
      const isTaxed = activeTaxToken?.characterId === char.id;
      const taxPenalty = isTaxed ? 15 : 0;

      let baseWeight = 20;

      // Personality adjustments for bluffing
      if (!hasCard) {
        if (personality === 'cautious') {
          baseWeight = 5; // rarely bluffs
        } else if (personality === 'aggressive') {
          baseWeight = 18; // bluffs often
        } else {
          // Strategic: bluffs if character is not exhausted
          const known = this.getKnownCopiesCount(aiPlayer, discardedCards, char.id);
          baseWeight = known >= 2 ? 2 : 14;
        }
      } else {
        // AI actually has the card! Much safer.
        baseWeight += personality === 'cautious' ? 35 : 25;
      }

      baseWeight = Math.max(1, baseWeight - taxPenalty);

      // Character-specific weights & targets
      if (char.id === 'nawab') {
        candidates.push({
          actionType: 'nawab_tax',
          characterId: 'nawab',
          weight: baseWeight + (aiPlayer.coins < 4 ? 20 : 10),
          isBluff: !hasCard,
        });
      } else if (char.id === 'sodagor') {
        candidates.push({
          actionType: 'sodagor_trade',
          characterId: 'sodagor',
          weight: baseWeight + 22,
          isBluff: !hasCard,
        });
      } else if (char.id === 'guptoghatok' && aiPlayer.coins >= 3) {
        const target = this.pickTarget(aiPlayer, livingOpponents, 'attack');
        candidates.push({
          actionType: 'assassinate',
          characterId: 'guptoghatok',
          targetId: target.id,
          weight: baseWeight + (personality === 'aggressive' ? 28 : 18),
          isBluff: !hasCard,
        });
      } else if (char.id === 'nishachor' && aiPlayer.coins >= 5) {
        const target = this.pickTarget(aiPlayer, livingOpponents, 'attack');
        candidates.push({
          actionType: 'nishachor_strike',
          characterId: 'nishachor',
          targetId: target.id,
          weight: baseWeight + 20,
          isBluff: !hasCard,
        });
      } else if (char.id === 'dosyu_sordar') {
        const validVictims = livingOpponents.filter((p) => p.coins > 0);
        if (validVictims.length > 0) {
          const target = this.pickTarget(aiPlayer, validVictims, 'steal');
          candidates.push({
            actionType: 'dosyu_steal',
            characterId: 'dosyu_sordar',
            targetId: target.id,
            weight: baseWeight + 16,
            isBluff: !hasCard,
          });
        }
      } else if (char.id === 'sidhel_chor') {
        const anyCoins = livingOpponents.some((p) => p.coins > 0);
        if (anyCoins) {
          candidates.push({
            actionType: 'sidhel_raid',
            characterId: 'sidhel_chor',
            weight: baseWeight + 18,
            isBluff: !hasCard,
          });
        }
      } else if (char.id === 'guptochor' || char.id === 'jyotishi') {
        // Exchange cards if hand has duplicates or unwanted cards
        const duplicates = new Set(handCharIds).size < handCharIds.length;
        const exchangeDesire = duplicates || !hasCard ? 20 : 10;
        candidates.push({
          actionType: char.id === 'guptochor' ? 'guptochor_spy' : 'jyotishi_divine',
          characterId: char.id,
          weight: baseWeight + exchangeDesire,
          isBluff: !hasCard,
        });
      } else if (char.id === 'khajnadar') {
        // Tax token: place on popular card like Nawab or Sodagor
        candidates.push({
          actionType: 'khajnadar_tax',
          characterId: 'khajnadar',
          weight: baseWeight + 10,
          isBluff: !hasCard,
        });
      }
    });

    // Roulette wheel selection based on weights
    const totalWeight = candidates.reduce((sum, c) => sum + c.weight, 0);
    let rand = Math.random() * totalWeight;

    for (const c of candidates) {
      if (rand < c.weight) {
        return {
          actionType: c.actionType,
          claimedCharacter: c.characterId,
          targetId: c.targetId,
          isBluff: c.isBluff,
        };
      }
      rand -= c.weight;
    }

    // Fallback to income
    return {
      actionType: 'income',
      isBluff: false,
    };
  }

  /**
   * Pick most strategic target among living opponents.
   */
  private static pickTarget(
    aiPlayer: Player,
    opponents: Player[],
    intent: 'attack' | 'steal' | 'coup'
  ): Player {
    if (opponents.length === 1) return opponents[0];

    if (intent === 'steal') {
      // Steal from the player with the most coins
      const sortedByCoins = [...opponents].sort((a, b) => b.coins - a.coins);
      return sortedByCoins[0];
    }

    if (intent === 'attack' || intent === 'coup') {
      // Priority 1: Finish off a player with only 1 life left (especially if rich)
      const oneLifePlayers = opponents.filter(
        (p) => p.cards.filter((c) => !c.isRevealed).length === 1
      );
      if (oneLifePlayers.length > 0) {
        oneLifePlayers.sort((a, b) => b.coins - a.coins);
        return oneLifePlayers[0];
      }

      // Priority 2: Hit player with highest coins
      const sortedByCoins = [...opponents].sort((a, b) => b.coins - a.coins);
      return sortedByCoins[0];
    }

    return opponents[Math.floor(Math.random() * opponents.length)];
  }

  /**
   * Decide whether to challenge an action, block it, or pass.
   */
  public static evaluateReaction(
    aiPlayer: Player,
    actor: Player,
    pendingAction: PendingAction,
    discardedCards: Card[],
    selectedCharacters: CharacterId[]
  ): AIReactionDecision {
    const personality = aiPlayer.personality || 'strategic';
    const activeHand = aiPlayer.cards.filter((c) => !c.isRevealed);
    const handCharIds = activeHand.map((c) => c.characterId);
    const claimedChar = pendingAction.claimedCharacter;

    if (!claimedChar) {
      return { type: 'pass' };
    }

    const knownCopies = this.getKnownCopiesCount(
      aiPlayer,
      discardedCards,
      claimedChar
    );

    // Rule of certainty: 3 copies exist in deck total.
    // If AI knows 3 copies are accounted for (in own hand + discard),
    // claimant is 100% BLUFFING!
    if (knownCopies >= 3) {
      return { type: 'challenge' };
    }

    // If action has a specific target and this AI is NOT the target,
    // bystanders naturally skip/pass to let the target handle reaction
    if (pendingAction.targetId && pendingAction.targetId !== aiPlayer.id) {
      return { type: 'pass' };
    }

    // Check if AI is the target of a theft (Dosyu Sordar)
    if (
      pendingAction.actionType === 'dosyu_steal' &&
      pendingAction.targetId === aiPlayer.id
    ) {
      const hasDosyu = handCharIds.includes('dosyu_sordar');
      const dosyuInGame = selectedCharacters.includes('dosyu_sordar');

      if (dosyuInGame) {
        // Can claim block with Dosyu Sordar
        if (hasDosyu) {
          return { type: 'block', claimedBlockCharacter: 'dosyu_sordar' };
        }
        // Bluff block?
        if (personality === 'aggressive' && Math.random() < 0.45) {
          return { type: 'block', claimedBlockCharacter: 'dosyu_sordar' };
        }
        if (personality === 'strategic' && Math.random() < 0.25) {
          return { type: 'block', claimedBlockCharacter: 'dosyu_sordar' };
        }
      }
    }

    // Probability evaluation for challenge
    let challengeChance = 0.05; // baseline small curiosity

    if (knownCopies === 2) {
      // Only 1 copy could possibly exist in the wild! High suspicion.
      challengeChance = 0.55;
    }

    // High impact actions attract more challenges
    if (claimedChar === 'guptoghatok' && pendingAction.targetId === aiPlayer.id) {
      // You are about to lose a life!
      challengeChance += 0.45;
    } else if (claimedChar === 'sodagor') {
      // 4 coins is a massive haul!
      challengeChance += 0.25;
    } else if (claimedChar === 'nawab') {
      challengeChance += 0.15;
    }

    // Personality factors
    if (personality === 'cautious') {
      challengeChance *= 0.4;
      // Cautious almost never challenges with 1 life remaining
      if (activeHand.length === 1 && knownCopies < 2) {
        challengeChance = 0.02;
      }
    } else if (personality === 'aggressive') {
      challengeChance *= 1.35;
    } else if (personality === 'strategic') {
      // If actor has 1 card left or many coins, challenge more
      if (actor.coins >= 6) challengeChance += 0.2;
    }

    if (Math.random() < Math.min(0.85, challengeChance)) {
      return { type: 'challenge' };
    }

    return { type: 'pass' };
  }

  /**
   * Decide whether to challenge a block.
   */
  public static evaluateBlockChallenge(
    aiPlayer: Player,
    blocker: Player,
    blockerClaim: CharacterId,
    discardedCards: Card[]
  ): boolean {
    const knownCopies = this.getKnownCopiesCount(
      aiPlayer,
      discardedCards,
      blockerClaim
    );

    if (knownCopies >= 3) return true; // 100% bluff

    const personality = aiPlayer.personality || 'strategic';
    let chance = 0.15;
    if (knownCopies === 2) chance = 0.5;

    if (personality === 'aggressive') chance += 0.2;
    if (personality === 'cautious') chance -= 0.1;

    return Math.random() < chance;
  }

  /**
   * Decide action when Nishachor attacks this AI player:
   * Choices:
   * 1. 'bribe': Pay 2 coins to cancel attack (if AI has 2+ coins)
   * 2. 'challenge': Accuse Nishachor user of bluffing
   * 3. 'take_hit': Suffer 1 life loss
   */
  public static evaluateNishachorResponse(
    aiPlayer: Player,
    attacker: Player,
    discardedCards: Card[]
  ): 'bribe' | 'challenge' | 'take_hit' {
    const knownCopies = this.getKnownCopiesCount(
      aiPlayer,
      discardedCards,
      'nishachor'
    );
    const activeHand = aiPlayer.cards.filter((c) => !c.isRevealed);

    // If 100% sure bluff, always challenge!
    if (knownCopies >= 3) return 'challenge';

    // If AI has coins to bribe
    if (aiPlayer.coins >= 2) {
      if (activeHand.length === 1) {
        // Last life: very high priority to protect! Bribe or challenge if very sure
        if (knownCopies === 2 && Math.random() < 0.6) return 'challenge';
        return 'bribe';
      }

      // 2 lives left:
      const personality = aiPlayer.personality || 'strategic';
      if (personality === 'cautious') return 'bribe';
      if (personality === 'aggressive' && Math.random() < 0.4) return 'challenge';
      if (personality === 'strategic') {
        return Math.random() < 0.25 ? 'challenge' : 'bribe';
      }
      return 'bribe';
    }

    // Cannot afford bribe: must challenge or take hit
    if (knownCopies >= 2 || Math.random() < 0.4) return 'challenge';
    return 'take_hit';
  }

  /**
   * Select which card to reveal and discard when losing a life.
   */
  public static pickCardToDiscard(aiPlayer: Player): Card {
    const activeCards = aiPlayer.cards.filter((c) => !c.isRevealed);
    if (activeCards.length <= 1) return activeCards[0];

    // If duplicate in hand, discard the duplicate
    if (activeCards[0].characterId === activeCards[1].characterId) {
      return activeCards[0];
    }

    // Keep offensive / high-coin characters if possible (Guptoghatok, Nawab, Sodagor)
    const priorityScore: Record<CharacterId, number> = {
      guptoghatok: 10,
      sodagor: 9,
      nawab: 8,
      nishachor: 7,
      dosyu_sordar: 6,
      khajnadar: 5,
      sidhel_chor: 4,
      jyotishi: 3,
      guptochor: 2,
    };

    activeCards.sort(
      (a, b) =>
        (priorityScore[a.characterId] || 0) - (priorityScore[b.characterId] || 0)
    );

    // Discard the lowest priority card
    return activeCards[0];
  }

  /**
   * Choose best character to place Tax Token on (Khajnadar action).
   */
  public static pickTaxTokenTarget(
    selectedCharacters: CharacterId[],
    currentTaxed?: CharacterId
  ): CharacterId {
    // High-frequency economic cards make the best tax targets
    const preferred: CharacterId[] = [
      'nawab',
      'sodagor',
      'dosyu_sordar',
      'sidhel_chor',
      'guptoghatok',
    ];
    for (const charId of preferred) {
      if (selectedCharacters.includes(charId) && charId !== currentTaxed) {
        return charId;
      }
    }
    const other = selectedCharacters.find((c) => c !== currentTaxed);
    return other || selectedCharacters[0];
  }
}
