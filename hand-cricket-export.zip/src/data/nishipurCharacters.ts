// Nishipur (নিশিপুর) Character Universe & Lore Data
// Driven by Central Verified Character Registry

import {
  VerifiedCharacterRecord,
  VERIFIED_CHARACTER_REGISTRY,
  ALL_VERIFIED_CHARACTERS,
  ORDERED_CHARACTER_IDS,
} from '../shadowdetective/data/characterRegistry';

export type NishipurCharacter = VerifiedCharacterRecord;

const charMap: Record<string, NishipurCharacter> = { ...VERIFIED_CHARACTER_REGISTRY };

export type NishipurCharactersType = NishipurCharacter[] & Record<string, NishipurCharacter>;

export const NISHIPUR_CHARACTERS: NishipurCharactersType = Object.assign(
  [...ALL_VERIFIED_CHARACTERS],
  charMap
);

export function getNishipurCharacter(id: string): NishipurCharacter | undefined {
  return charMap[id];
}

export {
  VERIFIED_CHARACTER_REGISTRY,
  ALL_VERIFIED_CHARACTERS,
  ORDERED_CHARACTER_IDS,
};
