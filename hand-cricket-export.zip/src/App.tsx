import React, { useState, useEffect } from 'react';
import { CharacterId, GameSettings } from './types/game';
import { DEFAULT_PRESET_5 } from './data/characters';
import { KhelghorHome } from './components/KhelghorHome';
import { CharacterSelectScreen } from './components/CharacterSelectScreen';
import { GameBoard } from './components/GameBoard';
import { RulesModal } from './components/RulesModal';
import { CalbajiLobby } from './components/calbaji/CalbajiLobby';
import { BorderPassLobby } from './components/borderpass/BorderPassLobby';
import { BorderPassBoard } from './components/borderpass/BorderPassBoard';
import { BorderPassRulesModal } from './components/borderpass/BorderPassRulesModal';
import { ShadowDetectiveApp } from './shadowdetective/components/ShadowDetectiveApp';
import { HandCricketApp } from './handcricket/components/HandCricketApp';
import { sound } from './utils/sound';

type AppView =
  | 'khelghor_home'
  | 'calbaji_lobby'
  | 'calbaji_solo_select'
  | 'calbaji_game'
  | 'borderpass_lobby'
  | 'borderpass_game'
  | 'shadowdetective_app'
  | 'handcricket_app';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('khelghor_home');
  const [selectedCharacters, setSelectedCharacters] = useState<CharacterId[]>(DEFAULT_PRESET_5);
  const [isCalbajiRulesOpen, setIsCalbajiRulesOpen] = useState<boolean>(false);
  const [isBorderPassRulesOpen, setIsBorderPassRulesOpen] = useState<boolean>(false);

  // Active Calbaji room session
  const [calbajiRoomId, setCalbajiRoomId] = useState<string | null>(null);
  const [calbajiPlayerId, setCalbajiPlayerId] = useState<string | null>(null);

  // Active Border Pass room session
  const [borderPassRoomId, setBorderPassRoomId] = useState<string | null>(null);
  const [borderPassPlayerId, setBorderPassPlayerId] = useState<string | null>(null);

  // Active Shadow Detective room session
  const [shadowDetectiveRoomId, setShadowDetectiveRoomId] = useState<string | null>(null);
  const [shadowDetectivePlayerId, setShadowDetectivePlayerId] = useState<string | null>(null);

  // Settings with LocalStorage persistence
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('khelghor_settings');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      reactionSeconds: 15,
      soundEnabled: true,
      showEnglishSubs: true,
      gameSpeed: 'normal',
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem('khelghor_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
    sound.setEnabled(settings.soundEnabled);
  }, [settings]);

  const toggleSound = () => {
    const next = !settings.soundEnabled;
    sound.setEnabled(next);
    sound.playClick();
    setSettings((s) => ({ ...s, soundEnabled: next }));
  };

  const handleSelectGame = (
    gameId: 'calbaji' | 'borderpass' | 'shadowdetective' | 'handcricket'
  ) => {
    if (gameId === 'calbaji') {
      setCurrentView('calbaji_lobby');
    } else if (gameId === 'borderpass') {
      setCurrentView('borderpass_lobby');
    } else if (gameId === 'shadowdetective') {
      setCurrentView('shadowdetective_app');
    } else if (gameId === 'handcricket') {
      setCurrentView('handcricket_app');
    }
  };

  const handleStartSoloGame = (chosen: CharacterId[], newSettings: GameSettings) => {
    setSelectedCharacters(chosen);
    setSettings(newSettings);
    setCalbajiRoomId(null);
    setCalbajiPlayerId(null);
    setCurrentView('calbaji_game');
  };

  const handleRestartCalbaji = () => {
    sound.playClick();
    setCurrentView('calbaji_lobby');
  };

  const handleBackToKhelghor = () => {
    sound.playClick();
    setCurrentView('khelghor_home');
  };

  const handleCalbajiRoomReady = (roomId: string, playerId: string) => {
    setCalbajiRoomId(roomId);
    setCalbajiPlayerId(playerId);
    setCurrentView('calbaji_game');
  };

  const handleBorderPassRoomReady = (roomId: string, playerId: string) => {
    setBorderPassRoomId(roomId);
    setBorderPassPlayerId(playerId);
    setCurrentView('borderpass_game');
  };

  const handleShadowDetectiveRoomReady = (roomId: string, playerId: string) => {
    setShadowDetectiveRoomId(roomId);
    setShadowDetectivePlayerId(playerId);
    setCurrentView('shadowdetective_app');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-500 selection:text-black">
      {/* 1. Khelghor Main Game Library */}
      {currentView === 'khelghor_home' && (
        <KhelghorHome
          onSelectGame={handleSelectGame}
          onOpenRules={() => setIsCalbajiRulesOpen(true)}
          soundEnabled={settings.soundEnabled}
          onToggleSound={toggleSound}
        />
      )}

      {/* 2. Calbaji Views */}
      {currentView === 'calbaji_lobby' && (
        <CalbajiLobby
          onBackToPlatform={handleBackToKhelghor}
          onOpenRules={() => setIsCalbajiRulesOpen(true)}
          onStartSolo={() => setCurrentView('calbaji_solo_select')}
          onRoomReady={handleCalbajiRoomReady}
        />
      )}

      {currentView === 'calbaji_solo_select' && (
        <CharacterSelectScreen
          onStartGame={handleStartSoloGame}
          onOpenRules={() => setIsCalbajiRulesOpen(true)}
          onBackToPlatform={() => setCurrentView('calbaji_lobby')}
          initialSettings={settings}
        />
      )}

      {currentView === 'calbaji_game' && (
        <GameBoard
          selectedCharacters={selectedCharacters}
          settings={settings}
          roomId={calbajiRoomId || undefined}
          playerId={calbajiPlayerId || undefined}
          onOpenRules={() => setIsCalbajiRulesOpen(true)}
          onRestart={handleRestartCalbaji}
          onBackToPlatform={() => {
            setCalbajiRoomId(null);
            setCalbajiPlayerId(null);
            setCurrentView('calbaji_lobby');
          }}
        />
      )}

      {/* 3. Border Pass Views */}
      {currentView === 'borderpass_lobby' && (
        <BorderPassLobby
          onBackToPlatform={handleBackToKhelghor}
          onOpenRules={() => setIsBorderPassRulesOpen(true)}
          onRoomReady={handleBorderPassRoomReady}
        />
      )}

      {currentView === 'borderpass_game' && borderPassRoomId && borderPassPlayerId && (
        <BorderPassBoard
          roomId={borderPassRoomId}
          playerId={borderPassPlayerId}
          onOpenRules={() => setIsBorderPassRulesOpen(true)}
          onLeaveGame={() => setCurrentView('borderpass_lobby')}
        />
      )}

      {/* 4. Shadow Detective View */}
      {currentView === 'shadowdetective_app' && (
        <ShadowDetectiveApp
          onBackToKhelghor={handleBackToKhelghor}
          initialRoomId={shadowDetectiveRoomId}
          initialPlayerId={shadowDetectivePlayerId}
        />
      )}

      {/* 5. Hand Cricket View */}
      {currentView === 'handcricket_app' && (
        <HandCricketApp onBackToKhelghor={handleBackToKhelghor} />
      )}

      {/* Modals */}
      <RulesModal isOpen={isCalbajiRulesOpen} onClose={() => setIsCalbajiRulesOpen(false)} />
      <BorderPassRulesModal
        isOpen={isBorderPassRulesOpen}
        onClose={() => setIsBorderPassRulesOpen(false)}
      />
    </div>
  );
}
