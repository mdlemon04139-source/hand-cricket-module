// Type definitions for Border Pass (বর্ডার পাস)

export type CardCategory = 'duty_free' | 'contraband' | 'power';

export type DutyFreeCardId =
  | 'branded_watch'
  | 'duty_free_chocolates'
  | 'designer_perfume'
  | 'silk_apparel';

export type ContrabandCardId =
  | 'raw_diamonds'
  | 'historic_relic'
  | 'classified_drive'
  | 'gold_bullion';

export type PowerCardId =
  | 'diplomatic_immunity'
  | 'customs_clearance_seal';

export type CardTypeId = DutyFreeCardId | ContrabandCardId | PowerCardId;

export interface CardDefinition {
  id: CardTypeId;
  nameEn: string;
  nameBn: string;
  category: CardCategory;
  count: number;
  baseVaultValue: number;
  seizureFine: number;
  image: string;
  descriptionBn: string;
}

export interface CardInstance {
  instanceId: string;
  typeId: CardTypeId;
  appliedBonus?: boolean; // If +50% Customs Clearance Seal was applied
}

export type PlayerRole = 'officer' | 'passenger';

export type GamePhase =
  | 'LOBBY'
  | 'MATCH_INITIALIZING'
  | 'ROUND_START'
  | 'HAND_REPLENISHMENT'
  | 'PASSENGER_PACKING'
  | 'PACKING_LOCKED'
  | 'CUSTOMS_REVIEW'
  | 'NEGOTIATION_PENDING'
  | 'INSPECTION_REVEAL'
  | 'SETTLEMENT'
  | 'ROUND_END'
  | 'MATCH_END';

export interface SuitcaseDeclaration {
  declaredItem: DutyFreeCardId;
  declaredQuantity: number;
  bribeOffer: number;
}

export interface SuitcaseContent {
  cards: CardInstance[];
  declaration: SuitcaseDeclaration;
  submittedAt: number;
}

export interface VaultItem {
  instanceId: string;
  typeId: CardTypeId;
  baseValue: number;
  effectiveValue: number;
  sealBonusApplied: boolean;
  roundSecured: number;
}

export interface NegotiationState {
  id?: string;
  passengerId: string;
  officerId?: string;
  currentOfferBy: 'officer' | 'passenger';
  amount: number;
  demandedBribe?: number;
  currentOffer?: number;
  exchangeCount: number; // Max 3
  deadline: number;
  startedAt?: number;
  expiresAt?: number;
  isSettled?: boolean;
}

export interface InspectionResult {
  passengerId: string;
  passengerName: string;
  isHonest: boolean;
  cards: CardInstance[];
  declaration: SuitcaseDeclaration;
  hasDiplomaticImmunity: boolean;
  confiscatedCards: CardInstance[];
  passedCards: CardInstance[];
  compensationPaid: number;
  totalFineCalculated: number;
  finePaidFromCash: number;
  fineDeficitToVault: number;
  sealBonusApplied: boolean;
  summaryBn: string;
}

export interface SettlementEvent {
  id: string;
  round: number;
  passengerId: string;
  passengerName: string;
  officerId: string;
  officerName: string;
  action: 'pass_bribe_accepted' | 'pass_bribe_rejected' | 'inspected_honest' | 'inspected_contraband' | 'inspected_immunity' | 'negotiation_agreed';
  amountTransferred: number;
  finePaid: number;
  compensationPaid: number;
  contrabandConfiscatedCount: number;
  descriptionBn: string;
  timestamp: number;
}

export interface BorderPassPlayer {
  id: string;
  name: string;
  avatar: string;
  isBot: boolean;
  botDifficulty?: 'easy' | 'normal' | 'hard';
  isOnline?: boolean;
  seatNumber: number;
  cash: number; // Starts at $500
  vault: VaultItem[];
  vaultScoreAdjustment: number; // Running negative adjustment from fine deficits
  effectiveVaultValue: number;
  netWorth: number; // cash + effectiveVaultValue
  role: PlayerRole;
  officerTurnsCompleted: number; // Max 2
  isReady: boolean;
  hasPacked: boolean;
  handCount: number; // Public count
  // Statistics
  bribesPaid: number;
  bribesReceived: number;
  finesPaid: number;
  compensationReceived: number;
}

export interface BorderPassPlayerPrivate {
  hand: CardInstance[];
  suitcase?: SuitcaseContent;
}

export interface BorderPassRoomPublicState {
  roomId: string;
  hostId: string;
  phase: GamePhase;
  currentRound: number;
  totalRounds: number;
  currentOfficerId: string;
  currentReviewPassengerId?: string;
  players: BorderPassPlayer[];
  drawDeckCount: number;
  discardPileCount: number;
  discardPileTop?: CardTypeId;
  activeNegotiation?: NegotiationState;
  lastInspectionResult?: InspectionResult;
  recentSettlements: SettlementEvent[];
  phaseDeadline?: number;
  botThinkingMessage?: string;
  winner?: {
    playerId: string;
    playerName: string;
    netWorth: number;
    tieBreakReason?: string;
  };
}

export interface BorderPassClientState extends BorderPassRoomPublicState {
  myPlayerId: string;
  myRole?: PlayerRole;
  myHand: CardInstance[];
  mySuitcase?: SuitcaseContent;
  reviewPassengerSuitcaseDeclaration?: SuitcaseDeclaration; // Officer sees declaration, not cards
  botThinkingMessage?: string;
}
