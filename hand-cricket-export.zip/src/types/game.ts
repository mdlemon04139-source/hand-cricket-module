export type CharacterId =
  | 'nawab'
  | 'sodagor'
  | 'guptoghatok'
  | 'nishachor'
  | 'guptochor'
  | 'jyotishi'
  | 'dosyu_sordar'
  | 'sidhel_chor'
  | 'khajnadar';

export type ActionType =
  | 'income' // রাজস্ব (General: 1 coin from bank)
  | 'coup' // সুপ্রিম নিধন (General: 7 coins, unchallengeable assassinate)
  | 'nawab_tax' // নবাব (Take 3 coins from bank)
  | 'sodagor_trade' // সদাগর (Take 4 coins from bank)
  | 'assassinate' // গুপ্তঘাতক (Pay 3 coins to assassinate target)
  | 'nishachor_strike' // নিশাচর (Pay 5 coins to attack, target can bribe 2 coins)
  | 'guptochor_spy' // গুপ্তচর (Inspect 1 card from deck, optionally swap)
  | 'jyotishi_divine' // জ্যোতিষী (Inspect 2 cards from deck, exchange)
  | 'dosyu_steal' // দস্যু সর্দার (Steal 2 coins from 1 target)
  | 'sidhel_raid' // সিঁধেল চোর (Steal 1 coin from each other eligible player)
  | 'khajnadar_tax'; // খাজনাদার (Place tax token on a character)

export type BlockType =
  | 'block_steal_dosyu' // দস্যু সর্দার blocks steal
  | 'block_assassination'; // In some variants or custom rules

export interface CharacterDef {
  id: CharacterId;
  nameBn: string;
  nameEn: string;
  titleBn: string;
  themeColor: string; // Tailwind color or hex
  accentColor: string;
  badgeBg: string;
  image: string;
  coinCost: number;
  coinGain: number;
  actionType: ActionType;
  descriptionBn: string;
  descriptionEn: string;
  canBlock?: BlockType[];
  isTargeted: boolean;
}

export interface Card {
  uid: string; // unique instance id
  characterId: CharacterId;
  isRevealed: boolean;
}

export type AIPersonality = 'cautious' | 'aggressive' | 'strategic';

export interface Player {
  id: string; // 'p1' (human) or 'ai_1', 'ai_2', 'ai_3'
  nameBn: string;
  nameEn: string;
  isHuman: boolean;
  avatar: string;
  personality?: AIPersonality;
  isOnline?: boolean;
  coins: number;
  cards: Card[]; // secret or revealed cards
  isEliminated: boolean;
}

export type ReactionPhaseType =
  | 'none'
  | 'action_declared' // A character claim action was made. Anyone can challenge or block.
  | 'nishachor_bribe_prompt' // Target chooses to bribe (2 coins), challenge, or suffer loss
  | 'block_declared' // Someone claimed a block. The original actor (or others) can challenge the block.
  | 'challenge_revealing' // Someone challenged! Revealing cards.
  | 'card_inspect_guptochor' // Inspecting 1 card
  | 'card_inspect_jyotishi' // Inspecting 2 cards
  | 'discard_card_choice'; // Target lost a life and chooses which card to discard

export interface PendingAction {
  actorId: string;
  actionType: ActionType;
  claimedCharacter?: CharacterId;
  targetId?: string;
  taxPaidToActor?: string;
}

export interface PendingBlock {
  blockerId: string;
  claimedCharacter: CharacterId;
}

export interface PendingChallenge {
  challengerId: string;
  challengedPlayerId: string;
  claimedCharacter: CharacterId;
  isBlockChallenge: boolean; // whether challenging an action or a block
}

export interface GameLogEntry {
  id: string;
  timestamp: number;
  turnNumber: number;
  textBn: string;
  textEn: string;
  type: 'action' | 'challenge' | 'block' | 'elimination' | 'system' | 'exchange';
  actorId?: string;
  targetId?: string;
  cardImage?: string;
}

export interface GameSettings {
  reactionSeconds: number; // default 30s authoritative response window
  soundEnabled: boolean;
  musicVolume?: number;
  sfxVolume?: number;
  showEnglishSubs: boolean;
  gameSpeed: 'normal' | 'fast';
}

export interface GameStats {
  gamesPlayed: number;
  gamesWon: number;
  totalBluffsCaught: number;
  successfulBluffs: number;
}
