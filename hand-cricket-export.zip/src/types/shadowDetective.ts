// Types for Shadow Detective (ছায়া গোয়েন্দা)

export type ShadowDetectiveRole =
  | 'chief_investigator' // প্রধান গোয়েন্দা (1) - জানে কে খুনি এবং কী অস্ত্র/প্রমাণ, শুধু বোর্ডে ক্লু দিতে পারে
  | 'shadow_killer'      // ছায়া খুনি (1) - অপরাধ করেছে, ক্লু বিভ্রান্ত করতে চায়, ধরা পড়লে উইটনেস হান্ট পায়
  | 'syndicate_insider'  // সিন্ডিকেট অনুচর (1) - খুনিকে চেনে, খুনিকে আড়াল করতে চায়
  | 'eyewitness'         // প্রত্যক্ষদর্শী (1) - অপরাধ চক্রকে দেখেছে (খুনি ও অনুচর), নিজেকে গোপন রেখে ক্লু বোঝাতে চায়
  | 'detective_squad';   // গোয়েন্দা দল (1-2) - সাধারণ তদন্তকারী

export type ShadowCardType = 'lethal_tool' | 'crime_artifact' | 'special_power';

export interface ShadowCard {
  id: string;
  nameBn: string;
  nameEn: string;
  type: ShadowCardType;
  image: string;
  descriptionBn: string;
  attributeTag?: string; // e.g. "Mechanical", "Chemical", "Digital", "Sharp", "Blunt"
}

export type ForensicCategoryKey = 'location' | 'trauma' | 'evidence_state';

export interface ForensicTileOption {
  id: string;
  labelBn: string;
  labelEn: string;
  hintHint?: string;
}

export interface ForensicCategory {
  key: ForensicCategoryKey;
  titleBn: string;
  titleEn: string;
  icon: string;
  options: ForensicTileOption[];
}

export interface CrimeSolution {
  killerId: string;
  lethalToolId: string;
  crimeArtifactId: string;
}

export type ShadowDetectivePhase =
  | 'LOBBY'
  | 'ROLE_ASSIGNMENT'
  | 'CRIME_SETUP'          // Killer picks 1 weapon + 1 artifact secretly
  | 'FORENSIC_HINTS'       // Chief places 3 clue markers on Forensic Board
  | 'DISCUSSION'           // 3-minute discussion with chat wheel & free chat
  | 'CASE_SUBMISSION'      // Detective squad official accusation attempt
  | 'WITNESS_HUNT'         // 15-second guess by killer to assassinate the eyewitness
  | 'GAME_OVER';

export interface ShadowPlayerPublic {
  id: string;
  name: string;
  avatar: string;
  isHost: boolean;
  isBot: boolean;
  isOnline: boolean;
  seatNumber: number;
  isReady: boolean;
  cards: ShadowCard[]; // Publicly dealt 4 cards (2 weapons + 2 artifacts)
  powerCardsUsed?: string[];
  revealedRole?: ShadowDetectiveRole; // Only populated at GAME_OVER
}

export interface ShadowChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  textBn: string;
  textEn?: string;
  isWheel?: boolean;
  timestamp: number;
}

export interface ShadowDetectiveRoomState {
  roomId: string;
  roomCode: string;
  hostId: string;
  phase: ShadowDetectivePhase;
  players: (ShadowPlayerPublic & {
    role: ShadowDetectiveRole;
  })[];
  crimeSolution?: CrimeSolution;
  forensicBoardMarkers: Partial<Record<ForensicCategoryKey, string>>; // categoryKey -> optionId
  remainingSubmissionAttempts: number; // 3 max
  lastSubmissionResult?: {
    success: boolean;
    accusedPlayerId: string;
    suspectedToolId: string;
    suspectedArtifactId: string;
    timestamp: number;
  };
  witnessHuntTargetId?: string;
  witnessHuntDeadline?: number;
  discussionDeadline?: number;
  chatMessages: ShadowChatMessage[];
  winnerTeam?: 'detectives' | 'syndicate';
  winReasonBn?: string;
  createdAt: number;
  lastActive: number;
}

export interface ShadowDetectiveClientState {
  roomId: string;
  roomCode: string;
  hostId: string;
  phase: ShadowDetectivePhase;
  myPlayerId: string;
  myRole: ShadowDetectiveRole;
  myRoleKnowledge?: {
    isChief: boolean;
    solution?: {
      killerId: string;
      killerName: string;
      lethalTool: ShadowCard;
      crimeArtifact: ShadowCard;
    };
    knownKillerId?: string;       // Insider sees who the Killer is
    knownSyndicateIds?: string[];  // Eyewitness sees both Killer and Insider
  };
  players: ShadowPlayerPublic[];
  forensicBoardMarkers: Partial<Record<ForensicCategoryKey, string>>;
  remainingSubmissionAttempts: number;
  lastSubmissionResult?: {
    success: boolean;
    accusedPlayerId: string;
    suspectedToolId: string;
    suspectedArtifactId: string;
    timestamp: number;
  };
  witnessHuntDeadline?: number;
  discussionDeadline?: number;
  chatMessages: ShadowChatMessage[];
  winnerTeam?: 'detectives' | 'syndicate';
  winReasonBn?: string;
  crimeSolutionRevealed?: {
    killerId: string;
    killerName: string;
    lethalTool: ShadowCard;
    crimeArtifact: ShadowCard;
  };
}
