import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { borderPassRoomManager } from './src/server/borderpassRoomManager';
import { calbajiRoomManager } from './src/server/calbajiRoomManager';
import { shadowDetectiveRoomManager } from './src/server/shadowDetectiveRoomManager';
import { handCricketManager, CAREER_ACHIEVEMENTS } from './src/server/handCricketManager';
import { gameStatsManager } from './src/server/gameStatsManager';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  app.use(express.json());

  // --- BORDER PASS REST & REALTIME APIS ---

  // Create room
  app.post('/api/borderpass/rooms', (req, res) => {
    const { name, avatar } = req.body;
    const result = borderPassRoomManager.createRoom(name || 'হোস্ট', avatar || '🧳');
    res.json(result);
  });

  // Join room by ID or code
  app.post('/api/borderpass/rooms/:roomId/join', (req, res) => {
    const { roomId } = req.params;
    const { name, avatar } = req.body;
    const result = borderPassRoomManager.joinRoom(roomId, name || 'খেলোয়াড়', avatar || '🎒');
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Add bot to room
  app.post('/api/borderpass/rooms/:roomId/add-bot', (req, res) => {
    const { roomId } = req.params;
    const { difficulty } = req.body;
    const result = borderPassRoomManager.addBot(roomId, difficulty || 'normal');
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Remove player or bot
  app.post('/api/borderpass/rooms/:roomId/remove-player', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = borderPassRoomManager.removePlayer(roomId, playerId);
    res.json(result);
  });

  // Start match
  app.post('/api/borderpass/rooms/:roomId/start', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = borderPassRoomManager.startGame(roomId, requesterId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Fetch client state
  app.get('/api/borderpass/rooms/:roomId/state', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;
    if (!playerId) {
      return res.status(400).json({ error: 'playerId is required' });
    }
    const state = borderPassRoomManager.getClientState(roomId, playerId);
    if (!state) {
      return res.status(404).json({ error: 'Room or player not found' });
    }
    res.json(state);
  });

  // SSE Real-time State Events
  app.get('/api/borderpass/rooms/:roomId/events', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;

    if (!playerId) {
      return res.status(400).end();
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const unsubscribe = borderPassRoomManager.subscribe(roomId, playerId, (state) => {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    });

    req.on('close', () => {
      unsubscribe();
    });
  });

  // Submit Suitcase packing
  app.post('/api/borderpass/rooms/:roomId/pack', (req, res) => {
    const { roomId } = req.params;
    const { playerId, cardInstanceIds, declaration } = req.body;
    const result = borderPassRoomManager.packSuitcase(roomId, playerId, cardInstanceIds, declaration);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Customs Officer Action (Pass, Inspect, Negotiate)
  app.post('/api/borderpass/rooms/:roomId/officer-action', (req, res) => {
    const { roomId } = req.params;
    const { officerId, action, payload } = req.body;
    const result = borderPassRoomManager.officerAction(roomId, officerId, action, payload);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Passenger negotiation response
  app.post('/api/borderpass/rooms/:roomId/negotiation-response', (req, res) => {
    const { roomId } = req.params;
    const { passengerId, accepted } = req.body;
    const result = borderPassRoomManager.respondToNegotiation(roomId, passengerId, accepted);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Apply Customs Clearance Seal
  app.post('/api/borderpass/rooms/:roomId/apply-seal', (req, res) => {
    const { roomId } = req.params;
    const { playerId, sealInstanceId, vaultItemInstanceId } = req.body;
    const result = borderPassRoomManager.applySeal(roomId, playerId, sealInstanceId, vaultItemInstanceId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Restart match
  app.post('/api/borderpass/rooms/:roomId/restart', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = borderPassRoomManager.restartMatch(roomId, requesterId);
    res.json(result);
  });

  // --- CALBAJI MULTIPLAYER REST & REALTIME APIS ---

  // Create room
  app.post('/api/calbaji/rooms', (req, res) => {
    const { name, avatar, characters } = req.body;
    const result = calbajiRoomManager.createRoom(name || 'হোস্ট', avatar || '👑', characters);
    res.json(result);
  });

  // Join room by ID or code
  app.post('/api/calbaji/rooms/:roomId/join', (req, res) => {
    const { roomId } = req.params;
    const { name, avatar } = req.body;
    const result = calbajiRoomManager.joinRoom(roomId, name || 'খেলোয়াড়', avatar || '⚔️');
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Add bot to room
  app.post('/api/calbaji/rooms/:roomId/add-bot', (req, res) => {
    const { roomId } = req.params;
    const { personality } = req.body;
    const result = calbajiRoomManager.addBot(roomId, personality || 'strategic');
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Remove player or bot
  app.post('/api/calbaji/rooms/:roomId/remove-player', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = calbajiRoomManager.removePlayer(roomId, playerId);
    res.json(result);
  });

  // Toggle ready status
  app.post('/api/calbaji/rooms/:roomId/toggle-ready', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = calbajiRoomManager.toggleReady(roomId, playerId);
    res.json(result);
  });

  // Update selected characters
  app.post('/api/calbaji/rooms/:roomId/characters', (req, res) => {
    const { roomId } = req.params;
    const { hostId, characters } = req.body;
    const result = calbajiRoomManager.updateCharacters(roomId, hostId, characters);
    res.json(result);
  });

  // Start match
  app.post('/api/calbaji/rooms/:roomId/start', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = calbajiRoomManager.startGame(roomId, requesterId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Fetch client state
  app.get('/api/calbaji/rooms/:roomId/state', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;
    if (!playerId) {
      return res.status(400).json({ error: 'playerId is required' });
    }
    const state = calbajiRoomManager.getClientState(roomId, playerId);
    if (!state) {
      return res.status(404).json({ error: 'Room or player not found' });
    }
    res.json(state);
  });

  // SSE Real-time State Events
  app.get('/api/calbaji/rooms/:roomId/events', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;

    if (!playerId) {
      return res.status(400).end();
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const unsubscribe = calbajiRoomManager.subscribe(roomId, playerId, (state) => {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    });

    req.on('close', () => {
      unsubscribe();
    });
  });

  // Declare Action
  app.post('/api/calbaji/rooms/:roomId/action', (req, res) => {
    const { roomId } = req.params;
    const { actorId, actionType, claimedCharacter, targetId } = req.body;
    const result = calbajiRoomManager.declareAction(roomId, actorId, actionType, claimedCharacter, targetId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Respond to Reaction (challenge, block, skip)
  app.post('/api/calbaji/rooms/:roomId/react', (req, res) => {
    const { roomId } = req.params;
    const { responderId, response, claimedBlockCharacter } = req.body;
    const result = calbajiRoomManager.respondToReaction(roomId, responderId, response, claimedBlockCharacter);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Discard Card on life loss
  app.post('/api/calbaji/rooms/:roomId/discard', (req, res) => {
    const { roomId } = req.params;
    const { playerId, cardUid } = req.body;
    const result = calbajiRoomManager.discardCard(roomId, playerId, cardUid);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Restart Match
  app.post('/api/calbaji/rooms/:roomId/restart', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = calbajiRoomManager.restartMatch(roomId, requesterId);
    res.json(result);
  });

  // --- SHADOW DETECTIVE: NISHIPUR REST & REALTIME APIS ---

  // Create Room
  app.post('/api/shadowdetective/rooms', (req, res) => {
    const { name, avatar, mode, targetPlayerCount } = req.body;
    const result = shadowDetectiveRoomManager.createRoom(
      name || 'প্রধান গোয়েন্দা রবিন',
      avatar || '🕵️‍♂️',
      mode || 'human_ai_multiplayer',
      targetPlayerCount || 5
    );
    res.json(result);
  });

  // Join Room
  app.post('/api/shadowdetective/rooms/:roomId/join', (req, res) => {
    const { roomId } = req.params;
    const { name, avatar } = req.body;
    const result = shadowDetectiveRoomManager.joinRoom(roomId, name || 'গ্রামবাসী', avatar || '🔍');
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Add Bot
  app.post('/api/shadowdetective/rooms/:roomId/add-bot', (req, res) => {
    const { roomId } = req.params;
    const result = shadowDetectiveRoomManager.addBot(roomId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Remove Player or Disconnect
  app.post('/api/shadowdetective/rooms/:roomId/remove-player', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = shadowDetectiveRoomManager.removePlayer(roomId, playerId);
    res.json(result);
  });

  // Toggle Ready
  app.post('/api/shadowdetective/rooms/:roomId/toggle-ready', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = shadowDetectiveRoomManager.toggleReady(roomId, playerId);
    res.json(result);
  });

  // Update target player count (5, 7, 9)
  app.post('/api/shadowdetective/rooms/:roomId/target-count', (req, res) => {
    const { roomId } = req.params;
    const { hostId, count } = req.body;
    const result = shadowDetectiveRoomManager.updateTargetCount(roomId, hostId, count);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Start Game
  app.post('/api/shadowdetective/rooms/:roomId/start', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = shadowDetectiveRoomManager.startGame(roomId, requesterId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Advance from Story Intro
  app.post('/api/shadowdetective/rooms/:roomId/advance-story', (req, res) => {
    const { roomId } = req.params;
    const result = shadowDetectiveRoomManager.advanceFromStoryIntro(roomId);
    res.json(result);
  });

  // Advance from Role Briefing
  app.post('/api/shadowdetective/rooms/:roomId/advance-briefing', (req, res) => {
    const { roomId } = req.params;
    const result = shadowDetectiveRoomManager.advanceFromRoleBriefing(roomId);
    res.json(result);
  });

  // Interrogation: Ask Question
  app.post('/api/shadowdetective/rooms/:roomId/ask-question', (req, res) => {
    const { roomId } = req.params;
    const { requesterId, targetSuspectId, questionId } = req.body;
    const result = shadowDetectiveRoomManager.askQuestion(roomId, requesterId, targetSuspectId, questionId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Submit Interrogation Answer
  app.post('/api/shadowdetective/rooms/:roomId/submit-answer', (req, res) => {
    const { roomId } = req.params;
    const { characterId, answerText } = req.body;
    const result = shadowDetectiveRoomManager.submitAnswer(roomId, characterId, answerText);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Mandatory Release Suspect
  app.post('/api/shadowdetective/rooms/:roomId/release', (req, res) => {
    const { roomId } = req.params;
    const { requesterId, suspectId } = req.body;
    const result = shadowDetectiveRoomManager.releaseSuspect(roomId, requesterId, suspectId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Submit Final Verdict
  app.post('/api/shadowdetective/rooms/:roomId/final-verdict', (req, res) => {
    const { roomId } = req.params;
    const { requesterId, guiltySuspectId, innocentSuspectId } = req.body;
    const result = shadowDetectiveRoomManager.submitFinalVerdict(
      roomId,
      requesterId,
      guiltySuspectId,
      innocentSuspectId
    );
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Restart
  app.post('/api/shadowdetective/rooms/:roomId/restart', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = shadowDetectiveRoomManager.restartMatch(roomId, requesterId);
    res.json(result);
  });

  // Get Client State
  app.get('/api/shadowdetective/rooms/:roomId/state', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;
    if (!playerId) {
      return res.status(400).json({ error: 'playerId is required' });
    }
    const state = shadowDetectiveRoomManager.getClientState(roomId, playerId);
    if (!state) {
      return res.status(404).json({ error: 'Room or player not found' });
    }
    res.json(state);
  });

  // SSE Stream
  app.get('/api/shadowdetective/rooms/:roomId/events', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;
    if (!playerId) {
      return res.status(400).end();
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    // Mark online
    shadowDetectiveRoomManager.setPlayerOnline(roomId, playerId, true);

    // Immediately push initial state if available
    const initialClientState = shadowDetectiveRoomManager.getClientState(roomId, playerId);
    if (initialClientState) {
      res.write(`data: ${JSON.stringify(initialClientState)}\n\n`);
    }

    const unsubscribe = shadowDetectiveRoomManager.subscribe(roomId, playerId, (state) => {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    });

    req.on('close', () => {
      shadowDetectiveRoomManager.setPlayerOnline(roomId, playerId, false);
      unsubscribe();
    });
  });

  // Platform-wide Game Statistics (used by KhelghorHome)
  app.get('/api/stats', (_req, res) => {
    res.json(gameStatsManager.getAllStats());
  });

  // Fetch Game Statistics
  app.get('/api/shadowdetective/stats', (_req, res) => {
    res.json(gameStatsManager.getAllStats());
  });

  // Record Game Play (for Solo Story Mode or matches)
  app.post('/api/shadowdetective/stats/record-play', (req, res) => {
    const { playerId } = req.body;
    const stats = gameStatsManager.recordMatchStart('shadowdetective', `solo_${Date.now()}`, playerId || 'guest');
    res.json(stats);
  });

  // --- HAND CRICKET REST & REALTIME APIS ---

  // Get or initialize player Career profile & statistics
  app.get('/api/handcricket/career/:playerId', (req, res) => {
    const { playerId } = req.params;
    if (!playerId) {
      return res.status(400).json({ error: 'playerId is required' });
    }
    const career = handCricketManager.getOrCreateCareer(playerId);
    res.json({
      career,
      achievementsCatalog: CAREER_ACHIEVEMENTS,
      stats: gameStatsManager.getGameStats('handcricket'),
      liveActivePlayers: handCricketManager.getLiveActiveHumanPlayersCount(),
    });
  });

  // Update player Career identity (Name, Country, Jersey Number, Avatar)
  app.post('/api/handcricket/career/:playerId/profile', (req, res) => {
    const { playerId } = req.params;
    const { name, country, jerseyNumber, avatar } = req.body;
    const career = handCricketManager.updateCareerProfile(playerId, {
      name,
      country,
      jerseyNumber,
      avatar,
    });
    res.json({ success: true, career });
  });

  // Get Multiplayer Leaderboard (strictly verified real-player matches only)
  app.get('/api/handcricket/leaderboard', (req, res) => {
    const sortBy = (req.query.sortBy as 'wins' | 'runs' | 'winRate' | 'xp' | 'level') || 'wins';
    const leaderboard = handCricketManager.getMultiplayerLeaderboard(sortBy);
    res.json({ leaderboard });
  });

  // Create AI Match or Multiplayer Room
  app.post('/api/handcricket/rooms', (req, res) => {
    const {
      playerId,
      name,
      country,
      jerseyNumber,
      avatar,
      mode,
      format,
      overs,
      wicketsPerInnings,
      aiDifficulty,
    } = req.body;

    if (!playerId || typeof playerId !== 'string') {
      return res.status(400).json({ error: 'Valid persistent playerId is required' });
    }

    const result = handCricketManager.createMatchOrRoom({
      playerId,
      name,
      country,
      jerseyNumber,
      avatar,
      mode: mode || 'ai_single_player',
      format: format || 'limited_overs',
      overs,
      wicketsPerInnings,
      aiDifficulty,
    });
    res.json(result);
  });

  // Join or Reconnect to Multiplayer Room
  app.post('/api/handcricket/rooms/:roomId/join', (req, res) => {
    const { roomId } = req.params;
    const { playerId, name, country, jerseyNumber, avatar } = req.body;
    if (!playerId || typeof playerId !== 'string') {
      return res.status(400).json({ success: false, error: 'Valid playerId is required' });
    }
    const result = handCricketManager.joinRoom(roomId, {
      playerId,
      name,
      country,
      jerseyNumber,
      avatar,
    });
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Toggle Ready Status in Waiting Room
  app.post('/api/handcricket/rooms/:roomId/ready', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = handCricketManager.toggleReady(roomId, playerId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Update Lobby Match Configuration (Host only)
  app.post('/api/handcricket/rooms/:roomId/config', (req, res) => {
    const { roomId } = req.params;
    const { requesterId, format, overs, wicketsPerInnings } = req.body;
    const result = handCricketManager.updateLobbyConfig(roomId, requesterId, {
      format,
      overs,
      wicketsPerInnings,
    });
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Start Multiplayer Match from Waiting Room
  app.post('/api/handcricket/rooms/:roomId/start', (req, res) => {
    const { roomId } = req.params;
    const { requesterId } = req.body;
    const result = handCricketManager.startMultiplayerMatch(roomId, requesterId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Call Toss (HEADS / TAILS)
  app.post('/api/handcricket/rooms/:roomId/toss-call', (req, res) => {
    const { roomId } = req.params;
    const { playerId, call } = req.body;
    const result = handCricketManager.performTossCall(roomId, playerId, call);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Confirm Toss Decision (BAT_FIRST / BOWL_FIRST)
  app.post('/api/handcricket/rooms/:roomId/toss-decision', (req, res) => {
    const { roomId } = req.params;
    const { playerId, decision } = req.body;
    const result = handCricketManager.confirmTossDecision(roomId, playerId, decision);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Submit Ball Choice (1-6 or GestureVariationId)
  app.post('/api/handcricket/rooms/:roomId/ball', (req, res) => {
    const { roomId } = req.params;
    const { playerId, number, gestureId, ballId } = req.body;
    const result = handCricketManager.submitBallChoice(roomId, playerId, {
      number,
      gestureId,
      ballId,
    });
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Advance from Reveal or Innings Break
  app.post('/api/handcricket/rooms/:roomId/advance', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = handCricketManager.advanceAfterRevealOrBreak(roomId, playerId);
    res.json(result);
  });

  // Vote for Rematch
  app.post('/api/handcricket/rooms/:roomId/rematch', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = handCricketManager.voteRematch(roomId, playerId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // Leave Room
  app.post('/api/handcricket/rooms/:roomId/leave', (req, res) => {
    const { roomId } = req.params;
    const { playerId } = req.body;
    const result = handCricketManager.leaveRoom(roomId, playerId);
    res.json(result);
  });

  // Get Sanitized Client State
  app.get('/api/handcricket/rooms/:roomId/state', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;
    if (!playerId) {
      return res.status(400).json({ error: 'playerId is required' });
    }
    const state = handCricketManager.getClientState(roomId, playerId);
    if (!state) {
      return res.status(404).json({ error: 'Room not found' });
    }
    res.json(state);
  });

  // SSE Real-time Stream for Hand Cricket Room
  app.get('/api/handcricket/rooms/:roomId/events', (req, res) => {
    const { roomId } = req.params;
    const playerId = req.query.playerId as string;
    if (!playerId) {
      return res.status(400).end();
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    handCricketManager.setPlayerOnline(roomId, playerId, true);

    const initial = handCricketManager.getClientState(roomId, playerId);
    if (initial) {
      res.write(`data: ${JSON.stringify(initial)}\n\n`);
    }

    const unsubscribe = handCricketManager.subscribe(roomId, playerId, (state) => {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    });

    req.on('close', () => {
      handCricketManager.setPlayerOnline(roomId, playerId, false);
      unsubscribe();
    });
  });

  // --- VITE MIDDLEWARE OR STATIC SERVING ---
  const distPath = path.resolve(__dirname, 'dist');
  const indexHtmlPath = path.resolve(distPath, 'index.html');

  if (isProd && fs.existsSync(indexHtmlPath)) {
    console.log(`📦 Serving production build from ${distPath}`);
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(indexHtmlPath);
    });
  } else {
    console.log('⚡ Starting Vite dev middleware');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT) || 3000, '0.0.0.0', () => {
    console.log(`🚀 KhelGhor Server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup failed:', err);
});
